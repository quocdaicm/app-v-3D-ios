import SwiftUI

@main
struct Draw3DApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
