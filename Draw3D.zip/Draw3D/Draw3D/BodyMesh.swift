import SceneKit
import Vision
import CoreImage
import UIKit
import simd

/// Tách nhân vật khỏi nền (Vision, iOS 17+) rồi "thổi phồng" thành mô hình 3D.
enum BodyMesh {
    enum Failure: Error { case badImage, noForeground }

    struct Analysis: Codable {
        let gw: Int
        let gh: Int
        let aspect: Float
        let dist: [Float]   // khoảng cách tới biên, 0 = ngoài hình
    }

    /// Lưới ở dáng gốc (chưa skinning)
    struct Mesh {
        var pos: [SIMD3<Float>]
        var uv: [SIMD2<Float>]
        var idx: [Int32]
    }

    static func analyze(_ image: UIImage) throws -> Analysis {
        guard let cg = image.cgImage else { throw Failure.badImage }
        let handler = VNImageRequestHandler(cgImage: cg, options: [:])
        let req = VNGenerateForegroundInstanceMaskRequest()
        try handler.perform([req])
        guard let obs = req.results?.first, !obs.allInstances.isEmpty else { throw Failure.noForeground }
        let buf = try obs.generateScaledMaskForImage(forInstances: obs.allInstances, from: handler)

        let aspect = Float(cg.width) / Float(cg.height)
        let gh = 160
        let gw = max(16, min(240, Int(Float(gh) * aspect)))

        let ci = CIImage(cvPixelBuffer: buf)
        let ext = ci.extent
        let scaled = ci.transformed(by: CGAffineTransform(scaleX: CGFloat(gw) / ext.width,
                                                          y: CGFloat(gh) / ext.height))
        guard let mcg = CIContext().createCGImage(scaled, from: CGRect(x: 0, y: 0, width: gw, height: gh)) else {
            throw Failure.badImage
        }
        var bytes = [UInt8](repeating: 0, count: gw * gh * 4)
        let ok: Bool = bytes.withUnsafeMutableBytes { ptr in
            guard let ctx = CGContext(data: ptr.baseAddress, width: gw, height: gh, bitsPerComponent: 8,
                                      bytesPerRow: gw * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.draw(mcg, in: CGRect(x: 0, y: 0, width: gw, height: gh))
            return true
        }
        guard ok else { throw Failure.badImage }

        var raw = [Bool](repeating: false, count: gw * gh)
        for k in 0..<(gw * gh) { raw[k] = bytes[k * 4] > 127 }

        // Co vào 1 ô để không dính màu nền ở mép
        func at(_ i: Int, _ j: Int) -> Int { j * gw + i }
        var inside = [Bool](repeating: false, count: gw * gh)
        var hasInside = false
        for j in 1..<(gh - 1) {
            for i in 1..<(gw - 1) {
                if raw[at(i, j)] && raw[at(i - 1, j)] && raw[at(i + 1, j)] && raw[at(i, j - 1)] && raw[at(i, j + 1)] {
                    inside[at(i, j)] = true
                    hasInside = true
                }
            }
        }
        guard hasInside else { throw Failure.noForeground }

        // Khoảng cách tới biên (chamfer 2 lượt)
        let big: Float = 1e6
        var dist = [Float](repeating: 0, count: gw * gh)
        for k in 0..<(gw * gh) where inside[k] { dist[k] = big }
        for j in 0..<gh {
            for i in 0..<gw where inside[at(i, j)] {
                var d = dist[at(i, j)]
                if i > 0 { d = min(d, dist[at(i - 1, j)] + 1) }
                if j > 0 { d = min(d, dist[at(i, j - 1)] + 1) }
                if i > 0 && j > 0 { d = min(d, dist[at(i - 1, j - 1)] + 1.414) }
                if i < gw - 1 && j > 0 { d = min(d, dist[at(i + 1, j - 1)] + 1.414) }
                dist[at(i, j)] = d
            }
        }
        for j in stride(from: gh - 1, through: 0, by: -1) {
            for i in stride(from: gw - 1, through: 0, by: -1) where inside[at(i, j)] {
                var d = dist[at(i, j)]
                if i < gw - 1 { d = min(d, dist[at(i + 1, j)] + 1) }
                if j < gh - 1 { d = min(d, dist[at(i, j + 1)] + 1) }
                if i < gw - 1 && j < gh - 1 { d = min(d, dist[at(i + 1, j + 1)] + 1.414) }
                if i > 0 && j < gh - 1 { d = min(d, dist[at(i - 1, j + 1)] + 1.414) }
                dist[at(i, j)] = d
            }
        }
        return Analysis(gw: gw, gh: gh, aspect: aspect, dist: dist)
    }

    /// Mặt trước và mặt sau phồng lên theo khoảng cách tới biên, gặp nhau ở mép.
    static func build(_ an: Analysis, thickness: Float, planeHeight: Float = 4, centerY: Float = 0.15) -> Mesh {
        let gw = an.gw
        let gh = an.gh
        let planeW = planeHeight * an.aspect
        let dmax: Float = 14

        var vid = [Int32](repeating: -1, count: gw * gh)
        var pos: [SIMD3<Float>] = []
        var uv: [SIMD2<Float>] = []
        for j in 0..<gh {
            for i in 0..<gw {
                let k = j * gw + i
                let d = an.dist[k]
                guard d > 0.5 else { continue }
                let s = min(max((d - 1) / (dmax - 1), 0), 1)
                let z = thickness * (1 - (1 - s) * (1 - s)).squareRoot()
                let x = (Float(i) / Float(gw - 1) - 0.5) * planeW
                let y = (0.5 - Float(j) / Float(gh - 1)) * planeHeight + centerY
                vid[k] = Int32(pos.count)
                pos.append(SIMD3<Float>(x, y, z))
                uv.append(SIMD2<Float>(Float(i) / Float(gw - 1), Float(j) / Float(gh - 1)))
            }
        }
        let n = pos.count
        for k in 0..<n {
            var p = pos[k]
            p.z = -p.z
            pos.append(p)
            uv.append(uv[k])
        }

        var idx: [Int32] = []
        let o = Int32(n)
        for j in 0..<(gh - 1) {
            for i in 0..<(gw - 1) {
                let a0 = vid[j * gw + i]
                let b0 = vid[j * gw + i + 1]
                let c0 = vid[(j + 1) * gw + i]
                let d0 = vid[(j + 1) * gw + i + 1]
                guard a0 >= 0, b0 >= 0, c0 >= 0, d0 >= 0 else { continue }
                idx += [a0, c0, b0, b0, c0, d0]                          // mặt trước
                idx += [a0 + o, b0 + o, c0 + o, b0 + o, d0 + o, c0 + o]  // mặt sau (đảo chiều)
            }
        }

        return Mesh(pos: pos, uv: uv, idx: idx)
    }

    static func normals(pos: [SIMD3<Float>], idx: [Int32]) -> [SIMD3<Float>] {
        var nrm = [SIMD3<Float>](repeating: .zero, count: pos.count)
        var t = 0
        while t + 2 < idx.count {
            let i0 = Int(idx[t]), i1 = Int(idx[t + 1]), i2 = Int(idx[t + 2])
            let fn = simd_cross(pos[i1] - pos[i0], pos[i2] - pos[i0])
            nrm[i0] += fn
            nrm[i1] += fn
            nrm[i2] += fn
            t += 3
        }
        for k in nrm.indices {
            let l = simd_length(nrm[k])
            nrm[k] = l > 1e-8 ? nrm[k] / l : SIMD3<Float>(0, 0, 1)
        }
        return nrm
    }

    /// Tạo geometry từ lưới gốc, với vị trí đỉnh tuỳ ý (dùng khi skinning)
    static func geometry(_ m: Mesh, positions: [SIMD3<Float>]) -> SCNGeometry {
        let pos = positions
        let idx = m.idx
        let nrm = normals(pos: pos, idx: idx)

        let vs = SCNGeometrySource(vertices: pos.map { SCNVector3($0.x, $0.y, $0.z) })
        let ns = SCNGeometrySource(normals: nrm.map { SCNVector3($0.x, $0.y, $0.z) })
        let ts = SCNGeometrySource(textureCoordinates: m.uv.map { CGPoint(x: CGFloat($0.x), y: CGFloat($0.y)) })
        return SCNGeometry(sources: [vs, ns, ts],
                           elements: [SCNGeometryElement(indices: idx, primitiveType: .triangles)])
    }

    static func mesh(_ an: Analysis, thickness: Float, planeHeight: Float = 4, centerY: Float = 0.15) -> SCNGeometry {
        let m = build(an, thickness: thickness, planeHeight: planeHeight, centerY: centerY)
        return geometry(m, positions: m.pos)
    }
}
