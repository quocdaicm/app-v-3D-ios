import SwiftUI
import PhotosUI

struct ShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

struct ContentView: View {
    @StateObject private var c = Controller()
    @State private var pickerItem: PhotosPickerItem?
    @State private var collapsed = false
    @State private var showSaves = false
    @State private var showAI = false

    var body: some View {
        ZStack(alignment: .bottom) {
            SceneContainer(controller: c)
                .ignoresSafeArea()

            if let msg = c.message {
                Text(msg)
                    .font(.footnote)
                    .padding(.horizontal, 14).padding(.vertical, 8)
                    .background(.ultraThinMaterial, in: Capsule())
                    .frame(maxHeight: .infinity, alignment: .top)
                    .padding(.top, 60)
                    .transition(.opacity)
            }

            VStack(spacing: 12) {
                HStack {
                    Picker("Chế độ", selection: $c.mode) {
                        Text("✏️ Vẽ").tag(Mode.draw)
                        Text("🔄 Xoay").tag(Mode.orbit)
                        Text("🦴 Xương").tag(Mode.bones)
                    }
                    .pickerStyle(.segmented)

                    Button {
                        withAnimation { collapsed.toggle() }
                    } label: {
                        Image(systemName: collapsed ? "chevron.up.circle" : "chevron.down.circle")
                            .font(.title3)
                    }
                }

                if !collapsed {
                VStack(spacing: 12) {

                HStack {
                    ColorPicker("Màu", selection: $c.color).labelsHidden()
                    Text("Nét").font(.caption)
                    Slider(value: $c.radius, in: 0.01...0.2)
                }

                HStack {
                    Text("Xa").font(.caption)
                    Slider(value: $c.depth, in: 2...12)
                }

                HStack(spacing: 10) {
                    PhotosPicker(selection: $pickerItem, matching: .images) {
                        Label("Ảnh mẫu", systemImage: "photo.on.rectangle")
                    }
                    if c.hasRef {
                        Image(systemName: "circle.lefthalf.filled").font(.caption)
                        Slider(value: $c.refOpacity, in: 0.1...1)
                        Image(systemName: "arrow.up.left.and.arrow.down.right").font(.caption)
                        Slider(value: $c.refScale, in: 0.5...2.5)
                        Button(role: .destructive) { c.removeReference() } label: {
                            Image(systemName: "xmark.circle")
                        }
                    }
                }

                if c.hasBody {
                    HStack {
                        Text("Dày").font(.caption)
                        Slider(value: $c.bodyThickness, in: 0.05...0.9)
                    }
                }

                HStack {
                    Button { c.undo() } label: {
                        Image(systemName: "arrow.uturn.backward")
                    }
                    .disabled(c.strokeCount == 0)

                    Spacer()

                    Menu {
                        Button { showSaves = true } label: { Label("Lưu / Mở bản vẽ…", systemImage: "folder") }
                        Button { c.exportUSDZ() } label: { Label("Xuất USDZ (chỉ nét vẽ)", systemImage: "cube") }
                        Button { c.exportUSDZ(includeSkeleton: true) } label: { Label("Xuất USDZ (nét vẽ + xương)", systemImage: "figure.stand") }
                        Button { c.exportGLB() } label: { Label("Xuất GLB (Blender, có xương)", systemImage: "cube.transparent") }
                        Button { c.exportPNG() } label: { Label("Xuất ảnh PNG", systemImage: "photo") }
                        Toggle("PNG: ẩn ảnh mẫu", isOn: $c.pngHideRef)
                        Toggle("PNG: ẩn xương", isOn: $c.pngHideSkeleton)
                        Toggle("PNG: ẩn lưới", isOn: $c.pngHideGrid)
                    } label: {
                        Label("Tệp", systemImage: "doc")
                    }

                    Spacer()

                    Menu {
                        Button { c.mode = .bones } label: { Label("Chỉnh dáng xương", systemImage: "figure.stand") }
                        Button { c.toggleSkeleton() } label: { Label("Ẩn/hiện xương", systemImage: "eye") }
                        Button { c.bindToSkeleton() } label: { Label("Gắn nét vẽ vào xương (rig)", systemImage: "link") }
                        Button { c.unbind() } label: { Label("Tháo nét vẽ khỏi xương", systemImage: "link.badge.plus") }
                            .disabled(!c.isBound)
                        Button { c.resetSkeleton() } label: { Label("Đặt lại dáng", systemImage: "arrow.counterclockwise") }
                    } label: {
                        Label("Xương", systemImage: "figure.stand")
                    }

                    Spacer()

                    Menu {
                        Button { c.makeBody() } label: { Label("Tạo mô hình 3D từ ảnh mẫu", systemImage: "wand.and.stars") }
                            .disabled(!c.hasRef)
                        Button { c.bindBody() } label: { Label("Gắn mô hình vào xương", systemImage: "link") }
                            .disabled(!c.hasBody || c.isBodyBound)
                        Button { c.unbindBody() } label: { Label("Tháo mô hình khỏi xương", systemImage: "link.badge.plus") }
                            .disabled(!c.isBodyBound)
                        Button { c.flipBodyTexture() } label: { Label("Lật ảnh (nếu bị ngược)", systemImage: "arrow.up.arrow.down") }
                            .disabled(!c.hasBody)
                        Button { showAI = true } label: { Label("Tạo 3D thật từ ảnh (Meshy)…", systemImage: "sparkles") }
                        Button(role: .destructive) { c.removeBody() } label: { Label("Xoá mô hình", systemImage: "trash") }
                            .disabled(!c.hasBody)
                    } label: {
                        Label("3D", systemImage: "cube")
                    }

                    Spacer()

                    Button(role: .destructive) { c.clear() } label: {
                        Image(systemName: "trash")
                    }
                    .disabled(c.strokeCount == 0)
                }
                }
                }
            }
            .padding()
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
            .padding()
        }
        .animation(.default, value: c.message)
        .onChange(of: pickerItem) { _, item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self),
                   let img = UIImage(data: data) {
                    await MainActor.run { c.setReference(img) }
                }
                await MainActor.run { pickerItem = nil }
            }
        }
        .sheet(item: $c.shareFile) { f in
            ShareSheet(url: f.url)
        }
        .sheet(isPresented: $showSaves) {
            SaveListView(c: c, isPresented: $showSaves)
        }
        .sheet(isPresented: $showAI) {
            AIModelView(c: c, isPresented: $showAI)
        }
    }
}
