import SceneKit
import simd

/// Mỗi nét vẽ là 1 geometry dạng ống (thay cho hàng trăm node sphere + cylinder).
enum StrokeMesh {
    struct Built {
        var pos: [SIMD3<Float>]
        var nrm: [SIMD3<Float>]
        var idx: [Int32]
        var owner: [Int]   // chỉ số điểm gốc của từng đỉnh (chỉ có khi withOwner = true)
    }

    static func build(points input: [SIMD3<Float>], radius: Float, sides: Int = 8,
                      withOwner: Bool = false) -> Built? {
        guard !input.isEmpty else { return nil }
        var pts = input
        if pts.count == 1 {
            let p = pts[0]
            pts = [p - SIMD3<Float>(0, 0, radius), p + SIMD3<Float>(0, 0, radius)]
        }
        let n = pts.count
        let lastPoint = input.count - 1

        // Tiếp tuyến tại mỗi điểm
        var tg = [SIMD3<Float>](repeating: SIMD3<Float>(0, 0, 1), count: n)
        for i in 0..<n {
            let d = pts[min(i + 1, n - 1)] - pts[max(i - 1, 0)]
            let l = simd_length(d)
            if l > 1e-7 {
                tg[i] = d / l
            } else if i > 0 {
                tg[i] = tg[i - 1]
            }
        }

        // Khung dọc theo nét (parallel transport) để ống không bị xoắn
        var nor = [SIMD3<Float>](repeating: SIMD3<Float>(1, 0, 0), count: n)
        let ref0 = abs(tg[0].y) < 0.9 ? SIMD3<Float>(0, 1, 0) : SIMD3<Float>(1, 0, 0)
        nor[0] = simd_normalize(simd_cross(tg[0], ref0))
        for i in 1..<n {
            var v = nor[i - 1] - tg[i] * simd_dot(nor[i - 1], tg[i])
            if simd_length(v) < 1e-5 {
                let r = abs(tg[i].y) < 0.9 ? SIMD3<Float>(0, 1, 0) : SIMD3<Float>(1, 0, 0)
                v = simd_cross(tg[i], r)
            }
            nor[i] = simd_normalize(v)
        }

        var pos: [SIMD3<Float>] = []
        var nrm: [SIMD3<Float>] = []
        var owner: [Int] = []
        pos.reserveCapacity(n * sides + 2)
        nrm.reserveCapacity(n * sides + 2)
        if withOwner { owner.reserveCapacity(n * sides + 2) }
        for i in 0..<n {
            let bi = simd_cross(tg[i], nor[i])
            for s in 0..<sides {
                let th = Float(s) / Float(sides) * 2 * Float.pi
                let dir = nor[i] * cos(th) + bi * sin(th)
                pos.append(pts[i] + dir * radius)
                nrm.append(dir)
                if withOwner { owner.append(min(i, lastPoint)) }
            }
        }
        // Mũi tròn hai đầu
        let c0 = Int32(pos.count)
        pos.append(pts[0] - tg[0] * radius)
        nrm.append(-tg[0])
        let c1 = Int32(pos.count)
        pos.append(pts[n - 1] + tg[n - 1] * radius)
        nrm.append(tg[n - 1])
        if withOwner {
            owner.append(0)
            owner.append(lastPoint)
        }

        var idx: [Int32] = []
        idx.reserveCapacity((n - 1) * sides * 6 + sides * 6)
        let sd = Int32(sides)
        for i in 0..<(n - 1) {
            let r0 = Int32(i) * sd
            let r1 = r0 + sd
            for s in 0..<sides {
                let s0 = Int32(s)
                let s1 = Int32((s + 1) % sides)
                let a = r0 + s0
                let b = r0 + s1
                let c = r1 + s0
                let d = r1 + s1
                idx += [a, c, b, b, c, d]
            }
        }
        let lastRing = Int32(n - 1) * sd
        for s in 0..<sides {
            let s0 = Int32(s)
            let s1 = Int32((s + 1) % sides)
            idx += [c0, s1, s0]
            idx += [c1, lastRing + s0, lastRing + s1]
        }
        return Built(pos: pos, nrm: nrm, idx: idx, owner: owner)
    }

    static func geometry(points: [SIMD3<Float>], radius: Float,
                         material: SCNMaterial, sides: Int = 8) -> SCNGeometry? {
        guard let b = build(points: points, radius: radius, sides: sides) else { return nil }
        let vs = SCNGeometrySource(vertices: b.pos.map { SCNVector3($0.x, $0.y, $0.z) })
        let ns = SCNGeometrySource(normals: b.nrm.map { SCNVector3($0.x, $0.y, $0.z) })
        let g = SCNGeometry(sources: [vs, ns],
                            elements: [SCNGeometryElement(indices: b.idx, primitiveType: .triangles)])
        g.materials = [material]
        return g
    }
}
