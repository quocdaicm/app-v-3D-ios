import SceneKit
import SwiftUI
import simd

enum Mode: Hashable { case draw, orbit, bones }

struct SaveFile: Codable {
    var strokes: [StrokeData]
    var pose: [[Float]]?
    var bindPose: [[Float]]?
    var boneOf: [[Int]]?
    var bone2Of: [[Int]]?
    var weights: [[Float]]?
    // Ảnh mẫu
    var refPNG: Data?
    var refVisible: Bool?
    var refScale: Double?
    var refOpacity: Double?
    // Mô hình body
    var bodyAnalysis: BodyMesh.Analysis?
    var bodyThickness: Double?
    var bodyFlipV: Bool?
    var bodyBind: [[Float]]?
    var bodyB1: [Int]?
    var bodyB2: [Int]?
    var bodyW: [Float]?
}

struct StrokeData: Codable {
    var color: [Double]      // r, g, b, a
    var radius: Double
    var points: [[Float]]    // [x, y, z]
}

struct ShareFile: Identifiable {
    let url: URL
    var id: URL { url }
}

final class Controller: ObservableObject {
    let scene = SCNScene()
    let cameraNode = SCNNode()
    weak var view: SCNView?
    private let strokesRoot = SCNNode()
    let skeleton = Skeleton()
    private let refNode = SCNNode()
    private var gridNode: SCNNode?
    private let modelNode = SCNNode()
    private var aiTask: Task<Void, Never>?
    private let bodyNode = SCNNode()
    private var refImage: UIImage?
    private var analysis: BodyMesh.Analysis?
    private var flipV = false
    private var bodyBase: BodyMesh.Mesh?
    private var bodyMat: SCNMaterial?
    private var bodyBind: [SIMD3<Float>]?
    private var bodyB1: [Int] = []
    private var bodyB2: [Int] = []
    private var bodyW: [Float] = []
    private var lastBodyUpdate: TimeInterval = 0

    @Published var color: Color = .red
    @Published var radius: Double = 0.05
    @Published var depth: Double = 6
    @Published var mode: Mode = .draw {
        didSet { if mode == .bones { skeleton.root.isHidden = false } }
    }
    @Published var strokeCount = 0
    @Published var message: String?
    @Published var shareFile: ShareFile?

    private var strokes: [StrokeData] = []
    private var bindPose: [SIMD3<Float>]?
    private var boneOf: [[Int]] = []
    private var bone2Of: [[Int]] = []
    private var wOf: [[Float]] = []
    @Published var isBound = false
    @Published var hasRef = false
    @Published var hasBody = false
    @Published var hasModel = false
    @Published var aiBusy = false
    @Published var aiStatus = ""
    @Published var saveNames: [String] = []
    @Published var currentName = ""
    @Published var pngHideRef = true
    @Published var pngHideSkeleton = true
    @Published var pngHideGrid = false
    @Published var isBodyBound = false
    @Published var bodyThickness: Double = 0.4 {
        didSet { rebuildBody() }
    }
    @Published var refOpacity: Double = 0.5 {
        didSet { refNode.opacity = CGFloat(refOpacity) }
    }
    @Published var refScale: Double = 1 {
        didSet { refNode.simdScale = SIMD3<Float>(repeating: Float(refScale)) }
    }
    private var current: SCNNode?
    private var material = SCNMaterial()
    private var last: SIMD3<Float>?
    private var currentPts: [SIMD3<Float>] = []
    private var lastRigUpdate: TimeInterval = 0

    init() {
        scene.background.contents = UIColor(white: 0.08, alpha: 1)
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(0, 0, 6)
        scene.rootNode.addChildNode(cameraNode)
        scene.rootNode.addChildNode(strokesRoot)
        let grid = makeGrid()
        gridNode = grid
        scene.rootNode.addChildNode(grid)
        skeleton.root.isHidden = true
        scene.rootNode.addChildNode(skeleton.root)
        refNode.position = SCNVector3(0, 0.15, -0.3)   // nằm sau mặt phẳng vẽ mặc định
        refNode.renderingOrder = -10
        refNode.opacity = 0.5
        refNode.isHidden = true
        scene.rootNode.addChildNode(refNode)
        scene.rootNode.addChildNode(bodyNode)
        scene.rootNode.addChildNode(modelNode)
    }

    private func makeGrid() -> SCNNode {
        let size: CGFloat = 512
        let img = UIGraphicsImageRenderer(size: CGSize(width: size, height: size)).image { ctx in
            UIColor(white: 0.12, alpha: 1).setFill()
            ctx.fill(CGRect(x: 0, y: 0, width: size, height: size))
            UIColor(white: 0.32, alpha: 1).setStroke()
            let path = UIBezierPath()
            for i in 0...10 {
                let p = CGFloat(i) * size / 10
                path.move(to: CGPoint(x: p, y: 0))
                path.addLine(to: CGPoint(x: p, y: size))
                path.move(to: CGPoint(x: 0, y: p))
                path.addLine(to: CGPoint(x: size, y: p))
            }
            path.lineWidth = 2
            path.stroke()
        }
        let plane = SCNPlane(width: 10, height: 10)
        plane.firstMaterial?.diffuse.contents = img
        plane.firstMaterial?.lightingModel = .constant
        plane.firstMaterial?.isDoubleSided = true
        let node = SCNNode(geometry: plane)
        node.eulerAngles.x = -.pi / 2
        node.position = SCNVector3(0, -2, 0)
        return node
    }

    // MARK: - Vẽ

    private func worldPoint(_ p: CGPoint, in v: SCNView) -> SIMD3<Float> {
        let a = v.unprojectPoint(SCNVector3(Float(p.x), Float(p.y), 0))
        let b = v.unprojectPoint(SCNVector3(Float(p.x), Float(p.y), 1))
        let o = SIMD3<Float>(a.x, a.y, a.z)
        let d = simd_normalize(SIMD3<Float>(b.x, b.y, b.z) - o)
        let cam = (v.pointOfView ?? cameraNode).simdWorldPosition
        return cam + d * Float(depth)
    }

    private func makeMaterial(_ rgba: [Double]) -> SCNMaterial {
        let m = SCNMaterial()
        m.diffuse.contents = UIColor(red: rgba[0], green: rgba[1], blue: rgba[2], alpha: rgba[3])
        m.specular.contents = UIColor.white
        m.isDoubleSided = true
        return m
    }

    func begin(at p: CGPoint, in v: SCNView) {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        UIColor(color).getRed(&r, green: &g, blue: &b, alpha: &a)
        let rgba = [Double(r), Double(g), Double(b), Double(a)]
        let pos = worldPoint(p, in: v)
        strokes.append(StrokeData(color: rgba, radius: radius, points: [[pos.x, pos.y, pos.z]]))
        if bindPose != nil { boneOf.append([]); bone2Of.append([]); wOf.append([]) }
        material = makeMaterial(rgba)
        let node = SCNNode()
        strokesRoot.addChildNode(node)
        current = node
        currentPts = [pos]
        node.geometry = StrokeMesh.geometry(points: currentPts, radius: Float(radius), material: material)
        last = pos
        strokeCount = strokes.count
    }

    func move(to p: CGPoint, in v: SCNView) {
        guard let node = current, let prev = last, !strokes.isEmpty else { return }
        let pos = worldPoint(p, in: v)
        let r = Float(strokes[strokes.count - 1].radius)
        if simd_distance(pos, prev) < r * 0.8 { return }
        currentPts.append(pos)
        node.geometry = StrokeMesh.geometry(points: currentPts, radius: r, material: material)
        strokes[strokes.count - 1].points.append([pos.x, pos.y, pos.z])
        last = pos
    }

    func end() {
        current = nil
        last = nil
        currentPts = []
    }

    // MARK: - Rig: nét vẽ đi theo xương

    private func boneRotations(_ bp: [SIMD3<Float>]) -> [simd_quatf?] {
        var out = [simd_quatf?](repeating: nil, count: bp.count)
        for i in bp.indices {
            guard let p = skeleton.parents[i] else { continue }
            let a = bp[i] - bp[p]
            let b = skeleton.pos[i] - skeleton.pos[p]
            guard simd_length(a) > 1e-5, simd_length(b) > 1e-5 else { continue }
            out[i] = simd_quatf(from: simd_normalize(a), to: simd_normalize(b))
        }
        return out
    }

    private func riggedPoints(_ si: Int, _ bp: [SIMD3<Float>], _ rots: [simd_quatf?]) -> [SIMD3<Float>]? {
        let n = strokes[si].points.count
        guard si < boneOf.count, si < bone2Of.count, si < wOf.count,
              boneOf[si].count == n, bone2Of[si].count == n, wOf[si].count == n else { return nil }
        func skin(_ P: SIMD3<Float>, _ b: Int) -> SIMD3<Float> {
            guard let p = skeleton.parents[b], let q = rots[b] else { return P }
            return skeleton.pos[p] + q.act(P - bp[p])
        }
        var out: [SIMD3<Float>] = []
        out.reserveCapacity(n)
        for (k, pt) in strokes[si].points.enumerated() {
            let P = SIMD3<Float>(pt[0], pt[1], pt[2])
            let w = wOf[si][k]
            let a = skin(P, boneOf[si][k])
            out.append(w >= 0.999 ? a : a * w + skin(P, bone2Of[si][k]) * (1 - w))
        }
        return out
    }

    /// Cập nhật các nét vẽ đã gắn theo dáng xương hiện tại (throttled: giới hạn ~25 lần/giây khi kéo)
    func applyRig(throttled: Bool = false) {
        guard let bp = bindPose else { return }
        let now = ProcessInfo.processInfo.systemUptime
        if throttled && now - lastRigUpdate < 0.04 { return }
        lastRigUpdate = now
        let rots = boneRotations(bp)
        for si in strokes.indices where si < strokesRoot.childNodes.count {
            guard let np = riggedPoints(si, bp, rots) else { continue }
            let node = strokesRoot.childNodes[si]
            let mat = node.geometry?.firstMaterial ?? makeMaterial(strokes[si].color)
            node.geometry = StrokeMesh.geometry(points: np, radius: Float(strokes[si].radius), material: mat)
        }
    }

    // Chốt vị trí hiện tại của các nét đã gắn vào dữ liệu
    private func bake() {
        guard let bp = bindPose else { return }
        let rots = boneRotations(bp)
        for si in strokes.indices {
            if let np = riggedPoints(si, bp, rots) {
                strokes[si].points = np.map { [$0.x, $0.y, $0.z] }
            }
        }
    }

    /// Hai xương gần nhất và trọng số của xương thứ nhất (xương thứ hai = 1 - w)
    private func nearestTwo(_ P: SIMD3<Float>, _ bp: [SIMD3<Float>]) -> (Int, Int, Float) {
        var ds: [(Int, Float)] = []
        for i in bp.indices {
            guard let p = skeleton.parents[i] else { continue }
            let a = bp[p]
            let ab = bp[i] - a
            let denom = simd_dot(ab, ab)
            let t = denom > 1e-8 ? min(max(simd_dot(P - a, ab) / denom, 0), 1) : 0
            ds.append((i, simd_distance(P, a + ab * t)))
        }
        ds.sort { $0.1 < $1.1 }
        let (b1, d1) = ds[0]
        let (b2, d2) = ds.count > 1 ? ds[1] : ds[0]
        if d2 > d1 * 2.5 + 0.05 { return (b1, b2, 1) }   // xương thứ hai quá xa: bám cứng
        let e1 = (d1 + 0.02) * (d1 + 0.02)
        let e2 = (d2 + 0.02) * (d2 + 0.02)
        return (b1, b2, e2 / (e1 + e2))
    }

    /// Gắn mọi nét vẽ vào 2 xương gần nhất (có trọng số), lấy dáng xương hiện tại làm dáng gốc
    func bindToSkeleton() {
        guard !strokes.isEmpty else { toast("Chưa có nét vẽ nào để gắn"); return }
        bake()
        let bp = skeleton.pos
        var b1: [[Int]] = []
        var b2: [[Int]] = []
        var ws: [[Float]] = []
        for st in strokes {
            var r1: [Int] = []
            var r2: [Int] = []
            var rw: [Float] = []
            for pt in st.points {
                let (x, y, w) = nearestTwo(SIMD3<Float>(pt[0], pt[1], pt[2]), bp)
                r1.append(x)
                r2.append(y)
                rw.append(w)
            }
            b1.append(r1)
            b2.append(r2)
            ws.append(rw)
        }
        boneOf = b1
        bone2Of = b2
        wOf = ws
        bindPose = bp
        isBound = true
        toast("Đã gắn \(strokes.count) nét vào xương. Sang chế độ Xương để kéo thử")
    }

    func unbind() {
        guard bindPose != nil else { return }
        bake()
        bindPose = nil
        boneOf = []
        bone2Of = []
        wOf = []
        isBound = false
        toast("Đã tháo nét vẽ khỏi xương")
    }

    // MARK: - Ảnh mẫu (vẽ đè)

    func setReference(_ image: UIImage) {
        let maxSide: CGFloat = 1024
        let k = min(1, maxSide / max(image.size.width, image.size.height))
        let size = CGSize(width: image.size.width * k, height: image.size.height * k)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        let resized = UIGraphicsImageRenderer(size: size, format: fmt).image { _ in
            image.draw(in: CGRect(origin: .zero, size: size))
        }
        refImage = resized
        let h: CGFloat = 4
        let plane = SCNPlane(width: h * size.width / size.height, height: h)
        let m = SCNMaterial()
        m.diffuse.contents = resized
        m.lightingModel = .constant
        m.isDoubleSided = true
        m.writesToDepthBuffer = false   // nét vẽ luôn nằm trên ảnh
        plane.materials = [m]
        refNode.geometry = plane
        refNode.isHidden = false
        hasRef = true
        toast("Đã đặt ảnh mẫu phía sau. Vẽ đè lên ảnh")
    }

    func removeReference() {
        refNode.geometry = nil
        refNode.isHidden = true
        hasRef = false
    }

    // MARK: - Mô hình 3D từ ảnh

    /// Tách nhân vật khỏi nền rồi tạo mô hình 3D phồng
    func makeBody() {
        guard let img = refImage else { toast("Hãy chọn Ảnh mẫu trước"); return }
        toast("Đang tách nhân vật…")
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                let a = try BodyMesh.analyze(img)
                DispatchQueue.main.async {
                    guard let self else { return }
                    self.analysis = a
                    self.resetBodyBind()
                    self.hasBody = true
                    self.rebuildBody()
                    self.refNode.isHidden = true
                    self.toast("Đã tạo mô hình 3D. Xoay camera để xem, kéo thanh Dày để chỉnh")
                }
            } catch {
                DispatchQueue.main.async {
                    self?.toast("Không tách được nhân vật. Thử ảnh có nền đơn giản hơn (cần iOS 17+)")
                }
            }
        }
    }

    private func rebuildBody() {
        guard let a = analysis, let img = refImage else { return }
        let base = BodyMesh.build(a, thickness: Float(bodyThickness))
        bodyBase = base
        let m = SCNMaterial()
        m.diffuse.contents = img
        m.isDoubleSided = true
        if flipV {
            m.diffuse.contentsTransform = SCNMatrix4Mult(SCNMatrix4MakeScale(1, -1, 1),
                                                         SCNMatrix4MakeTranslation(0, 1, 0))
        }
        bodyMat = m
        if bodyBind != nil, bodyB1.count == base.pos.count {
            applyBodyRig(force: true)
        } else {
            let g = BodyMesh.geometry(base, positions: base.pos)
            g.materials = [m]
            bodyNode.geometry = g
        }
    }

    // MARK: - Rig cho mô hình body

    private func skinPoint(_ P: SIMD3<Float>, _ b: Int, _ rots: [simd_quatf?], _ bp: [SIMD3<Float>]) -> SIMD3<Float> {
        guard let p = skeleton.parents[b], let q = rots[b] else { return P }
        return skeleton.pos[p] + q.act(P - bp[p])
    }

    /// Gắn mọi đỉnh của mô hình vào 2 xương gần nhất, lấy dáng xương hiện tại làm dáng gốc
    func bindBody() {
        guard let base = bodyBase else { toast("Chưa có mô hình để gắn"); return }
        let bp = skeleton.pos
        var b1: [Int] = []
        var b2: [Int] = []
        var ws: [Float] = []
        b1.reserveCapacity(base.pos.count)
        b2.reserveCapacity(base.pos.count)
        ws.reserveCapacity(base.pos.count)
        for P in base.pos {
            let (x, y, w) = nearestTwo(P, bp)
            b1.append(x)
            b2.append(y)
            ws.append(w)
        }
        bodyBind = bp
        bodyB1 = b1
        bodyB2 = b2
        bodyW = ws
        isBodyBound = true
        toast("Đã gắn mô hình vào xương. Sang chế độ Xương để kéo thử")
    }

    func unbindBody() {
        guard bodyBind != nil else { return }
        resetBodyBind()
        rebuildBody()
        toast("Đã tháo mô hình khỏi xương")
    }

    private func resetBodyBind() {
        bodyBind = nil
        bodyB1 = []
        bodyB2 = []
        bodyW = []
        isBodyBound = false
    }

    /// Cập nhật lưới theo dáng xương (giới hạn ~20 lần/giây khi kéo)
    func applyBodyRig(force: Bool = false) {
        guard let base = bodyBase, let bp = bodyBind, let m = bodyMat,
              bodyB1.count == base.pos.count else { return }
        let now = ProcessInfo.processInfo.systemUptime
        if !force && now - lastBodyUpdate < 0.05 { return }
        lastBodyUpdate = now
        let rots = boneRotations(bp)
        var out: [SIMD3<Float>] = []
        out.reserveCapacity(base.pos.count)
        for k in base.pos.indices {
            let P = base.pos[k]
            let a = skinPoint(P, bodyB1[k], rots, bp)
            let w = bodyW[k]
            out.append(w >= 0.999 ? a : a * w + skinPoint(P, bodyB2[k], rots, bp) * (1 - w))
        }
        let g = BodyMesh.geometry(base, positions: out)
        g.materials = [m]
        bodyNode.geometry = g
    }

    func flipBodyTexture() {
        flipV.toggle()
        rebuildBody()
    }

    func removeBody() {
        bodyNode.geometry = nil
        analysis = nil
        bodyBase = nil
        bodyMat = nil
        resetBodyBind()
        hasBody = false
        refNode.isHidden = !hasRef
    }

    // MARK: - Cảm ứng theo chế độ

    func touchDown(_ p: CGPoint, in v: SCNView) {
        switch mode {
        case .draw: begin(at: p, in: v)
        case .bones: skeleton.beginDrag(at: p, in: v)
        case .orbit: break
        }
    }

    func touchMove(_ p: CGPoint, in v: SCNView) {
        switch mode {
        case .draw: move(to: p, in: v)
        case .bones:
            skeleton.drag(to: p, in: v)
            applyRig(throttled: true)
            applyBodyRig()
        case .orbit: break
        }
    }

    func touchUp() {
        end()
        skeleton.endDrag()
        if mode == .bones { applyRig(); applyBodyRig(force: true) }
    }

    func toggleSkeleton() { skeleton.root.isHidden.toggle() }
    func resetSkeleton() { skeleton.reset(); skeleton.root.isHidden = false; applyRig(); applyBodyRig(force: true) }

    func undo() {
        guard !strokes.isEmpty else { return }
        strokes.removeLast()
        if bindPose != nil, !boneOf.isEmpty { boneOf.removeLast(); bone2Of.removeLast(); wOf.removeLast() }
        strokesRoot.childNodes.last?.removeFromParentNode()
        strokeCount = strokes.count
    }

    func clear() {
        strokes.removeAll()
        bindPose = nil
        boneOf = []
        bone2Of = []
        wOf = []
        isBound = false
        strokesRoot.childNodes.forEach { $0.removeFromParentNode() }
        strokeCount = 0
    }

    // MARK: - Lưu / Mở (nhiều bản có tên)

    private var docsURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    private var saveDir: URL {
        let d = docsURL.appendingPathComponent("Draw3D", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    private func saveURL(_ name: String) -> URL {
        saveDir.appendingPathComponent(name + ".json")
    }

    private func cleanName(_ raw: String) -> String {
        let bad = CharacterSet(charactersIn: "/\\:?*\"<>|")
        let n = raw.components(separatedBy: bad).joined(separator: "-")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return n.isEmpty ? "Ban ve" : n
    }

    func refreshSaves() {
        let fm = FileManager.default
        // Chuyển file cũ Documents/Draw3D.json (bản duy nhất) vào thư mục mới
        let legacy = docsURL.appendingPathComponent("Draw3D.json")
        if fm.fileExists(atPath: legacy.path), !fm.fileExists(atPath: saveURL("Ban cu").path) {
            do {
                try fm.copyItem(at: legacy, to: saveURL("Ban cu"))
                try fm.removeItem(at: legacy)
            } catch {}
        }
        let urls = (try? fm.contentsOfDirectory(at: saveDir, includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
        var items: [(String, Date)] = []
        for u in urls where u.pathExtension == "json" {
            let d = (try? u.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? Date.distantPast
            items.append((u.deletingPathExtension().lastPathComponent, d))
        }
        items.sort { $0.1 > $1.1 }
        saveNames = items.map { $0.0 }
    }

    func deleteSave(_ name: String) {
        try? FileManager.default.removeItem(at: saveURL(name))
        refreshSaves()
    }

    func save(as rawName: String) {
        let name = cleanName(rawName)
        do {
            var f = SaveFile(strokes: strokes, pose: skeleton.pose,
                             bindPose: bindPose?.map { [$0.x, $0.y, $0.z] },
                             boneOf: bindPose == nil ? nil : boneOf,
                             bone2Of: bindPose == nil ? nil : bone2Of,
                             weights: bindPose == nil ? nil : wOf)
            if let img = refImage {
                f.refPNG = img.pngData()
                f.refVisible = hasRef
                f.refScale = refScale
                f.refOpacity = refOpacity
            }
            if hasBody, let a = analysis {
                f.bodyAnalysis = a
                f.bodyThickness = bodyThickness
                f.bodyFlipV = flipV
                if let bb = bodyBind {
                    f.bodyBind = bb.map { [$0.x, $0.y, $0.z] }
                    f.bodyB1 = bodyB1
                    f.bodyB2 = bodyB2
                    f.bodyW = bodyW
                }
            }
            let data = try JSONEncoder().encode(f)
            try data.write(to: saveURL(name), options: .atomic)
            currentName = name
            refreshSaves()
            toast("Đã lưu \"\(name)\" (xem trong app Tệp > Draw3D)")
        } catch {
            toast("Lưu lỗi: \(error.localizedDescription)")
        }
    }

    func load(name: String) {
        do {
            let data = try Data(contentsOf: saveURL(name))
            var file: SaveFile?
            var fileBind: ([[Float]], [[Int]])?
            var fileBone2: [[Int]]?
            var fileW: [[Float]]?
            let loaded: [StrokeData]
            if let f = try? JSONDecoder().decode(SaveFile.self, from: data) {
                file = f
                loaded = f.strokes
                if let pose = f.pose { skeleton.setPose(pose) }
                if let bp = f.bindPose, let bo = f.boneOf { fileBind = (bp, bo); fileBone2 = f.bone2Of; fileW = f.weights }
            } else {
                loaded = try JSONDecoder().decode([StrokeData].self, from: data)
            }
            clear()
            for s in loaded where s.color.count == 4 && !s.points.isEmpty {
                let m = makeMaterial(s.color)
                var pts: [SIMD3<Float>] = []
                for p in s.points where p.count == 3 {
                    pts.append(SIMD3<Float>(p[0], p[1], p[2]))
                }
                let node = SCNNode()
                node.geometry = StrokeMesh.geometry(points: pts, radius: Float(s.radius), material: m)
                strokesRoot.addChildNode(node)
                strokes.append(s)
            }
            strokeCount = strokes.count
            if let fb = fileBind, fb.0.count == skeleton.pos.count, fb.1.count == strokes.count,
               fb.0.allSatisfy({ $0.count == 3 }) {
                let bp = fb.0
                let bo = fb.1
                bindPose = bp.map { SIMD3<Float>($0[0], $0[1], $0[2]) }
                boneOf = bo
                if let b2 = fileBone2, let w = fileW, b2.count == bo.count, w.count == bo.count {
                    bone2Of = b2
                    wOf = w
                } else {
                    bone2Of = bo
                    wOf = bo.map { [Float](repeating: 1, count: $0.count) }
                }
                isBound = true
                applyRig()
            }
            restoreExtras(file)
            currentName = name
            toast("Đã mở \"\(name)\"")
        } catch {
            toast("Không mở được bản vẽ này")
        }
    }

    /// Khôi phục ảnh mẫu và mô hình body từ file (nếu có)
    private func restoreExtras(_ f: SaveFile?) {
        removeReference()
        removeBody()
        guard let f = f else { return }
        if let d = f.refPNG, let img = UIImage(data: d) {
            setReference(img)
            if let o = f.refOpacity { refOpacity = o }
            if let sc = f.refScale { refScale = sc }
            if f.refVisible == false { removeReference() }
        }
        guard let a = f.bodyAnalysis, a.dist.count == a.gw * a.gh, refImage != nil else { return }
        if let t = f.bodyThickness { bodyThickness = t }   // analysis đang nil nên chưa dựng lưới
        flipV = f.bodyFlipV ?? false
        analysis = a
        if let bb = f.bodyBind, let b1 = f.bodyB1, let b2 = f.bodyB2, let w = f.bodyW,
           bb.count == skeleton.pos.count, bb.allSatisfy({ $0.count == 3 }),
           b1.count == b2.count, b1.count == w.count {
            bodyBind = bb.map { SIMD3<Float>($0[0], $0[1], $0[2]) }
            bodyB1 = b1
            bodyB2 = b2
            bodyW = w
            isBodyBound = true
        }
        hasBody = true
        rebuildBody()
        if bodyBind != nil, bodyB1.count != (bodyBase?.pos.count ?? -1) {
            resetBodyBind()   // dữ liệu gắn xương không khớp lưới: bỏ
            rebuildBody()
        }
        refNode.isHidden = true
    }

    // MARK: - Xuất

    func exportUSDZ(includeSkeleton: Bool = false) {
        guard !strokes.isEmpty || includeSkeleton || hasBody else { toast("Chưa có gì để xuất"); return }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Draw3D.usdz")
        try? FileManager.default.removeItem(at: url)
        let s = SCNScene()
        s.rootNode.addChildNode(strokesRoot.clone())
        if hasBody, bodyNode.geometry != nil { s.rootNode.addChildNode(bodyNode.clone()) }
        if hasModel { s.rootNode.addChildNode(modelNode.clone()) }
        if includeSkeleton {
            // Nhân bản xương, dùng vật liệu thường để file USDZ hiển thị đúng
            let sk = skeleton.root.clone()
            sk.isHidden = false
            sk.enumerateHierarchy { node, _ in
                guard let g = node.geometry?.copy() as? SCNGeometry else { return }
                let m = SCNMaterial()
                m.diffuse.contents = (g is SCNCylinder) ? UIColor.orange : UIColor.white
                g.materials = [m]
                node.geometry = g
            }
            s.rootNode.addChildNode(sk)
        }
        if s.write(to: url, options: nil, delegate: nil, progressHandler: nil) {
            shareFile = ShareFile(url: url)
        } else {
            toast("Xuất USDZ lỗi")
        }
    }

    func exportPNG() {
        let refWas = refNode.isHidden
        let skWas = skeleton.root.isHidden
        let gridWas = gridNode?.isHidden ?? false
        if pngHideRef { refNode.isHidden = true }
        if pngHideSkeleton { skeleton.root.isHidden = true }
        if pngHideGrid { gridNode?.isHidden = true }
        let snap = view?.snapshot()
        refNode.isHidden = refWas
        skeleton.root.isHidden = skWas
        gridNode?.isHidden = gridWas
        guard let img = snap, let data = img.pngData() else { toast("Xuất ảnh lỗi"); return }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Draw3D.png")
        do {
            try data.write(to: url, options: .atomic)
            shareFile = ShareFile(url: url)
        } catch {
            toast("Xuất ảnh lỗi")
        }
    }

    // MARK: - Xuất GLB (Blender): có xương thật + skinning

    func exportGLB() {
        guard !strokes.isEmpty || (hasBody && bodyBase != nil) else { toast("Chưa có gì để xuất"); return }
        var meshes: [GLTFMeshInput] = []

        for si in strokes.indices {
            let st = strokes[si]
            guard st.points.allSatisfy({ $0.count == 3 }) else { continue }
            let pts = st.points.map { SIMD3<Float>($0[0], $0[1], $0[2]) }
            guard let b = StrokeMesh.build(points: pts, radius: Float(st.radius), withOwner: true) else { continue }
            var m = GLTFMeshInput(name: "net\(si)", pos: b.pos, nrm: b.nrm, uv: nil, idx: b.idx,
                                  color: st.color, texturePNG: nil, skin: nil)
            if let bp = bindPose, si < boneOf.count, si < bone2Of.count, si < wOf.count,
               boneOf[si].count == pts.count, bone2Of[si].count == pts.count, wOf[si].count == pts.count {
                var j: [UInt8] = []
                var w: [Float] = []
                j.reserveCapacity(b.owner.count * 4)
                w.reserveCapacity(b.owner.count * 4)
                for o in b.owner {
                    appendSkinWeights(&j, &w, boneOf[si][o], bone2Of[si][o], wOf[si][o])
                }
                m.skin = GLTFSkinInput(skinID: 0, bind: bp, joints: j, weights: w)
            }
            meshes.append(m)
        }

        if hasBody, let base = bodyBase {
            let nrm = BodyMesh.normals(pos: base.pos, idx: base.idx)
            var m = GLTFMeshInput(name: "body", pos: base.pos, nrm: nrm, uv: base.uv, idx: base.idx,
                                  color: nil, texturePNG: refImage?.pngData(), skin: nil)
            if let bb = bodyBind, bodyB1.count == base.pos.count,
               bodyB2.count == base.pos.count, bodyW.count == base.pos.count {
                var j: [UInt8] = []
                var w: [Float] = []
                j.reserveCapacity(base.pos.count * 4)
                w.reserveCapacity(base.pos.count * 4)
                for k in base.pos.indices {
                    appendSkinWeights(&j, &w, bodyB1[k], bodyB2[k], bodyW[k])
                }
                m.skin = GLTFSkinInput(skinID: 1, bind: bb, joints: j, weights: w)
            }
            meshes.append(m)
        }

        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Draw3D.glb")
        try? FileManager.default.removeItem(at: url)
        do {
            try GLTFExporter.write(meshes: meshes, parents: skeleton.parents, current: skeleton.pos,
                                   reference: bindPose ?? bodyBind ?? skeleton.pos, to: url)
            shareFile = ShareFile(url: url)
        } catch {
            toast("Xuất GLB lỗi: \(error.localizedDescription)")
        }
    }

    // MARK: - Mô hình 3D thật từ ảnh (Meshy)

    func generateFromImage(apiKey: String) {
        guard let img = refImage else { toast("Hãy chọn Ảnh mẫu trước"); return }
        guard !aiBusy else { return }
        guard let jpg = img.jpegData(compressionQuality: 0.9) else { toast("Không đọc được ảnh mẫu"); return }
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { toast("Chưa nhập API key Meshy"); return }
        aiBusy = true
        aiStatus = "Đang gửi ảnh…"
        aiTask = Task { @MainActor [self] in
            do {
                let id = try await MeshyClient.createTask(imageData: jpg, mime: "image/jpeg", key: key)
                var tries = 0
                while tries < 200 {   // tối đa khoảng 10 phút
                    tries += 1
                    try await Task.sleep(nanoseconds: 3_000_000_000)
                    let st = try await MeshyClient.status(id: id, key: key)
                    switch st.status {
                    case "SUCCEEDED":
                        guard let u = st.usdz else { throw MeshyError.failed("Kết quả không có file USDZ") }
                        aiStatus = "Đang tải mô hình…"
                        let file = try await MeshyClient.download(u)
                        try importModel(from: file)
                        aiBusy = false
                        aiStatus = ""
                        toast("Đã tạo mô hình 3D từ Meshy")
                        return
                    case "FAILED", "CANCELED":
                        throw MeshyError.failed(st.error.isEmpty ? "Meshy báo \(st.status)" : st.error)
                    default:
                        aiStatus = "Đang tạo 3D… \(st.progress)%"
                    }
                }
                throw MeshyError.failed("Quá thời gian chờ")
            } catch {
                aiBusy = false
                aiStatus = ""
                if error is CancellationError {
                    toast("Đã huỷ")
                } else {
                    toast("Lỗi Meshy: \(error.localizedDescription)")
                }
            }
        }
    }

    func cancelAI() {
        aiTask?.cancel()
    }

    /// Nạp USDZ, co/dời cho cao 4 và đặt giữa cảnh (cùng chỗ với ảnh mẫu)
    private func importModel(from url: URL) throws {
        let sc = try SCNScene(url: url, options: nil)
        let holder = SCNNode()
        for n in sc.rootNode.childNodes { holder.addChildNode(n) }
        let (mn, mx) = holder.boundingBox
        let h = mx.y - mn.y
        guard h > 1e-6 else { throw MeshyError.failed("Mô hình rỗng") }
        let k = Float(4) / h
        let cx = (mn.x + mx.x) / 2
        let cy = (mn.y + mx.y) / 2
        let cz = (mn.z + mx.z) / 2
        holder.simdScale = SIMD3<Float>(repeating: k)
        holder.simdPosition = SIMD3<Float>(-cx * k, 0.15 - cy * k, -cz * k)
        modelNode.childNodes.forEach { $0.removeFromParentNode() }
        modelNode.addChildNode(holder)
        hasModel = true
    }

    func removeModel() {
        modelNode.childNodes.forEach { $0.removeFromParentNode() }
        hasModel = false
    }

    private func toast(_ text: String) {
        message = text
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { [weak self] in
            if self?.message == text { self?.message = nil }
        }
    }
}

/// Ghi 2 xương + trọng số của một đỉnh (glTF cần 4 joint, 4 weight mỗi đỉnh)
private func appendSkinWeights(_ j: inout [UInt8], _ w: inout [Float], _ a: Int, _ b: Int, _ wa: Float) {
    if wa >= 0.999 || a == b {
        j += [UInt8(truncatingIfNeeded: a), 0, 0, 0]
        w += [1, 0, 0, 0]
    } else {
        j += [UInt8(truncatingIfNeeded: a), UInt8(truncatingIfNeeded: b), 0, 0]
        w += [wa, 1 - wa, 0, 0]
    }
}
