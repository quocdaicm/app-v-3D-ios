import Foundation
import Security

/// Lưu API key trong Keychain (không nằm trong file lưu hay mã nguồn)
enum Keychain {
    static func set(_ value: String, for key: String) {
        let base: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                   kSecAttrAccount as String: key]
        SecItemDelete(base as CFDictionary)
        let v = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !v.isEmpty else { return }
        var add = base
        add[kSecValueData as String] = Data(v.utf8)
        SecItemAdd(add as CFDictionary, nil)
    }

    static func get(_ key: String) -> String? {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                kSecAttrAccount as String: key,
                                kSecReturnData as String: true,
                                kSecMatchLimit as String: kSecMatchLimitOne]
        var out: AnyObject?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
              let d = out as? Data else { return nil }
        return String(data: d, encoding: .utf8)
    }
}

enum MeshyError: LocalizedError {
    case http(Int, String)
    case failed(String)
    case badResponse

    var errorDescription: String? {
        switch self {
        case .http(let code, let msg):
            switch code {
            case 401: return "API key không đúng (401)"
            case 402: return "Hết credit Meshy (402)"
            case 429: return "Gọi quá nhiều lần, thử lại sau (429)"
            default: return "Lỗi HTTP \(code) \(msg)"
            }
        case .failed(let m): return m
        case .badResponse: return "Phản hồi không hợp lệ"
        }
    }
}

/// Meshy Image-to-3D: https://docs.meshy.ai/api/image-to-3d
enum MeshyClient {
    static let endpoint = "https://api.meshy.ai/openapi/v1/image-to-3d"

    struct Status {
        let status: String
        let progress: Int
        let usdz: URL?
        let error: String
    }

    private static func check(_ resp: URLResponse, _ data: Data) throws {
        guard let h = resp as? HTTPURLResponse else { throw MeshyError.badResponse }
        guard (200..<300).contains(h.statusCode) else {
            var msg = ""
            if let j = try? JSONSerialization.jsonObject(with: data),
               let d = j as? [String: Any], let m = d["message"] as? String { msg = m }
            throw MeshyError.http(h.statusCode, msg)
        }
    }

    static func createTask(imageData: Data, mime: String, key: String) async throws -> String {
        guard let url = URL(string: endpoint) else { throw MeshyError.badResponse }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 120
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "image_url": "data:\(mime);base64,\(imageData.base64EncodedString())",
            "target_formats": ["usdz"],
            "should_texture": true,
            "should_remesh": true,
            "target_polycount": 30000
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, resp) = try await URLSession.shared.data(for: req)
        try check(resp, data)
        guard let j = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let id = j["result"] as? String else { throw MeshyError.badResponse }
        return id
    }

    static func status(id: String, key: String) async throws -> Status {
        guard let url = URL(string: endpoint + "/" + id) else { throw MeshyError.badResponse }
        var req = URLRequest(url: url)
        req.timeoutInterval = 60
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        let (data, resp) = try await URLSession.shared.data(for: req)
        try check(resp, data)
        guard let j = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw MeshyError.badResponse
        }
        let st = j["status"] as? String ?? ""
        let pr = (j["progress"] as? NSNumber)?.intValue ?? 0
        var usdz: URL?
        if let mu = j["model_urls"] as? [String: Any], let s = mu["usdz"] as? String {
            usdz = URL(string: s)
        }
        var err = ""
        if let te = j["task_error"] as? [String: Any], let m = te["message"] as? String { err = m }
        return Status(status: st, progress: pr, usdz: usdz, error: err)
    }

    static func download(_ url: URL) async throws -> URL {
        let (tmp, resp) = try await URLSession.shared.download(from: url)
        guard let h = resp as? HTTPURLResponse, (200..<300).contains(h.statusCode) else {
            throw MeshyError.badResponse
        }
        let dst = FileManager.default.temporaryDirectory
            .appendingPathComponent("meshy-\(UUID().uuidString).usdz")
        try FileManager.default.moveItem(at: tmp, to: dst)
        return dst
    }
}
