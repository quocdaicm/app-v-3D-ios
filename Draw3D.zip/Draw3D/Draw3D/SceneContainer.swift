import SceneKit
import SwiftUI

final class DrawView: SCNView {
    weak var controller: Controller?

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let c = controller, c.mode != .orbit, let t = touches.first {
            c.touchDown(t.location(in: self), in: self)
        } else {
            super.touchesBegan(touches, with: event)
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let c = controller, c.mode != .orbit, let t = touches.first {
            c.touchMove(t.location(in: self), in: self)
        } else {
            super.touchesMoved(touches, with: event)
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        controller?.touchUp()
        super.touchesEnded(touches, with: event)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        controller?.touchUp()
        super.touchesCancelled(touches, with: event)
    }
}

struct SceneContainer: UIViewRepresentable {
    @ObservedObject var controller: Controller

    func makeUIView(context: Context) -> DrawView {
        let v = DrawView()
        v.controller = controller
        controller.view = v
        v.scene = controller.scene
        v.pointOfView = controller.cameraNode
        v.autoenablesDefaultLighting = true
        v.antialiasingMode = .multisampling4X
        v.backgroundColor = .black
        v.allowsCameraControl = controller.mode == .orbit
        return v
    }

    func updateUIView(_ v: DrawView, context: Context) {
        v.allowsCameraControl = controller.mode == .orbit
    }
}
