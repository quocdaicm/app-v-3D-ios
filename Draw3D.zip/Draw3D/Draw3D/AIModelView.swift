import SwiftUI

/// Tạo mô hình 3D thật từ Ảnh mẫu bằng Meshy
struct AIModelView: View {
    @ObservedObject var c: Controller
    @Binding var isPresented: Bool
    @State private var key = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("API key Meshy") {
                    SecureField("msy_…", text: $key)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Text("Lấy key ở meshy.ai (cần tài khoản có quyền dùng API). Mỗi lần tạo tốn credit của bạn. Key chỉ lưu trong Keychain trên máy này. Ảnh mẫu sẽ được gửi lên máy chủ Meshy.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                Section {
                    if c.aiBusy {
                        HStack {
                            ProgressView()
                            Text(c.aiStatus)
                        }
                        Button("Huỷ", role: .destructive) { c.cancelAI() }
                    } else {
                        Button("Tạo mô hình 3D từ Ảnh mẫu") {
                            Keychain.set(key, for: "meshy")
                            c.generateFromImage(apiKey: key)
                        }
                        .disabled(!c.hasRef)
                    }
                    if c.hasModel {
                        Button("Xoá mô hình Meshy", role: .destructive) { c.removeModel() }
                    }
                } footer: {
                    Text("Mô hình tạo ra là khối cứng (chưa rig), đặt cùng chỗ với ảnh mẫu để vẽ đè hoặc đối chiếu.")
                }
            }
            .navigationTitle("Ảnh → 3D (Meshy)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Xong") { isPresented = false }
                }
            }
        }
        .onAppear { key = Keychain.get("meshy") ?? "" }
    }
}
