import Foundation
import simd

/// Dữ liệu skinning của một lưới: mỗi đỉnh tối đa 2 xương (bone i = nút i trong file)
struct GLTFSkinInput {
    var skinID: Int
    var bind: [SIMD3<Float>]   // dáng xương lúc gắn (19 khớp)
    var joints: [UInt8]        // 4 giá trị mỗi đỉnh
    var weights: [Float]       // 4 giá trị mỗi đỉnh
}

struct GLTFMeshInput {
    var name: String
    var pos: [SIMD3<Float>]
    var nrm: [SIMD3<Float>]
    var uv: [SIMD2<Float>]?
    var idx: [Int32]
    var color: [Double]?       // RGBA
    var texturePNG: Data?
    var skin: GLTFSkinInput?
}

/// Ghi file .glb (glTF 2.0) có bộ xương thật: mỗi xương là một nút, skin dùng đúng
/// công thức của app (đầu xương = khớp cha, xoay theo cung ngắn nhất).
enum GLTFExporter {
    enum Failure: Error { case empty }

    static func write(meshes: [GLTFMeshInput], parents: [Int?], current: [SIMD3<Float>],
                      reference: [SIMD3<Float>], to url: URL) throws {
        let jc = parents.count
        guard jc > 0, current.count == jc, reference.count == jc else { throw Failure.empty }

        var bin = Data()
        var views: [[String: Any]] = []
        var accessors: [[String: Any]] = []

        func addView(_ d: Data, target: Int?) -> Int {
            while bin.count % 4 != 0 { bin.append(0) }
            var v: [String: Any] = ["buffer": 0, "byteOffset": bin.count, "byteLength": d.count]
            if let t = target { v["target"] = t }
            bin.append(d)
            views.append(v)
            return views.count - 1
        }

        func addAccessor(_ d: Data, target: Int?, comp: Int, count: Int, type: String,
                         lo: [Double]? = nil, hi: [Double]? = nil) -> Int {
            let vi = addView(d, target: target)
            var a: [String: Any] = ["bufferView": vi, "componentType": comp, "count": count, "type": type]
            if let l = lo { a["min"] = l }
            if let h = hi { a["max"] = h }
            accessors.append(a)
            return accessors.count - 1
        }

        func bytes<T>(_ a: [T]) -> Data {
            return a.withUnsafeBufferPointer { Data(buffer: $0) }
        }

        func flat3(_ a: [SIMD3<Float>]) -> [Float] {
            var o: [Float] = []
            o.reserveCapacity(a.count * 3)
            for v in a {
                o.append(v.x)
                o.append(v.y)
                o.append(v.z)
            }
            return o
        }

        func flat2(_ a: [SIMD2<Float>]) -> [Float] {
            var o: [Float] = []
            o.reserveCapacity(a.count * 2)
            for v in a {
                o.append(v.x)
                o.append(v.y)
            }
            return o
        }

        let identity = simd_quatf(ix: 0, iy: 0, iz: 0, r: 1)

        // Xoay (cung ngắn nhất) của xương i khi chuyển từ dáng `from` sang dáng `to`
        func boneRot(_ from: [SIMD3<Float>], _ to: [SIMD3<Float>], _ i: Int) -> simd_quatf {
            guard let p = parents[i] else { return identity }
            let a = from[i] - from[p]
            let b = to[i] - to[p]
            guard simd_length(a) > 1e-5, simd_length(b) > 1e-5 else { return identity }
            return simd_quatf(from: simd_normalize(a), to: simd_normalize(b))
        }

        // ---- Bộ xương: nút 0 = gốc (hông), nút i = xương i, đầu xương tại khớp cha ----
        var rw: [simd_quatf] = []
        for i in 0..<jc { rw.append(boneRot(reference, current, i)) }

        var nodes: [[String: Any]] = []
        for i in 0..<jc {
            var n: [String: Any] = ["name": "bone\(i)"]
            if let p = parents[i] {
                var t = SIMD3<Float>(0, 0, 0)
                if p != 0, let pp = parents[p] { t = reference[p] - reference[pp] }
                n["translation"] = [Double(t.x), Double(t.y), Double(t.z)]
                let q = (rw[p].inverse * rw[i]).vector
                n["rotation"] = [Double(q.x), Double(q.y), Double(q.z), Double(q.w)]
            } else {
                let c = current[i]
                n["translation"] = [Double(c.x), Double(c.y), Double(c.z)]
            }
            let kids = (0..<jc).filter { parents[$0] == i }
            if !kids.isEmpty { n["children"] = kids }
            nodes.append(n)
        }

        // ---- Skin: mỗi skinID một skin (khác dáng gắn → khác inverseBindMatrices) ----
        var skinIndexOf: [Int: Int] = [:]
        var skins: [[String: Any]] = []
        for m in meshes {
            guard let s = m.skin, skinIndexOf[s.skinID] == nil, s.bind.count == jc else { continue }
            var ibm: [Float] = []
            ibm.reserveCapacity(jc * 16)
            for k in 0..<jc {
                var head = s.bind[k]
                if let p = parents[k] { head = s.bind[p] }
                var mat = simd_float4x4(boneRot(reference, s.bind, k))
                mat.columns.3 = SIMD4<Float>(head.x, head.y, head.z, 1)
                let inv = mat.inverse
                for c in 0..<4 {
                    let col = inv[c]
                    ibm.append(col.x)
                    ibm.append(col.y)
                    ibm.append(col.z)
                    ibm.append(col.w)
                }
            }
            let ai = addAccessor(bytes(ibm), target: nil, comp: 5126, count: jc, type: "MAT4")
            skins.append(["joints": Array(0..<jc), "inverseBindMatrices": ai, "skeleton": 0])
            skinIndexOf[s.skinID] = skins.count - 1
        }

        // ---- Lưới ----
        var gMeshes: [[String: Any]] = []
        var materials: [[String: Any]] = []
        var textures: [[String: Any]] = []
        var images: [[String: Any]] = []
        var colorMat: [String: Int] = [:]
        var sceneNodes: [Int] = [0]

        for m in meshes {
            guard !m.pos.isEmpty, !m.idx.isEmpty, m.nrm.count == m.pos.count else { continue }
            var attrs: [String: Any] = [:]

            var lo = SIMD3<Float>(repeating: Float.greatestFiniteMagnitude)
            var hi = SIMD3<Float>(repeating: -Float.greatestFiniteMagnitude)
            for p in m.pos {
                lo = simd_min(lo, p)
                hi = simd_max(hi, p)
            }
            attrs["POSITION"] = addAccessor(bytes(flat3(m.pos)), target: 34962, comp: 5126,
                                            count: m.pos.count, type: "VEC3",
                                            lo: [Double(lo.x), Double(lo.y), Double(lo.z)],
                                            hi: [Double(hi.x), Double(hi.y), Double(hi.z)])
            attrs["NORMAL"] = addAccessor(bytes(flat3(m.nrm)), target: 34962, comp: 5126,
                                          count: m.nrm.count, type: "VEC3")
            if let uv = m.uv, uv.count == m.pos.count {
                attrs["TEXCOORD_0"] = addAccessor(bytes(flat2(uv)), target: 34962, comp: 5126,
                                                  count: uv.count, type: "VEC2")
            }
            var skinIndex: Int?
            if let s = m.skin, let si = skinIndexOf[s.skinID],
               s.joints.count == m.pos.count * 4, s.weights.count == m.pos.count * 4 {
                attrs["JOINTS_0"] = addAccessor(bytes(s.joints), target: 34962, comp: 5121,
                                                count: m.pos.count, type: "VEC4")
                attrs["WEIGHTS_0"] = addAccessor(bytes(s.weights), target: 34962, comp: 5126,
                                                 count: m.pos.count, type: "VEC4")
                skinIndex = si
            }
            let indices: [UInt32] = m.idx.map { UInt32($0) }
            let ii = addAccessor(bytes(indices), target: 34963, comp: 5125,
                                 count: indices.count, type: "SCALAR")

            // Vật liệu
            var matIndex = 0
            if let png = m.texturePNG {
                let iv = addView(png, target: nil)
                images.append(["bufferView": iv, "mimeType": "image/png"])
                textures.append(["source": images.count - 1, "sampler": 0])
                let pbr: [String: Any] = ["baseColorTexture": ["index": textures.count - 1],
                                          "metallicFactor": 0.0, "roughnessFactor": 0.8]
                materials.append(["pbrMetallicRoughness": pbr, "doubleSided": true])
                matIndex = materials.count - 1
            } else {
                let c = (m.color ?? [1, 1, 1, 1])
                let col = c.count == 4 ? c : [1, 1, 1, 1]
                let key = col.map { String($0) }.joined(separator: ",")
                if let existing = colorMat[key] {
                    matIndex = existing
                } else {
                    let pbr: [String: Any] = ["baseColorFactor": col,
                                              "metallicFactor": 0.0, "roughnessFactor": 0.6]
                    var mat: [String: Any] = ["pbrMetallicRoughness": pbr, "doubleSided": true]
                    if col[3] < 1 { mat["alphaMode"] = "BLEND" }
                    materials.append(mat)
                    matIndex = materials.count - 1
                    colorMat[key] = matIndex
                }
            }

            let prim: [String: Any] = ["attributes": attrs, "indices": ii, "material": matIndex, "mode": 4]
            gMeshes.append(["name": m.name, "primitives": [prim]])
            var node: [String: Any] = ["name": m.name, "mesh": gMeshes.count - 1]
            if let si = skinIndex { node["skin"] = si }
            nodes.append(node)
            sceneNodes.append(nodes.count - 1)
        }

        while bin.count % 4 != 0 { bin.append(0) }

        var root: [String: Any] = [
            "asset": ["version": "2.0", "generator": "Draw3D"],
            "scene": 0,
            "scenes": [["nodes": sceneNodes]],
            "nodes": nodes
        ]
        if !gMeshes.isEmpty { root["meshes"] = gMeshes }
        if !skins.isEmpty { root["skins"] = skins }
        if !materials.isEmpty { root["materials"] = materials }
        if !textures.isEmpty {
            root["textures"] = textures
            root["images"] = images
            root["samplers"] = [["magFilter": 9729, "minFilter": 9729, "wrapS": 33071, "wrapT": 33071]]
        }
        if !bin.isEmpty {
            root["buffers"] = [["byteLength": bin.count]]
            root["bufferViews"] = views
            root["accessors"] = accessors
        }

        var json = try JSONSerialization.data(withJSONObject: root)
        while json.count % 4 != 0 { json.append(0x20) }

        var out = Data()
        func u32(_ v: UInt32) {
            var x = v.littleEndian
            withUnsafeBytes(of: &x) { out.append(contentsOf: $0) }
        }
        let total = 12 + 8 + json.count + (bin.isEmpty ? 0 : 8 + bin.count)
        u32(0x46546C67)            // "glTF"
        u32(2)
        u32(UInt32(total))
        u32(UInt32(json.count))
        u32(0x4E4F534A)            // "JSON"
        out.append(json)
        if !bin.isEmpty {
            u32(UInt32(bin.count))
            u32(0x004E4942)        // "BIN\0"
            out.append(bin)
        }
        try out.write(to: url, options: .atomic)
    }
}
