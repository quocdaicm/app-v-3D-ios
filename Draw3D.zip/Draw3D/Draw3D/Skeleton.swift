import SceneKit
import UIKit
import simd

/// Bộ xương người 3D: kéo khớp để chỉnh dáng (xoay xương, giữ nguyên độ dài).
final class Skeleton {
    private struct J {
        let parent: Int?
        let pos: SIMD3<Float>
    }

    // 0 hips, 1 spine, 2 chest, 3 neck, 4 head,
    // 5-7 tay trái (vai, khuỷu, cổ tay), 8-10 tay phải,
    // 11-14 chân trái (hông, gối, cổ chân, mũi chân), 15-18 chân phải
    private static let rest: [J] = [
        J(parent: nil, pos: [0, 0.2, 0]),
        J(parent: 0, pos: [0, 0.7, 0]),
        J(parent: 1, pos: [0, 1.2, 0]),
        J(parent: 2, pos: [0, 1.5, 0]),
        J(parent: 3, pos: [0, 1.85, 0]),
        J(parent: 2, pos: [-0.4, 1.4, 0]),
        J(parent: 5, pos: [-0.45, 0.9, 0]),
        J(parent: 6, pos: [-0.45, 0.4, 0.05]),
        J(parent: 2, pos: [0.4, 1.4, 0]),
        J(parent: 8, pos: [0.45, 0.9, 0]),
        J(parent: 9, pos: [0.45, 0.4, 0.05]),
        J(parent: 0, pos: [-0.2, 0.15, 0]),
        J(parent: 11, pos: [-0.22, -0.7, 0]),
        J(parent: 12, pos: [-0.22, -1.5, 0]),
        J(parent: 13, pos: [-0.22, -1.6, 0.3]),
        J(parent: 0, pos: [0.2, 0.15, 0]),
        J(parent: 15, pos: [0.22, -0.7, 0]),
        J(parent: 16, pos: [0.22, -1.5, 0]),
        J(parent: 17, pos: [0.22, -1.6, 0.3]),
    ]

    let root = SCNNode()
    private(set) var pos: [SIMD3<Float>] = []
    let parents: [Int?]
    private var jointNodes: [SCNNode] = []
    private var boneNodes: [Int: SCNNode] = [:]
    private var selected: Int?
    private var anchor = SIMD3<Float>(repeating: 0)
    private var grabOffset = SIMD3<Float>(repeating: 0)

    private let jointMat = Skeleton.makeMat(.white)
    private let selMat = Skeleton.makeMat(.yellow)
    private let boneMat = Skeleton.makeMat(UIColor.orange)

    var pose: [[Float]] { pos.map { [$0.x, $0.y, $0.z] } }

    private static func makeMat(_ c: UIColor) -> SCNMaterial {
        let m = SCNMaterial()
        m.diffuse.contents = c
        m.lightingModel = .constant
        m.readsFromDepthBuffer = false   // luôn hiện trên nét vẽ
        m.writesToDepthBuffer = false
        return m
    }

    init() {
        parents = Skeleton.rest.map { $0.parent }
        pos = Skeleton.rest.map { $0.pos }
        for i in pos.indices {
            let sphere = SCNSphere(radius: i == 4 ? 0.15 : 0.06)
            sphere.firstMaterial = jointMat
            let n = SCNNode(geometry: sphere)
            n.renderingOrder = 100
            root.addChildNode(n)
            jointNodes.append(n)
            if parents[i] != nil {
                let c = SCNCylinder(radius: 0.025, height: 1)
                c.firstMaterial = boneMat
                let bn = SCNNode(geometry: c)
                bn.renderingOrder = 99
                root.addChildNode(bn)
                boneNodes[i] = bn
            }
        }
        refresh()
    }

    private func refresh() {
        for i in pos.indices {
            jointNodes[i].simdPosition = pos[i]
            guard let p = parents[i], let bn = boneNodes[i] else { continue }
            let dir = pos[i] - pos[p]
            let len = simd_length(dir)
            (bn.geometry as? SCNCylinder)?.height = CGFloat(len)
            bn.simdPosition = (pos[p] + pos[i]) / 2
            var up = SIMD3<Float>(0, 0, 1)
            if len > 1e-5, abs(simd_dot(dir / len, up)) > 0.99 { up = SIMD3<Float>(0, 1, 0) }
            bn.simdLook(at: pos[i], up: up, localFront: SIMD3<Float>(0, 1, 0))
        }
    }

    func reset() {
        pos = Skeleton.rest.map { $0.pos }
        refresh()
    }

    func setPose(_ p: [[Float]]) {
        guard p.count == pos.count, p.allSatisfy({ $0.count == 3 }) else { return }
        pos = p.map { SIMD3<Float>($0[0], $0[1], $0[2]) }
        refresh()
    }

    // MARK: - Kéo khớp

    private func pick(at p: CGPoint, in v: SCNView) -> Int? {
        var best: (Int, CGFloat)?
        for i in pos.indices {
            let s = v.projectPoint(SCNVector3(pos[i].x, pos[i].y, pos[i].z))
            guard s.z > 0, s.z < 1 else { continue }
            let d = hypot(CGFloat(s.x) - p.x, CGFloat(s.y) - p.y)
            if d < 40, d < (best?.1 ?? .infinity) { best = (i, d) }
        }
        return best?.0
    }

    // Điểm trên mặt phẳng song song màn hình, đi qua `through`
    private func planePoint(_ p: CGPoint, in v: SCNView, through: SIMD3<Float>) -> SIMD3<Float>? {
        guard let pov = v.pointOfView else { return nil }
        let a = v.unprojectPoint(SCNVector3(Float(p.x), Float(p.y), 0))
        let b = v.unprojectPoint(SCNVector3(Float(p.x), Float(p.y), 1))
        let o = SIMD3<Float>(a.x, a.y, a.z)
        let d = simd_normalize(SIMD3<Float>(b.x, b.y, b.z) - o)
        let cam = pov.simdWorldPosition
        let fwd = pov.simdWorldFront
        let denom = simd_dot(d, fwd)
        guard abs(denom) > 1e-5 else { return nil }
        let t = simd_dot(through - cam, fwd) / denom
        return cam + d * t
    }

    func beginDrag(at p: CGPoint, in v: SCNView) {
        guard let i = pick(at: p, in: v), let hit = planePoint(p, in: v, through: pos[i]) else { return }
        selected = i
        anchor = pos[i]
        grabOffset = pos[i] - hit
        jointNodes[i].geometry?.firstMaterial = selMat
    }

    func drag(to p: CGPoint, in v: SCNView) {
        guard let i = selected, let hit = planePoint(p, in: v, through: anchor) else { return }
        let target = hit + grabOffset
        if let par = parents[i] {
            let old = pos[i] - pos[par]
            let new = target - pos[par]
            guard simd_length(old) > 1e-4, simd_length(new) > 1e-4 else { return }
            let q = simd_quatf(from: simd_normalize(old), to: simd_normalize(new))
            for d in subtree(of: i) {
                pos[d] = pos[par] + q.act(pos[d] - pos[par])
            }
        } else {
            let delta = target - pos[i]
            for k in pos.indices { pos[k] += delta }
        }
        refresh()
    }

    func endDrag() {
        if let i = selected { jointNodes[i].geometry?.firstMaterial = jointMat }
        selected = nil
    }

    private func subtree(of i: Int) -> [Int] {
        var out = [i]
        var k = 0
        while k < out.count {
            for c in pos.indices where parents[c] == out[k] { out.append(c) }
            k += 1
        }
        return out
    }
}
