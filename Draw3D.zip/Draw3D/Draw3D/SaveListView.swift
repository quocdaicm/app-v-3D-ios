import SwiftUI

/// Màn hình lưu / mở / xoá các bản vẽ có tên
struct SaveListView: View {
    @ObservedObject var c: Controller
    @Binding var isPresented: Bool
    @State private var name = ""

    private var trimmed: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        NavigationStack {
            List {
                Section("Lưu bản vẽ hiện tại") {
                    TextField("Tên bản vẽ", text: $name)
                    Button("Lưu") {
                        c.save(as: name)
                        isPresented = false
                    }
                    .disabled(trimmed.isEmpty)
                }
                Section("Đã lưu (vuốt sang trái để xoá)") {
                    if c.saveNames.isEmpty {
                        Text("Chưa có bản nào").foregroundStyle(.secondary)
                    }
                    ForEach(c.saveNames, id: \.self) { n in
                        Button(n) {
                            c.load(name: n)
                            isPresented = false
                        }
                        .swipeActions {
                            Button(role: .destructive) {
                                c.deleteSave(n)
                            } label: {
                                Label("Xoá", systemImage: "trash")
                            }
                        }
                    }
                }
            }
            .navigationTitle("Bản vẽ")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Xong") { isPresented = false }
                }
            }
        }
        .onAppear {
            c.refreshSaves()
            if name.isEmpty { name = c.currentName }
        }
    }
}
