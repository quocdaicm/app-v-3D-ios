# Làng Quê – game dựng làng 3D (SwiftUI + SceneKit)
- Cảnh con đường ven sông; toàn bộ cây, hoa, bụi, hàng rào là model OBJ trong `Resources/Models` (50 loại). Cỏ tạo bằng mảng cỏ procedural.
- Chạm mặt đất để trồng, chuyển "Xóa" rồi chạm vào cây đã trồng để nhổ. Cần điều khiển bên trái để đi, vuốt màn hình để nhìn quanh, nút 🏃 để chạy, 🏠 về điểm đầu.
- Build: đẩy lên GitHub nhánh `main` → tab Actions → "Build iOS" → tải artifact `VillageBuilder-ipa` (ipa chưa ký, cần ký lại bằng Sideloadly/AltStore).

- Vẽ đường/mương: chọn nhóm "Vẽ đường", chạm từng điểm trên mặt đất, bấm ✔ để hoàn tất (↩ bỏ điểm cuối). Điểm cách đường có sẵn dưới 2,5 m tự nối vào, góc tự bo tròn. Chế độ Xóa chạm vào đường để xóa.
- Nút 🍃: chuyển hiệu ứng cây, bụi đung đưa theo gió: tắt / nhẹ / mạnh (được lưu).
- Nhóm "Nhà & vườn": nhà mái lá, luống rau, luống cải bắp, luống đất, chậu cây đỏ, hàng chậu, giàn leo, hàng rào gỗ, lu sành, hoa hướng dương (tự dựng theo ảnh vườn miền Tây).
- Mẫu có sẵn → "Ao cá miền Tây (chiều sâu)": ao nuôi cá nước trong mờ nhìn thấy đáy, cá bơi, lưới nuôi, chòi tôn, máy bơm phun nước, guồng quạt, cầu ao, xuồng, chuối + dừa.
- Nút 🚶: điều khiển nhân vật đi lại (camera theo sau). Nút ⛶ (góc phải trên): toàn màn hình để đi xem, ⤡ để thoát.
- Hoàn tác ↩ / Làm lại ↪ (hai nút phía trên joystick): quay lại / tiến tới mọi thao tác đặt, xóa, kéo, xoay, phóng to, vẽ / nối / xóa đường, tạo hàng. Sau khi xóa có thanh thông báo nhỏ để hoàn tác ngay.

- Bảng vẽ nét 2D (khung dưới): chọn mô hình đường / mương / hàng rào / bụi / cột điện... (nhóm "Vẽ đường", "Bụi & hàng rào", "Đường & giao thông", "Điện & hạ tầng", hàng rào gỗ, giàn leo, hàng chậu) thì màn hình tự chia đôi: khung trên là cảnh 3D nhìn từ trên xuống, khung dưới là bản đồ phẳng để vẽ. Kéo 1 ngón để vẽ, đường / hàng hiện ngay trong khung 3D. \"📏 Thẳng\" nét đi thẳng từ chỗ chạm tới chỗ thả; \"〰️ Cong\" nét tay được làm mượt thành đường cong. Đầu nét gần đầu nét cũ (20 px) tự dính (chấm vàng) và nối liền thành một đường. 📐 khóa góc 15°. Chụm 2 ngón / nút ＋ － để phóng to khung dưới, kéo 2 ngón để di chuyển; khung 3D phóng to bằng chụm hai ngón hoặc nút ＋ － bên phải. 🔗 bật thì hai khung cùng phóng to / di chuyển. Vật dạng hàng có thanh \"Cách (m)\". Nút ✍️ (bên phải) mở / đóng bảng vẽ; ✕ trong bảng để về chạm đặt từng vật. Hoàn tác ↩ ↪ dùng chung.
