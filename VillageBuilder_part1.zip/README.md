# Làng Quê – game dựng làng 3D (SwiftUI + SceneKit)
- Cảnh con đường ven sông; toàn bộ cây, hoa, bụi, hàng rào là model OBJ trong `Resources/Models` (50 loại). Cỏ tạo bằng mảng cỏ procedural.
- Chạm mặt đất để trồng, chuyển "Xóa" rồi chạm vào cây đã trồng để nhổ (hoàn 50% xu). Cần điều khiển bên trái để đi, vuốt màn hình để nhìn quanh, nút 🏃 để chạy, 🏠 về điểm đầu.
- Build: đẩy lên GitHub nhánh `main` → tab Actions → "Build iOS" → tải artifact `VillageBuilder-ipa` (ipa chưa ký, cần ký lại bằng Sideloadly/AltStore).

- Vẽ đường/mương: chọn nhóm "Vẽ đường", chạm từng điểm trên mặt đất, bấm ✔ để hoàn tất (↩ bỏ điểm cuối). Điểm cách đường có sẵn dưới 2,5 m tự nối vào, góc tự bo tròn. Chế độ Xóa chạm vào đường để xóa.
- Nút 🍃: chuyển hiệu ứng cây, bụi đung đưa theo gió: tắt / nhẹ / mạnh (được lưu).
