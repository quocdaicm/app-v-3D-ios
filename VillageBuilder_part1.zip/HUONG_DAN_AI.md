# HƯỚNG DẪN CHO AI TIẾP THEO — game "Làng Quê" (VillageBuilder)

Đọc kỹ file này trước khi sửa hoặc vẽ thêm bất cứ thứ gì. Người dùng nói **tiếng Việt**, trả lời bằng tiếng Việt, ngắn gọn, đưa file đã đóng gói sẵn để tải lên GitHub.

## 1. Mục tiêu và phong cách (QUAN TRỌNG NHẤT)
- Game iOS dựng làng quê miền Tây Việt Nam, góc nhìn người đi bộ (joystick), SwiftUI + SceneKit.
- Người dùng yêu cầu rõ: **nét vẽ chuyên nghiệp, đẹp, uyển chuyển, mềm mại; lá, vườn, mọi vật đều có chi tiết rõ ràng.**
- Vì vậy KHÔNG dựng bằng khối hộp/cầu trơn. Luôn dùng: lá có cong và gân, cạnh bo (chamfer), vật tiện tròn (lathe), texture vẽ bằng mã có vân/nhiễu, các lớp chồng lên nhau, chi tiết nhỏ (đai buộc, ốc, đầu phun, vân gỗ...). Mỗi mô hình mới phải có tối thiểu 4–5 chi tiết phụ nhìn rõ được.
- Màu tự nhiên, hơi bạc nắng, không bão hòa gắt. Có vết bẩn/nứt/rêu ở vật bê tông, đất.
- Không có hệ thống xu/tiền. Người dùng đã yêu cầu BỎ; đừng thêm lại giá, xu, thu nhập.

## 2. Ảnh tham chiếu người dùng đã đưa
1. Con đường bê tông hẹp ven sông: tấm bê tông nứt, hàng hoa trang đỏ cam/vàng, cọ hoàng hậu, cau thân trắng, dừa, chuối, bờ bùn nứt nẻ, sông rộng nước đục xanh olive, cây rừng nền xa.
2. Vườn rau miền Tây (ảnh TikTok): nhà mái tranh chữ A trên sàn gỗ có pin mặt trời, luống rau có viền bê tông lát hoa văn, cải bắp xanh nhạt, rau xanh, luống đất, hàng chậu nhựa đỏ trồng cây, giàn tre leo, hoa vàng (bầu/bí/hướng dương), lu sành, ao nước bên cạnh.
3. Mô hình ao ,hồ,sông,nước... phải có hiệu ứng và chiều sâu như mô hình có sẵn trong code

## 3. Cấu trúc project
- `project.yml` (XcodeGen) → tạo `VillageBuilder.xcodeproj`. `Resources/Models` là folder reference (giữ nguyên thư mục con). `Resources/catalog.json` (nhóm → danh sách id model OBJ), `Resources/sizes.json` (kích thước mặc định cho model không phải cây: `[0, chiều_cao]` hoặc `[1, chiều_dài_lớn_nhất]`).
- `Sources/App.swift`, `Sources/ContentView.swift` (UI, xem mục 7h), `Sources/Game.swift` (toàn bộ cảnh và logic).
- Model OBJ lấy từ file `CityBuilder_SaoLuu_PhanLoai.zip` của người dùng (122 thư mục, có `library.json` gán nhóm). Đã đưa vào các nhóm: Cây cối, Hoa & cây cảnh, Bụi & hàng rào, Điện & hạ tầng (chỉ còn `poteau-en-bois`), Ngoài trời & sân vườn, Động vật, Nhân vật, Nội thất (chỉ còn `candelabre`, `etabli`).
- **Đã bỏ theo yêu cầu người dùng (ưu tiên giữ cây cỏ, bỏ đồ hiện đại):** các nhóm Xe cộ, Đường & giao thông, Đồ bếp & gia dụng, và nội thất / đồ sân vườn / cột điện hiện đại. Đã xóa khỏi `catalog.json`, `Game.order`, danh sách `cats` trong `Sketch.swift` và xóa cả thư mục model. Đừng thêm lại nếu người dùng không yêu cầu. Vật cũ đã đặt thuộc các nhóm này sẽ không hiện nữa (dữ liệu `recs` vẫn còn, `spawn` bỏ qua id không có model).
- Build: GitHub Actions (`.github/workflows/build.yml`, macOS, xcodegen, xcodebuild không ký → `VillageBuilder.ipa`). Do giới hạn tải lên của GitHub mobile, project chia thành **ba** zip: `VillageBuilder_part1.zip` (TOÀN BỘ mã `Sources`, `project.yml`, `catalog.json`, `sizes.json`, tài liệu + một số model), `VillageBuilder_part2.zip` và `VillageBuilder_part3.zip` (part2/part3 chỉ có `Resources/Models/...`); workflow phải `unzip` cả ba vào cùng một thư mục (nếu `build.yml` chỉ liệt kê part1/part2 thì phải thêm part3, nếu không các model trong part3 như `coconutTree`, `tree`, `pine 2`, `dog-house`, `sycamoreMaple`... sẽ thiếu). **`build.yml` phải là file thường ở `.github/workflows/`, không nằm trong zip.** Mã nguồn chỉ nằm ở part1 nên khi sửa code / thêm chức năng chỉ cần tải lại part1; chỉ đụng tới part2/part3 khi thêm hoặc bỏ model (khi đó vẫn phải sửa `catalog.json` ở part1). Mỗi file zip phải < 25 MB.
- Khi đóng gói lại: bỏ thư mục `.github`, chia model theo dung lượng nén cho cân bằng, part1 chứa toàn bộ mã.

## 4. Quy ước hình học
- Đơn vị mét, trục Y hướng lên, gốc mô hình ở **tâm đáy** (y = 0 là mặt đất). Hướng "phía trước" của nhà là +z.
- Cảnh: đường bê tông chạy dọc −z (rộng 2,1 m, tấm 3 m), sông bên trái (x < −8), đất liền bên phải. Camera người đi bộ cao 1,6 m.
- Mô hình tự dựng đăng ký ở `procIds` (nhóm "Nhà & vườn") và dựng trong `procModel(_:)`, kết thúc bằng `root.flattenedClone()` để giảm số draw call. Mô hình OBJ được `proto(_:)` chuẩn hóa về chiều cao/chiều dài mục tiêu.
- Cây OBJ mới thêm phải có ảnh texture; `parseMtl` tự đọc `.mtl` và gắn `map_Kd` (SceneKit không tự nạp). Có cờ `Game.flipV` nếu texture bị ngược.

## 5. Bộ công cụ vẽ trong Game.swift (dùng lại, đừng viết lại)
- `meshGeo(P, UV, I)`: tạo SCNGeometry từ đỉnh/UV/chỉ số, tự tính pháp tuyến mượt.
- `leafGeo(L, W, arch, fold, mat)`: lá thon, cong (`arch` > 0 cong lên/ôm vào, < 0 rủ xuống), gấp dọc gân giữa (`fold`). Có cache theo tham số + tên vật liệu (luôn truyền vật liệu có `name`).
- `rosette(n, L, W, mat, outer:, inner:, arch:, fold:, radius:, step:)`: cụm lá xoay theo góc vàng; lá ngoài dài/phẳng, lá trong ngắn/dựng. Dùng cho rau, cỏ, cây chậu, cánh hoa (đặt `step` = 2π/số cánh để đều).
- `leafMat(key)`: vật liệu lá có gân/chuyển màu: grass, lettuce, cabbage, sun, petal, default.
- `lathe([(bán kính, độ cao)], seg)`: vật tiện tròn (chậu, lu, cột, đèn lồng).
- `cabbage`, `flower`, `sunflower`, `potNode`, `bedNode`, `houseNode`: ví dụ chuẩn về mức chi tiết cần đạt.
- Texture vẽ bằng mã: `makeTex` (đốm + vết nứt), `woodImg`, `thatchImg`, `tileImg`, `discImg`, `solarImg`, `leafImg`, `laneImg`. Mọi texture đều thêm nhiễu nhỏ để không bị phẳng.
- Mái lá: `thatchImg` (rơm vàng liền mạch) + `thatchRows(mat)` dựng các hàng tranh xếp lớp như ngói, mép dưới tua rua; dùng trong `houseNode`.
- Vật liệu nhanh: `mat(img, sx, sy)` (lặp texture), `pcol(r,g,b)`; khối: `pbox` (mặc định bo cạnh 0,012), `pcyl`, `psph`.

## 6. Cách thêm một mô hình tự dựng mới
1. Thêm tên vào `procIds`.
2. Thêm `case "Tên":` trong `procModel` hoặc viết hàm riêng (như `houseNode`).
3. Dựng theo checklist chi tiết: hình khối chính bo cạnh → lớp phụ (viền, khung, chân đế) → vật liệu có vân → ít nhất vài chi tiết nhỏ → cây/hoa/lá bằng `leafGeo`/`rosette`.
4. Giữ số node vừa phải (hàng trăm là ổn), dùng chung geometry/vật liệu, cuối cùng `flattenedClone()`.
5. Cập nhật README và file này nếu có quy ước mới.

## 7. Hiệu ứng đã có
- Nước sông: `makeWater` (shader hình học + fragment tạo sóng gợn), mực nước **đứng yên** (đã bỏ thủy triều / sóng đánh, chỉ còn sóng lăn tăn nhẹ); bờ bùn dốc `makeBank` có shader làm ướt/sẫm và sóng lăn tăn rất nhẹ ở mép nước (đã bỏ vệt bọt trắng) (cả hai dùng chung công thức `sin(t*0.5)*0.3`, đừng đổi một bên).
- Cây, bụi OBJ đung đưa: shader hình học `swayShader`, nút 🍃 chuyển tắt/nhẹ/mạnh. Mô hình tự dựng chưa đung đưa (đã flatten).
- Vẽ đường/mương: nhóm "Vẽ đường", chạm các điểm, ✔ hoàn tất; điểm cách điểm cũ < 2,5 m tự nối; góc tự bo bằng cung bezier (`smooth`), mặt đường là dải lưới (`ribbon`) kèm đầu bo tròn. Mương nước có thành bê tông + nước gợn.
- Vẽ tay: nút ✏️ (mặc định bật) trong nhóm "Vẽ đường" → kéo ngón tay, `strokeMove` thêm điểm mỗi ≥1,2 m và dựng lại đường ngay (đường mọc theo ngón tay), nhả tay thì `finish()`. Tắt ✏️ thì quay lại kiểu chạm từng điểm + ✔. Loại "Đường bê tông" (kind 3, rộng 2,1 m) dựng bằng `concreteRoad`: tấm 3 m có vết nứt giống đường chính, làm mượt bằng `chaikin`.
- Kéo vật đi chỗ khác: chế độ "Chọn", đặt ngón lên vật rồi kéo (`dragBegin/dragMove/dragEnd`); vật nhấc lên 0,25 m, có đĩa vàng + vòng + cột báo điểm đặt, thả tay thì hạ xuống và lưu.
- Hoàn tác: nút ↩ cam (`undoLast`, ngăn xếp `undoStack` gồm vật "p:id" và đường "r:id"); chế độ Chọn có nút 🗑 xóa vật đang chọn; chế độ Xóa chạm vào vật/đường để xóa.
- Mô hình dựng sẵn (hàng rào, cây ven đường) nằm trong `seedRecs` với id cố định `seedN` (sinh theo thứ tự rng, đừng đổi thứ tự gọi rng trong `seed()`); chỉnh sửa lưu ở `seedEdits`, xóa lưu ở `seedGone`. Dùng `recOf/setRec/dropRec` cho cả vật tự đặt lẫn vật dựng sẵn.
- Đường chính giờ là `RoadRec` id "main" (kind 3, tạo lần đầu theo cờ `mainInit`), nên chọn/xóa/nối thêm như mọi đường. Chế độ Chọn chạm vào đường/mương → `selectRoad` hiện `RoadPanel` (thẳng / cong trái / cong phải, đầu/cuối, dài m, bán kính m) → `extendRoad` thêm điểm vào cùng `pts` nên tự nối liền; hoàn tác bằng `undoPts`.
- Tạo hàng: chọn một vật (hàng rào, bụi, cỏ, hoa, cây...) → nút ▦ → `RowPanel` (thẳng / cong trái / cong phải, dài m, cách m, bán kính m, hướng nhìn hoặc theo vật) → `makeRow` nhân vật đó dọc theo đường thẳng/cung; hoàn tác theo nhóm (`undoGroups`). Mô hình có `sizes.json` kiểu `[1, dài]` là mô hình dạng dài (hàng rào) nên được xoay theo tiếp tuyến.
- Nhóm "Mẫu có sẵn" (`sampleIds`, `sampleModel`): mẫu lấy từ vật dựng sẵn trong cảnh (đoạn đường có cây 2 bên, tấm bê tông, khối bùn nứt, ao nước) để đặt chỗ khác; mô hình ghép từ OBJ không flatten để giữ shader đung đưa.
- `canalDiorama()` (mẫu "Mương nước quê (chiều sâu)"): đoạn mương 24 m dựng theo ảnh tham chiếu (mặt cắt bờ đất nhiễu tuần hoàn nên nối nhiều đoạn khít nhau, nước dưới mặt bờ có shader `waterFrag`, lục bình, chuối, cầu ván, xuồng `boatHull`, nhà tranh, giếng, dừa). Dùng ma trận simd (`mT/mRy/mRx/mS`, `rosetteInto`) thay vì node lồng nhau vì flattenedClone từng làm mất vị trí node lồng (lỗi mái nhà).
- Ảnh xem trước từng mô hình: `renderThumb` dùng SCNRenderer, tạo dần khi cuộn.
- Chọn / phóng to / thu nhỏ / xoay vật đã đặt (chế độ "Chọn", nút ➕ ➖ ↻, chụm hai ngón).

## 7b. Ao cá miền Tây (nhóm "Mẫu có sẵn", id `Game.pondId`)
- Mã nằm ở `Sources/Pond*.swift` (extension của `Game`): `PondTerrain` (viền ao siêu elip `pondR`, đáy ao, bờ, mặt nước shader), `PondFish` (cá 3 loại, lưới nuôi, `startPondLife`), `PondProps` (chòi tôn, cầu ao, ống/rod), `PondMore` (máy bơm + tia nước, guồng quạt, xuồng, bọt), `PondNature` (cây cỏ, lục bình, sen, bố cục `pondDiorama`).
- Tọa độ: tâm ao (0,0); mặt nước y = 0,62; đáy ~0,04 (sâu ~0,58 m); mặt bờ ~1,1; ngoài cùng y = 0. Vật đặt trên bờ dùng `bankFrame(θ, d)` (trục +z hướng vào ao); gộp mesh bằng `frameNode` + `flattenedClone`.
- Nước trong mờ (`transparency` 0,62) để thấy đáy, đá, rong, cá. Cá, guồng quạt, tia nước, vòng sóng KHÔNG gộp mesh vì có chuyển động; `Game.spawn` gọi `startPondLife` cho bản đặt (clone không chắc giữ action). Cá có tên `fish:cx,cz,a,b,y,w,phase,dir` (quỹ đạo elip), đuôi tên `tail`.
- Lưới nuôi/tia nước dùng ảnh có alpha (`transparent.contents` + `.aOne`, `writesToDepthBuffer = false`, `renderingOrder` cao).

- `Sources/Sampan.swift`: `sampanNode()` = Xuồng ba lá (nhóm "Nhà & vườn", dùng lại trong `pondBoat`): thân lưới mặt cắt `sec(t,q)` ghép ván (`plankImg`), cạp, sườn, 3 ghế, dây thừng, mái chèo. Gốc ở đáy xuồng, mũi +z.

## 7c. Nhân vật đi lại 🚶 + toàn màn hình
- `Sources/Avatar.swift` (extension Game): nút 🚶 (`walkMode` → `setWalk`). Người đi dạo là `walkAv` (nhân vật có xương, mục 7d) hoặc, khi chưa chọn (`walkCharacter == nil`), người mẫu cũ `mannequinMale` (OBJ tách bộ phận, hướng +z, cm) với tay/chân gom nhóm quanh khớp (`limbGroup`) đung đưa theo `walkPhase`. `stepAvatar(dt, dxw, dzw, mag, sp)` chạy mỗi khung hình từ `Game.step`: di chuyển + va chạm + độ cao + hoạt ảnh + camera đi sau lưng (`walkDist`; vuốt xoay, kéo xuống = nhìn từ cao).
- `groundY(x,z)`: độ cao nền, đi lên bờ ao / lội xuống đáy ao cho ao cá đã đặt; dùng cả cho camera người nhìn thứ nhất.
- Nút ⛶/⤡ (`fullscreen`): ẩn mọi bảng chọn, chỉ giữ joystick + 🚶 🏃 🏠; chạm không đặt vật, vuốt chỉ để nhìn quanh. Khi `walkMode` bật: vẫn dùng đúng `Joystick` cố định góc trái dưới (không còn `WalkPad`), thanh chọn dưới ẩn, `Game.tap` bỏ qua chạm.

## 7d. Nhân vật có xương, gắn xương, va chạm, NPC (đã chuyển từ CityBuilder-v12-clean.zip)
- File: `GLTFLoader.swift` (đọc GLB/GLTF/VRM, xương + hoạt ảnh), `CharacterRig.swift` (giao diện `WalkAvatar`; `RiggedAvatar` = nhân vật có xương chạy clip Idle/Walk/Run theo vận tốc thật, trộn mượt; `ClipLibrary` = hoạt ảnh nhập riêng ở `Documents/Animations`, tên file chứa Idle/Walk/Run/Jump, tên khác thành hành động ✨; `WalkEmote` = menu hoạt ảnh), `Rigging.swift` (`RigStore` lưu 15 khớp ở `UserDefaults` khóa `rig.points.<tên>`, `ProceduralRig` = xương tự dựng cho mô hình tĩnh, `RigEditorView` = màn chạm đặt khớp), `CharFiles.swift` (kho `Documents/Characters`, nhập zip/file lẻ, đọc OBJ bằng ModelIO; `CharFiles.builtinName` = người mẫu có sẵn đi qua `RiggedAvatar` để gắn xương thử, `builtinProvider` do `Game.ensureCharHooks()` gán), `WalkPad.swift` (cần ảo nửa trái, nhìn quanh nửa phải), `CharacterUI.swift` (`CharacterSheet` nút 👤: chọn nhân vật / nhập mô hình + hoạt ảnh / gắn xương / thả NPC; `WalkTools` ✨ ⟲ 🛩 ➖ ➕), `DocPicker.swift`, `NPC.swift`, `WalkWorld.swift`.
- Cần gói SPM **ZIPFoundation** (khai báo trong `project.yml`; xcodegen + xcodebuild tự tải). `UIFileSharingEnabled` bật để chép file vào Tệp → Làng Quê.
- Nối vào game: `Avatar.swift` (`makeWalker`, `placeWalker`, `useCharacter`, `reloadWalker` khi đổi nhân vật / vừa gắn xương / nhập hoạt ảnh; `walkPerform`, `walkTurnFace`…), biến trạng thái khai báo trong `Game.swift` (`walkAv`, `walkCharacter` lưu khóa `vb.walkChar`, `solids`, `avYT`, `wClimb`, `wSeat`, `walkDist`, `flyMode`, `npcs`). Tốc độ truyền cho `animate(speed:)` là m/s thật, ngưỡng chạy 5,5 m/s khớp 4/9 m/s của joystick. Hướng mặt từng nhân vật lưu `walk.face.<tên>` (nút ⟲ xoay 90°).
- `WalkWorld.swift` (viết lại cho vật đặt của Làng Quê; CityBuilder-v12 thực ra đã bỏ phần va chạm nên chỉ lấy thuật toán): `buildSolids()` quét node `placed:<id>` mỗi 1 s (bỏ cỏ, hoa, động vật, nhân vật, đường, ao, mẫu có sẵn, vật mỏng < 0,12 m; cây chỉ cản ngang gối). `sweepWalls` = tia ngang (cao hơn bậc 0,55 m + ngang ngực) để dừng / trượt dọc tường; `supportHeight` = tia xuống để bước lên bậc / sàn / mái; đẩy vào vật cản 0,35 s thì `startClimb` (leo tới 3,3 m, clip `.climb`); `findSeat` cho ngồi lên mặt ngang trước mặt. Độ cao đang đứng `avY`, đích `avYT`.
- Camera đi dạo: `walkDist` (mặc định 3,6 m), 🛩 `toggleFly` (40 m, nhìn xuống), ➖ ➕ `walkZoom`; ở cao thì đi nhanh hơn (`walkDist/10`).
- NPC: `NPCEntry` + `NPCDriver` (1 đi lang thang, 2 múa, 3 nhảy, 4 làm việc, 5 vẫy tay); lưu `UserDefaults` khóa `vb.npcs`, khôi phục bằng `restoreNPCs()` trong `ContentView.onAppear`; `Game.step` gọi `stepNPCs`. NPC chỉ theo `groundY`, chưa tránh vật cản.

## 7e. Nhập mô hình 3D vào thư viện đặt vật (nhóm "Mô hình nhập")
- File: `ModelLib.swift` (kho + phần mở rộng `Game`), `ObjLoader.swift` (bộ đọc OBJ + MTL riêng, chuyển từ `Builder.swift` của CityBuilder: giữ đúng màu Kd, texture map_Kd, độ trong suốt, tự tính pháp tuyến). Định dạng khác OBJ (GLB, GLTF, VRM, USDZ, DAE, SCN) đọc qua `CharFiles.loadScene`. FBX chưa đọc được (báo người dùng đổi sang GLB / USDZ / DAE).
- Lưu ở `Documents/Models` (mỗi mục là file lẻ hoặc thư mục .obj + .mtl + ảnh); app bật `UIFileSharingEnabled` nên chép tay qua Tệp → Làng Quê cũng được. Mã mô hình trong `Rec.item` là `"imp:" + tên mục` (`ModelLib.id/entry/display/isImp`); `Game.items["Mô hình nhập"]` dựng lại bằng `reloadImported()` (gọi trong `init` và sau mỗi lần nhập / xóa; `impRev` tăng để giao diện vẽ lại). Chip "Mô hình nhập" nằm CUỐI thanh nhóm; trong nhóm này ô đầu là nút ＋ "Nhập 3D" (`importModels()` → `DocPicker` → `ModelLib.add`), nhập xong tự chọn mô hình đầu tiên. Nhấn giữ một mô hình → "Xóa khỏi thư viện" (`deleteImported`: xóa file, thumbnail, và mọi bản đã đặt; đây là thao tác thư viện nên KHÔNG đi qua hoàn tác, nhưng `addRec` bỏ qua `imp:` đã mất file nên hoàn tác / làm lại cũ không lỗi).
- `proto(id)` gặp `imp:` thì gọi `impProto`: đoán đơn vị theo cạnh lớn nhất (0,3–30 → mét; 30–3000 → cm, nhân 0,01; còn lại co về 6 m; dưới 0,5 m thì phóng lên 0,5 m), căn giữa x/z, chân đặt y = 0, ambient đen + hai mặt (mục 9), vật liệu không màu → xám ấm. Đặt vẫn qua `placeRec` nên có hoàn tác (mục 11); ảnh xem trước qua `renderThumb` như mọi mô hình; chọn / kéo / xoay / phóng to / nhân bản / tạo hàng dùng chung cơ chế. Chưa có chuyển động cho mô hình nhập (không đung đưa, hoạt ảnh nhúng bị bỏ); hướng mặt không rõ nên dùng ↻ để xoay.
- `Game.tap` ở nhóm "Mô hình nhập" mà chưa chọn mô hình nhập nào thì chỉ báo "Bấm ＋ để nhập" (không đặt nhầm vật cũ).

## 7f. Thời tiết (`Weather.swift`, chuyển từ CityBuilder, đã chỉnh cho Làng Quê)
- 7 kiểu: nắng, nhiều mây, gió, mưa, giông bão, tuyết, sương mù. Chọn bằng nút 🌦 (Menu) cạnh nút 🍃; lưu `UserDefaults` khóa `weather`; `Game.weather` (didSet gọi `weatherSys.apply`). `WeatherSystem(scene:camera:ambient:sun:)` dựng ở `setupWeather()` (Horizon.swift, cuối `init`), dùng hai đèn `wxAmb` / `wxSun` lấy trong `buildTerrain`.
- Gồm: nền trời + hai mái vòm mây fractal (tính nền sau), hạt mưa / tuyết / sương / lá bay / bụi / tia nắng, sấm sét (đèn chớp + tia sét), và shader `.surface` chèn vào vật liệu để mặt ướt, vũng nước gợn, tuyết bám.
- Điểm nối đã xử lý (ĐỪNG phá): (a) cường độ nắng / ambient trong `look(_:)` đã đổi cho thế giới blinn của Làng Quê (nắng 1000 / ambient 650 ở trời nắng = đúng như trước); (b) `adoptSurface` BỎ QUA vật liệu có shader `.fragment` (nước sông, bờ bùn, mương, ao) nên shader nước không bị đè; (c) gió: `onWind` đặt `swayGain` (tối đa 2,2) và nhân vào biên độ `amp` của `swayShader`, nên nút 🍃 (tắt = 0) vẫn quyết định cuối cùng (`swayMul` đã gồm `swayGain`); (d) sương: `onFog` đặt `fogStart = 80 × f`, `fogEnd = 1600 × f` và gọi `setHorizonTone`; (e) `Game.step` gọi `cameraMoved` mỗi khung hình để hạt bám theo camera; (f) bóng đổ chỉ bật khi nắng > 300.
- Chưa làm: ban đêm / đổi giờ trong ngày.

## 7g. Chân trời (`Horizon.swift`)
- `horizonNode()` thêm vào cảnh ở `setupWeather()`; camera `zFar = 3000`. Dùng RNG riêng `hr` (KHÔNG dùng `Game.rng` để không lệch cảnh dựng sẵn, mục 13). Khung địa hình giả định: x −151…102, z −380…40 (sửa trong hàm nếu mở rộng đất).
- Gồm: (1) đồng ruộng vẽ bằng mã (thửa lúa, bờ, luống, kênh) trải 4 mảnh quanh khu đất tới 1800 m (y = −0,1, không chồng địa hình); (2) ~330 cây quanh khu đất theo 3 hàng + 150 cây rải xa: dừa (thân cong có đốt, 7–10 tàu lá cong rủ, buồng dừa), cây tán lá lốm đốm lá (xoài / mít), bụi tre (có mắt, chùm lá), chuối, nhà mái lá chữ A có sàn; tất cả gộp thành vài lưới theo chất liệu nên chỉ vài lần vẽ (≈ 180 nghìn đỉnh); (3) ba lớp rặng cây xa (R = 780 / 1050 / 1400 m, ảnh 4096×256 có alpha vẽ bằng mã: hàng cây thấp, dừa, cây tán tròn, cây nhọn, đúng cỡ thật theo mét/điểm ảnh, mờ dần về chân cây), `renderingOrder` −50…−52, `.constant`; độ sáng chỉnh theo sương qua `setHorizonTone`.
- Quy tắc phong cách (mục 1) giữ nguyên: lá có `arch`/`fold` và gân, tán cây có texture lá, không khối hộp / cầu trơn.
- Muốn thêm / bớt cây: đổi số vòng lặp `rim` / `placed`; nặng máy thì giảm 150 → 80 và hàng 3 → 2.

## 7h. Bố cục giao diện (`ContentView.swift`)
- Thành phần dùng chung: `ToolIcon` (nút tròn SF Symbols, `active` = xanh), `Dock` (nhóm nút nổi dạng viên thuốc mờ, dọc hoặc ngang). Mọi nút nổi mới PHẢI dùng hai thứ này để giữ đồng nhất; không thêm nút emoji rời.
- Hàng trên (`topBar`): ⚙ Cảnh (Menu: Thời tiết, Cây lay theo gió Tắt/Nhẹ/Mạnh qua `Game.setSway`) · Đặt / Chọn / Xóa · toàn màn hình. Ở toàn màn hình chỉ còn nút thu nhỏ.
- Cột trái dưới (`leftColumn`): hoàn tác / làm lại, RoadPanel / RowPanel, cần điều khiển `Joystick` (hiện cả khi đi dạo). Thông báo (`toast`) hiện giữa trên, không còn nút hoàn tác trong đó.
- Cột phải (`rightColumn`), theo nhóm: nhóm Vẽ (✍ phác thảo, ✏ vẽ tay, ✔ xong / ↩ bỏ điểm khi đang vẽ đường) chỉ khi chế độ Đặt; `WalkTools` (hoạt ảnh, xoay mặt, kéo gần / xa, bay) khi đi dạo; nhóm Đi dạo (nhân vật, đi bộ, chạy, về nhà). Khi mở phác thảo chỉ còn nút phóng to / thu nhỏ.
- Hàng dưới: `ActionBar` khi đang chọn vật; ngược lại `CatalogBar` (hàng nhóm + hàng mô hình, ô chọn viền xanh, nút ⌄ thu gọn thành một viên thuốc hiện vật đang chọn để nhường chỗ cho cảnh). Nhóm "Mô hình nhập" có ô ＋ viền đứt.
- Toàn màn hình (`Immersive.swift`): `Game.fullscreen` bật thì tự vào chế độ đi dạo (`walkBeforeFull` nhớ trạng thái cũ để trả lại khi thoát, xem `fullscreenChanged`) và ẨN mọi nút; chỉ còn `ImmersiveMenu` (nút ⋯ mờ góc trên phải: Thoát, Đổi nhân vật, Hoạt ảnh, Xoay mặt, Bay cao, Chạy / Đi bộ, Về nhà, Thời tiết, Cây lay). Điều khiển GIỐNG HỆT lúc không có người (người dùng yêu cầu, vì `WalkPad` cũ làm màn hình xoay loạn: một ngón ở mỗi nửa màn hình bị SwiftUI `MagnificationGesture` nhận nhầm là chụm, nên cần đi bị ngắt và camera zoom lung tung): `Joystick` cố định góc trái dưới, vuốt ở bất kỳ chỗ nào khác để nhìn quanh (`Coordinator.pan` → `g.look`, kiểm tra `walkMode` TRƯỚC các nhánh vẽ / kéo vật), chụm / mở 2 ngón → `Coordinator.pinch` gọi `g.walkZoom(1 / scale)`. `WalkPad.swift` vẫn còn trong project nhưng KHÔNG được dùng nữa; đừng gắn lại nếu không được yêu cầu. `sceneMenuSections` và `emoteMenuItems` dùng chung với menu ⚙ và nút ✨, đừng chép lại.
- Ẩn giao diện (`Game.hideUI`, nút 👁︎̸ `eye.slash` trong Dock góc trên phải, khác với ⛶ toàn màn hình vốn là đi dạo không nút): ẩn thanh trên, cột nút, thanh chọn vật, thông báo và thanh trạng thái; chỉ còn nút `eye` mờ góc trên phải để hiện lại và cần điều khiển (mờ 70%) khi không đi dạo. Trong lúc ẩn: chạm không đặt / chọn gì (`Game.tap`), kéo 1 ngón chỉ nhìn quanh, phác thảo tạm đóng (`sketchVisible` có `!hideUI`).
- Chụm / mở 2 ngón ở màn hình chính (`Coordinator.pinch`): phác thảo → `aerialZoom`; đang ở Chọn / Xóa và có vật chọn → `resize` vật; còn lại → `Game.zoomView` đổi góc nhìn camera 25°–85° (mặc định 70°, `home()` đặt lại). Khi đi dạo, chụm do `WalkPad` xử lý (đổi khoảng cách camera).
- Khoảng cách trên cùng 10 pt (bản cũ 54 pt); nếu nút bị che bởi tai thỏ / đảo động thì tăng `topBar.padding(.top, …)`.

## 7i. Tối ưu hiệu năng / giảm nóng (đã làm, KHÔNG được giảm chất lượng hình ảnh)
Máy thử: iPhone 12. Người dùng muốn bớt lag và nóng nhưng giữ nguyên hình ảnh.
- `ContentView.swift` (`Coordinator.renderer`): FPS thích ứng. 60 khi đang chạm / kéo / chụm / joystick, tụt về 30 sau ~1,5 s đứng yên (`touchedAt`, đặt `preferredFramesPerSecond` trên main). Cử chỉ mới thêm vào thì nhớ cập nhật `touchedAt`.
- Bóng: đèn mặt trời `maximumShadowDistance = 70` (Game.swift, `buildTerrain`); camera nhìn từ trên (`applyAerial`, Sketch.swift) nới theo `aerialH * 2.4`, thoát chế độ này trả về 70.
- `Weather.swift`: số hạt mưa / giọt bắn / tuyết giảm khoảng một nửa, hạt to hơn chút để mật độ nhìn tương đương. Shader ướt/tuyết (`SurfaceFX`) tự gỡ khỏi mọi chất liệu khi trời quang và đã khô (`stripSurfaces`, cờ `surfActive`).
- Đã cân nhắc nhưng KHÔNG làm: hạ `zFar` (Horizon cần `zFar = 3000`, sương mù tới 1600 để vẽ núi xa); gộp vật đã đặt bằng `flattenedClone` (làm hỏng chọn / di chuyển / xóa / hoàn tác từng vật). Còn một phương án cuối nếu vẫn nóng: MSAA 4X → 2X (`ContentView.swift`), đổi nhẹ hình ảnh nên chỉ làm khi người dùng đồng ý.

## 7j. Âm thanh (Sound.swift)
Toàn bộ tiếng được TẠO BẰNG CODE lúc chạy (AVAudioEngine), KHÔNG có file mp3 / wav nên không làm app nặng thêm. Singleton `SoundFX.shared`, khởi động ở cuối `Game.init` (`SoundFX.shared.start()`).
- Tiếng nền liên tục (`AmbientLoop`, `AVAudioSourceNode`): mưa, gió, nước lăn tăn (`.stream`, êm và đều, không dâng hạ; to dần khi `cam.position.x` tiến về sông x < −8, gọi `setStream` mỗi khung hình trong `Game.step`), nốt trầm kéo dài cho nhạc.
- Thời tiết: `rebuildParticles()` (Weather.swift) gọi `SoundFX.setWeather(weather, level:)` → chỉnh mưa / gió, bật chim hót khi trời nắng hoặc nhiều mây, nhạc nhỏ bớt khi mưa. `strike()` gọi `SoundFX.thunder(distance:)` (sấm tới trễ theo khoảng cách).
- Bước chân: `Avatar.stepAvatar` phát khi chân chạm đất (theo `walkPhase`, biến `Game.lastStepK`); `stepSurfaceKind()` chọn cỏ / nền cứng (đường bê tông id `main`, sàn, bậc) / ướt (mưa, giông).
- Thao tác: `Game.commit` → `cue(forAction:)` (tên bắt đầu "Đặt" → tiếng đặt, "Xóa" → tiếng xóa, còn lại tiếng tách nhỏ; chỉ phát ở bước mới, không phát lặp khi chụm / xoay liên tục), `undoLast` / `redoLast`, `select`.
- Nhạc nền: đàn gảy kiểu Karplus-Strong theo ngũ cung Rê, giai điệu đi ngẫu nhiên, qua bộ vang `AVAudioUnitReverb`. Muốn đổi bản nhạc sửa mảng `freqs` và hàm `playMelodyNote` trong Sound.swift.
- Bước chân kèm tiếng nhân vật: nhảy (`walkPerform(.jump)`, bay cao), tiếp đất (sau nhảy, sau leo, hạ xuống từ chế độ bay), leo (`startClimb`), ngồi (`walkPerform` với tư thế ngồi).
- Lá xào xạc (`AmbientLoop.leaves`): mức theo thời tiết nhân với mức "Cây lay" (`Game.setSway` → `SoundFX.setSway`; Tắt = im).
- Bật / tắt và âm lượng: menu ⚙ và ⋯ có mục "Âm thanh" (`Game.sfxOn`, `Game.musicOn`, lưu UserDefaults `snd.sfx` / `snd.music`) và nút "Âm lượng…" mở `SoundSheet` (SoundUI.swift) với 3 thanh trượt: nhạc nền (`snd.vmusic`), bước chân và thao tác (`snd.vsfx`), mưa / gió / suối / chim / lá (`snd.vamb`). Mặc định 0,7; hệ số thật = giá trị × 1,4. Audio session là `.ambient`: gạt công tắc im lặng của iPhone thì game cũng im; vào nền thì tạm dừng.
- Muốn tiếng thu thật: thêm file âm thanh vào bundle và phát bằng `AVAudioPlayerNode` thay cho buffer tương ứng; hiện chưa có. Lưu ý chưa được thử trên máy thật (môi trường dựng không có Swift), âm lượng các lớp có thể cần chỉnh lại.

## 7k. Ngày và đêm (Weather.swift, Horizon.swift, Sound.swift)
- Giờ trong ngày `WeatherSystem.hour` (0...24). `timeMode`: 0 tự động (một ngày đêm = `dayLength` = 900 s thật, `Timer` 0,5 s trên luồng chính, chỉ chạy khi ở chế độ này), 1 sáng 8h, 2 trưa 12h30, 3 chiều 17h24, 4 đêm 23h. Game lưu `timeMode` (UserDefaults `timeMode`) và giờ (`timeHour`). Menu ⚙ / ⋯ có mục "Thời gian".
- `applyTimeLook(_:force:)` gộp THỜI TIẾT (`look(weather)`) và GIỜ: nắng (đêm là ánh trăng xanh 70), đèn môi trường, `lightingEnvironment.intensity`, màu sương, độ tối của hai tầng mây (`multiply`), `castsShadow` (đêm tắt bóng cho nhẹ máy). `apply(_ w:)` gọi hàm này thay cho việc đặt đèn trực tiếp; mọi chỉnh sáng-tối khác phải đi qua đây, đừng đặt `sun.light` / `ambient.light` / `fogColor` ở chỗ khác.
- Hai mái vòm trong suốt trong `skyRoot`: `nightDome` (ảnh trời đêm có 900 sao, trăng; `renderingOrder -102`) và `duskDome` (ráng cam ở chân trời; `-101`), vẽ sau nền trời và trước mây (`-100` / `-99`), không ghi / đọc độ sâu nên không che địa hình. Độ mờ (`transparency`) theo `dayParams(hour)`: ngày 7h-17h, rạng đông ~6h20, hoàng hôn ~17h40.
- Hướng mặt trời KHÔNG đổi theo giờ (giữ nguyên để bóng và vầng mặt trời trên bầu trời khớp nhau). Chưa có đèn sáng trong nhà ban đêm.
- Rặng cây xa (`Horizon.swift`, vật liệu `.constant`): `setHorizonTone` nhân thêm `horizonDay` (do `ws.onDay` cập nhật) để tối đi ban đêm.
- Âm thanh: `SoundFX.setNight(_:)` (0 ngày ... 1 đêm): đêm có dế và ếch (`AmbientLoop.night`), chim hót tắt khi `nightAmt >= 0.3`, mưa thì tiếng côn trùng nhỏ bớt.
- Chưa xử lý: hạt mưa / tuyết vẫn sáng như ban ngày khi trời tối.

## 7l. Chụp ảnh, sao lưu và nhập làng (Backup.swift)
- `Game.takePhoto()`: `scnView.snapshot()` (chỉ ảnh khung cảnh 3D, không có nút), phát tiếng `shutter`, mở `ShareSheet` (Lưu ảnh, AirDrop...). `Game.scnView` là `weak`, gán trong `SceneUI.makeUIView`.
- `Game.exportVillage()`: gói các khóa UserDefaults `recs`, `roads`, `seedEdits`, `seedGone`, `vb.npcs` cùng thời tiết, cây lay, `timeMode`, `timeHour` thành `VillageBackup` (JSON, `Data` là base64) rồi chia sẻ file `LangQue_yyyyMMdd-HHmm.json`. KHÔNG gồm mô hình 3D người dùng tự nhập (thư mục Documents).
- `Game.importVillage()` (chọn file bằng `DocPicker`): kiểm tra `app == "langque"`, tự lưu làng hiện tại vào `Documents/LangQue_TruocKhiNhap.json`, ghi dữ liệu mới vào UserDefaults, đặt `importLock = true` (làm `save()` / `saveRoads()` / `saveNPCs()` / `autoBackup()` không ghi đè) và hiện hộp thoại chỉ có nút "Thoát app" (`exit(0)`): làng mới chỉ hiện sau khi mở lại app. Nếu thêm chỗ nào ghi `recs` / `roads` / `seedEdits` / `seedGone` / `vb.npcs` thì phải kiểm tra `importLock`.
- `Game.autoBackup()`: mỗi khi app ra nền tự ghi `Documents/LangQue_TuDongLuu.json` (xem được trong app Tệp nhờ `UIFileSharingEnabled`). Gỡ app thì bản này mất theo, nên vẫn cần xuất ra Tệp / iCloud.

## 8. Lưu ý kỹ thuật
- Mã chưa từng được biên dịch trong môi trường tạo ra nó (không có Xcode). Nếu build lỗi, người dùng gửi log; sửa theo log, giữ nguyên phong cách.
- Hiệu năng: dùng cache geometry, gộp bằng `flattenedClone`, tránh tạo geometry riêng cho từng lá. Đặt/xóa vẫn phải mượt trên iPhone đời cũ.
- Đã sửa lỗi model bị trắng bằng việc tự gắn texture từ `.mtl`; tên vật liệu trong `.mtl` khớp `SCNMaterial.name`, nếu không khớp thì gắn theo thứ tự.
- Người dùng làm trên điện thoại (GitHub mobile): luôn đưa lại đúng các file zip cần tải lên và nói rõ file nào cần thay.
- Camera đi dạo (cuối `stepAvatar`) đặt hướng bằng ma trận dựng từ `yaw` (phải = (cos yaw, 0, −sin yaw)), không dùng `look(at:)` vì từng làm cảnh bị nghiêng (roll) khi kéo qua lại. Muốn đổi cách đặt camera thì giữ trục phải nằm ngang.
- Tâm đặt vật (`Anchor.swift`): gốc của MỌI mô hình trong `proto()` phải nằm dưới chân (y = 0; x / z = giữa khung bao của lớp đỉnh thấp nhất, 3% chiều cao, hàm `baseCenter`), để cây tán lệch (đào, liễu, dừa nghiêng…) đứng đúng gốc thân và xoay / phóng to quanh gốc. `proto()` bọc mẫu trong một nút ngoài rồi dịch mẫu bên trong; KHÔNG đặt vị trí lên chính mẫu vì `spawn` ghi đè `position` của bản sao. Mẫu `sampleIds` (ao, mương, đoạn đường, bùn) giữ nguyên gốc do mã đặt. Vòng chọn / vòng kéo dùng `footRadius` (tính từ gốc). Mô hình mới thêm vào phải đi qua `proto()`.

## 9. Lỗi đã gặp (đừng lặp lại)
- Cây OBJ bị cháy trắng: file `.mtl` có `Ka 1 1 1`, SceneKit cộng thêm ánh sáng nền → phải đặt `material.ambient.contents = .black` cho mọi vật liệu OBJ (đã làm trong `proto`).
- Một số thư mục có file `.obj` khác tên thư mục (`birch 2`, `palm 2`, `pine 2`, `horse 2`, `yuccaPlant 2`...): luôn tìm file bằng `objURL`, không ghép tên theo thư mục.
- Texture có thể nằm trong thư mục con hoặc khác hoa thường: dùng `findTex`.
- `ScrollView` ngang trong `VStack` bị giãn chiều dọc, làm thanh chọn chiếm nửa màn hình: luôn đặt `.frame(height:)` cố định.

- Nút tràn mép / đè lên đồng hồ: `App.swift` từng gọi `ContentView().ignoresSafeArea()` nên giao diện nằm cả dưới tai thỏ / thanh trạng thái, và hàng trên (⚙ + Đặt/Chọn/Xóa + 👁⛶) rộng hơn màn hình iPhone 12 nên bị cắt ở mép phải. Đã sửa: bỏ `ignoresSafeArea()` ở gốc (chỉ `SceneUI` còn tràn viền), `Picker` Đặt/Chọn/Xóa co được (`minWidth 120, maxWidth 190`), lớp nút `.frame(width: geo.size.width)`. Khi thêm nút vào hàng trên nhớ cộng tổng bề rộng (iPhone nhỏ ~375 pt).

## 10. Logo ứng dụng
- Logo: `Resources/Assets.xcassets/AppIcon.appiconset/icon.png` (1024x1024, RGB, không trong suốt, không bo góc). Cảnh nhà mái lá trên sông, đường bê tông, dừa nghiêng, nắng chiều. Được vẽ bằng Python/Pillow (lưới 1024, vẽ gấp đôi rồi thu nhỏ). Khi đổi logo, giữ phong cách phẳng mềm, không chữ, vật chính ở giữa.

## 11. Hoàn tác ↩ / Làm lại ↪ (Game.swift, phần "Hoàn tác / Làm lại")
- Hai nút ↩ ↪ nằm trên joystick (ẩn khi toàn màn hình, và khi đang chấm điểm vẽ đường thì ↩ bên phải chỉ bỏ điểm cuối). Mỗi lần xóa / hoàn tác / làm lại có thanh thông báo nhỏ dưới thanh Đặt-Chọn-Xóa kèm nút ↩ ↪ (tự ẩn sau 4 giây).
- Cơ chế: `commit(tên, key:, undo:, redo:)` đẩy `Act` (hai closure) vào `undoStack`, xóa `redoStack`; tối đa 100 bước. `undoLast()` / `redoLast()` chuyển bước qua lại giữa hai ngăn xếp.
- Mọi thao tác thay đổi cảnh PHẢI đi qua hàm có ghi lịch sử: `placeRec` (đặt), `deletePlaced` (xóa vật), `deleteRoad` (xóa đường), `finish` (vẽ đường), `extendRoad` (nối), `makeRow` (tạo hàng), `recEdit` (di chuyển/xoay/phóng to). Hàm thô không ghi lịch sử, chỉ dùng bên trong closure undo/redo: `addRec`, `delRec`, `remove`, `addRoad`, `delRoad`, `removeRoad`, `setRoadPts`, `applyRec`. Thêm thao tác mới → viết cặp undo/redo bằng các hàm thô này, đừng gọi `remove` trực tiếp từ giao diện.
- `addRec`/`delRec` xử lý cả vật dựng sẵn `seedN` (khôi phục khỏi `seedGone`/`seedEdits`). Xoay/phóng to dùng `key` để các lần bấm/chụm liên tiếp trong 1,2 giây gộp thành một bước.


## 12. Chọn rồi mới thao tác (chế độ Chọn và Xóa)
- Cả hai chế độ Chọn (mode 1) và Xóa (mode 2) đều KHÔNG xóa ngay khi chạm: chạm vào vật thì `select` (vòng vàng + đĩa sáng nhấp nháy) và hiện `ActionBar` ở dưới: 🗑 Xóa, ✥ Di chuyển (bật `moving`, chạm mặt đất để chuyển tới đó; kéo trực tiếp vẫn được), ↻ Xoay, ➕ ➖, ⧉ Nhân bản, ▦ Tạo hàng. Chạm vào đường/mương thì hiện `RoadPanel` (có nút Xóa). Mọi thao tác đều có hoàn tác (mục 11). Chuyển sang chế độ Đặt (mode 0) thì bỏ chọn.

## 13. Vật dựng sẵn đều sửa được
- Mọi vật dựng sẵn là `Rec` id `seed…` (cây, hàng rào, hoa, và từ nay cả cỏ phủ nền `seedGn`, khối bùn ven bờ `seedRn` dùng mẫu "Cục bùn nứt", tấm bê tông nứt `seedS0`) → chọn / xóa / di chuyển / xoay / phóng to / nhân bản / hoàn tác như vật tự đặt. Trạng thái lưu ở `seedEdits` và `seedGone`.
- `buildTerrain` gom các vật này vào `extraSeeds`, `finishSeed` nối vào `seedRecs`. QUAN TRỌNG: phải giữ nguyên thứ tự và số lần gọi `rng.f` khi tạo địa hình (kể cả khi bỏ giá trị; mỗi tuft cỏ cũ tiêu thụ 12 lần rng trong `rosette`, nay mô phỏng bằng vòng lặp 12 lần), nếu không các vật `seedN` cũ đổi vị trí và bản lưu của người dùng sẽ lệch. Vật dựng sẵn mới nên dùng id có tiền tố `seed` khác (vd `seedX0`) để không trùng.
- Chưa sửa được: mặt đất, sông, bờ bùn dốc (địa hình nền). Đường bê tông chính là đường id `main` (xóa được qua RoadPanel).

## 14. Chọn vật khi chạm (`pickAt` / `rawPick`)
- Tia chạm (`hitTest` kiểu .all) có thể trúng nhiều thứ. `rawPick` ưu tiên: vật (nhóm 0) > mảng cỏ nền (nhóm 1) > đường (nhóm 2); cùng nhóm lấy vật gần nhất. Nhờ vậy vật nhỏ (máy giặt, ghế...) đặt giữa cỏ hoặc trên đường vẫn chọn được. Khi chạm trượt, `pickAt(near: true)` thử thêm 16 và 32 điểm xung quanh (vật nhỏ khó chạm trúng). Kéo vật (`dragBegin`) dùng `near: false` để vuốt xoay camera không vô tình bắt vật.
- Giới hạn kéo/di chuyển vật theo phạm vi mặt đất: x −14…100, z ≤ 38 (trước đây 60 / 8 làm vật đặt xa bị kéo giật về).

## 15. Bảng vẽ nét 2D (Sketch.swift) — đường / mương / hàng rào
- `SketchModel` (khung dưới, SwiftUI `Canvas` + `SketchTouch` bằng UIKit: 1 ngón vẽ, 2 ngón chụm / kéo) và `extension Game` cùng file. Trạng thái trong `Game`: `sketchOpen`, `sketchVisible` (= mở && mode == 0 && không toàn màn hình), `sketchCam`, `aerialC/aerialH`.
- Khi `sketchVisible`, `ContentView` chia màn hình: `SceneUI` ở trên, `SketchPanel` cao 46% ở dưới; camera chuyển sang nhìn xuống 57° (`applyAerial`), yaw = 0 nên trục khớp khung dưới (x sang phải, z xuống). Thoát thì `refreshSketchCam` trả lại camera cũ. `step()` thoát sớm khi `sketchCam`; joystick lúc này là di chuyển tâm nhìn; chạm khung 3D bị bỏ qua (`tap`).
- Nét thẳng: 2 điểm; nét cong: `fit` = RDP lọc điểm + Catmull-Rom. Đầu nét dính vào đầu đường cũ / hàng cũ trong 20 px (`nearestEnd`), nên `commitRoadStroke` nối vào `RoadRec` cùng loại (đảo chiều nếu cần) bằng `setRoadPts`, có hoàn tác. Mô hình không phải 4 loại đường (`kinds`) thì đi theo `rowRecs`: đặt vật cách nhau `sk.spacing`, vật dài (`rowSpec.aligned`) xoay theo nét, vật tròn thì xoay ngẫu nhiên; nét sau dính đầu nét trước thì bỏ vật đầu.
- Khi đang kéo, `sketchPreview` dựng tạm nút `sketch3d` (cập nhật mỗi 0,07 s); thả tay mới tạo thật (`sketchCommit`).
- `link` (🔗): `syncFromAerial` / `syncFromSketch` giữ hai khung cùng tâm và cùng độ phóng (xấp xỉ: chiều cao camera ≈ bề rộng khung / (1,17 × tỉ lệ)).
- Đã thêm nhưng CHƯA biên dịch được ở môi trường tạo ra nó; nếu build lỗi, sửa theo log.

## 16. Việc cần làm tiếp (làm xong mục nào thì XÓA mô tả mục đó, ghi vào mục 7x)
Nguồn: `CityBuilder-v12-clean.zip` của người dùng. Không lấy công cụ vẽ đường / tường / bản đồ (Làng Quê đã có `Sketch.swift`). Đã xong: nhập mô hình 3D (7e), thời tiết (7f), chân trời (7g).
1. Tùy chọn: chuyển động cho mô hình nhập (đung đưa, lá lay, đi vòng); sao lưu / khôi phục dự án (CityBuilder: `Library.swift` `backup()` / `restoreBackup`); đổi giờ trong ngày.
Cần kiểm tra trên máy thật (mã chưa từng biên dịch): thời tiết có làm tối / sáng sai (so với bản trước) không; shader ướt có đè nước không; chân trời có nặng máy không (giảm số cây, mục 7g); rặng cây xa có lộ mép / lặp lại không; mô hình nhập: đơn vị đoán sai, texture ngược; va chạm có cản quá tay / giật không (`buildSolids`); NPC chưa tránh vật cản. Chưa làm và chưa cần: làm mờ vách khi vào nhà rỗng, nhân vật ảnh phẳng (`PhotoAvatar`).

## 10. Tải nhẹ khi mở app và khi làng lớn (đã thêm 26/10/2026)
- `Game.init` không dựng cảnh một lượt nữa: dựng đường → dựng vật theo lô (`spawnBatched`, có màn hình "Đang tải" và tên model đang nạp, `loadNote`) → trời / chân trời / âm thanh (`finishLoad`). Dữ liệu lưu (`recs`, `roads`, `seedEdits`, `seedGone`) vẫn đọc ngay trong init để `save()` không ghi đè rỗng.
- `Cull.swift`: vật "placed:" cách camera > 190 m (ngang mặt đất) bị ẩn, vào trong 170 m hiện lại; mẫu lớn (`sampleIds`) và đường không bị ẩn; tắt khi nhìn từ trên xuống (bảng vẽ nét). Chỉnh ngưỡng ở `Game.cullShow / cullHide`.
- Texture vẽ bằng code dùng `Game.fmtTex` (tối đa 2x); texture OBJ thu về ≤ 1024px (`Game.capImage`); cỏ dùng 4 mẫu `grassProtos`.


## 7m. Địa hình thật hơn (Terrain.swift)
- Texture nền cỏ / đất dựng bằng nhiễu nhiều tầng + normal map (`TerrainTex.build`), chạy ở luồng nền; lúc đầu hiện ảnh `makeTex` cũ, xong thì thay (`groundMat`). Lớp `multiply` ~40 m phá lặp ô.
- Gò đất: `moundModel` / `moundGeo` (nhóm "Mẫu có sẵn": "Gò đất cỏ", "Gò đất nâu"); rải sẵn 38 gò id `seedM0…seedM37` ở cuối `buildTerrain`, tránh dải đường (x < 4,6 + 3,5·tỉ lệ). Gò cao 0,12–0,5 m, nhân vật đi dạo không bị chặn (nhóm "Mẫu có sẵn" không thành vật cản) nên chân hơi lún khi bước lên gò.

## 7e. Thị trấn cổ (Sources/Town.swift, extension Game)
- Dựng theo ảnh thị trấn trong volamweb (`img/z/town.jpg`) nhưng là mô hình 3D thật, KHÔNG dùng ảnh 2D của volamweb. Nhóm mới **"Thị trấn"** (`Game.townIds`): Nhà ngói đỏ, Nhà ngói xám, Tường đỏ, Cổng bài phường, Tháp canh gạch, Đường lát đá. Trong nhóm "Mẫu có sẵn": **Hồ tường gạch** (nước dùng `canalWater`, không flatten) và **Thị trấn cổ (mẫu)** (khu sân có tường đỏ bao, chính điện, 4 nhà xám, 2 tháp canh, cổng bài phường, đường lát đá, hồ và cây OBJ `tree` / `pine 2`).
- `townRoof(...)`: mái hai dốc lõm có mép + hai đầu vểnh, hàng ngói ống, diềm mái, đầu ngói tròn, bờ nóc + sừng + nụ vàng, tường hồi lấp hở. Mọi hình dựng bằng `meshGeo` trong tọa độ tuyệt đối (không lồng node) nên `flattenedClone()` an toàn.
- Texture vẽ bằng mã trong `townDraw` (ngói đỏ/xám, gạch xám/nâu, đá xếp, vôi, tường đỏ bong tróc, lát đá, chấn song); `tmat(kind, sx, sy)` cache vật liệu trong `leafMats` khóa `T:`; `tBox` tự tính số lần lặp texture theo kích thước thật; `tLac` = sơn son / gỗ tối / vàng / đèn lồng.
- Tường đỏ và Đường lát đá dài theo trục x và có trong `sizes.json` kiểu `[1, 6]` để dùng với nút ▦ tạo hàng.
- File này viết khi chưa có máy biên dịch Swift: nếu GitHub Actions báo lỗi cú pháp thì sửa trong `Town.swift`, đừng đổi API của `Game.swift`.


## 7n. Quái vật & Boss + Đào hoa (Beasts.swift, Blossom.swift) — ĐÃ LÀM theo cách 2 (vẽ 3D bằng mã)
- Nhóm mới **"Quái vật"** (`Game.beastIds`, 17 con): Hổ Đông Bắc, Hổ Hoa Nam, Bạch Hổ, Hỏa Hổ (Boss), Kim Tiền Báo, Báo Trắng, Sói Xám/Đỏ/Xanh/Tuyết, Hồ Ly, Heo Rừng, Heo Trắng, Hươu Đốm, Kim Miêu, Nhím, Đại Tượng (Boss). Thêm vào nhóm "Cây cối" (`Game.blossomIds`): Đào hoa, Đào hoa nhỏ, Bụi hoa đào.
- `Beasts.swift`: `BeastSpec` + `beastSpec(id)` (thông số từng con), `bLoft` (ống Catmull-Rom, khung ax × ay = hướng đi nên pháp tuyến hướng ra ngoài), `beastDraw` (texture lông vằn / đốm hoa / lông / nếp da, đối xứng lưng–bụng), `quadruped` (thân, cổ, chân, đuôi, bờm, lông nhím), `beastHead` (cat / wolf / fox / boar / deer / elephant / porc: tai, mắt, mũi, ria, nanh, ngà, vòi, gạc). Gốc ở chân, mặt +z, KHÔNG flatten (có hoạt ảnh).
- Hoạt ảnh `startBeastLife` (gọi trong `Game.spawn`): nút `roam:R:chu kỳ:biên độ chân:số nhịp` đi vòng số 8 quanh chỗ đặt (không đổi toạ độ lưu), chân chéo bước, đuôi vẫy, đầu gật, tai giật, vòi lắc. Chưa tránh vật cản / ao; nhóm "Quái vật" nằm trong skip của `buildSolids`, Terrain, Horizon.
- `Blossom.swift`: thân + cành bằng `bLoft`, tán là các cụm elip phủ bông 5 cánh (khía đầu, nhị vàng) gộp một lưới (`BMesh`), cánh rơi dưới gốc. Cây tĩnh.
- CHƯA BIÊN DỊCH, CHƯA CHẠY THỬ. Việc đầu tiên: build GitHub Actions, sửa lỗi theo log; xem từng con, chỉnh tỉ lệ (thông số trong `beastSpec`, profile đầu trong `beastHead`). Chưa làm: chiến đấu / máu / hoạt ảnh đánh, chết; quái đi lang thang tránh vật cản.


## 7f. Khu nhà sân vườn miền Tây (Sources/WestGarden.swift, extension Game)
- Mẫu ghép sẵn trong "Mẫu có sẵn": `Game.westGardenId`, đăng ký ở `sampleIds` + `sampleModel` -> `westGardenDiorama()`. Nhà dựng bằng `wgHouse` (nền đá, tường vôi + chân gạch, hiên cột, mái hai dốc `wgGableRoof` ngói đỏ/xám hoặc tôn bạc/xanh), mương có đáy + bờ bậc + `canalWater`, cây dừa/ficus/hoa dùng OBJ qua `proto`, chuối + lúa dùng `rosette`, xuồng `sampanNode()`. Mã chưa được biên dịch lúc viết: nếu CI báo lỗi, sửa trong file này.
