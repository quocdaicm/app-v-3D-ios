# HƯỚNG DẪN CHO AI TIẾP THEO — game "Làng Quê" (VillageBuilder)

Đọc kỹ file này trước khi sửa hoặc vẽ thêm bất cứ thứ gì. Người dùng nói **tiếng Việt**, trả lời bằng tiếng Việt, ngắn gọn, đưa file đã đóng gói sẵn để tải lên GitHub.

## 1. Mục tiêu và phong cách (QUAN TRỌNG NHẤT)
- Game iOS dựng làng quê miền Tây Việt Nam, góc nhìn người đi bộ (joystick), SwiftUI + SceneKit.
- Người dùng yêu cầu rõ: **nét vẽ chuyên nghiệp, đẹp, uyển chuyển, mềm mại; lá, vườn, mọi vật đều có chi tiết rõ ràng.**
- Vì vậy KHÔNG dựng bằng khối hộp/cầu trơn. Luôn dùng: lá có cong và gân, cạnh bo (chamfer), vật tiện tròn (lathe), texture vẽ bằng mã có vân/nhiễu, các lớp chồng lên nhau, chi tiết nhỏ (đai buộc, ốc, đầu phun, vân gỗ...). Mỗi mô hình mới phải có tối thiểu 4–5 chi tiết phụ nhìn rõ được.
- Màu tự nhiên, hơi bạc nắng, không bão hòa gắt. Có vết bẩn/nứt/rêu ở vật bê tông, đất.
- Không có hệ thống xu/tiền. Người dùng đã yêu cầu BỎ; đừng thêm lại giá, xu, thu nhập.

## 2. Ảnh tham chiếu người dùng đã đưa
1. Con đường bê tông hẹp ven sông: tấm bê tông nứt, hàng hoa trang đỏ cam/vàng, cọ hoàng hậu, cau thân trắng, dừa, chuối, bờ bùn nứt nẻ, sông rộng nước đục xanh olive, cây rừng nền xa.
2. Vườn rau miền Tây (ảnh TikTok): nhà mái tranh chữ A trên sàn gỗ có pin mặt trời, luống rau có viền bê tông lát hoa văn, cải bắp xanh nhạt, rau xanh, luống đất, hàng chậu nhựa đỏ trồng cây, giàn tre leo, hoa vàng (bầu/bí/hướng dương), lu sành, ao nước bên cạnh.

## 3. Cấu trúc project
- `project.yml` (XcodeGen) → tạo `VillageBuilder.xcodeproj`. `Resources/Models` là folder reference (giữ nguyên thư mục con). `Resources/catalog.json` (nhóm → danh sách id model OBJ), `Resources/sizes.json` (kích thước mặc định cho model không phải cây: `[0, chiều_cao]` hoặc `[1, chiều_dài_lớn_nhất]`).
- `Sources/App.swift`, `Sources/ContentView.swift` (UI: joystick, nút 🏃 🏠 🍃, thanh nhóm, thanh mô hình có ảnh xem trước, chế độ Đặt/Chọn/Xóa), `Sources/Game.swift` (toàn bộ cảnh và logic).
- Model OBJ lấy từ file `CityBuilder_SaoLuu_PhanLoai.zip` của người dùng (122 thư mục, có `library.json` gán nhóm). Đã đưa vào các nhóm: Cây cối, Hoa & cây cảnh, Bụi & hàng rào, Xe cộ, Đường & giao thông, Điện & hạ tầng, Ngoài trời & sân vườn, Động vật, Nhân vật, Nội thất, Đồ bếp & gia dụng.
- Build: GitHub Actions (`.github/workflows/build.yml`, macOS, xcodegen, xcodebuild không ký → `VillageBuilder.ipa`). Do giới hạn tải lên của GitHub mobile, project chia thành `VillageBuilder_part1.zip` (mã + một nửa model) và `VillageBuilder_part2.zip`; workflow tự `unzip` cả hai. **`build.yml` phải là file thường ở `.github/workflows/`, không nằm trong zip.** Mã nguồn chỉ nằm ở part1 nên thường chỉ cần tải lại part1. Mỗi file zip phải < 25 MB.
- Khi đóng gói lại: bỏ thư mục `.github`, chia model theo dung lượng nén cho cân bằng, part1 chứa toàn bộ mã.

## 4. Quy ước hình học
- Đơn vị mét, trục Y hướng lên, gốc mô hình ở **tâm đáy** (y = 0 là mặt đất). Hướng "phía trước" của nhà là +z.
- Cảnh: đường bê tông chạy dọc −z (rộng 2,1 m, tấm 3 m), sông bên trái (x < −8), đất liền bên phải. Camera người đi bộ cao 1,6 m.
- Mô hình tự dựng đăng ký ở `procIds` (nhóm "Nhà & vườn") và dựng trong `procModel(_:)`, kết thúc bằng `root.flattenedClone()` để giảm số draw call. Mô hình OBJ được `proto(_:)` chuẩn hóa về chiều cao/chiều dài mục tiêu.
- Cây OBJ mới thêm phải có ảnh texture; `parseMtl` tự đọc `.mtl` và gắn `map_Kd` (SceneKit không tự nạp). Có cờ `Game.flipV` nếu texture bị ngược.

## 5. Bộ công cụ vẽ trong Game.swift (dùng lại, đừng viết lại)
- `meshGeo(P, UV, I)`: tạo SCNGeometry từ đỉnh/UV/chỉ số, tự tính pháp tuyến mượt.
- `leafGeo(L, W, arch, fold, mat)`: lá thon, cong (`arch` > 0 cong lên/ôm vào, < 0 rủ xuống), gấp dọc gân giữa (`fold`). Có cache theo tham số + tên vật liệu (luôn truyền vật liệu có `name`).
- `rosette(n, L, W, mat, outer:, inner:, arch:, fold:, radius:, step:)`: cụm lá xoay theo góc vàng; lá ngoài dài/phẳng, lá trong ngắn/dựng. Dùng cho rau, cỏ, cây chậu, cánh hoa (đặt `step` = 2π/số cánh để đều).
- `leafMat(key)`: vật liệu lá có gân/chuyển màu: grass, lettuce, cabbage, sun, petal, default.
- `lathe([(bán kính, độ cao)], seg)`: vật tiện tròn (chậu, lu, cột, đèn lồng).
- `cabbage`, `flower`, `sunflower`, `potNode`, `bedNode`, `houseNode`: ví dụ chuẩn về mức chi tiết cần đạt.
- Texture vẽ bằng mã: `makeTex` (đốm + vết nứt), `woodImg`, `thatchImg`, `tileImg`, `discImg`, `solarImg`, `leafImg`, `laneImg`. Mọi texture đều thêm nhiễu nhỏ để không bị phẳng.
- Vật liệu nhanh: `mat(img, sx, sy)` (lặp texture), `pcol(r,g,b)`; khối: `pbox` (mặc định bo cạnh 0,012), `pcyl`, `psph`.

## 6. Cách thêm một mô hình tự dựng mới
1. Thêm tên vào `procIds`.
2. Thêm `case "Tên":` trong `procModel` hoặc viết hàm riêng (như `houseNode`).
3. Dựng theo checklist chi tiết: hình khối chính bo cạnh → lớp phụ (viền, khung, chân đế) → vật liệu có vân → ít nhất vài chi tiết nhỏ → cây/hoa/lá bằng `leafGeo`/`rosette`.
4. Giữ số node vừa phải (hàng trăm là ổn), dùng chung geometry/vật liệu, cuối cùng `flattenedClone()`.
5. Cập nhật README và file này nếu có quy ước mới.

## 7. Hiệu ứng đã có
- Nước sông: `makeWater` (shader hình học + fragment tạo sóng gợn), mặt nước **lên xuống như thủy triều**; bờ bùn dốc `makeBank` có shader làm ướt/sẫm và vệt bọt ở mép nước (cả hai dùng chung công thức `sin(t*0.5)*0.3`, đừng đổi một bên).
- Cây, bụi OBJ đung đưa: shader hình học `swayShader`, nút 🍃 chuyển tắt/nhẹ/mạnh. Mô hình tự dựng chưa đung đưa (đã flatten).
- Vẽ đường/mương: nhóm "Vẽ đường", chạm các điểm, ✔ hoàn tất; điểm cách điểm cũ < 2,5 m tự nối; góc tự bo bằng cung bezier (`smooth`), mặt đường là dải lưới (`ribbon`) kèm đầu bo tròn. Mương nước có thành bê tông + nước gợn.
- Ảnh xem trước từng mô hình: `renderThumb` dùng SCNRenderer, tạo dần khi cuộn.
- Chọn / phóng to / thu nhỏ / xoay vật đã đặt (chế độ "Chọn", nút ➕ ➖ ↻, chụm hai ngón).

## 8. Lưu ý kỹ thuật
- Mã chưa từng được biên dịch trong môi trường tạo ra nó (không có Xcode). Nếu build lỗi, người dùng gửi log; sửa theo log, giữ nguyên phong cách.
- Hiệu năng: dùng cache geometry, gộp bằng `flattenedClone`, tránh tạo geometry riêng cho từng lá. Đặt/xóa vẫn phải mượt trên iPhone đời cũ.
- Đã sửa lỗi model bị trắng bằng việc tự gắn texture từ `.mtl`; tên vật liệu trong `.mtl` khớp `SCNMaterial.name`, nếu không khớp thì gắn theo thứ tự.
- Người dùng làm trên điện thoại (GitHub mobile): luôn đưa lại đúng các file zip cần tải lên và nói rõ file nào cần thay.
