# HƯỚNG DẪN CHO AI TIẾP THEO — game "Làng Quê" (VillageBuilder)

Đọc kỹ file này trước khi sửa hoặc vẽ thêm bất cứ thứ gì. Người dùng nói **tiếng Việt**, trả lời bằng tiếng Việt, ngắn gọn, đưa file đã đóng gói sẵn để tải lên GitHub.

## 1. Mục tiêu và phong cách (QUAN TRỌNG NHẤT)
- Game iOS dựng làng quê miền Tây Việt Nam, góc nhìn người đi bộ (joystick), SwiftUI + SceneKit.
- Người dùng yêu cầu rõ: **nét vẽ chuyên nghiệp, đẹp, uyển chuyển, mềm mại; lá, vườn, mọi vật đều có chi tiết rõ ràng.**
- Vì vậy KHÔNG dựng bằng khối hộp/cầu trơn. Luôn dùng: lá có cong và gân, cạnh bo (chamfer), vật tiện tròn (lathe), texture vẽ bằng mã có vân/nhiễu, các lớp chồng lên nhau, chi tiết nhỏ (đai buộc, ốc, đầu phun, vân gỗ...). Mỗi mô hình mới phải có tối thiểu 4–5 chi tiết phụ nhìn rõ được.
- Màu tự nhiên, hơi bạc nắng, không bão hòa gắt. Có vết bẩn/nứt/rêu ở vật bê tông, đất.
- Không có hệ thống xu/tiền. Người dùng đã yêu cầu BỎ; đừng thêm lại giá, xu, thu nhập.

## 2. Ảnh tham chiếu người dùng đã đưa
1. Con đường bê tông hẹp ven sông: tấm bê tông nứt, hàng hoa trang đỏ cam/vàng, cọ hoàng hậu, cau thân trắng, dừa, chuối, bờ bùn nứt nẻ, sông rộng nước đục xanh olive, cây rừng nền xa.
2. Vườn rau miền Tây (ảnh TikTok): nhà mái tranh chữ A trên sàn gỗ có pin mặt trời, luống rau có viền bê tông lát hoa văn, cải bắp xanh nhạt, rau xanh, luống đất, hàng chậu nhựa đỏ trồng cây, giàn tre leo, hoa vàng (bầu/bí/hướng dương), lu sành, ao nước bên cạnh.

## 3. Cấu trúc project
- `project.yml` (XcodeGen) → tạo `VillageBuilder.xcodeproj`. `Resources/Models` là folder reference (giữ nguyên thư mục con). `Resources/catalog.json` (nhóm → danh sách id model OBJ), `Resources/sizes.json` (kích thước mặc định cho model không phải cây: `[0, chiều_cao]` hoặc `[1, chiều_dài_lớn_nhất]`).
- `Sources/App.swift`, `Sources/ContentView.swift` (UI: joystick, nút 🏃 🏠 🍃, thanh nhóm, thanh mô hình có ảnh xem trước, chế độ Đặt/Chọn/Xóa), `Sources/Game.swift` (toàn bộ cảnh và logic).
- Model OBJ lấy từ file `CityBuilder_SaoLuu_PhanLoai.zip` của người dùng (122 thư mục, có `library.json` gán nhóm). Đã đưa vào các nhóm: Cây cối, Hoa & cây cảnh, Bụi & hàng rào, Xe cộ, Đường & giao thông, Điện & hạ tầng, Ngoài trời & sân vườn, Động vật, Nhân vật, Nội thất, Đồ bếp & gia dụng.
- Build: GitHub Actions (`.github/workflows/build.yml`, macOS, xcodegen, xcodebuild không ký → `VillageBuilder.ipa`). Do giới hạn tải lên của GitHub mobile, project chia thành `VillageBuilder_part1.zip` (mã + một nửa model) và `VillageBuilder_part2.zip`; workflow tự `unzip` cả hai. **`build.yml` phải là file thường ở `.github/workflows/`, không nằm trong zip.** Mã nguồn chỉ nằm ở part1 nên thường chỉ cần tải lại part1. Mỗi file zip phải < 25 MB.
- Khi đóng gói lại: bỏ thư mục `.github`, chia model theo dung lượng nén cho cân bằng, part1 chứa toàn bộ mã.

## 4. Quy ước hình học
- Đơn vị mét, trục Y hướng lên, gốc mô hình ở **tâm đáy** (y = 0 là mặt đất). Hướng "phía trước" của nhà là +z.
- Cảnh: đường bê tông chạy dọc −z (rộng 2,1 m, tấm 3 m), sông bên trái (x < −8), đất liền bên phải. Camera người đi bộ cao 1,6 m.
- Mô hình tự dựng đăng ký ở `procIds` (nhóm "Nhà & vườn") và dựng trong `procModel(_:)`, kết thúc bằng `root.flattenedClone()` để giảm số draw call. Mô hình OBJ được `proto(_:)` chuẩn hóa về chiều cao/chiều dài mục tiêu.
- Cây OBJ mới thêm phải có ảnh texture; `parseMtl` tự đọc `.mtl` và gắn `map_Kd` (SceneKit không tự nạp). Có cờ `Game.flipV` nếu texture bị ngược.

## 5. Bộ công cụ vẽ trong Game.swift (dùng lại, đừng viết lại)
- `meshGeo(P, UV, I)`: tạo SCNGeometry từ đỉnh/UV/chỉ số, tự tính pháp tuyến mượt.
- `leafGeo(L, W, arch, fold, mat)`: lá thon, cong (`arch` > 0 cong lên/ôm vào, < 0 rủ xuống), gấp dọc gân giữa (`fold`). Có cache theo tham số + tên vật liệu (luôn truyền vật liệu có `name`).
- `rosette(n, L, W, mat, outer:, inner:, arch:, fold:, radius:, step:)`: cụm lá xoay theo góc vàng; lá ngoài dài/phẳng, lá trong ngắn/dựng. Dùng cho rau, cỏ, cây chậu, cánh hoa (đặt `step` = 2π/số cánh để đều).
- `leafMat(key)`: vật liệu lá có gân/chuyển màu: grass, lettuce, cabbage, sun, petal, default.
- `lathe([(bán kính, độ cao)], seg)`: vật tiện tròn (chậu, lu, cột, đèn lồng).
- `cabbage`, `flower`, `sunflower`, `potNode`, `bedNode`, `houseNode`: ví dụ chuẩn về mức chi tiết cần đạt.
- Texture vẽ bằng mã: `makeTex` (đốm + vết nứt), `woodImg`, `thatchImg`, `tileImg`, `discImg`, `solarImg`, `leafImg`, `laneImg`. Mọi texture đều thêm nhiễu nhỏ để không bị phẳng.
- Mái lá: `thatchImg` (rơm vàng liền mạch) + `thatchRows(mat)` dựng các hàng tranh xếp lớp như ngói, mép dưới tua rua; dùng trong `houseNode`.
- Vật liệu nhanh: `mat(img, sx, sy)` (lặp texture), `pcol(r,g,b)`; khối: `pbox` (mặc định bo cạnh 0,012), `pcyl`, `psph`.

## 6. Cách thêm một mô hình tự dựng mới
1. Thêm tên vào `procIds`.
2. Thêm `case "Tên":` trong `procModel` hoặc viết hàm riêng (như `houseNode`).
3. Dựng theo checklist chi tiết: hình khối chính bo cạnh → lớp phụ (viền, khung, chân đế) → vật liệu có vân → ít nhất vài chi tiết nhỏ → cây/hoa/lá bằng `leafGeo`/`rosette`.
4. Giữ số node vừa phải (hàng trăm là ổn), dùng chung geometry/vật liệu, cuối cùng `flattenedClone()`.
5. Cập nhật README và file này nếu có quy ước mới.

## 7. Hiệu ứng đã có
- Nước sông: `makeWater` (shader hình học + fragment tạo sóng gợn), mặt nước **lên xuống như thủy triều**; bờ bùn dốc `makeBank` có shader làm ướt/sẫm và vệt bọt ở mép nước (cả hai dùng chung công thức `sin(t*0.5)*0.3`, đừng đổi một bên).
- Cây, bụi OBJ đung đưa: shader hình học `swayShader`, nút 🍃 chuyển tắt/nhẹ/mạnh. Mô hình tự dựng chưa đung đưa (đã flatten).
- Vẽ đường/mương: nhóm "Vẽ đường", chạm các điểm, ✔ hoàn tất; điểm cách điểm cũ < 2,5 m tự nối; góc tự bo bằng cung bezier (`smooth`), mặt đường là dải lưới (`ribbon`) kèm đầu bo tròn. Mương nước có thành bê tông + nước gợn.
- Vẽ tay: nút ✏️ (mặc định bật) trong nhóm "Vẽ đường" → kéo ngón tay, `strokeMove` thêm điểm mỗi ≥1,2 m và dựng lại đường ngay (đường mọc theo ngón tay), nhả tay thì `finish()`. Tắt ✏️ thì quay lại kiểu chạm từng điểm + ✔. Loại "Đường bê tông" (kind 3, rộng 2,1 m) dựng bằng `concreteRoad`: tấm 3 m có vết nứt giống đường chính, làm mượt bằng `chaikin`.
- Kéo vật đi chỗ khác: chế độ "Chọn", đặt ngón lên vật rồi kéo (`dragBegin/dragMove/dragEnd`); vật nhấc lên 0,25 m, có đĩa vàng + vòng + cột báo điểm đặt, thả tay thì hạ xuống và lưu.
- Hoàn tác: nút ↩ cam (`undoLast`, ngăn xếp `undoStack` gồm vật "p:id" và đường "r:id"); chế độ Chọn có nút 🗑 xóa vật đang chọn; chế độ Xóa chạm vào vật/đường để xóa.
- Mô hình dựng sẵn (hàng rào, cây ven đường) nằm trong `seedRecs` với id cố định `seedN` (sinh theo thứ tự rng, đừng đổi thứ tự gọi rng trong `seed()`); chỉnh sửa lưu ở `seedEdits`, xóa lưu ở `seedGone`. Dùng `recOf/setRec/dropRec` cho cả vật tự đặt lẫn vật dựng sẵn.
- Đường chính giờ là `RoadRec` id "main" (kind 3, tạo lần đầu theo cờ `mainInit`), nên chọn/xóa/nối thêm như mọi đường. Chế độ Chọn chạm vào đường/mương → `selectRoad` hiện `RoadPanel` (thẳng / cong trái / cong phải, đầu/cuối, dài m, bán kính m) → `extendRoad` thêm điểm vào cùng `pts` nên tự nối liền; hoàn tác bằng `undoPts`.
- Tạo hàng: chọn một vật (hàng rào, bụi, cỏ, hoa, cây...) → nút ▦ → `RowPanel` (thẳng / cong trái / cong phải, dài m, cách m, bán kính m, hướng nhìn hoặc theo vật) → `makeRow` nhân vật đó dọc theo đường thẳng/cung; hoàn tác theo nhóm (`undoGroups`). Mô hình có `sizes.json` kiểu `[1, dài]` là mô hình dạng dài (hàng rào) nên được xoay theo tiếp tuyến.
- Nhóm "Mẫu có sẵn" (`sampleIds`, `sampleModel`): mẫu lấy từ vật dựng sẵn trong cảnh (đoạn đường có cây 2 bên, tấm bê tông, khối bùn nứt, ao nước) để đặt chỗ khác; mô hình ghép từ OBJ không flatten để giữ shader đung đưa.
- `canalDiorama()` (mẫu "Mương nước quê (chiều sâu)"): đoạn mương 24 m dựng theo ảnh tham chiếu (mặt cắt bờ đất nhiễu tuần hoàn nên nối nhiều đoạn khít nhau, nước dưới mặt bờ có shader `waterFrag`, lục bình, chuối, cầu ván, xuồng `boatHull`, nhà tranh, giếng, dừa). Dùng ma trận simd (`mT/mRy/mRx/mS`, `rosetteInto`) thay vì node lồng nhau vì flattenedClone từng làm mất vị trí node lồng (lỗi mái nhà).
- Ảnh xem trước từng mô hình: `renderThumb` dùng SCNRenderer, tạo dần khi cuộn.
- Chọn / phóng to / thu nhỏ / xoay vật đã đặt (chế độ "Chọn", nút ➕ ➖ ↻, chụm hai ngón).

## 7b. Ao cá miền Tây (nhóm "Mẫu có sẵn", id `Game.pondId`)
- Mã nằm ở `Sources/Pond*.swift` (extension của `Game`): `PondTerrain` (viền ao siêu elip `pondR`, đáy ao, bờ, mặt nước shader), `PondFish` (cá 3 loại, lưới nuôi, `startPondLife`), `PondProps` (chòi tôn, cầu ao, ống/rod), `PondMore` (máy bơm + tia nước, guồng quạt, xuồng, bọt), `PondNature` (cây cỏ, lục bình, sen, bố cục `pondDiorama`).
- Tọa độ: tâm ao (0,0); mặt nước y = 0,62; đáy ~0,04 (sâu ~0,58 m); mặt bờ ~1,1; ngoài cùng y = 0. Vật đặt trên bờ dùng `bankFrame(θ, d)` (trục +z hướng vào ao); gộp mesh bằng `frameNode` + `flattenedClone`.
- Nước trong mờ (`transparency` 0,62) để thấy đáy, đá, rong, cá. Cá, guồng quạt, tia nước, vòng sóng KHÔNG gộp mesh vì có chuyển động; `Game.spawn` gọi `startPondLife` cho bản đặt (clone không chắc giữ action). Cá có tên `fish:cx,cz,a,b,y,w,phase,dir` (quỹ đạo elip), đuôi tên `tail`.
- Lưới nuôi/tia nước dùng ảnh có alpha (`transparent.contents` + `.aOne`, `writesToDepthBuffer = false`, `renderingOrder` cao).

- `Sources/Sampan.swift`: `sampanNode()` = Xuồng ba lá (nhóm "Nhà & vườn", dùng lại trong `pondBoat`): thân lưới mặt cắt `sec(t,q)` ghép ván (`plankImg`), cạp, sườn, 3 ghế, dây thừng, mái chèo. Gốc ở đáy xuồng, mũi +z.

## 7c. Nhân vật đi lại + toàn màn hình
- `Sources/Avatar.swift`: nút 🚶 (`walkMode`) lấy mô hình `mannequinMale` (OBJ có sẵn các bộ phận tách rời, hướng +z, đơn vị cm) ra làm nhân vật; joystick điều khiển, camera đi sau lưng (vuốt để xoay, kéo xuống = nhìn từ cao). Tay/chân gom nhóm quanh khớp (`limbGroup`) rồi đung đưa theo `walkPhase`.
- `groundY(x,z)`: độ cao nền, đi lên bờ ao / lội xuống đáy ao cho ao cá đã đặt; dùng cho cả camera người nhìn thứ nhất. Chưa có va chạm với vật thể.
- Nút ⛶/⤡ (`fullscreen`): ẩn mọi bảng chọn, chỉ giữ joystick + 🚶 🏃 🏠; chạm không đặt vật, vuốt chỉ để nhìn quanh.

## 8. Lưu ý kỹ thuật
- Mã chưa từng được biên dịch trong môi trường tạo ra nó (không có Xcode). Nếu build lỗi, người dùng gửi log; sửa theo log, giữ nguyên phong cách.
- Hiệu năng: dùng cache geometry, gộp bằng `flattenedClone`, tránh tạo geometry riêng cho từng lá. Đặt/xóa vẫn phải mượt trên iPhone đời cũ.
- Đã sửa lỗi model bị trắng bằng việc tự gắn texture từ `.mtl`; tên vật liệu trong `.mtl` khớp `SCNMaterial.name`, nếu không khớp thì gắn theo thứ tự.
- Người dùng làm trên điện thoại (GitHub mobile): luôn đưa lại đúng các file zip cần tải lên và nói rõ file nào cần thay.

## 9. Lỗi đã gặp (đừng lặp lại)
- Cây OBJ bị cháy trắng: file `.mtl` có `Ka 1 1 1`, SceneKit cộng thêm ánh sáng nền → phải đặt `material.ambient.contents = .black` cho mọi vật liệu OBJ (đã làm trong `proto`).
- Một số thư mục có file `.obj` khác tên thư mục (`birch 2`, `palm 2`, `pine 2`, `horse 2`, `yuccaPlant 2`...): luôn tìm file bằng `objURL`, không ghép tên theo thư mục.
- Texture có thể nằm trong thư mục con hoặc khác hoa thường: dùng `findTex`.
- `ScrollView` ngang trong `VStack` bị giãn chiều dọc, làm thanh chọn chiếm nửa màn hình: luôn đặt `.frame(height:)` cố định.

## 10. Logo ứng dụng
- Logo: `Resources/Assets.xcassets/AppIcon.appiconset/icon.png` (1024x1024, RGB, không trong suốt, không bo góc). Cảnh nhà mái lá trên sông, đường bê tông, dừa nghiêng, nắng chiều. Được vẽ bằng Python/Pillow (lưới 1024, vẽ gấp đôi rồi thu nhỏ). Khi đổi logo, giữ phong cách phẳng mềm, không chữ, vật chính ở giữa.

## 11. Hoàn tác ↩ / Làm lại ↪ (Game.swift, phần "Hoàn tác / Làm lại")
- Hai nút ↩ ↪ nằm trên joystick (ẩn khi toàn màn hình, và khi đang chấm điểm vẽ đường thì ↩ bên phải chỉ bỏ điểm cuối). Mỗi lần xóa / hoàn tác / làm lại có thanh thông báo nhỏ dưới thanh Đặt-Chọn-Xóa kèm nút ↩ ↪ (tự ẩn sau 4 giây).
- Cơ chế: `commit(tên, key:, undo:, redo:)` đẩy `Act` (hai closure) vào `undoStack`, xóa `redoStack`; tối đa 100 bước. `undoLast()` / `redoLast()` chuyển bước qua lại giữa hai ngăn xếp.
- Mọi thao tác thay đổi cảnh PHẢI đi qua hàm có ghi lịch sử: `placeRec` (đặt), `deletePlaced` (xóa vật), `deleteRoad` (xóa đường), `finish` (vẽ đường), `extendRoad` (nối), `makeRow` (tạo hàng), `recEdit` (di chuyển/xoay/phóng to). Hàm thô không ghi lịch sử, chỉ dùng bên trong closure undo/redo: `addRec`, `delRec`, `remove`, `addRoad`, `delRoad`, `removeRoad`, `setRoadPts`, `applyRec`. Thêm thao tác mới → viết cặp undo/redo bằng các hàm thô này, đừng gọi `remove` trực tiếp từ giao diện.
- `addRec`/`delRec` xử lý cả vật dựng sẵn `seedN` (khôi phục khỏi `seedGone`/`seedEdits`). Xoay/phóng to dùng `key` để các lần bấm/chụm liên tiếp trong 1,2 giây gộp thành một bước.


## 12. Chọn rồi mới thao tác (chế độ Chọn và Xóa)
- Cả hai chế độ Chọn (mode 1) và Xóa (mode 2) đều KHÔNG xóa ngay khi chạm: chạm vào vật thì `select` (vòng vàng + đĩa sáng nhấp nháy) và hiện `ActionBar` ở dưới: 🗑 Xóa, ✥ Di chuyển (bật `moving`, chạm mặt đất để chuyển tới đó; kéo trực tiếp vẫn được), ↻ Xoay, ➕ ➖, ⧉ Nhân bản, ▦ Tạo hàng. Chạm vào đường/mương thì hiện `RoadPanel` (có nút Xóa). Mọi thao tác đều có hoàn tác (mục 11). Chuyển sang chế độ Đặt (mode 0) thì bỏ chọn.

## 13. Vật dựng sẵn đều sửa được
- Mọi vật dựng sẵn là `Rec` id `seed…` (cây, hàng rào, hoa, và từ nay cả cỏ phủ nền `seedGn`, khối bùn ven bờ `seedRn` dùng mẫu "Cục bùn nứt", tấm bê tông nứt `seedS0`) → chọn / xóa / di chuyển / xoay / phóng to / nhân bản / hoàn tác như vật tự đặt. Trạng thái lưu ở `seedEdits` và `seedGone`.
- `buildTerrain` gom các vật này vào `extraSeeds`, `finishSeed` nối vào `seedRecs`. QUAN TRỌNG: phải giữ nguyên thứ tự và số lần gọi `rng.f` khi tạo địa hình (kể cả khi bỏ giá trị; mỗi tuft cỏ cũ tiêu thụ 12 lần rng trong `rosette`, nay mô phỏng bằng vòng lặp 12 lần), nếu không các vật `seedN` cũ đổi vị trí và bản lưu của người dùng sẽ lệch. Vật dựng sẵn mới nên dùng id có tiền tố `seed` khác (vd `seedX0`) để không trùng.
- Chưa sửa được: mặt đất, sông, bờ bùn dốc (địa hình nền). Đường bê tông chính là đường id `main` (xóa được qua RoadPanel).

## 14. Chọn vật khi chạm (`pickAt` / `rawPick`)
- Tia chạm (`hitTest` kiểu .all) có thể trúng nhiều thứ. `rawPick` ưu tiên: vật (nhóm 0) > mảng cỏ nền (nhóm 1) > đường (nhóm 2); cùng nhóm lấy vật gần nhất. Nhờ vậy vật nhỏ (máy giặt, ghế...) đặt giữa cỏ hoặc trên đường vẫn chọn được. Khi chạm trượt, `pickAt(near: true)` thử thêm 16 và 32 điểm xung quanh (vật nhỏ khó chạm trúng). Kéo vật (`dragBegin`) dùng `near: false` để vuốt xoay camera không vô tình bắt vật.
- Giới hạn kéo/di chuyển vật theo phạm vi mặt đất: x −14…100, z ≤ 38 (trước đây 60 / 8 làm vật đặt xa bị kéo giật về).

## 10. Bảng vẽ nét 2D (Sketch.swift) — đường / mương / hàng rào
- `SketchModel` (khung dưới, SwiftUI `Canvas` + `SketchTouch` bằng UIKit: 1 ngón vẽ, 2 ngón chụm / kéo) và `extension Game` cùng file. Trạng thái trong `Game`: `sketchOpen`, `sketchVisible` (= mở && mode == 0 && không toàn màn hình), `sketchCam`, `aerialC/aerialH`.
- Khi `sketchVisible`, `ContentView` chia màn hình: `SceneUI` ở trên, `SketchPanel` cao 46% ở dưới; camera chuyển sang nhìn xuống 57° (`applyAerial`), yaw = 0 nên trục khớp khung dưới (x sang phải, z xuống). Thoát thì `refreshSketchCam` trả lại camera cũ. `step()` thoát sớm khi `sketchCam`; joystick lúc này là di chuyển tâm nhìn; chạm khung 3D bị bỏ qua (`tap`).
- Nét thẳng: 2 điểm; nét cong: `fit` = RDP lọc điểm + Catmull-Rom. Đầu nét dính vào đầu đường cũ / hàng cũ trong 20 px (`nearestEnd`), nên `commitRoadStroke` nối vào `RoadRec` cùng loại (đảo chiều nếu cần) bằng `setRoadPts`, có hoàn tác. Mô hình không phải 4 loại đường (`kinds`) thì đi theo `rowRecs`: đặt vật cách nhau `sk.spacing`, vật dài (`rowSpec.aligned`) xoay theo nét, vật tròn thì xoay ngẫu nhiên; nét sau dính đầu nét trước thì bỏ vật đầu.
- Khi đang kéo, `sketchPreview` dựng tạm nút `sketch3d` (cập nhật mỗi 0,07 s); thả tay mới tạo thật (`sketchCommit`).
- `link` (🔗): `syncFromAerial` / `syncFromSketch` giữ hai khung cùng tâm và cùng độ phóng (xấp xỉ: chiều cao camera ≈ bề rộng khung / (1,17 × tỉ lệ)).
- Đã thêm nhưng CHƯA biên dịch được ở môi trường tạo ra nó; nếu build lỗi, sửa theo log.
