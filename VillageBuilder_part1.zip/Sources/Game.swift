import SceneKit
import UIKit
import simd

struct Rec: Codable { var id: String; var item: String; var x: Float; var z: Float; var yaw: Float; var s: Float }
struct RNG { var s: UInt64 = 7
  mutating func f(_ a: Float, _ b: Float) -> Float { s = s &* 6364136223846793005 &+ 1442695040888963407; return a + Float(s >> 40) / Float(1 << 24) * (b - a) } }

final class Game: ObservableObject {
  @Published var coins = UserDefaults.standard.object(forKey: "coins") as? Int ?? 5000
  @Published var cat = "Cây cối"
  @Published var sel = "palm 2"
  @Published var mode = 0   // 0 đặt, 1 xóa
  let order = ["Cây cối", "Hoa & cây cảnh", "Bụi & hàng rào", "Cỏ", "Vẽ đường", "Ngoài trời & sân vườn", "Động vật", "Xe cộ", "Đường & giao thông", "Điện & hạ tầng", "Nhân vật", "Nội thất", "Đồ bếp & gia dụng"]
  var sizes: [String: [Float]] = [:]
  var items: [String: [String]] = [:]
  let scene = SCNScene(); let cam = SCNNode()
  var protos: [String: SCNNode] = [:]; var catOf: [String: String] = [:]
  var recs: [Rec] = []; var rng = RNG()
  let heights: [String: Float] = ["palm": 9, "palm 2": 9, "coconutTree": 10, "coconutTreeBended": 9, "fanPalm": 5, "sabalPalmeto": 3, "cypress": 9, "lombardyPoplar": 12, "pine": 8, "pine 2": 8, "tree": 6, "bonsai-tree": 0.8]

  init() {
    if let u = Bundle.main.url(forResource: "catalog", withExtension: "json"), let d = try? Data(contentsOf: u),
       let c = try? JSONDecoder().decode([String: [String]].self, from: d) { items = c; for (k, l) in c { for i in l { catOf[i] = k } } }
    if let u = Bundle.main.url(forResource: "sizes", withExtension: "json"), let d = try? Data(contentsOf: u), let z = try? JSONDecoder().decode([String: [Float]].self, from: d) { sizes = z }
    items["Cỏ"] = ["grass"]; catOf["grass"] = "Cỏ"; items["Vẽ đường"] = kinds; kinds.forEach { catOf[$0] = "Vẽ đường" }
    buildTerrain(); seed()
    if let d = UserDefaults.standard.data(forKey: "recs"), let r = try? JSONDecoder().decode([Rec].self, from: d) { recs = r; r.forEach { spawn($0) } }
    if let d = UserDefaults.standard.data(forKey: "roads"), let r = try? JSONDecoder().decode([RoadRec].self, from: d) { roads = r; r.forEach { scene.rootNode.addChildNode(roadNode($0)) } }
  }

  func price(_ i: String) -> Int { kinds.contains(i) ? 5 : i == "grass" ? 10 : Int((sizes[i]?[1] ?? height(i)) * 30) + 20 }
  func height(_ i: String) -> Float { heights[i] ?? (catOf[i] == "Cây cối" ? 7 : catOf[i] == "Bụi & hàng rào" ? 1.4 : 1.0) }

  func proto(_ id: String) -> SCNNode? {
    if let p = protos[id] { return p }
    guard let u = Bundle.main.url(forResource: id, withExtension: "obj", subdirectory: "Models/\(id)"),
          let s = try? SCNScene(url: u, options: nil) else { return nil }
    let inner = SCNNode(); s.rootNode.childNodes.forEach { inner.addChildNode($0) }
    let (mn, mx) = inner.boundingBox; let sz = sizes[id]; let ext = sz?[0] == 1 ? max(mx.x - mn.x, mx.z - mn.z) : (mx.y - mn.y); let k = (sz?[1] ?? height(id)) / max(ext, 0.001)
    inner.scale = SCNVector3(k, k, k)
    inner.position = SCNVector3(-(mn.x + mx.x) / 2 * k, -mn.y * k, -(mn.z + mx.z) / 2 * k)
    let plant = ["Cây cối", "Hoa & cây cảnh", "Bụi & hàng rào"].contains(catOf[id] ?? "")
    let amp: Float = catOf[id] == "Cây cối" ? 0.035 : catOf[id] == "Bụi & hàng rào" ? 0.03 : 0.04
    let hgt = max(mx.y - mn.y, 0.001), baseY = mn.y
    inner.enumerateHierarchy { n, _ in n.geometry?.materials.forEach { m in
      m.isDoubleSided = true
      if plant { m.shaderModifiers = [.geometry: Game.swayShader]
        m.setValue(NSNumber(value: hgt), forKey: "hh"); m.setValue(NSNumber(value: baseY), forKey: "base")
        m.setValue(NSNumber(value: amp * self.swayMul), forKey: "amp"); self.swayMats.append((m, amp)) } } }
    let w = SCNNode(); w.addChildNode(inner); protos[id] = w; return w
  }

  lazy var grassImg: UIImage = {
    UIGraphicsImageRenderer(size: CGSize(width: 128, height: 128)).image { c in
      for i in 0..<22 { let x = CGFloat(i) * 6 + 2, h = CGFloat(60 + (i * 37) % 60)
        UIColor(red: 0.25 + CGFloat(i % 4) * 0.05, green: 0.6 + CGFloat(i % 3) * 0.08, blue: 0.2, alpha: 1).setFill()
        let p = UIBezierPath(); p.move(to: CGPoint(x: x, y: 128)); p.addLine(to: CGPoint(x: x + 3 + CGFloat(i % 5), y: 128 - h)); p.addLine(to: CGPoint(x: x + 7, y: 128)); p.fill() } }
  }()
  func tuft() -> SCNNode {
    let n = SCNNode()
    for a in [0, Float.pi / 2] { let p = SCNPlane(width: 0.7, height: 0.55); p.firstMaterial?.diffuse.contents = grassImg
      p.firstMaterial?.isDoubleSided = true; let m = SCNNode(geometry: p); m.position.y = 0.27; m.eulerAngles.y = a; n.addChildNode(m) }
    return n
  }

  func spawn(_ r: Rec, name: String? = nil) {
    let n: SCNNode
    if r.item == "grass" { n = SCNNode(); for _ in 0..<10 { let t = tuft(); t.position = SCNVector3(Float.random(in: -0.8...0.8), 0, Float.random(in: -0.8...0.8)); n.addChildNode(t) } }
    else { guard let p = proto(r.item) else { return }; n = p.clone() }
    n.position = SCNVector3(r.x, 0, r.z); n.eulerAngles.y = r.yaw; n.scale = SCNVector3(r.s, r.s, r.s)
    n.name = name ?? "placed:\(r.id)"; scene.rootNode.addChildNode(n)
  }
  func seedPut(_ i: String, _ x: Float, _ z: Float) { spawn(Rec(id: "", item: i, x: x, z: z, yaw: rng.f(0, 6.28), s: rng.f(0.85, 1.2)), name: "seed") }

  func makeTex(_ base: UIColor, _ specks: [UIColor], _ count: Int, _ maxR: CGFloat, cracks: Int = 0, crackColor: UIColor = .black, crackW: CGFloat = 1.5, seed: UInt64) -> UIImage {
    var r = RNG(); r.s = seed; let S: CGFloat = 512
    return UIGraphicsImageRenderer(size: CGSize(width: S, height: S)).image { c in
      base.setFill(); c.fill(CGRect(x: 0, y: 0, width: S, height: S))
      for _ in 0..<count {
        specks[min(Int(r.f(0, Float(specks.count))), specks.count - 1)].withAlphaComponent(CGFloat(r.f(0.15, 0.6))).setFill()
        let d = CGFloat(r.f(1, Float(maxR)))
        UIBezierPath(ovalIn: CGRect(x: CGFloat(r.f(0, 512)), y: CGFloat(r.f(0, 512)), width: d, height: d * CGFloat(r.f(0.5, 1.5)))).fill() }
      for _ in 0..<cracks {
        var x = CGFloat(r.f(0, 512)), y = CGFloat(r.f(0, 512)); let q = UIBezierPath(); q.move(to: CGPoint(x: x, y: y)); var a = r.f(0, 6.28)
        for _ in 0..<Int(r.f(5, 14)) { a += r.f(-0.7, 0.7); x += CGFloat(cos(a)) * CGFloat(r.f(10, 30)); y += CGFloat(sin(a)) * CGFloat(r.f(10, 30)); q.addLine(to: CGPoint(x: x, y: y)) }
        crackColor.withAlphaComponent(0.85).setStroke(); q.lineWidth = crackW * CGFloat(r.f(0.5, 1.4)); q.stroke() } }
  }
  func mat(_ img: UIImage, _ sx: Float, _ sy: Float) -> SCNMaterial {
    let m = SCNMaterial(); m.diffuse.contents = img; m.diffuse.wrapS = .repeat; m.diffuse.wrapT = .repeat
    m.diffuse.contentsTransform = SCNMatrix4MakeScale(sx, sy, 1); m.lightingModel = .blinn; m.specular.contents = UIColor(white: 0.08, alpha: 1); return m
  }
  func tplane(_ w: CGFloat, _ l: CGFloat, _ x: Float, _ y: Float, _ z: Float, _ m: SCNMaterial, _ name: String?) {
    let p = SCNPlane(width: w, height: l); p.firstMaterial = m
    let n = SCNNode(geometry: p); n.eulerAngles.x = -.pi / 2; n.position = SCNVector3(x, y, z); n.name = name; scene.rootNode.addChildNode(n)
  }
  func makeWater() {
    let p = SCNPlane(width: 48, height: 420); p.widthSegmentCount = 40; p.heightSegmentCount = 240
    let m = SCNMaterial(); m.lightingModel = .blinn; m.diffuse.contents = UIColor(red: 0.30, green: 0.34, blue: 0.2, alpha: 1)
    m.specular.contents = UIColor.white; m.shininess = 0.9
    m.reflective.contents = UIColor(red: 0.8, green: 0.9, blue: 0.95, alpha: 1); m.fresnelExponent = 2.5
    m.shaderModifiers = [
      .geometry: """
      #pragma body
      float t = scn_frame.time; float2 q = _geometry.position.xy;
      float a = q.x * 0.8 + t * 1.2, b = q.y * 0.5 + t * 0.9, c = (q.x + q.y) * 1.7 + t * 2.0;
      _geometry.position.z += sin(a) * 0.03 + sin(b) * 0.04 + sin(c) * 0.015;
      float dx = cos(a) * 0.024 + cos(c) * 0.0255, dy = cos(b) * 0.02 + cos(c) * 0.0255;
      _geometry.normal = normalize(float3(-dx, -dy, 1.0));
      """,
      .fragment: """
      #pragma body
      float2 uv = _surface.diffuseTexcoord * float2(48.0, 420.0); float t = scn_frame.time;
      float r = sin(uv.x * 3.1 + t * 1.6) * sin(uv.y * 2.3 - t * 1.2) + sin((uv.x + uv.y) * 5.0 + t * 2.5) * 0.5 + sin((uv.x - uv.y) * 9.0 - t * 3.1) * 0.25;
      _surface.normal = normalize(_surface.normal + float3(r * 0.06, r * 0.06, 0.0));
      _surface.diffuse.rgb += r * 0.035;
      """]
    p.firstMaterial = m
    let n = SCNNode(geometry: p); n.eulerAngles.x = -.pi / 2; n.position = SCNVector3(-38, -0.3, -170); n.name = "water"; scene.rootNode.addChildNode(n)
  }
  func plane(_ w: CGFloat, _ l: CGFloat, _ x: Float, _ y: Float, _ z: Float, _ c: UIColor, _ name: String?) -> SCNNode {
    let p = SCNPlane(width: w, height: l); p.firstMaterial?.diffuse.contents = c; p.firstMaterial?.lightingModel = .blinn
    let n = SCNNode(geometry: p); n.eulerAngles.x = -.pi / 2; n.position = SCNVector3(x, y, z); n.name = name; scene.rootNode.addChildNode(n); return n
  }

  func buildTerrain() {
    let sky = UIColor(red: 0.75, green: 0.86, blue: 0.9, alpha: 1)
    scene.background.contents = sky; scene.fogColor = sky; scene.fogStartDistance = 40; scene.fogEndDistance = 190
    let amb = SCNNode(); amb.light = SCNLight(); amb.light?.type = .ambient; amb.light?.intensity = 650; scene.rootNode.addChildNode(amb)
    let sun = SCNNode(); sun.light = SCNLight(); sun.light?.type = .directional; sun.light?.intensity = 1000; sun.light?.castsShadow = true
    sun.eulerAngles = SCNVector3(-0.9, -0.6, 0); scene.rootNode.addChildNode(sun)
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    let grassT = makeTex(C(0.36, 0.52, 0.2), [C(0.25, 0.42, 0.14), C(0.5, 0.66, 0.28), C(0.3, 0.3, 0.15)], 2800, 10, seed: 11)
    let soilT = makeTex(C(0.33, 0.26, 0.19), [C(0.22, 0.17, 0.12), C(0.45, 0.37, 0.26), C(0.3, 0.45, 0.18)], 2800, 14, seed: 12)
    let mudT = makeTex(C(0.2, 0.19, 0.17), [C(0.1, 0.1, 0.09), C(0.35, 0.34, 0.31)], 1800, 9, cracks: 34, crackColor: C(0.03, 0.03, 0.03), crackW: 2, seed: 13)
    let mudMat = mat(mudT, 1, 1)
    tplane(110, 420, 47, -0.02, -170, mat(grassT, 110 / 6, 420 / 6), "land")
    tplane(36, 420, 22, -0.015, -170, mat(soilT, 6, 70), "land")
    tplane(8, 420, -12, -0.05, -170, mat(mudT, 2, 70), "land")
    makeWater()
    tplane(90, 420, -106, -0.02, -170, mat(grassT, 15, 70), nil)
    let cs = [2, 3, 6, 4].enumerated().map { mat(makeTex(C(0.55, 0.57, 0.53), [C(0.4, 0.42, 0.38), C(0.72, 0.72, 0.68), C(0.35, 0.42, 0.3), C(0.92, 0.92, 0.9)], 3000, 6, cracks: $1, crackColor: C(0.13, 0.13, 0.12), seed: UInt64(20 + $0)), 1, 1) }
    let crackedMat = mat(makeTex(C(0.52, 0.54, 0.5), [C(0.4, 0.42, 0.38), C(0.7, 0.7, 0.66), C(0.35, 0.4, 0.3)], 3000, 6, cracks: 22, crackColor: C(0.12, 0.12, 0.11), crackW: 2.2, seed: 29), 1, 1)
    let path = SCNNode()
    for i in 0..<80 { let b = SCNBox(width: 2.1, height: 0.12, length: 2.96, chamferRadius: 0); b.firstMaterial = cs[i % 4]
      let n = SCNNode(geometry: b); n.position = SCNVector3(0, 0.04, 6 - Float(i) * 3); path.addChildNode(n) }
    let pf = path.flattenedClone(); pf.name = "land"; scene.rootNode.addChildNode(pf)
    let bb = SCNBox(width: 5, height: 0.12, length: 4.5, chamferRadius: 0); bb.firstMaterial = crackedMat
    let bn = SCNNode(geometry: bb); bn.position = SCNVector3(3.8, 0.05, 1.2); bn.eulerAngles.y = -0.5; bn.name = "land"; scene.rootNode.addChildNode(bn)
    let rk = SCNNode()   // khối bùn nứt ven bờ
    for i in 0..<45 { let k = rng.f(0.6, 1.6); let bx = SCNBox(width: CGFloat(k), height: CGFloat(k * 0.6), length: CGFloat(k * rng.f(0.8, 1.4)), chamferRadius: CGFloat(k * 0.15)); bx.firstMaterial = mudMat
      let n = SCNNode(geometry: bx); n.position = SCNVector3(rng.f(-7.5, -4), k * 0.25, 4 - Float(i) * 0.9); n.eulerAngles = SCNVector3(rng.f(-0.3, 0.3), rng.f(0, 6), rng.f(-0.3, 0.3)); rk.addChildNode(n) }
    scene.rootNode.addChildNode(rk.flattenedClone())
    let gr = SCNNode()   // cỏ phủ nền
    for _ in 0..<500 { let t = tuft(); t.position = SCNVector3(rng.f(-8, -1.3), 0, rng.f(-120, 8)); gr.addChildNode(t) }
    for _ in 0..<700 { let t = tuft(); t.position = SCNVector3(rng.f(1.3, 30), 0, rng.f(-120, 8)); gr.addChildNode(t) }
    scene.rootNode.addChildNode(gr.flattenedClone())
    cam.camera = SCNCamera(); cam.camera?.fieldOfView = 70; cam.camera?.zFar = 300; cam.position = SCNVector3(0, 1.6, 8); scene.rootNode.addChildNode(cam)
  }

  func seed() {   // dựng lại cảnh trong ảnh bằng các model thật
    var z: Float = 6
    let forest = ["tree", "birch", "cypress", "lombardyPoplar", "pine", "acacia"]
    var k = 0
    while z > -150 {
      let m: Float = z > -60 ? 1 : 2.5
      seedPut("hedge", -1.9, z); seedPut("hedge", 1.9, z)
      if k % 2 == 0 { seedPut("roses-bush", -2.4, z - 1); seedPut("lavender-bush", 2.5, z - 1) }
      if k % Int(3 * m) == 0 { seedPut(k % 2 == 0 ? "palm" : "fanPalm", rng.f(3.5, 6), z); seedPut("coconutTree", rng.f(-11, -9), z) }
      if k % Int(2 * m) == 0 { seedPut(forest[k % forest.count], rng.f(7, 18), z + rng.f(-2, 2)) }
      if k % 9 == 0 && z > -100 { seedPut("coconutTree", rng.f(-70, -64), z); seedPut("weepingWillow", rng.f(-90, -75), z) }
      z -= 2.5 * m; k += 1 }
  }

  // ===== Cây, bụi đung đưa =====
  @Published var swayLevel = UserDefaults.standard.object(forKey: "sway") as? Int ?? 1   // 0 tắt, 1 nhẹ, 2 mạnh
  var swayMats: [(SCNMaterial, Float)] = []
  var swayMul: Float { [0, 1, 2.2][swayLevel] }
  static let swayShader = """
  uniform float amp; uniform float hh; uniform float base;
  #pragma body
  float h = clamp((_geometry.position.y - base) / hh, 0.0, 1.0);
  float k = h * h * amp * hh;
  float t = scn_frame.time;
  float ph = (_geometry.position.x + _geometry.position.z) / hh * 6.0;
  _geometry.position.x += (sin(t * 1.6 + ph) + sin(t * 5.0 + ph * 3.0) * 0.15) * k;
  _geometry.position.z += cos(t * 1.3 + ph * 1.3) * k * 0.7;
  """
  func cycleSway() {
    swayLevel = (swayLevel + 1) % 3; UserDefaults.standard.set(swayLevel, forKey: "sway")
    for (m, a) in swayMats { m.setValue(NSNumber(value: a * swayMul), forKey: "amp") }
  }

  // ===== Vẽ đường / mương: tự nối điểm gần nhau + bo góc =====
  struct RoadRec: Codable { var id: String; var kind: Int; var pts: [[Float]] }
  let kinds = ["Đường nhựa", "Đường đất", "Mương nước"]; let widths: [Float] = [6, 3.5, 2.8]
  var roads: [RoadRec] = []; var draft: [[Float]] = []
  @Published var drawing = 0
  var kindIdx: Int { kinds.firstIndex(of: sel) ?? 0 }
  static let canalFrag = """
  #pragma body
  float2 uv = _surface.diffuseTexcoord * float2(4.0, 40.0); float t = scn_frame.time;
  float r = sin(uv.x * 3.1 + t * 1.6) * sin(uv.y * 2.3 - t * 1.2) + sin((uv.x + uv.y) * 5.0 + t * 2.5) * 0.5;
  _surface.normal = normalize(_surface.normal + float3(r * 0.06, r * 0.06, 0.0));
  _surface.diffuse.rgb += r * 0.035;
  """
  func laneImg(_ dirt: Bool) -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256)).image { c in
      let g = c.cgContext
      (dirt ? UIColor(red: 0.45, green: 0.34, blue: 0.22, alpha: 1) : UIColor(white: 0.22, alpha: 1)).setFill(); g.fill(CGRect(x: 0, y: 0, width: 256, height: 256))
      UIColor(white: dirt ? 0.4 : 0.72, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 30, height: 256)); g.fill(CGRect(x: 226, y: 0, width: 30, height: 256))
      if !dirt { UIColor(red: 0.95, green: 0.8, blue: 0.2, alpha: 1).setFill(); g.fill(CGRect(x: 124, y: 0, width: 8, height: 128)) }
      for i in 0..<900 { UIColor(white: CGFloat((i * 37) % 100) / 100, alpha: 0.08).setFill(); g.fill(CGRect(x: CGFloat((i * 53) % 256), y: CGFloat((i * 97) % 256), width: 3, height: 3)) } }
  }
  func roadMat(_ img: UIImage) -> SCNMaterial { let m = mat(img, 1, 1); m.isDoubleSided = true; return m }
  lazy var asphaltMat = roadMat(laneImg(false))
  lazy var dirtMat = roadMat(laneImg(true))
  lazy var bankMat = roadMat(makeTex(UIColor(white: 0.6, alpha: 1), [UIColor(white: 0.45, alpha: 1), UIColor(white: 0.75, alpha: 1)], 1500, 6, cracks: 6, crackColor: UIColor(white: 0.15, alpha: 1), seed: 41))
  lazy var canalWater: SCNMaterial = {
    let m = SCNMaterial(); m.lightingModel = .blinn; m.diffuse.contents = UIColor(red: 0.28, green: 0.4, blue: 0.3, alpha: 1)
    m.specular.contents = UIColor.white; m.shininess = 0.9; m.isDoubleSided = true; m.shaderModifiers = [.fragment: Game.canalFrag]; return m }()

  func smooth(_ p: [[Float]], _ rad: Float) -> [SIMD2<Float>] {   // bo góc bằng cung bezier
    let q = p.map { SIMD2<Float>($0[0], $0[1]) }; guard q.count > 2 else { return q }
    var out = [q[0]]
    for i in 1..<(q.count - 1) {
      let a = q[i - 1], c = q[i], b = q[i + 1]; let r = min(rad, 0.45 * simd_length(a - c), 0.45 * simd_length(b - c))
      if r < 0.01 { out.append(c); continue }
      let s = c + simd_normalize(a - c) * r, e = c + simd_normalize(b - c) * r
      for k in 0...8 { let t = Float(k) / 8; out.append((1 - t) * (1 - t) * s + 2 * (1 - t) * t * c + t * t * e) } }
    out.append(q[q.count - 1]); return out
  }
  func ribbon(_ p: [SIMD2<Float>], _ w: Float, _ y: Float, _ m: SCNMaterial) -> SCNNode? {
    guard p.count > 1 else { return nil }
    var v = [SCNVector3](), nm = [SCNVector3](), t = [CGPoint](), idx = [Int32](); var d: Float = 0
    for i in 0..<p.count {
      let dv = p[min(i + 1, p.count - 1)] - p[max(i - 1, 0)]; let l = simd_length(dv); let dir = l > 0 ? dv / l : SIMD2<Float>(0, 1)
      if i > 0 { d += simd_length(p[i] - p[i - 1]) }
      let n = SIMD2<Float>(-dir.y, dir.x) * (w / 2)
      v.append(SCNVector3(p[i].x + n.x, y, p[i].y + n.y)); v.append(SCNVector3(p[i].x - n.x, y, p[i].y - n.y))
      nm.append(SCNVector3(0, 1, 0)); nm.append(SCNVector3(0, 1, 0))
      t.append(CGPoint(x: 0, y: CGFloat(d / 8))); t.append(CGPoint(x: 1, y: CGFloat(d / 8)))
      if i > 0 { let b = Int32(2 * i); idx += [b - 2, b, b - 1, b - 1, b, b + 1] } }
    let g = SCNGeometry(sources: [SCNGeometrySource(vertices: v), SCNGeometrySource(normals: nm), SCNGeometrySource(textureCoordinates: t)],
                        elements: [SCNGeometryElement(indices: idx, primitiveType: .triangles)])
    g.firstMaterial = m; return SCNNode(geometry: g)
  }
  func disc(_ pt: SIMD2<Float>, _ r: Float, _ y: Float, _ m: SCNMaterial) -> SCNNode {
    let c = SCNCylinder(radius: CGFloat(r), height: 0.004); c.firstMaterial = m
    let n = SCNNode(geometry: c); n.position = SCNVector3(pt.x, y + 0.002, pt.y); return n
  }
  func roadNode(_ r: RoadRec) -> SCNNode {
    let n = SCNNode(); n.name = "road:\(r.id)"; let p = smooth(r.pts, 3.5), w = widths[r.kind]
    if r.kind == 2 {
      if let a = ribbon(p, w, 0.06, bankMat) { n.addChildNode(a) }; if let b = ribbon(p, w - 1.2, 0.07, canalWater) { n.addChildNode(b) }
      for e in [p.first!, p.last!] { n.addChildNode(disc(e, w / 2, 0.06, bankMat)); n.addChildNode(disc(e, w / 2 - 0.6, 0.07, canalWater)) }
    } else {
      let m = r.kind == 0 ? asphaltMat : dirtMat
      if let a = ribbon(p, w, 0.05, m) { n.addChildNode(a) }; for e in [p.first!, p.last!] { n.addChildNode(disc(e, w / 2, 0.05, m)) } }
    return n
  }
  func snap(_ x: Float, _ z: Float) -> [Float] {   // tự nối vào điểm đường có sẵn trong 2.5 m
    var best: [Float]? = nil; var bd: Float = 2.5
    for r in roads { for p in r.pts { let d = hypot(p[0] - x, p[1] - z); if d < bd { bd = d; best = p } } }
    return best ?? [x, z]
  }
  func addPoint(_ x: Float, _ z: Float) {
    let p = snap(x, z); if let l = draft.last, l == p { return }
    draft.append(p); drawing = draft.count; preview()
  }
  func preview() {
    scene.rootNode.childNode(withName: "draft", recursively: false)?.removeFromParentNode()
    let d = SCNNode(); d.name = "draft"
    for p in draft { let s = SCNSphere(radius: 0.35); s.firstMaterial?.diffuse.contents = UIColor.yellow; let n = SCNNode(geometry: s); n.position = SCNVector3(p[0], 0.4, p[1]); d.addChildNode(n) }
    if draft.count > 1 { d.addChildNode(roadNode(RoadRec(id: "d", kind: kindIdx, pts: draft))) }
    scene.rootNode.addChildNode(d)
  }
  func undoPoint() { if !draft.isEmpty { draft.removeLast(); drawing = draft.count; preview() } }
  func length(_ p: [[Float]]) -> Float { zip(p, p.dropFirst()).reduce(0) { $0 + hypot($1.0[0] - $1.1[0], $1.0[1] - $1.1[1]) } }
  func finish() {
    guard draft.count > 1 else { draft = []; drawing = 0; preview(); return }
    let cost = Int(length(draft) * 5); guard coins >= cost else { return }
    let r = RoadRec(id: UUID().uuidString, kind: kindIdx, pts: draft); coins -= cost; roads.append(r); scene.rootNode.addChildNode(roadNode(r))
    draft = []; drawing = 0; preview(); save()
  }
  func removeRoad(_ n: SCNNode, _ id: String) {
    if let i = roads.firstIndex(where: { $0.id == id }) { coins += Int(length(roads[i].pts) * 2.5); roads.remove(at: i) }
    n.removeFromParentNode(); save()
  }
  func saveRoads() { if let d = try? JSONEncoder().encode(roads) { UserDefaults.standard.set(d, forKey: "roads") } }

  // chọn / phóng to / thu nhỏ
  @Published var selId: String? = nil
  var ring: SCNNode?
  func select(_ n: SCNNode?, _ id: String?) {
    ring?.removeFromParentNode(); ring = nil; selId = id
    guard let n = n else { return }
    let (mn, mx) = n.boundingBox; let r = max(mx.x - mn.x, mx.z - mn.z) / 2 * 0.9 + 0.2
    let t = SCNTorus(ringRadius: CGFloat(r), pipeRadius: CGFloat(max(r * 0.03, 0.03)))
    t.firstMaterial?.diffuse.contents = UIColor.yellow; t.firstMaterial?.emission.contents = UIColor.yellow
    let rn = SCNNode(geometry: t); rn.position.y = 0.05; ring = rn; n.addChildNode(rn)
  }
  func resize(_ f: Float) {
    guard let id = selId, let i = recs.firstIndex(where: { $0.id == id }), let n = scene.rootNode.childNode(withName: "placed:\(id)", recursively: false) else { return }
    recs[i].s = min(max(recs[i].s * f, 0.2), 8); let s = recs[i].s; n.scale = SCNVector3(s, s, s); save()
  }
  func rotate(_ a: Float) {
    guard let id = selId, let i = recs.firstIndex(where: { $0.id == id }), let n = scene.rootNode.childNode(withName: "placed:\(id)", recursively: false) else { return }
    recs[i].yaw += a; n.eulerAngles.y = recs[i].yaw; save()
  }
  // di chuyển kiểu game
  var move = CGVector.zero; var yaw: Float = 0; var pitch: Float = 0
  @Published var run = false
  func step(_ dt: Float) {
    let sp: Float = (run ? 9 : 4) * dt, f = Float(move.dy), r = Float(move.dx)
    var x = cam.position.x + (-sin(yaw) * f + cos(yaw) * r) * sp
    var z = cam.position.z + (-cos(yaw) * f - sin(yaw) * r) * sp
    x = min(max(x, -14), 60); z = min(z, 8); if z < -200 { z = -200 }
    cam.position = SCNVector3(x, 1.6, z); cam.eulerAngles = SCNVector3(pitch, yaw, 0)
  }
  func look(_ dx: Float, _ dy: Float) { yaw -= dx * 0.005; pitch = min(max(pitch - dy * 0.005, -1.2), 1.2) }
  func home() { cam.position = SCNVector3(0, 1.6, 8); yaw = 0; pitch = 0 }

  func tap(_ v: SCNView, _ p: CGPoint) {
    let hits = v.hitTest(p, options: [SCNHitTestOption.searchMode: SCNHitTestSearchMode.all.rawValue])
    if mode == 1 {
      for h in hits { var n: SCNNode? = h.node
        while let c = n { if let nm = c.name, nm.hasPrefix("placed:") { select(c, String(nm.dropFirst(7))); return }; n = c.parent } }
      select(nil, nil); return }
    if mode == 2 {
      for h in hits { var n: SCNNode? = h.node
        while let c = n { if let nm = c.name, nm.hasPrefix("road:") { removeRoad(c, String(nm.dropFirst(5))); return }; if let nm = c.name, nm.hasPrefix("placed:") { remove(c, String(nm.dropFirst(7))); return }; n = c.parent } }
      return }
    guard let g = hits.first(where: { $0.node.name == "land" }) else { return }
    let c = g.worldCoordinates; if cat == "Vẽ đường" { addPoint(c.x, c.z); return }; let item = cat == "Cỏ" ? "grass" : sel; let pr = price(item)
    guard coins >= pr else { return }
    let r = Rec(id: UUID().uuidString, item: item, x: c.x, z: c.z, yaw: Float.random(in: 0...6.28), s: Float.random(in: 0.9...1.15))
    coins -= pr; recs.append(r); spawn(r); save()
  }
  func remove(_ n: SCNNode, _ id: String) {
    if let i = recs.firstIndex(where: { $0.id == id }) { coins += price(recs[i].item) / 2; recs.remove(at: i) }
    if selId == id { select(nil, nil) }
    n.removeFromParentNode(); save()
  }
  func save() { saveRoads(); UserDefaults.standard.set(coins, forKey: "coins"); if let d = try? JSONEncoder().encode(recs) { UserDefaults.standard.set(d, forKey: "recs") } }
}
