import SceneKit
import UIKit
import simd
import Metal

struct Rec: Codable { var id: String; var item: String; var x: Float; var z: Float; var yaw: Float; var s: Float }
struct RNG { var s: UInt64 = 7
  mutating func f(_ a: Float, _ b: Float) -> Float { s = s &* 6364136223846793005 &+ 1442695040888963407; return a + Float(s >> 40) / Float(1 << 24) * (b - a) } }

final class Game: ObservableObject {
  @Published var cat = "Cây cối"
  @Published var sel = "palm 2"
  @Published var mode = 0   // 0 đặt, 1 xóa
  let order = ["Cây cối", "Hoa & cây cảnh", "Bụi & hàng rào", "Cỏ", "Vẽ đường", "Nhà & vườn", "Ngoài trời & sân vườn", "Động vật", "Xe cộ", "Đường & giao thông", "Điện & hạ tầng", "Nhân vật", "Nội thất", "Đồ bếp & gia dụng"]
  var sizes: [String: [Float]] = [:]
  var items: [String: [String]] = [:]
  let scene = SCNScene(); let cam = SCNNode()
  var protos: [String: SCNNode] = [:]; var catOf: [String: String] = [:]
  var recs: [Rec] = []; var rng = RNG()
  let heights: [String: Float] = ["palm": 9, "palm 2": 9, "coconutTree": 10, "coconutTreeBended": 9, "fanPalm": 5, "sabalPalmeto": 3, "cypress": 9, "lombardyPoplar": 12, "pine": 8, "pine 2": 8, "tree": 6, "bonsai-tree": 0.8]

  init() {
    if let u = Bundle.main.url(forResource: "catalog", withExtension: "json"), let d = try? Data(contentsOf: u),
       let c = try? JSONDecoder().decode([String: [String]].self, from: d) { items = c; for (k, l) in c { for i in l { catOf[i] = k } } }
    if let u = Bundle.main.url(forResource: "sizes", withExtension: "json"), let d = try? Data(contentsOf: u), let z = try? JSONDecoder().decode([String: [Float]].self, from: d) { sizes = z }
    items["Cỏ"] = ["grass"]; catOf["grass"] = "Cỏ"; items["Vẽ đường"] = kinds; kinds.forEach { catOf[$0] = "Vẽ đường" }; items["Nhà & vườn"] = procIds; procIds.forEach { catOf[$0] = "Nhà & vườn" }
    buildTerrain(); seed()
    if let d = UserDefaults.standard.data(forKey: "recs"), let r = try? JSONDecoder().decode([Rec].self, from: d) { recs = r; r.forEach { spawn($0) } }
    if let d = UserDefaults.standard.data(forKey: "roads"), let r = try? JSONDecoder().decode([RoadRec].self, from: d) { roads = r; r.forEach { scene.rootNode.addChildNode(roadNode($0)) } }
  }

  func height(_ i: String) -> Float { heights[i] ?? (catOf[i] == "Cây cối" ? 7 : catOf[i] == "Bụi & hàng rào" ? 1.4 : 1.0) }

  // Tự đọc file .mtl để gắn texture (SceneKit không tự nạp texture của OBJ)
  struct MtlInfo { var kd = UIColor.white; var map: String? }
  static let flipV = true   // nếu texture bị ngược trên/dưới thì đổi thành false
  func parseMtl(_ dir: URL) -> ([String: MtlInfo], [MtlInfo]) {
    var d: [String: MtlInfo] = [:]; var list: [MtlInfo] = []
    let files = ((try? FileManager.default.contentsOfDirectory(atPath: dir.path)) ?? []).filter { $0.lowercased().hasSuffix(".mtl") }
    for f in files {
      guard let data = FileManager.default.contents(atPath: dir.appendingPathComponent(f).path) else { continue }
      var cur = ""; var info = MtlInfo()
      for raw in String(decoding: data, as: UTF8.self).components(separatedBy: .newlines) {
        let p = raw.components(separatedBy: .whitespaces).filter { !$0.isEmpty }; guard let k = p.first else { continue }
        if k == "newmtl" { if !cur.isEmpty { d[cur] = info; list.append(info) }; cur = p.dropFirst().joined(separator: " "); info = MtlInfo() }
        else if k == "Kd", p.count >= 4, let r = Double(p[1]), let g = Double(p[2]), let b = Double(p[3]) { info.kd = UIColor(red: CGFloat(r), green: CGFloat(g), blue: CGFloat(b), alpha: 1) }
        else if k == "map_Kd" { info.map = p.dropFirst().joined(separator: " ") } }
      if !cur.isEmpty { d[cur] = info; list.append(info) } }
    return (d, list)
  }

  func proto(_ id: String) -> SCNNode? {
    if let p = protos[id] { return p }
    if procIds.contains(id) { if let n = procModel(id) { protos[id] = n; return n }; return nil }
    guard let u = Bundle.main.url(forResource: id, withExtension: "obj", subdirectory: "Models/\(id)"),
          let s = try? SCNScene(url: u, options: nil) else { return nil }
    let inner = SCNNode(); s.rootNode.childNodes.forEach { inner.addChildNode($0) }
    let (mn, mx) = inner.boundingBox; let sz = sizes[id]; let ext = sz?[0] == 1 ? max(mx.x - mn.x, mx.z - mn.z) : (mx.y - mn.y); let k = (sz?[1] ?? height(id)) / max(ext, 0.001)
    inner.scale = SCNVector3(k, k, k)
    inner.position = SCNVector3(-(mn.x + mx.x) / 2 * k, -mn.y * k, -(mn.z + mx.z) / 2 * k)
    let dir = u.deletingLastPathComponent(); let (infos, infoList) = parseMtl(dir)
    let plant = ["Cây cối", "Hoa & cây cảnh", "Bụi & hàng rào"].contains(catOf[id] ?? "")
    let amp: Float = catOf[id] == "Cây cối" ? 0.035 : catOf[id] == "Bụi & hàng rào" ? 0.03 : 0.04
    let hgt = max(mx.y - mn.y, 0.001), baseY = mn.y
    inner.enumerateHierarchy { n, _ in n.geometry?.materials.enumerated().forEach { (i, m) in
      m.isDoubleSided = true
      var inf: MtlInfo? = infos[m.name ?? ""]; if inf == nil && i < infoList.count { inf = infoList[i] }
      if let inf = inf {
        if let f = inf.map, let img = UIImage(contentsOfFile: dir.appendingPathComponent((f as NSString).lastPathComponent).path) {
          m.diffuse.contents = img; m.diffuse.wrapS = .repeat; m.diffuse.wrapT = .repeat
          if Game.flipV { m.diffuse.contentsTransform = SCNMatrix4MakeScale(1, -1, 1) }
        } else { m.diffuse.contents = inf.kd } }
      if plant { m.shaderModifiers = [.geometry: Game.swayShader]
        m.setValue(NSNumber(value: hgt), forKey: "hh"); m.setValue(NSNumber(value: baseY), forKey: "base")
        m.setValue(NSNumber(value: amp * self.swayMul), forKey: "amp"); self.swayMats.append((m, amp)) } } }
    let w = SCNNode(); w.addChildNode(inner); protos[id] = w; return w
  }

  lazy var grassImg: UIImage = {
    UIGraphicsImageRenderer(size: CGSize(width: 128, height: 128)).image { c in
      for i in 0..<22 { let x = CGFloat(i) * 6 + 2, h = CGFloat(60 + (i * 37) % 60)
        UIColor(red: 0.25 + CGFloat(i % 4) * 0.05, green: 0.6 + CGFloat(i % 3) * 0.08, blue: 0.2, alpha: 1).setFill()
        let p = UIBezierPath(); p.move(to: CGPoint(x: x, y: 128)); p.addLine(to: CGPoint(x: x + 3 + CGFloat(i % 5), y: 128 - h)); p.addLine(to: CGPoint(x: x + 7, y: 128)); p.fill() } }
  }()
  func tuft() -> SCNNode { rosette(6, 0.5, 0.07, leafMat("grass"), outer: 0.9, inner: 1.35, arch: 0.4, fold: 0.1) }

  func spawn(_ r: Rec, name: String? = nil) {
    let n: SCNNode
    if r.item == "grass" { n = SCNNode(); for _ in 0..<10 { let t = tuft(); t.position = SCNVector3(Float.random(in: -0.8...0.8), 0, Float.random(in: -0.8...0.8)); n.addChildNode(t) } }
    else { guard let p = proto(r.item) else { return }; n = p.clone() }
    n.position = SCNVector3(r.x, 0, r.z); n.eulerAngles.y = r.yaw; n.scale = SCNVector3(r.s, r.s, r.s)
    n.name = name ?? "placed:\(r.id)"; scene.rootNode.addChildNode(n)
  }
  func seedPut(_ i: String, _ x: Float, _ z: Float) { spawn(Rec(id: "", item: i, x: x, z: z, yaw: rng.f(0, 6.28), s: rng.f(0.85, 1.2)), name: "seed") }

  func makeTex(_ base: UIColor, _ specks: [UIColor], _ count: Int, _ maxR: CGFloat, cracks: Int = 0, crackColor: UIColor = .black, crackW: CGFloat = 1.5, seed: UInt64) -> UIImage {
    var r = RNG(); r.s = seed; let S: CGFloat = 512
    return UIGraphicsImageRenderer(size: CGSize(width: S, height: S)).image { c in
      base.setFill(); c.fill(CGRect(x: 0, y: 0, width: S, height: S))
      for _ in 0..<count {
        specks[min(Int(r.f(0, Float(specks.count))), specks.count - 1)].withAlphaComponent(CGFloat(r.f(0.15, 0.6))).setFill()
        let d = CGFloat(r.f(1, Float(maxR)))
        UIBezierPath(ovalIn: CGRect(x: CGFloat(r.f(0, 512)), y: CGFloat(r.f(0, 512)), width: d, height: d * CGFloat(r.f(0.5, 1.5)))).fill() }
      for _ in 0..<cracks {
        var x = CGFloat(r.f(0, 512)), y = CGFloat(r.f(0, 512)); let q = UIBezierPath(); q.move(to: CGPoint(x: x, y: y)); var a = r.f(0, 6.28)
        for _ in 0..<Int(r.f(5, 14)) { a += r.f(-0.7, 0.7); x += CGFloat(cos(a)) * CGFloat(r.f(10, 30)); y += CGFloat(sin(a)) * CGFloat(r.f(10, 30)); q.addLine(to: CGPoint(x: x, y: y)) }
        crackColor.withAlphaComponent(0.85).setStroke(); q.lineWidth = crackW * CGFloat(r.f(0.5, 1.4)); q.stroke() } }
  }
  func mat(_ img: UIImage, _ sx: Float, _ sy: Float) -> SCNMaterial {
    let m = SCNMaterial(); m.diffuse.contents = img; m.diffuse.wrapS = .repeat; m.diffuse.wrapT = .repeat
    m.diffuse.contentsTransform = SCNMatrix4MakeScale(sx, sy, 1); m.lightingModel = .blinn; m.specular.contents = UIColor(white: 0.08, alpha: 1); return m
  }
  func tplane(_ w: CGFloat, _ l: CGFloat, _ x: Float, _ y: Float, _ z: Float, _ m: SCNMaterial, _ name: String?) {
    let p = SCNPlane(width: w, height: l); p.firstMaterial = m
    let n = SCNNode(geometry: p); n.eulerAngles.x = -.pi / 2; n.position = SCNVector3(x, y, z); n.name = name; scene.rootNode.addChildNode(n)
  }
  // Bờ bùn dốc + nước lên xuống (thủy triều) để mép nước tràn vào ra trên phù sa
  static let bankShader = """
  #pragma body
  float t = scn_frame.time;
  float lvl = -0.55 + 0.3 * sin(t * 0.5) + 0.03 * sin(t * 1.9);
  float u = _surface.diffuseTexcoord.x;
  float d = (-0.05 - u * 1.15) - lvl;
  float wet = 1.0 - smoothstep(0.0, 0.3, d);
  _surface.diffuse.rgb *= (1.0 - 0.5 * wet);
  _surface.specular.rgb += wet * 0.15;
  float edge = smoothstep(0.0, 0.02, d) * (1.0 - smoothstep(0.02, 0.1, d));
  float n = 0.6 + 0.4 * sin(_surface.diffuseTexcoord.y * 108.0 + t * 1.5);
  _surface.diffuse.rgb = mix(_surface.diffuse.rgb, float3(0.95), edge * n);
  """
  func makeBank(_ img: UIImage) {
    var v: [SCNVector3] = [], nm: [SCNVector3] = [], t: [CGPoint] = []
    for z in [Float(20), Float(-390)] {
      v.append(SCNVector3(-8, -0.05, z)); v.append(SCNVector3(-26, -1.2, z))
      nm.append(SCNVector3(-0.064, 0.998, 0)); nm.append(SCNVector3(-0.064, 0.998, 0))
      t.append(CGPoint(x: 0, y: CGFloat(z / 18))); t.append(CGPoint(x: 1, y: CGFloat(z / 18))) }
    let g = SCNGeometry(sources: [SCNGeometrySource(vertices: v), SCNGeometrySource(normals: nm), SCNGeometrySource(textureCoordinates: t)],
                        elements: [SCNGeometryElement(indices: [Int32](arrayLiteral: 0, 2, 1, 1, 2, 3), primitiveType: .triangles)])
    let m = mat(img, 1, 1); m.isDoubleSided = true; m.shaderModifiers = [.fragment: Game.bankShader]; g.firstMaterial = m
    let n = SCNNode(geometry: g); n.name = "bank"; scene.rootNode.addChildNode(n)
  }
  func makeWater() {
    let p = SCNPlane(width: 56, height: 420); p.widthSegmentCount = 40; p.heightSegmentCount = 240
    let m = SCNMaterial(); m.lightingModel = .blinn; m.diffuse.contents = UIColor(red: 0.30, green: 0.34, blue: 0.2, alpha: 1)
    m.specular.contents = UIColor.white; m.shininess = 0.9
    m.reflective.contents = UIColor(red: 0.8, green: 0.9, blue: 0.95, alpha: 1); m.fresnelExponent = 2.5
    m.shaderModifiers = [
      .geometry: """
      #pragma body
      float t = scn_frame.time; float2 q = _geometry.position.xy;
      float a = q.x * 0.8 + t * 1.2, b = q.y * 0.5 + t * 0.9, c = (q.x + q.y) * 1.7 + t * 2.0;
      _geometry.position.z += sin(a) * 0.03 + sin(b) * 0.04 + sin(c) * 0.015 + sin(t * 0.5) * 0.3;
      float dx = cos(a) * 0.024 + cos(c) * 0.0255, dy = cos(b) * 0.02 + cos(c) * 0.0255;
      _geometry.normal = normalize(float3(-dx, -dy, 1.0));
      """,
      .fragment: """
      #pragma body
      float2 uv = _surface.diffuseTexcoord * float2(48.0, 420.0); float t = scn_frame.time;
      float r = sin(uv.x * 3.1 + t * 1.6) * sin(uv.y * 2.3 - t * 1.2) + sin((uv.x + uv.y) * 5.0 + t * 2.5) * 0.5 + sin((uv.x - uv.y) * 9.0 - t * 3.1) * 0.25;
      _surface.normal = normalize(_surface.normal + float3(r * 0.06, r * 0.06, 0.0));
      _surface.diffuse.rgb += r * 0.035;
      """]
    p.firstMaterial = m
    let n = SCNNode(geometry: p); n.eulerAngles.x = -.pi / 2; n.position = SCNVector3(-34, -0.55, -170); n.name = "water"; scene.rootNode.addChildNode(n)
  }
  func plane(_ w: CGFloat, _ l: CGFloat, _ x: Float, _ y: Float, _ z: Float, _ c: UIColor, _ name: String?) -> SCNNode {
    let p = SCNPlane(width: w, height: l); p.firstMaterial?.diffuse.contents = c; p.firstMaterial?.lightingModel = .blinn
    let n = SCNNode(geometry: p); n.eulerAngles.x = -.pi / 2; n.position = SCNVector3(x, y, z); n.name = name; scene.rootNode.addChildNode(n); return n
  }

  func buildTerrain() {
    let sky = UIColor(red: 0.75, green: 0.86, blue: 0.9, alpha: 1)
    scene.background.contents = sky; scene.fogColor = sky; scene.fogStartDistance = 40; scene.fogEndDistance = 190
    let amb = SCNNode(); amb.light = SCNLight(); amb.light?.type = .ambient; amb.light?.intensity = 650; scene.rootNode.addChildNode(amb)
    let sun = SCNNode(); sun.light = SCNLight(); sun.light?.type = .directional; sun.light?.intensity = 1000; sun.light?.castsShadow = true; sun.light?.shadowRadius = 3; sun.light?.shadowColor = UIColor(white: 0, alpha: 0.45)
    sun.eulerAngles = SCNVector3(-0.9, -0.6, 0); scene.rootNode.addChildNode(sun)
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    let grassT = makeTex(C(0.36, 0.52, 0.2), [C(0.25, 0.42, 0.14), C(0.5, 0.66, 0.28), C(0.3, 0.3, 0.15)], 2800, 10, seed: 11)
    let soilT = makeTex(C(0.33, 0.26, 0.19), [C(0.22, 0.17, 0.12), C(0.45, 0.37, 0.26), C(0.3, 0.45, 0.18)], 2800, 14, seed: 12)
    let mudT = makeTex(C(0.2, 0.19, 0.17), [C(0.1, 0.1, 0.09), C(0.35, 0.34, 0.31)], 1800, 9, cracks: 34, crackColor: C(0.03, 0.03, 0.03), crackW: 2, seed: 13)
    let mudMat = mat(mudT, 1, 1)
    tplane(110, 420, 47, -0.02, -170, mat(grassT, 110 / 6, 420 / 6), "land")
    tplane(36, 420, 22, -0.015, -170, mat(soilT, 6, 70), "land")
    makeBank(mudT)
    makeWater()
    tplane(90, 420, -106, -0.02, -170, mat(grassT, 15, 70), nil)
    let cs = [2, 3, 6, 4].enumerated().map { mat(makeTex(C(0.55, 0.57, 0.53), [C(0.4, 0.42, 0.38), C(0.72, 0.72, 0.68), C(0.35, 0.42, 0.3), C(0.92, 0.92, 0.9)], 3000, 6, cracks: $1, crackColor: C(0.13, 0.13, 0.12), seed: UInt64(20 + $0)), 1, 1) }
    let crackedMat = mat(makeTex(C(0.52, 0.54, 0.5), [C(0.4, 0.42, 0.38), C(0.7, 0.7, 0.66), C(0.35, 0.4, 0.3)], 3000, 6, cracks: 22, crackColor: C(0.12, 0.12, 0.11), crackW: 2.2, seed: 29), 1, 1)
    let path = SCNNode()
    for i in 0..<80 { let b = SCNBox(width: 2.1, height: 0.12, length: 2.96, chamferRadius: 0); b.firstMaterial = cs[i % 4]
      let n = SCNNode(geometry: b); n.position = SCNVector3(0, 0.04, 6 - Float(i) * 3); path.addChildNode(n) }
    let pf = path.flattenedClone(); pf.name = "land"; scene.rootNode.addChildNode(pf)
    let bb = SCNBox(width: 5, height: 0.12, length: 4.5, chamferRadius: 0); bb.firstMaterial = crackedMat
    let bn = SCNNode(geometry: bb); bn.position = SCNVector3(3.8, 0.05, 1.2); bn.eulerAngles.y = -0.5; bn.name = "land"; scene.rootNode.addChildNode(bn)
    let rk = SCNNode()   // khối bùn nứt ven bờ
    for i in 0..<45 { let k = rng.f(0.6, 1.6); let bx = SCNBox(width: CGFloat(k), height: CGFloat(k * 0.6), length: CGFloat(k * rng.f(0.8, 1.4)), chamferRadius: CGFloat(k * 0.15)); bx.firstMaterial = mudMat
      let n = SCNNode(geometry: bx); n.position = SCNVector3(rng.f(-7.5, -4), k * 0.25, 4 - Float(i) * 0.9); n.eulerAngles = SCNVector3(rng.f(-0.3, 0.3), rng.f(0, 6), rng.f(-0.3, 0.3)); rk.addChildNode(n) }
    scene.rootNode.addChildNode(rk.flattenedClone())
    let gr = SCNNode()   // cỏ phủ nền
    for _ in 0..<350 { let t = tuft(); t.position = SCNVector3(rng.f(-8, -1.3), 0, rng.f(-120, 8)); gr.addChildNode(t) }
    for _ in 0..<450 { let t = tuft(); t.position = SCNVector3(rng.f(1.3, 30), 0, rng.f(-120, 8)); gr.addChildNode(t) }
    scene.rootNode.addChildNode(gr.flattenedClone())
    cam.camera = SCNCamera(); cam.camera?.fieldOfView = 70; cam.camera?.zFar = 300; cam.position = SCNVector3(0, 1.6, 8); scene.rootNode.addChildNode(cam)
  }

  func seed() {   // dựng lại cảnh trong ảnh bằng các model thật
    var z: Float = 6
    let forest = ["tree", "birch", "cypress", "lombardyPoplar", "pine", "acacia"]
    var k = 0
    while z > -150 {
      let m: Float = z > -60 ? 1 : 2.5
      seedPut("hedge", -1.9, z); seedPut("hedge", 1.9, z)
      if k % 2 == 0 { seedPut("roses-bush", -2.4, z - 1); seedPut("lavender-bush", 2.5, z - 1) }
      if k % Int(3 * m) == 0 { seedPut(k % 2 == 0 ? "palm" : "fanPalm", rng.f(3.5, 6), z); seedPut("coconutTree", rng.f(-11, -9), z) }
      if k % Int(2 * m) == 0 { seedPut(forest[k % forest.count], rng.f(7, 18), z + rng.f(-2, 2)) }
      if k % 9 == 0 && z > -100 { seedPut("coconutTree", rng.f(-70, -64), z); seedPut("weepingWillow", rng.f(-90, -75), z) }
      z -= 2.5 * m; k += 1 }
  }

  // ===== Nhà & vườn: mô hình tự dựng chi tiết (lá có gân, chậu tiện, mái lá nhiều lớp...) =====
  let procIds = ["Nhà mái lá", "Luống rau", "Luống cải bắp", "Luống đất", "Chậu cây đỏ", "Hàng chậu", "Giàn leo", "Hàng rào gỗ", "Lu sành", "Hoa hướng dương"]
  var geoCache: [String: SCNGeometry] = [:]; var leafMats: [String: SCNMaterial] = [:]
  func pcol(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> SCNMaterial {
    let m = SCNMaterial(); m.diffuse.contents = UIColor(red: r, green: g, blue: b, alpha: 1); m.lightingModel = .blinn; m.specular.contents = UIColor(white: 0.08, alpha: 1); return m }
  func pbox(_ w: CGFloat, _ h: CGFloat, _ l: CGFloat, _ x: Float, _ y: Float, _ z: Float, _ m: SCNMaterial, _ ch: CGFloat = 0.012) -> SCNNode {
    let g = SCNBox(width: w, height: h, length: l, chamferRadius: ch); g.firstMaterial = m
    let n = SCNNode(geometry: g); n.position = SCNVector3(x, y, z); return n }
  func pcyl(_ r: CGFloat, _ h: CGFloat, _ x: Float, _ y: Float, _ z: Float, _ m: SCNMaterial) -> SCNNode {
    let g = SCNCylinder(radius: r, height: h); g.radialSegmentCount = 16; g.firstMaterial = m
    let n = SCNNode(geometry: g); n.position = SCNVector3(x, y, z); return n }
  func psph(_ r: CGFloat, _ x: Float, _ y: Float, _ z: Float, _ sy: Float, _ m: SCNMaterial) -> SCNNode {
    let g = SCNSphere(radius: r); g.segmentCount = 20; g.firstMaterial = m
    let n = SCNNode(geometry: g); n.position = SCNVector3(x, y, z); n.scale = SCNVector3(1, sy, 1); return n }

  func meshGeo(_ P: [SIMD3<Float>], _ UV: [SIMD2<Float>], _ I: [Int32]) -> SCNGeometry {
    var N = [SIMD3<Float>](repeating: .zero, count: P.count)
    for t in stride(from: 0, to: I.count, by: 3) { let a = Int(I[t]), b = Int(I[t + 1]), c = Int(I[t + 2]); let n = simd_cross(P[b] - P[a], P[c] - P[a]); N[a] += n; N[b] += n; N[c] += n }
    return SCNGeometry(sources: [SCNGeometrySource(vertices: P.map { SCNVector3($0.x, $0.y, $0.z) }),
      SCNGeometrySource(normals: N.map { n -> SCNVector3 in let l = simd_length(n); let u = l > 0 ? n / l : SIMD3<Float>(0, 1, 0); return SCNVector3(u.x, u.y, u.z) }),
      SCNGeometrySource(textureCoordinates: UV.map { CGPoint(x: CGFloat($0.x), y: CGFloat($0.y)) })],
      elements: [SCNGeometryElement(indices: I, primitiveType: .triangles)])
  }
  // lá thon, cong, có gấp dọc gân giữa
  func leafGeo(_ L: Float, _ W: Float, _ arch: Float, _ fold: Float, _ m: SCNMaterial) -> SCNGeometry {
    let key = "\(L)_\(W)_\(arch)_\(fold)_\(m.name ?? "")"; if let g = geoCache[key] { return g }
    var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32](); let segs = 8
    for i in 0...segs { let t = Float(i) / Float(segs)
      let w = W / 2 * pow(sin(Float.pi * pow(t, 0.75)), 0.9), y = arch * t * t * L, z = t * L * (1 - 0.15 * arch * t)
      for j in 0..<3 { let s = Float(j) - 1; P.append(SIMD3<Float>(s * w, y + fold * abs(s) * w, z)); UV.append(SIMD2<Float>(Float(j) / 2, t)) } }
    for i in 0..<segs { for j in 0..<2 { let a = Int32(i * 3 + j), b = a + 1, c = a + 3, d = a + 4; I += [a, c, b, b, c, d] } }
    let g = meshGeo(P, UV, I); g.firstMaterial = m; geoCache[key] = g; return g
  }
  func lathe(_ prof: [(Float, Float)], _ seg: Int = 28) -> SCNGeometry {
    var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32](); let n = prof.count
    for k in 0...seg { let a = Float(k) / Float(seg) * 2 * Float.pi
      for (r, y) in prof { P.append(SIMD3<Float>(r * cos(a), y, r * sin(a))); UV.append(SIMD2<Float>(Float(k) / Float(seg), y)) } }
    for k in 0..<seg { for j in 0..<(n - 1) { let a = Int32(k * n + j), b = a + 1, c = a + Int32(n), d = c + 1; I += [a, b, c, b, d, c] } }
    return meshGeo(P, UV, I)
  }
  func leafImg(_ a: UIColor, _ b: UIColor, _ v: UIColor) -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 128, height: 256)).image { c in
      let g = c.cgContext
      if let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [a.cgColor, b.cgColor] as CFArray, locations: [0, 1]) { g.drawLinearGradient(gr, start: CGPoint(x: 0, y: 256), end: CGPoint(x: 0, y: 0), options: []) }
      v.withAlphaComponent(0.35).setStroke(); g.setLineWidth(1.5)
      for k in 1..<12 { let y = CGFloat(k) * 20; for s in [CGFloat(-1), CGFloat(1)] { g.move(to: CGPoint(x: 64, y: y)); g.addQuadCurve(to: CGPoint(x: 64 + s * 58, y: y - 34), control: CGPoint(x: 64 + s * 30, y: y - 6)); g.strokePath() } }
      v.withAlphaComponent(0.85).setStroke(); g.setLineWidth(4); g.move(to: CGPoint(x: 64, y: 256)); g.addLine(to: CGPoint(x: 64, y: 8)); g.strokePath()
      for i in 0..<400 { UIColor(white: CGFloat((i * 37) % 100) / 100, alpha: 0.05).setFill(); g.fill(CGRect(x: CGFloat((i * 53) % 128), y: CGFloat((i * 97) % 256), width: 2, height: 2)) } }
  }
  func leafMat(_ k: String) -> SCNMaterial {
    if let m = leafMats[k] { return m }
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    let t: (UIColor, UIColor, UIColor)
    switch k {
    case "grass": t = (C(0.16, 0.4, 0.09), C(0.58, 0.78, 0.26), C(0.45, 0.62, 0.2))
    case "lettuce": t = (C(0.28, 0.52, 0.14), C(0.64, 0.84, 0.3), C(0.88, 0.96, 0.62))
    case "cabbage": t = (C(0.42, 0.6, 0.48), C(0.8, 0.9, 0.8), C(0.96, 0.98, 0.92))
    case "sun": t = (C(0.12, 0.36, 0.08), C(0.34, 0.6, 0.16), C(0.55, 0.75, 0.35))
    case "petal": t = (C(0.88, 0.55, 0.02), C(1.0, 0.87, 0.15), C(0.95, 0.7, 0.1))
    default: t = (C(0.1, 0.35, 0.08), C(0.4, 0.66, 0.18), C(0.7, 0.85, 0.45)) }
    let m = mat(leafImg(t.0, t.1, t.2), 1, 1); m.isDoubleSided = true; m.specular.contents = UIColor(white: 0.25, alpha: 1); m.shininess = 0.25; m.name = k
    leafMats[k] = m; return m
  }
  // cụm lá xoay theo góc vàng: dùng cho rau, cỏ, cây chậu, cánh hoa
  func rosette(_ n: Int, _ L: Float, _ W: Float, _ m: SCNMaterial, outer: Float, inner: Float, arch: Float, fold: Float = 0.15, radius: Float = 0, step: Float = 2.39996) -> SCNNode {
    let root = SCNNode()
    for i in 0..<n {
      let t = Float(i) / Float(max(n - 1, 1))
      let ln = SCNNode(geometry: leafGeo(L * (1 - 0.35 * t), W * (1 - 0.25 * t), arch, fold, m)); ln.position.z = radius
      ln.eulerAngles.x = -(outer + (inner - outer) * t + rng.f(-0.08, 0.08))
      let piv = SCNNode(); piv.eulerAngles.y = Float(i) * step + rng.f(-0.12, 0.12); piv.position.y = 0.008 * Float(i)
      piv.addChildNode(ln); root.addChildNode(piv) }
    return root
  }
  func cabbage(_ s: Float) -> SCNNode {
    let n = SCNNode(); let m = leafMat("cabbage")
    let core = SCNSphere(radius: 0.2); core.firstMaterial = m; let cn = SCNNode(geometry: core); cn.position.y = 0.2; cn.scale = SCNVector3(1, 0.9, 1); n.addChildNode(cn)
    n.addChildNode(rosette(7, 0.42, 0.32, m, outer: 0.45, inner: 0.9, arch: -0.25, radius: 0.1))
    let w = rosette(8, 0.5, 0.42, m, outer: 1.15, inner: 1.35, arch: 0.8, fold: 0.25, radius: 0.1); w.position.y = 0.06; n.addChildNode(w)
    n.scale = SCNVector3(s, s, s); return n
  }
  func flower(_ x: Float, _ z: Float, _ h: Float) -> SCNNode {
    let n = SCNNode(); n.position = SCNVector3(x, 0, z)
    n.addChildNode(pcyl(0.006, CGFloat(h), 0, h / 2, 0, pcol(0.2, 0.45, 0.15)))
    let pet = rosette(7, 0.06, 0.03, leafMat("petal"), outer: 0.25, inner: 0.25, arch: 0.15, step: 0.9); pet.position.y = h; n.addChildNode(pet)
    n.addChildNode(psph(0.012, 0, h + 0.012, 0, 1, pcol(0.5, 0.3, 0.05))); return n
  }
  func woodImg(_ base: UIColor) -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256)).image { c in
      let g = c.cgContext; base.setFill(); g.fill(CGRect(x: 0, y: 0, width: 256, height: 256))
      for i in 0..<90 { let x = CGFloat((i * 53) % 256), a = CGFloat((i * 37) % 100) / 100
        UIColor(white: a > 0.5 ? 0 : 1, alpha: 0.08 + 0.1 * a).setStroke(); g.setLineWidth(CGFloat(1 + i % 3))
        g.move(to: CGPoint(x: x, y: 0)); g.addCurve(to: CGPoint(x: x + CGFloat((i * 7) % 9) - 4, y: 256), control1: CGPoint(x: x + 6, y: 80), control2: CGPoint(x: x - 6, y: 170)); g.strokePath() }
      UIColor(white: 0, alpha: 0.35).setStroke(); g.setLineWidth(2)
      for k in 0..<4 { g.move(to: CGPoint(x: CGFloat(k) * 64, y: 0)); g.addLine(to: CGPoint(x: CGFloat(k) * 64, y: 256)); g.strokePath() } }
  }
  func thatchImg() -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256)).image { c in
      let g = c.cgContext; UIColor(red: 0.5, green: 0.4, blue: 0.27, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 256, height: 256))
      for i in 0..<900 { let x = CGFloat((i * 71) % 256), y0 = CGFloat((i * 29) % 256), len = CGFloat(30 + (i * 13) % 60), t = CGFloat((i * 37) % 100) / 100
        UIColor(red: 0.38 + 0.35 * t, green: 0.3 + 0.3 * t, blue: 0.18 + 0.2 * t, alpha: 0.7).setStroke(); g.setLineWidth(CGFloat(1 + i % 3))
        g.move(to: CGPoint(x: x, y: y0)); g.addLine(to: CGPoint(x: x + CGFloat(i % 5) - 2, y: y0 + len)); g.strokePath() }
      UIColor(white: 0, alpha: 0.22).setFill(); for k in 0..<2 { g.fill(CGRect(x: 0, y: CGFloat(k) * 128 + 118, width: 256, height: 10)) } }
  }
  func tileImg() -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 128, height: 128)).image { c in
      let g = c.cgContext; UIColor(red: 0.74, green: 0.74, blue: 0.7, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 128, height: 128))
      UIColor(white: 0.5, alpha: 0.7).setStroke(); g.setLineWidth(3); g.stroke(CGRect(x: 1, y: 1, width: 126, height: 126))
      g.setLineWidth(2); g.strokeEllipse(in: CGRect(x: 28, y: 28, width: 72, height: 72)); g.stroke(CGRect(x: 48, y: 48, width: 32, height: 32))
      for i in 0..<500 { UIColor(white: CGFloat((i * 37) % 100) / 100, alpha: 0.07).setFill(); g.fill(CGRect(x: CGFloat((i * 53) % 128), y: CGFloat((i * 97) % 128), width: 2, height: 2)) } }
  }
  func discImg() -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 128, height: 128)).image { c in
      let g = c.cgContext; UIColor(red: 0.25, green: 0.14, blue: 0.05, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 128, height: 128))
      for i in 0..<170 { let r = 4.4 * sqrt(CGFloat(i)), a = CGFloat(i) * 2.39996
        (i % 3 == 0 ? UIColor(red: 0.55, green: 0.38, blue: 0.1, alpha: 1) : UIColor(red: 0.12, green: 0.07, blue: 0.03, alpha: 1)).setFill()
        g.fillEllipse(in: CGRect(x: 64 + r * cos(a) - 2.4, y: 64 + r * sin(a) - 2.4, width: 4.8, height: 4.8)) } }
  }

  func potNode(_ s: Float, _ kind: Int) -> SCNNode {
    let n = SCNNode(); let clay = pcol(0.72, 0.16, 0.1); clay.specular.contents = UIColor(white: 0.3, alpha: 1); clay.shininess = 0.35; clay.isDoubleSided = true
    let g = lathe([(0, 0), (0.12, 0), (0.135, 0.02), (0.19, 0.27), (0.205, 0.29), (0.228, 0.3), (0.228, 0.345), (0.205, 0.356), (0.19, 0.335), (0.186, 0.32), (0, 0.312)]); g.firstMaterial = clay
    n.addChildNode(SCNNode(geometry: g)); n.addChildNode(pcyl(0.185, 0.02, 0, 0.316, 0, pcol(0.16, 0.11, 0.08)))
    let pl = rosette(9, 0.26, 0.15, leafMat(kind == 0 ? "default" : "lettuce"), outer: 0.5, inner: 1.2, arch: 0.4); pl.position.y = 0.32; n.addChildNode(pl)
    if kind == 0 { for k in 0..<3 { n.addChildNode(flower(0.08 * cos(Float(k) * 2.1), 0.08 * sin(Float(k) * 2.1), 0.5 + Float(k) * 0.05)) } }
    n.scale = SCNVector3(s, s, s); return n
  }
  func sunflower(_ h: Float) -> SCNNode {
    let n = SCNNode(); let stem = pcol(0.2, 0.42, 0.12); var px: Float = 0, py: Float = 0
    for i in 0..<6 { let seg = h / 6, lean = 0.06 * Float(i)
      let c = pcyl(0.03 - 0.003 * CGFloat(i), CGFloat(seg), px + seg * sin(lean) / 2, py + seg * cos(lean) / 2, 0, stem); c.eulerAngles.z = -lean; n.addChildNode(c); px += seg * sin(lean); py += seg * cos(lean) }
    let sm = leafMat("sun")
    for k in 0..<4 { let ln = SCNNode(geometry: leafGeo(0.32, 0.26, -0.5, 0.15, sm)); ln.eulerAngles.x = -0.35
      let piv = SCNNode(); piv.position = SCNVector3(0, 0.25 + 0.28 * Float(k), 0); piv.eulerAngles.y = Float(k) * 1.6 + 0.4; piv.addChildNode(ln); n.addChildNode(piv) }
    let head = SCNNode(); head.position = SCNVector3(px, py, 0); head.eulerAngles.x = 1.1
    let disc = SCNCylinder(radius: 0.14, height: 0.04); disc.firstMaterial = mat(discImg(), 1, 1); head.addChildNode(SCNNode(geometry: disc))
    for (k, yy) in [(0, Float(-0.012)), (1, 0.0)] { let r = rosette(18, 0.12, 0.045, leafMat("petal"), outer: 0.05, inner: 0.05, arch: 0.1, radius: 0.12, step: 0.349 + Float(k) * 0.17); r.position.y = yy; head.addChildNode(r) }
    n.addChildNode(head); return n
  }
  func houseNode() -> SCNNode {
    let root = SCNNode(); func U(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    let wood = mat(woodImg(U(0.45, 0.27, 0.16)), 1, 1), dark = mat(woodImg(U(0.3, 0.18, 0.1)), 1, 1), light = mat(woodImg(U(0.6, 0.4, 0.24)), 1, 1)
    let thatch = mat(thatchImg(), 3, 1); thatch.isDoubleSided = true; let straw = pcol(0.5, 0.4, 0.27)
    root.addChildNode(pbox(9.4, 0.3, 7, 0, 0.17, 0, dark, 0.02))
    for i in 0..<28 { root.addChildNode(pbox(0.33, 0.06, 7, -4.52 + Float(i) * 0.335, 0.36, 0, i % 2 == 0 ? light : wood, 0.01)) }
    root.addChildNode(pbox(2, 0.18, 0.8, 0, 0.09, 3.9, dark)); root.addChildNode(pbox(2, 0.18, 0.8, 0, 0.27, 3.6, wood))
    let post = lathe([(0.16, 0), (0.16, 0.12), (0.12, 0.16), (0.12, 2.35), (0.15, 2.4), (0.15, 2.46)], 16); post.firstMaterial = dark
    for x in [Float(-4.2), 0, 4.2] { for z in [Float(-3.1), 3.1] { let p = SCNNode(geometry: post); p.position = SCNVector3(x, 0.39, z); root.addChildNode(p) } }
    for i in 0..<40 { root.addChildNode(pbox(0.21, 2.3, 0.06, -4.3 + Float(i) * 0.215, 1.54, -3.1, i % 3 == 0 ? dark : wood)) }
    root.addChildNode(pbox(9, 0.12, 0.12, 0, 2.75, -3.1, dark)); root.addChildNode(pbox(9, 0.12, 0.12, 0, 0.45, -3.1, dark))
    // cửa sổ có chớp
    root.addChildNode(pbox(1.3, 1.1, 0.08, 2, 1.7, -3.04, pcol(0.1, 0.07, 0.05)))
    for k in 0..<7 { let lv = pbox(1.1, 0.06, 0.18, 2, 1.3 + Float(k) * 0.14, -2.98, light); lv.eulerAngles.x = -0.5; root.addChildNode(lv) }
    for sx in [Float(-4.5), 4.5] { root.addChildNode(pbox(0.1, 0.1, 6.2, sx, 1.25, 0, dark)); root.addChildNode(pbox(0.1, 0.1, 6.2, sx, 0.5, 0, dark))
      for i in 0..<24 { root.addChildNode(pcyl(0.025, 0.7, sx, 0.88, -3 + Float(i) * 0.26, wood)) } }
    for sx in [Float(-2.9), 2.9] { root.addChildNode(pbox(3, 0.1, 0.1, sx, 1.25, 3.2, dark)); root.addChildNode(pbox(3, 0.1, 0.1, sx, 0.5, 3.2, dark))
      for i in 0..<11 { root.addChildNode(pcyl(0.025, 0.7, sx - 1.25 + Float(i) * 0.25, 0.88, 3.2, wood)) } }
    // bàn ghế, đèn lồng
    root.addChildNode(pbox(1.6, 0.08, 0.9, -1.5, 0.85, -1.4, light)); for dx in [Float(-0.7), 0.7] { for dz in [Float(-0.35), 0.35] { root.addChildNode(pcyl(0.04, 0.45, -1.5 + dx, 0.62, -1.4 + dz, wood)) } }
    for sz in [Float(-0.4), Float(-2.4)] { root.addChildNode(pbox(1.8, 0.07, 0.35, -1.5, 0.62, sz, wood)); for dx in [Float(-0.75), 0.75] { root.addChildNode(pcyl(0.035, 0.28, -1.5 + dx, 0.5, sz, dark)) } }
    root.addChildNode(pcyl(0.006, 0.5, 1.2, 2.5, 1.5, pcol(0.1, 0.1, 0.1)))
    let lg = lathe([(0.0, 0), (0.1, 0.02), (0.16, 0.14), (0.12, 0.28), (0.06, 0.3), (0, 0.3)], 14); lg.firstMaterial = pcol(0.85, 0.2, 0.1); let ln = SCNNode(geometry: lg); ln.position = SCNVector3(1.2, 2.0, 1.5); root.addChildNode(ln)
    // mái tranh nhiều lớp
    let ridgeY: Float = 5.35
    for s in [Float(0), Float(1)] {
      let yaw = SCNNode(); yaw.position.y = ridgeY; yaw.eulerAngles.y = s * Float.pi; let tilt = SCNNode(); tilt.eulerAngles.x = 0.62; yaw.addChildNode(tilt)
      for i in 0..<10 { let c = pbox(10.6, 0.14, 0.8, 0, 0.02 * Float(i), 0.4 + Float(i) * 0.5, thatch, 0.03); c.eulerAngles.x = -0.1; tilt.addChildNode(c) }
      for k in 0..<110 { let len = 0.25 + 0.2 * Float((k * 37) % 10) / 10; let f = pbox(0.045, 0.025, CGFloat(len), -5.2 + Float(k) * 0.095, 0.0, 5.1 + len / 2, straw, 0.005); f.eulerAngles.x = 0.14 + 0.1 * Float((k * 13) % 5) / 5; tilt.addChildNode(f) }
      if s == 0 { let sp = pbox(2.6, 0.05, 1.5, -2.2, 0.2, 2.3, mat(solarImg(), 1, 1)); tilt.addChildNode(sp); tilt.addChildNode(pbox(2.7, 0.04, 1.6, -2.2, 0.17, 2.3, pcol(0.75, 0.75, 0.75))) }
      root.addChildNode(yaw) }
    let ridge = pcyl(0.24, 10.8, 0, ridgeY + 0.1, 0, thatch); ridge.eulerAngles.z = .pi / 2; root.addChildNode(ridge)
    for k in 0..<8 { let b = SCNTorus(ringRadius: 0.245, pipeRadius: 0.02); b.firstMaterial = dark; let bn = SCNNode(geometry: b); bn.position = SCNVector3(-4.8 + Float(k) * 1.37, ridgeY + 0.1, 0); bn.eulerAngles.z = .pi / 2; root.addChildNode(bn) }
    for sx in [Float(-5.4), 5.4] { for a in [Float(0.45), Float(-0.45)] { let p = pcyl(0.04, 1.4, sx, ridgeY + 0.65, 0, pcol(0.7, 0.6, 0.35)); p.eulerAngles.x = a; root.addChildNode(p) } }
    let tri = UIBezierPath(); tri.move(to: CGPoint(x: -3.1, y: 0)); tri.addLine(to: CGPoint(x: 3.1, y: 0)); tri.addLine(to: CGPoint(x: 0, y: 2.3)); tri.close()
    for sx in [Float(-4.95), 4.95] { let sh = SCNShape(path: tri, extrusionDepth: 0.12); sh.firstMaterial = dark; let n = SCNNode(geometry: sh); n.position = SCNVector3(sx, 2.85, 0); n.eulerAngles.y = .pi / 2; root.addChildNode(n) }
    for z in [Float(-3.6), 3.6] { let p = pcyl(0.05, 10.4, 0, 2.95, z, pcol(0.7, 0.6, 0.35)); p.eulerAngles.z = .pi / 2; root.addChildNode(p) }
    return root
  }
  func solarImg() -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 192, height: 112)).image { c in
      let g = c.cgContext; UIColor(red: 0.07, green: 0.1, blue: 0.22, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 192, height: 112))
      UIColor(white: 0.7, alpha: 0.6).setStroke(); g.setLineWidth(1.5)
      for i in 0...6 { g.move(to: CGPoint(x: CGFloat(i) * 32, y: 0)); g.addLine(to: CGPoint(x: CGFloat(i) * 32, y: 112)); g.strokePath() }
      for j in 0...4 { g.move(to: CGPoint(x: 0, y: CGFloat(j) * 28)); g.addLine(to: CGPoint(x: 192, y: CGFloat(j) * 28)); g.strokePath() } }
  }
  func bedNode(_ id: String) -> SCNNode {
    let root = SCNNode(); let tile = mat(tileImg(), 1, 12)
    for sx in [Float(-1.22), 1.22] { root.addChildNode(pbox(0.28, 0.22, 6.3, sx, 0.11, 0, tile, 0.035)) }
    let soil = mat(makeTex(UIColor(red: 0.2, green: 0.14, blue: 0.1, alpha: 1), [UIColor(red: 0.1, green: 0.07, blue: 0.05, alpha: 1), UIColor(red: 0.4, green: 0.3, blue: 0.2, alpha: 1)], 1800, 7, seed: 77), 2, 6)
    root.addChildNode(pbox(2.2, 0.16, 6.1, 0, 0.08, 0, soil, 0.06))
    let hose = pcol(0.04, 0.04, 0.04)
    if id != "Luống đất" { let h = pcyl(0.014, 6, 0, 0.19, 0, hose); h.eulerAngles.x = .pi / 2; root.addChildNode(h); for i in 0..<12 { root.addChildNode(psph(0.022, 0.02, 0.2, -2.8 + Float(i) * 0.5, 0.6, pcol(0.1, 0.3, 0.8))) } }
    if id == "Luống rau" {
      for x in [Float(-0.7), 0, 0.7] { for i in 0..<13 { let p = rosette(8, 0.3, 0.17, leafMat(i % 3 == 0 ? "default" : "lettuce"), outer: 0.5, inner: 1.1, arch: 0.45, fold: 0.2)
        let s = rng.f(0.8, 1.25); p.scale = SCNVector3(s, s, s); p.position = SCNVector3(x + rng.f(-0.05, 0.05), 0.15, -2.8 + Float(i) * 0.45 + rng.f(-0.04, 0.04)); root.addChildNode(p) } }
    } else if id == "Luống cải bắp" {
      for x in [Float(-0.65), 0, 0.65] { for i in 0..<7 { let c = cabbage(rng.f(0.85, 1.1)); c.position = SCNVector3(x, 0.14, -2.7 + Float(i) * 0.9); root.addChildNode(c) } }
    } else {
      let ridge = mat(makeTex(UIColor(red: 0.16, green: 0.11, blue: 0.08, alpha: 1), [UIColor(red: 0.3, green: 0.22, blue: 0.14, alpha: 1)], 1200, 6, seed: 78), 1, 6)
      for x in [Float(-0.65), 0, 0.65] { root.addChildNode(pbox(0.5, 0.18, 5.7, x, 0.2, 0, ridge, 0.09))
        for i in 0..<9 { let sp = rosette(3, 0.1, 0.05, leafMat("default"), outer: 0.8, inner: 0.8, arch: 0.3); sp.position = SCNVector3(x, 0.28, -2.6 + Float(i) * 0.65); root.addChildNode(sp) } }
      for _ in 0..<40 { let b = pbox(0.02, 0.01, CGFloat(rng.f(0.1, 0.3)), rng.f(-1, 1), 0.17, rng.f(-2.8, 2.8), pcol(0.8, 0.7, 0.4), 0.004); b.eulerAngles.y = rng.f(0, 3); root.addChildNode(b) } }
    return root
  }
  func procModel(_ id: String) -> SCNNode? {
    let root = SCNNode(); let wood = mat(woodImg(UIColor(red: 0.45, green: 0.3, blue: 0.18, alpha: 1)), 1, 1), bamboo = pcol(0.72, 0.62, 0.36)
    switch id {
    case "Nhà mái lá": root.addChildNode(houseNode())
    case "Luống rau", "Luống cải bắp", "Luống đất": root.addChildNode(bedNode(id))
    case "Chậu cây đỏ": root.addChildNode(potNode(1, 0))
    case "Hàng chậu": for i in 0..<6 { let p = potNode(i % 2 == 0 ? 1 : 0.85, i % 2); p.position = SCNVector3(0, 0, Float(i) * 0.55 - 1.4); root.addChildNode(p) }
    case "Giàn leo":
      for i in 0..<5 { let x = -2.4 + Float(i) * 1.2; root.addChildNode(pcyl(0.04, 2.2, x, 1.1, 0, bamboo))
        for k in 1..<5 { let t = SCNTorus(ringRadius: 0.042, pipeRadius: 0.012); t.firstMaterial = pcol(0.5, 0.42, 0.2); let tn = SCNNode(geometry: t); tn.position = SCNVector3(x, Float(k) * 0.42, 0); root.addChildNode(tn) }
        if i > 0 { for s in [Float(-1), 1] { let d = pbox(0.03, 2.4, 0.03, x - 0.6, 1.1, 0, bamboo, 0.005); d.eulerAngles.z = s * 0.5; root.addChildNode(d) } } }
      for y in [Float(0.6), 1.2, 1.8] { let r = pcyl(0.025, 4.8, 0, y, 0, bamboo); r.eulerAngles.z = .pi / 2; root.addChildNode(r) }
      for _ in 0..<24 { let v = rosette(4, 0.12, 0.08, leafMat("default"), outer: 0.6, inner: 0.6, arch: 0.3); v.position = SCNVector3(rng.f(-2.4, 2.4), rng.f(0.3, 2.1), rng.f(-0.06, 0.06)); root.addChildNode(v) }
      for _ in 0..<7 { let f = flower(rng.f(-2.2, 2.2), 0.06, 0.02); f.position.y = rng.f(0.5, 2); root.addChildNode(f) }
    case "Hàng rào gỗ":
      for i in 0..<5 { let x = -3 + Float(i) * 1.5; root.addChildNode(pcyl(0.065, 1.15, x, 0.575, 0, wood)); root.addChildNode(psph(0.07, x, 1.17, 0, 0.8, wood)) }
      for y in [Float(0.5), 0.9] { root.addChildNode(pbox(6, 0.09, 0.06, 0, y, 0, wood, 0.02)) }
      for i in 0..<20 { root.addChildNode(pbox(0.07, 0.95, 0.025, -2.85 + Float(i) * 0.3, 0.5, 0.05, wood, 0.01)) }
    case "Lu sành":
      let g = lathe([(0, 0), (0.2, 0), (0.3, 0.05), (0.42, 0.25), (0.46, 0.45), (0.4, 0.65), (0.28, 0.8), (0.22, 0.88), (0.24, 0.93), (0.27, 0.96), (0.25, 0.985), (0.2, 0.96), (0, 0.94)], 32)
      let clay = pcol(0.45, 0.22, 0.1); clay.specular.contents = UIColor(white: 0.6, alpha: 1); clay.shininess = 0.7; clay.isDoubleSided = true; g.firstMaterial = clay; root.addChildNode(SCNNode(geometry: g))
    case "Hoa hướng dương":
      for k in 0..<6 { let s = sunflower(rng.f(1.2, 1.75)); s.position = SCNVector3(rng.f(-0.7, 0.7), 0, rng.f(-0.7, 0.7)); s.eulerAngles.y = Float(k); root.addChildNode(s) }
    default: return nil }
    return root.flattenedClone()
  }

  // ===== Ảnh xem trước mô hình + thu nhập =====
  @Published var thumbs: [String: UIImage] = [:]
  var thumbQ: [String] = []; var thumbBusy = false
  lazy var thumbRenderer: SCNRenderer? = { MTLCreateSystemDefaultDevice().map { SCNRenderer(device: $0, options: nil) } }()
  func icon(_ i: String) -> String { i == "grass" ? "🌿" : i == "Đường nhựa" ? "🛣️" : i == "Đường đất" ? "🟫" : i == "Mương nước" ? "💧" : "⏳" }
  func requestThumb(_ id: String) {
    guard thumbs[id] == nil, !thumbQ.contains(id), id != "grass", catOf[id] != "Vẽ đường" else { return }
    thumbQ.append(id); pump()
  }
  func pump() {
    guard !thumbBusy, !thumbQ.isEmpty else { return }
    thumbBusy = true; let id = thumbQ.removeFirst()
    DispatchQueue.main.async { self.thumbs[id] = self.renderThumb(id) ?? UIImage(systemName: "questionmark.square")!; self.thumbBusy = false; self.pump() }
  }
  func renderThumb(_ id: String) -> UIImage? {
    guard let r = thumbRenderer, let p = proto(id) else { return nil }
    let sc = SCNScene(); sc.background.contents = UIColor(red: 0.8, green: 0.88, blue: 0.9, alpha: 1)
    let n = p.clone(); sc.rootNode.addChildNode(n)
    let (mn, mx) = n.boundingBox; let c = SCNVector3((mn.x + mx.x) / 2, (mn.y + mx.y) / 2, (mn.z + mx.z) / 2)
    let size = max(mx.x - mn.x, mx.y - mn.y, mx.z - mn.z, 0.1)
    let look = SCNNode(); look.position = c; sc.rootNode.addChildNode(look)
    let cm = SCNNode(); cm.camera = SCNCamera(); cm.camera?.fieldOfView = 35
    cm.position = SCNVector3(c.x + size * 0.9, c.y + size * 0.5, c.z + size * 1.8); cm.constraints = [SCNLookAtConstraint(target: look)]; sc.rootNode.addChildNode(cm)
    let a = SCNNode(); a.light = SCNLight(); a.light?.type = .ambient; a.light?.intensity = 700; sc.rootNode.addChildNode(a)
    let d = SCNNode(); d.light = SCNLight(); d.light?.type = .directional; d.light?.intensity = 900; d.eulerAngles = SCNVector3(-0.7, 0.6, 0); sc.rootNode.addChildNode(d)
    r.scene = sc; r.pointOfView = cm
    return r.snapshot(atTime: 0, with: CGSize(width: 160, height: 160), antialiasingMode: .multisampling4X)
  }

  // ===== Cây, bụi đung đưa =====
  @Published var swayLevel = UserDefaults.standard.object(forKey: "sway") as? Int ?? 1   // 0 tắt, 1 nhẹ, 2 mạnh
  var swayMats: [(SCNMaterial, Float)] = []
  var swayMul: Float { [0, 1, 2.2][swayLevel] }
  static let swayShader = """
  uniform float amp; uniform float hh; uniform float base;
  #pragma body
  float h = clamp((_geometry.position.y - base) / hh, 0.0, 1.0);
  float k = h * h * amp * hh;
  float t = scn_frame.time;
  float ph = (_geometry.position.x + _geometry.position.z) / hh * 6.0;
  _geometry.position.x += (sin(t * 1.6 + ph) + sin(t * 5.0 + ph * 3.0) * 0.15) * k;
  _geometry.position.z += cos(t * 1.3 + ph * 1.3) * k * 0.7;
  """
  func cycleSway() {
    swayLevel = (swayLevel + 1) % 3; UserDefaults.standard.set(swayLevel, forKey: "sway")
    for (m, a) in swayMats { m.setValue(NSNumber(value: a * swayMul), forKey: "amp") }
  }

  // ===== Vẽ đường / mương: tự nối điểm gần nhau + bo góc =====
  struct RoadRec: Codable { var id: String; var kind: Int; var pts: [[Float]] }
  let kinds = ["Đường nhựa", "Đường đất", "Mương nước"]; let widths: [Float] = [6, 3.5, 2.8]
  var roads: [RoadRec] = []; var draft: [[Float]] = []
  @Published var drawing = 0
  var kindIdx: Int { kinds.firstIndex(of: sel) ?? 0 }
  static let canalFrag = """
  #pragma body
  float2 uv = _surface.diffuseTexcoord * float2(4.0, 40.0); float t = scn_frame.time;
  float r = sin(uv.x * 3.1 + t * 1.6) * sin(uv.y * 2.3 - t * 1.2) + sin((uv.x + uv.y) * 5.0 + t * 2.5) * 0.5;
  _surface.normal = normalize(_surface.normal + float3(r * 0.06, r * 0.06, 0.0));
  _surface.diffuse.rgb += r * 0.035;
  """
  func laneImg(_ dirt: Bool) -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256)).image { c in
      let g = c.cgContext
      (dirt ? UIColor(red: 0.45, green: 0.34, blue: 0.22, alpha: 1) : UIColor(white: 0.22, alpha: 1)).setFill(); g.fill(CGRect(x: 0, y: 0, width: 256, height: 256))
      UIColor(white: dirt ? 0.4 : 0.72, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 30, height: 256)); g.fill(CGRect(x: 226, y: 0, width: 30, height: 256))
      if !dirt { UIColor(red: 0.95, green: 0.8, blue: 0.2, alpha: 1).setFill(); g.fill(CGRect(x: 124, y: 0, width: 8, height: 128)) }
      for i in 0..<900 { UIColor(white: CGFloat((i * 37) % 100) / 100, alpha: 0.08).setFill(); g.fill(CGRect(x: CGFloat((i * 53) % 256), y: CGFloat((i * 97) % 256), width: 3, height: 3)) } }
  }
  func roadMat(_ img: UIImage) -> SCNMaterial { let m = mat(img, 1, 1); m.isDoubleSided = true; return m }
  lazy var asphaltMat = roadMat(laneImg(false))
  lazy var dirtMat = roadMat(laneImg(true))
  lazy var bankMat = roadMat(makeTex(UIColor(white: 0.6, alpha: 1), [UIColor(white: 0.45, alpha: 1), UIColor(white: 0.75, alpha: 1)], 1500, 6, cracks: 6, crackColor: UIColor(white: 0.15, alpha: 1), seed: 41))
  lazy var canalWater: SCNMaterial = {
    let m = SCNMaterial(); m.lightingModel = .blinn; m.diffuse.contents = UIColor(red: 0.28, green: 0.4, blue: 0.3, alpha: 1)
    m.specular.contents = UIColor.white; m.shininess = 0.9; m.isDoubleSided = true; m.shaderModifiers = [.fragment: Game.canalFrag]; return m }()

  func smooth(_ p: [[Float]], _ rad: Float) -> [SIMD2<Float>] {   // bo góc bằng cung bezier
    let q = p.map { SIMD2<Float>($0[0], $0[1]) }; guard q.count > 2 else { return q }
    var out = [q[0]]
    for i in 1..<(q.count - 1) {
      let a = q[i - 1], c = q[i], b = q[i + 1]; let r = min(rad, 0.45 * simd_length(a - c), 0.45 * simd_length(b - c))
      if r < 0.01 { out.append(c); continue }
      let s = c + simd_normalize(a - c) * r, e = c + simd_normalize(b - c) * r
      for k in 0...8 { let t = Float(k) / 8; out.append((1 - t) * (1 - t) * s + 2 * (1 - t) * t * c + t * t * e) } }
    out.append(q[q.count - 1]); return out
  }
  func ribbon(_ p: [SIMD2<Float>], _ w: Float, _ y: Float, _ m: SCNMaterial) -> SCNNode? {
    guard p.count > 1 else { return nil }
    var v = [SCNVector3](), nm = [SCNVector3](), t = [CGPoint](), idx = [Int32](); var d: Float = 0
    for i in 0..<p.count {
      let dv = p[min(i + 1, p.count - 1)] - p[max(i - 1, 0)]; let l = simd_length(dv); let dir = l > 0 ? dv / l : SIMD2<Float>(0, 1)
      if i > 0 { d += simd_length(p[i] - p[i - 1]) }
      let n = SIMD2<Float>(-dir.y, dir.x) * (w / 2)
      v.append(SCNVector3(p[i].x + n.x, y, p[i].y + n.y)); v.append(SCNVector3(p[i].x - n.x, y, p[i].y - n.y))
      nm.append(SCNVector3(0, 1, 0)); nm.append(SCNVector3(0, 1, 0))
      t.append(CGPoint(x: 0, y: CGFloat(d / 8))); t.append(CGPoint(x: 1, y: CGFloat(d / 8)))
      if i > 0 { let b = Int32(2 * i); idx += [b - 2, b, b - 1, b - 1, b, b + 1] } }
    let g = SCNGeometry(sources: [SCNGeometrySource(vertices: v), SCNGeometrySource(normals: nm), SCNGeometrySource(textureCoordinates: t)],
                        elements: [SCNGeometryElement(indices: idx, primitiveType: .triangles)])
    g.firstMaterial = m; return SCNNode(geometry: g)
  }
  func disc(_ pt: SIMD2<Float>, _ r: Float, _ y: Float, _ m: SCNMaterial) -> SCNNode {
    let c = SCNCylinder(radius: CGFloat(r), height: 0.004); c.firstMaterial = m
    let n = SCNNode(geometry: c); n.position = SCNVector3(pt.x, y + 0.002, pt.y); return n
  }
  func roadNode(_ r: RoadRec) -> SCNNode {
    let n = SCNNode(); n.name = "road:\(r.id)"; let p = smooth(r.pts, 3.5), w = widths[r.kind]
    if r.kind == 2 {
      if let a = ribbon(p, w, 0.06, bankMat) { n.addChildNode(a) }; if let b = ribbon(p, w - 1.2, 0.07, canalWater) { n.addChildNode(b) }
      for e in [p.first!, p.last!] { n.addChildNode(disc(e, w / 2, 0.06, bankMat)); n.addChildNode(disc(e, w / 2 - 0.6, 0.07, canalWater)) }
    } else {
      let m = r.kind == 0 ? asphaltMat : dirtMat
      if let a = ribbon(p, w, 0.05, m) { n.addChildNode(a) }; for e in [p.first!, p.last!] { n.addChildNode(disc(e, w / 2, 0.05, m)) } }
    return n
  }
  func snap(_ x: Float, _ z: Float) -> [Float] {   // tự nối vào điểm đường có sẵn trong 2.5 m
    var best: [Float]? = nil; var bd: Float = 2.5
    for r in roads { for p in r.pts { let d = hypot(p[0] - x, p[1] - z); if d < bd { bd = d; best = p } } }
    return best ?? [x, z]
  }
  func addPoint(_ x: Float, _ z: Float) {
    let p = snap(x, z); if let l = draft.last, l == p { return }
    draft.append(p); drawing = draft.count; preview()
  }
  func preview() {
    scene.rootNode.childNode(withName: "draft", recursively: false)?.removeFromParentNode()
    let d = SCNNode(); d.name = "draft"
    for p in draft { let s = SCNSphere(radius: 0.35); s.firstMaterial?.diffuse.contents = UIColor.yellow; let n = SCNNode(geometry: s); n.position = SCNVector3(p[0], 0.4, p[1]); d.addChildNode(n) }
    if draft.count > 1 { d.addChildNode(roadNode(RoadRec(id: "d", kind: kindIdx, pts: draft))) }
    scene.rootNode.addChildNode(d)
  }
  func undoPoint() { if !draft.isEmpty { draft.removeLast(); drawing = draft.count; preview() } }
  func length(_ p: [[Float]]) -> Float { zip(p, p.dropFirst()).reduce(0) { $0 + hypot($1.0[0] - $1.1[0], $1.0[1] - $1.1[1]) } }
  func finish() {
    guard draft.count > 1 else { draft = []; drawing = 0; preview(); return }
    let r = RoadRec(id: UUID().uuidString, kind: kindIdx, pts: draft); roads.append(r); scene.rootNode.addChildNode(roadNode(r))
    draft = []; drawing = 0; preview(); save()
  }
  func removeRoad(_ n: SCNNode, _ id: String) {
    if let i = roads.firstIndex(where: { $0.id == id }) { roads.remove(at: i) }
    n.removeFromParentNode(); save()
  }
  func saveRoads() { if let d = try? JSONEncoder().encode(roads) { UserDefaults.standard.set(d, forKey: "roads") } }

  // chọn / phóng to / thu nhỏ
  @Published var selId: String? = nil
  var ring: SCNNode?
  func select(_ n: SCNNode?, _ id: String?) {
    ring?.removeFromParentNode(); ring = nil; selId = id
    guard let n = n else { return }
    let (mn, mx) = n.boundingBox; let r = max(mx.x - mn.x, mx.z - mn.z) / 2 * 0.9 + 0.2
    let t = SCNTorus(ringRadius: CGFloat(r), pipeRadius: CGFloat(max(r * 0.03, 0.03)))
    t.firstMaterial?.diffuse.contents = UIColor.yellow; t.firstMaterial?.emission.contents = UIColor.yellow
    let rn = SCNNode(geometry: t); rn.position.y = 0.05; ring = rn; n.addChildNode(rn)
  }
  func resize(_ f: Float) {
    guard let id = selId, let i = recs.firstIndex(where: { $0.id == id }), let n = scene.rootNode.childNode(withName: "placed:\(id)", recursively: false) else { return }
    recs[i].s = min(max(recs[i].s * f, 0.2), 8); let s = recs[i].s; n.scale = SCNVector3(s, s, s); save()
  }
  func rotate(_ a: Float) {
    guard let id = selId, let i = recs.firstIndex(where: { $0.id == id }), let n = scene.rootNode.childNode(withName: "placed:\(id)", recursively: false) else { return }
    recs[i].yaw += a; n.eulerAngles.y = recs[i].yaw; save()
  }
  // di chuyển kiểu game
  var move = CGVector.zero; var yaw: Float = 0; var pitch: Float = 0
  @Published var run = false
  func step(_ dt: Float) {
    let sp: Float = (run ? 9 : 4) * dt, f = Float(move.dy), r = Float(move.dx)
    var x = cam.position.x + (-sin(yaw) * f + cos(yaw) * r) * sp
    var z = cam.position.z + (-cos(yaw) * f - sin(yaw) * r) * sp
    x = min(max(x, -14), 60); z = min(z, 8); if z < -200 { z = -200 }
    cam.position = SCNVector3(x, 1.6, z); cam.eulerAngles = SCNVector3(pitch, yaw, 0)
  }
  func look(_ dx: Float, _ dy: Float) { yaw -= dx * 0.005; pitch = min(max(pitch - dy * 0.005, -1.2), 1.2) }
  func home() { cam.position = SCNVector3(0, 1.6, 8); yaw = 0; pitch = 0 }

  func tap(_ v: SCNView, _ p: CGPoint) {
    let hits = v.hitTest(p, options: [SCNHitTestOption.searchMode: SCNHitTestSearchMode.all.rawValue])
    if mode == 1 {
      for h in hits { var n: SCNNode? = h.node
        while let c = n { if let nm = c.name, nm.hasPrefix("placed:") { select(c, String(nm.dropFirst(7))); return }; n = c.parent } }
      select(nil, nil); return }
    if mode == 2 {
      for h in hits { var n: SCNNode? = h.node
        while let c = n { if let nm = c.name, nm.hasPrefix("road:") { removeRoad(c, String(nm.dropFirst(5))); return }; if let nm = c.name, nm.hasPrefix("placed:") { remove(c, String(nm.dropFirst(7))); return }; n = c.parent } }
      return }
    guard let g = hits.first(where: { $0.node.name == "land" }) else { return }
    let c = g.worldCoordinates; if cat == "Vẽ đường" { addPoint(c.x, c.z); return }; let item = cat == "Cỏ" ? "grass" : sel
    let r = Rec(id: UUID().uuidString, item: item, x: c.x, z: c.z, yaw: Float.random(in: 0...6.28), s: Float.random(in: 0.9...1.15))
    recs.append(r); spawn(r); save()
  }
  func remove(_ n: SCNNode, _ id: String) {
    if let i = recs.firstIndex(where: { $0.id == id }) { recs.remove(at: i) }
    if selId == id { select(nil, nil) }
    n.removeFromParentNode(); save()
  }
  func save() { saveRoads(); if let d = try? JSONEncoder().encode(recs) { UserDefaults.standard.set(d, forKey: "recs") } }
}
