import SceneKit
import UIKit
import simd
import Metal

struct Rec: Codable { var id: String; var item: String; var x: Float; var z: Float; var yaw: Float; var s: Float }
struct RNG { var s: UInt64 = 7
  mutating func f(_ a: Float, _ b: Float) -> Float { s = s &* 6364136223846793005 &+ 1442695040888963407; return a + Float(s >> 40) / Float(1 << 24) * (b - a) } }

final class Game: ObservableObject {
  @Published var cat = "Cây cối"
  @Published var sel = "palm 2"
  @Published var mode = 0 { didSet { if mode == 0 { select(nil, nil); selectRoad(nil); rowPanel = false; moving = false }; refreshSketchCam() } }   // 0 đặt, 1 chọn, 2 xóa (cả hai chạm vào vật để chọn rồi hiện bảng tuỳ chọn)
  @Published var moving = false   // đang ở chế độ "Di chuyển": chạm mặt đất để chuyển vật đang chọn tới đó
  let order = ["Cây cối", "Hoa & cây cảnh", "Bụi & hàng rào", "Vẽ đường", "Mẫu có sẵn", "Nhà & vườn", "Thị trấn", "Ngoài trời & sân vườn", "Động vật", "Quái vật", "Điện & hạ tầng", "Nhân vật", "Nội thất", ModelLib.category]
  var sizes: [String: [Float]] = [:]
  var items: [String: [String]] = [:]
  let scene = SCNScene(); let cam = SCNNode()
  var protos: [String: SCNNode] = [:]; var catOf: [String: String] = [:]
  var recs: [Rec] = []; var rng = RNG()
  var moundT: Float = 0; var moundList: [MoundInfo] = []   // gò đất đang hiện (để tính độ cao chân), xem refreshMounds (Terrain.swift)
  var cullT: Float = 0; var cullAny = false; var cullExempt = Set<String>()   // ẩn vật ở xa camera (xem cullStep)
  static let cullShow: Float = 170, cullHide: Float = 190   // mét; hiện lại khi vào trong 170, ẩn khi ra ngoài 190 (tránh nhấp nháy)
  let heights: [String: Float] = ["palm": 9, "palm 2": 9, "coconutTree": 10, "coconutTreeBended": 9, "fanPalm": 5, "sabalPalmeto": 3, "cypress": 9, "lombardyPoplar": 12, "pine": 8, "pine 2": 8, "tree": 6, "bonsai-tree": 0.8]

  init() {
    if let u = Bundle.main.url(forResource: "catalog", withExtension: "json"), let d = try? Data(contentsOf: u),
       let c = try? JSONDecoder().decode([String: [String]].self, from: d) { items = c; for (k, l) in c { for i in l { catOf[i] = k } } }
    if let u = Bundle.main.url(forResource: "sizes", withExtension: "json"), let d = try? Data(contentsOf: u), let z = try? JSONDecoder().decode([String: [Float]].self, from: d) { sizes = z }
    items["Cỏ"] = []; items["Vẽ đường"] = [kinds[3], kinds[0], kinds[1], kinds[2]]; kinds.forEach { catOf[$0] = "Vẽ đường" }; items["Mẫu có sẵn"] = sampleIds; sampleIds.forEach { catOf[$0] = "Mẫu có sẵn" }; items["Nhà & vườn"] = procIds; procIds.forEach { catOf[$0] = "Nhà & vườn" }; items["Thị trấn"] = Game.townIds; Game.townIds.forEach { catOf[$0] = "Thị trấn" }
    items["Quái vật"] = Game.beastIds; Game.beastIds.forEach { catOf[$0] = "Quái vật" }
    items["Cây cối", default: []].append(contentsOf: Game.blossomIds); Game.blossomIds.forEach { catOf[$0] = "Cây cối" }
    initSafeMode()
    reloadImported()
    if let d = UserDefaults.standard.data(forKey: "seedEdits"), let e = try? JSONDecoder().decode([String: Rec].self, from: d) { seedEdits = e }
    if let gs = UserDefaults.standard.stringArray(forKey: "seedGone") { seedGone = Set(gs) }
    buildTerrain()
    if let d = UserDefaults.standard.data(forKey: "recs"), let r = try? JSONDecoder().decode([Rec].self, from: d) { recs = r }
    if let d = UserDefaults.standard.data(forKey: "roads"), let r = try? JSONDecoder().decode([RoadRec].self, from: d) { roads = r.filter { $0.pts.count >= 2 && $0.kind >= 0 && $0.kind < kinds.count } }
    if !UserDefaults.standard.bool(forKey: "mainInit") { roads.insert(RoadRec(id: "main", kind: 3, pts: [[0, 7.5], [0, -232.5]]), at: 0); UserDefaults.standard.set(true, forKey: "mainInit"); save() }
    NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main) { [weak self] _ in self?.autoBackup() }
    // dựng cảnh từng đợt qua các khung hình (màn hình báo "Đang tải") để không treo luồng chính lúc mở app
    let steps: [(String, () -> Void)] = [
      ("Đang dựng đường…", { [unowned self] in self.roads.forEach { self.scene.rootNode.addChildNode(self.roadNode($0)) } }),
      ("Đang trồng cây, hàng rào…", { [unowned self] in self.seed(spawnNow: false) }),
    ]
    runLoad(steps)
  }

  @Published var loadNote: String? = "Đang chuẩn bị…"
  private func runLoad(_ steps: [(String, () -> Void)]) {
    var q = steps
    func next() {
      guard !q.isEmpty else { return }   // finishLoad() tắt màn hình tải sau khi dựng xong vật
      let (note, job) = q.removeFirst(); loadNote = note
      DispatchQueue.main.asyncAfter(deadline: .now() + 0.03) { job(); next() } }
    next()
  }
  /// Dựng vật theo lô nhỏ, mỗi lô một nhịp main-queue, rồi chạy bước kế tiếp.
  private func spawnBatched(_ list: [Rec], size: Int = 20, done: @escaping () -> Void) {
    var i = 0; var announced = Set<String>()
    func go() {
      var n = 0
      while i < list.count && n < size {
        let r = list[i]
        // model OBJ nạp lần đầu rất nặng: báo tên trước để màn hình tải hiện đúng model đang nạp
        if r.item != "grass", protos[r.item] == nil, !announced.contains(r.item) {
          announced.insert(r.item); loadNote = "Đang nạp \(label(r.item))… (\(i)/\(list.count))"
          DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { go() }; return }
        spawn(r); i += 1; n += 1 }
      if i < list.count { loadNote = "Đang trồng cây, hàng rào… (\(i)/\(list.count))"; DispatchQueue.main.async { go() } } else { done() }
    }
    go()
  }
  // ----- chế độ an toàn: nếu lần trước app thoát khi đang dựng một phần (chân trời / thời tiết / âm thanh) thì lần này bỏ qua phần đó -----
  static let buildTag = "2026-10-26-m"   // đổi mỗi khi sửa lỗi: danh sách bỏ qua được xóa để thử lại
  var skipStages: Set<String> = []
  func initSafeMode() {
    let ud = UserDefaults.standard
    if ud.string(forKey: "vb.skipTag") != Game.buildTag { ud.removeObject(forKey: "vb.skip"); ud.removeObject(forKey: "vb.stage"); ud.removeObject(forKey: "vb.details"); ud.set(Game.buildTag, forKey: "vb.skipTag") }
    skipStages = Set(ud.stringArray(forKey: "vb.skip") ?? [])
    if let s = ud.string(forKey: "vb.stage"), !s.isEmpty {
      skipStages.insert(s); ud.set(Array(skipStages), forKey: "vb.skip"); ud.removeObject(forKey: "vb.stage")
      if let d = ud.string(forKey: "vb.detail"), !d.isEmpty { var l = ud.stringArray(forKey: "vb.details") ?? []; l.append("\(s) → \(d)"); ud.set(l, forKey: "vb.details") } }
    ud.removeObject(forKey: "vb.detail")
  }
  private func runStage(_ name: String, _ note: String, _ job: @escaping () -> Void, next: @escaping () -> Void) {
    if skipStages.contains(name) { next(); return }
    loadNote = note
    let ud = UserDefaults.standard; ud.set(name, forKey: "vb.stage"); ud.synchronize()
    DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { job(); next() }
  }
  private func finishLoad() {
    runStage("chân trời", "Đang dựng chân trời…", { self.setupHorizon() }, next: {
      self.runStage("thời tiết", "Đang dựng thời tiết…", { self.setupWeather() }, next: {
        self.runStage("âm thanh", "Đang bật âm thanh…", { SoundFX.shared.start(); SoundFX.shared.setSway(self.swayLevel) }, next: {
          self.loadNote = nil; self.pump()
          if !self.skipStages.isEmpty { self.villageAlert = "Lần trước app bị thoát khi đang dựng: " + self.skipStages.sorted().joined(separator: ", ") + ". Lần này app tạm bỏ qua phần đó để vào được cảnh. Chi tiết: " + (UserDefaults.standard.stringArray(forKey: "vb.details") ?? []).joined(separator: "; ") + ". Hãy chụp màn hình này gửi người sửa lỗi." }
          DispatchQueue.main.asyncAfter(deadline: .now() + 25) { UserDefaults.standard.removeObject(forKey: "vb.stage"); UserDefaults.standard.removeObject(forKey: "vb.detail") } }) }) })
  }

  func height(_ i: String) -> Float { heights[i] ?? (catOf[i] == "Cây cối" ? 7 : catOf[i] == "Bụi & hàng rào" ? 1.4 : 1.0) }

  // Tự đọc file .mtl để gắn texture (SceneKit không tự nạp texture của OBJ)
  struct MtlInfo { var kd = UIColor.white; var map: String? }
  static let flipV = true   // nếu texture bị ngược trên/dưới thì đổi thành false
  func parseMtl(_ dir: URL) -> ([String: MtlInfo], [MtlInfo]) {
    var d: [String: MtlInfo] = [:]; var list: [MtlInfo] = []
    let files = ((try? FileManager.default.contentsOfDirectory(atPath: dir.path)) ?? []).filter { $0.lowercased().hasSuffix(".mtl") }
    for f in files {
      guard let data = FileManager.default.contents(atPath: dir.appendingPathComponent(f).path) else { continue }
      var cur = ""; var info = MtlInfo()
      for raw in String(decoding: data, as: UTF8.self).components(separatedBy: .newlines) {
        let p = raw.components(separatedBy: .whitespaces).filter { !$0.isEmpty }; guard let k = p.first else { continue }
        if k == "newmtl" { if !cur.isEmpty { d[cur] = info; list.append(info) }; cur = p.dropFirst().joined(separator: " "); info = MtlInfo() }
        else if k == "Kd", p.count >= 4, let r = Double(p[1]), let g = Double(p[2]), let b = Double(p[3]) { info.kd = UIColor(red: CGFloat(r), green: CGFloat(g), blue: CGFloat(b), alpha: 1) }
        else if k == "map_Kd" { info.map = p.dropFirst().joined(separator: " ") } }
      if !cur.isEmpty { d[cur] = info; list.append(info) } }
    return (d, list)
  }

  // một số thư mục có tên file .obj khác tên thư mục (birch 2, palm 2, pine 2, horse 2...) nên tìm theo đuôi .obj
  func objURL(_ id: String) -> URL? {
    if let u = Bundle.main.url(forResource: id, withExtension: "obj", subdirectory: "Models/\(id)") { return u }
    guard let base = Bundle.main.resourceURL?.appendingPathComponent("Models/\(id)") else { return nil }
    let f = (try? FileManager.default.contentsOfDirectory(atPath: base.path)) ?? []
    return f.first { $0.lowercased().hasSuffix(".obj") }.map { base.appendingPathComponent($0) }
  }
  /// Thu ảnh texture lớn về tối đa 1024px (giữ tỉ lệ); ảnh nhỏ hơn giữ nguyên.
  static func capImage(_ img: UIImage?, _ maxDim: CGFloat = 1024) -> UIImage? {
    guard let img = img, let cg = img.cgImage else { return img }
    let w = CGFloat(cg.width), h = CGFloat(cg.height), m = max(w, h)
    guard m > maxDim else { return img }
    let k = maxDim / m; let f = UIGraphicsImageRendererFormat(); f.scale = 1; f.opaque = !(cg.alphaInfo != .none && cg.alphaInfo != .noneSkipFirst && cg.alphaInfo != .noneSkipLast)
    return UIGraphicsImageRenderer(size: CGSize(width: (w * k).rounded(), height: (h * k).rounded()), format: f).image { _ in img.draw(in: CGRect(x: 0, y: 0, width: (w * k).rounded(), height: (h * k).rounded())) }
  }
  /// Màu trung bình (0...1) của các điểm không trong suốt của ảnh, đo trên ảnh thu nhỏ 16 x 16.
  static func opaqueAvg(_ img: UIImage) -> (Float, Float, Float)? {
    guard let cg = img.cgImage else { return nil }
    let n = 16; var px = [UInt8](repeating: 0, count: n * n * 4)
    let ok: Bool = px.withUnsafeMutableBytes { buf in
      guard let ctx = CGContext(data: buf.baseAddress, width: n, height: n, bitsPerComponent: 8, bytesPerRow: n * 4, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
      ctx.interpolationQuality = .medium; ctx.draw(cg, in: CGRect(x: 0, y: 0, width: n, height: n)); return true }
    guard ok else { return nil }
    var r: Float = 0, g: Float = 0, b: Float = 0, c: Float = 0
    for i in 0..<(n * n) {
      let a = Float(px[i * 4 + 3]) / 255; guard a > 0.5 else { continue }
      r += Float(px[i * 4]) / 255 / a; g += Float(px[i * 4 + 1]) / 255 / a; b += Float(px[i * 4 + 2]) / 255 / a; c += 1 }
    return c > 0 ? (r / c, g / c, b / c) : nil
  }
  func findTex(_ dir: URL, _ name: String) -> UIImage? { Game.capImage(findTexRaw(dir, name)) }
  func findTexRaw(_ dir: URL, _ name: String) -> UIImage? {
    let last = (name as NSString).lastPathComponent
    for p in [dir.appendingPathComponent(name).path, dir.appendingPathComponent(last).path] { if let i = UIImage(contentsOfFile: p) { return i } }
    for f in (try? FileManager.default.contentsOfDirectory(atPath: dir.path)) ?? [] where f.lowercased() == last.lowercased() { return UIImage(contentsOfFile: dir.appendingPathComponent(f).path) }
    return nil
  }
  /// Mẫu dùng để nhân bản. Gốc (x, z) luôn đặt giữa CHÂN mô hình (Anchor.swift); mẫu dựng sẵn kiểu ao / mương / đoạn đường giữ nguyên gốc do mã đặt.
  func proto(_ id: String) -> SCNNode? {
    if let p = protos[id] { return p }
    guard let n = protoBuild(id) else { return nil }
    if !sampleIds.contains(id), let c = baseCenter(n), abs(c.x) > 0.02 || abs(c.z) > 0.02 {
      let o = SCNNode(); o.addChildNode(n); n.position.x -= c.x; n.position.z -= c.z
      protos[id] = o; return o }
    protos[id] = n; return n
  }
  func protoBuild(_ id: String) -> SCNNode? {
    if let p = protos[id] { return p }
    if ModelLib.isImp(id) { if let n = impProto(id) { protos[id] = n; return n }; return nil }
    if procIds.contains(id) || sampleIds.contains(id) || Game.townIds.contains(id) || Game.beastIds.contains(id) || Game.blossomIds.contains(id) { if let n = procModel(id) { protos[id] = n; return n }; return nil }
    guard let u = objURL(id), let s = try? SCNScene(url: u, options: nil) else { return nil }
    let inner = SCNNode(); s.rootNode.childNodes.forEach { inner.addChildNode($0) }
    let (mn, mx) = inner.boundingBox; let sz = sizes[id]; let ext = sz?[0] == 1 ? max(mx.x - mn.x, mx.z - mn.z) : (mx.y - mn.y); let k = (sz?[1] ?? height(id)) / max(ext, 0.001)
    inner.scale = SCNVector3(k, k, k)
    inner.position = SCNVector3(-(mn.x + mx.x) / 2 * k, -mn.y * k, -(mn.z + mx.z) / 2 * k)
    let dir = u.deletingLastPathComponent(); let (infos, infoList) = parseMtl(dir)
    let plant = ["Cây cối", "Hoa & cây cảnh", "Bụi & hàng rào"].contains(catOf[id] ?? "")
    let amp: Float = catOf[id] == "Cây cối" ? 0.035 : catOf[id] == "Bụi & hàng rào" ? 0.03 : 0.04
    let hgt = max(mx.y - mn.y, 0.001), baseY = mn.y
    inner.enumerateHierarchy { n, _ in n.geometry?.materials.enumerated().forEach { (i, m) in
      m.isDoubleSided = true; m.ambient.contents = UIColor.black; m.emission.contents = UIColor.black   // Ka=1 trong .mtl làm cây bị cháy trắng
      var inf: MtlInfo? = infos[m.name ?? ""]; if inf == nil && i < infoList.count { inf = infoList[i] }
      if let inf = inf {
        if let f = inf.map, let img = findTex(dir, f) {
          m.diffuse.contents = img; m.diffuse.wrapS = .repeat; m.diffuse.wrapT = .repeat
          if Game.flipV { m.diffuse.contentsTransform = SCNMatrix4MakeScale(1, -1, 1) }
        } else { m.diffuse.contents = inf.kd } }
      if plant {   // lá / thân nhìn trắng như tuyết (ảnh bị cháy trắng hoặc thiếu ảnh nên Kd = trắng): nhuộm xanh lá, bỏ bóng loáng
        m.specular.contents = UIColor.black
        var avg: (Float, Float, Float)? = nil
        if let img = m.diffuse.contents as? UIImage { avg = Game.opaqueAvg(img) }
        else if let c = m.diffuse.contents as? UIColor { var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, al: CGFloat = 0; if c.getRed(&r, green: &g, blue: &b, alpha: &al) { avg = (Float(r), Float(g), Float(b)) } }
        if let a = avg, min(a.0, a.1, a.2) > 0.72 { m.multiply.contents = UIColor(red: 0.3, green: 0.52, blue: 0.16, alpha: 1) } }
      if plant { m.shaderModifiers = [.geometry: Game.swayShader]
        m.setValue(NSNumber(value: hgt), forKey: "hh"); m.setValue(NSNumber(value: baseY), forKey: "base")
        m.setValue(NSNumber(value: amp * self.swayMul), forKey: "amp"); self.swayMats.append((m, amp)) } } }
    let w = SCNNode(); w.addChildNode(inner); protos[id] = w; return w
  }

  lazy var grassImg: UIImage = {
    UIGraphicsImageRenderer(size: CGSize(width: 128, height: 128), format: Game.fmtTex).image { c in
      for i in 0..<22 { let x = CGFloat(i) * 6 + 2, h = CGFloat(60 + (i * 37) % 60)
        UIColor(red: 0.25 + CGFloat(i % 4) * 0.05, green: 0.6 + CGFloat(i % 3) * 0.08, blue: 0.2, alpha: 1).setFill()
        let p = UIBezierPath(); p.move(to: CGPoint(x: x, y: 128)); p.addLine(to: CGPoint(x: x + 3 + CGFloat(i % 5), y: 128 - h)); p.addLine(to: CGPoint(x: x + 7, y: 128)); p.fill() } }
  }()
  lazy var grassProtos: [SCNNode] = (0..<4).map { _ in   // 4 mảng cỏ dựng một lần, nhân bản dùng chung hình học
    let g0 = SCNNode(); for _ in 0..<10 { let t = tuft(); t.position = SCNVector3(Float.random(in: -0.8...0.8), 0, Float.random(in: -0.8...0.8)); g0.addChildNode(t) }; return g0.flattenedClone() }
  func tuft() -> SCNNode { rosette(6, 0.5, 0.07, leafMat("grass"), outer: 0.9, inner: 1.35, arch: 0.4, fold: 0.1) }

  func spawn(_ r: Rec, name: String? = nil) {
    let n: SCNNode
    if r.item == "grass" { n = grassProtos[r.id.unicodeScalars.reduce(0) { $0 &+ Int($1.value) } % grassProtos.count].clone() }
    else { guard let p = proto(r.item) else { return }; n = p.clone() }
    n.position = SCNVector3(r.x, 0, r.z); n.eulerAngles.y = r.yaw; n.scale = SCNVector3(r.s, r.s, r.s)
    n.name = name ?? "placed:\(r.id)"; if sampleIds.contains(r.item), let nm = n.name { cullExempt.insert(nm) }; scene.rootNode.addChildNode(n)
    if r.item == Game.pondId { startPondLife(n) }
    if Game.beastIds.contains(r.item) { startBeastLife(n) }
  }
  // mô hình dựng sẵn (cây, hàng rào ven đường): có id cố định seedN để chọn / kéo / xoay / phóng to / xóa như vật tự đặt
  var extraSeeds: [Rec] = []   // vật dựng sẵn thêm từ địa hình (bùn, cỏ nền, tấm bê tông), gộp vào seedRecs ở finishSeed
  var seedRecs: [Rec] = []; var seedEdits: [String: Rec] = [:]; var seedGone: Set<String> = []
  func seedPut(_ i: String, _ x: Float, _ z: Float) { let yw = rng.f(0, 6.28), sc = rng.f(0.85, 1.2); seedRecs.append(Rec(id: "seed\(seedRecs.count)", item: i, x: x, z: z, yaw: yw, s: sc)) }
  func finishSeed(spawnNow: Bool = true) {
    seedRecs += extraSeeds.filter { $0.item != "grass" }   // bỏ các mảng cỏ khỏi cảnh dựng sẵn
    if let d = UserDefaults.standard.data(forKey: "seedEdits"), let e = try? JSONDecoder().decode([String: Rec].self, from: d) { seedEdits = e }
    if let g = UserDefaults.standard.stringArray(forKey: "seedGone") { seedGone = Set(g) }
    seedRecs = seedRecs.filter { !seedGone.contains($0.id) }.map { seedEdits[$0.id] ?? $0 }
    if spawnNow { seedRecs.forEach { spawn($0) } }
    else { let all = seedRecs + recs; spawnBatched(all) { [weak self] in self?.finishLoad() } }
  }
  func recOf(_ id: String) -> Rec? { id.hasPrefix("seed") ? seedRecs.first { $0.id == id } : recs.first { $0.id == id } }
  func setRec(_ r: Rec) {
    if r.id.hasPrefix("seed") { if let i = seedRecs.firstIndex(where: { $0.id == r.id }) { seedRecs[i] = r }; seedEdits[r.id] = r }
    else if let i = recs.firstIndex(where: { $0.id == r.id }) { recs[i] = r } }
  func dropRec(_ id: String) {
    if id.hasPrefix("seed") { seedRecs.removeAll { $0.id == id }; seedEdits[id] = nil; seedGone.insert(id) }
    else { recs.removeAll { $0.id == id } } }

  func makeTex(_ base: UIColor, _ specks: [UIColor], _ count: Int, _ maxR: CGFloat, cracks: Int = 0, crackColor: UIColor = .black, crackW: CGFloat = 1.5, seed: UInt64) -> UIImage {
    var r = RNG(); r.s = seed; let S: CGFloat = 512
    return UIGraphicsImageRenderer(size: CGSize(width: S, height: S), format: Game.fmtTex).image { c in
      base.setFill(); c.fill(CGRect(x: 0, y: 0, width: S, height: S))
      for _ in 0..<count {
        specks[min(Int(r.f(0, Float(specks.count))), specks.count - 1)].withAlphaComponent(CGFloat(r.f(0.15, 0.6))).setFill()
        let d = CGFloat(r.f(1, Float(maxR)))
        UIBezierPath(ovalIn: CGRect(x: CGFloat(r.f(0, 512)), y: CGFloat(r.f(0, 512)), width: d, height: d * CGFloat(r.f(0.5, 1.5)))).fill() }
      for _ in 0..<cracks {
        var x = CGFloat(r.f(0, 512)), y = CGFloat(r.f(0, 512)); let q = UIBezierPath(); q.move(to: CGPoint(x: x, y: y)); var a = r.f(0, 6.28)
        for _ in 0..<Int(r.f(5, 14)) { a += r.f(-0.7, 0.7); x += CGFloat(cos(a)) * CGFloat(r.f(10, 30)); y += CGFloat(sin(a)) * CGFloat(r.f(10, 30)); q.addLine(to: CGPoint(x: x, y: y)) }
        crackColor.withAlphaComponent(0.85).setStroke(); q.lineWidth = crackW * CGFloat(r.f(0.5, 1.4)); q.stroke() } }
  }
  static var fmtTex: UIGraphicsImageRendererFormat { let f = UIGraphicsImageRendererFormat(); f.scale = min(UIScreen.main.scale, 2); return f }   // máy 3x chỉ dùng 2x: nhẹ RAM ~2,3 lần, mipmap + anisotropy giữ nét
  func mat(_ img: UIImage, _ sx: Float, _ sy: Float) -> SCNMaterial {
    let m = SCNMaterial(); m.diffuse.contents = img; m.diffuse.wrapS = .repeat; m.diffuse.wrapT = .repeat; m.diffuse.mipFilter = .linear; m.diffuse.maxAnisotropy = 4
    m.diffuse.contentsTransform = SCNMatrix4MakeScale(sx, sy, 1); m.lightingModel = .blinn; m.specular.contents = UIColor(white: 0.08, alpha: 1); return m
  }
  func tplane(_ w: CGFloat, _ l: CGFloat, _ x: Float, _ y: Float, _ z: Float, _ m: SCNMaterial, _ name: String?) {
    let p = SCNPlane(width: w, height: l); p.firstMaterial = m
    let n = SCNNode(geometry: p); n.eulerAngles.x = -.pi / 2; n.position = SCNVector3(x, y, z); n.name = name; scene.rootNode.addChildNode(n)
  }
  // Bờ bùn dốc: mực nước đứng yên (không còn thủy triều / sóng đánh), mép nước chỉ có sóng lăn tăn rất nhẹ
  static let bankShader = """
  #pragma body
  float t = scn_frame.time;
  float lvl = -0.55;
  float u = _surface.diffuseTexcoord.x;
  float d = (-0.05 - u * 1.15) - lvl;
  float wet = 1.0 - smoothstep(0.0, 0.3, d);
  _surface.diffuse.rgb *= (1.0 - 0.5 * wet);
  _surface.specular.rgb += wet * 0.15;
  float band = 1.0 - smoothstep(0.0, 0.14, abs(d - 0.03));
  float rip = 0.5 + 0.5 * sin(d * 70.0 - t * 1.6 + sin(_surface.diffuseTexcoord.y * 55.0 + t * 0.7) * 1.8);
  _surface.diffuse.rgb = mix(_surface.diffuse.rgb, float3(0.62, 0.70, 0.68), band * rip * 0.16);
  """
  func makeBank(_ img: UIImage) {
    var v: [SCNVector3] = [], nm: [SCNVector3] = [], t: [CGPoint] = []
    for z in [Float(20), Float(-390)] {
      v.append(SCNVector3(-8, -0.05, z)); v.append(SCNVector3(-26, -1.2, z))
      nm.append(SCNVector3(-0.064, 0.998, 0)); nm.append(SCNVector3(-0.064, 0.998, 0))
      t.append(CGPoint(x: 0, y: CGFloat(z / 18))); t.append(CGPoint(x: 1, y: CGFloat(z / 18))) }
    let g = SCNGeometry(sources: [SCNGeometrySource(vertices: v), SCNGeometrySource(normals: nm), SCNGeometrySource(textureCoordinates: t)],
                        elements: [SCNGeometryElement(indices: [Int32](arrayLiteral: 0, 2, 1, 1, 2, 3), primitiveType: .triangles)])
    let m = mat(img, 1, 1); m.isDoubleSided = true; m.shaderModifiers = [.fragment: Game.bankShader]; g.firstMaterial = m
    let n = SCNNode(geometry: g); n.name = "bank"; scene.rootNode.addChildNode(n)
  }
  func makeWater() {
    let p = SCNPlane(width: 56, height: 420); p.widthSegmentCount = 40; p.heightSegmentCount = 240
    let m = SCNMaterial(); m.lightingModel = .blinn; m.diffuse.contents = UIColor(red: 0.30, green: 0.34, blue: 0.2, alpha: 1)
    m.specular.contents = UIColor.white; m.shininess = 0.9
    m.reflective.contents = UIColor(red: 0.8, green: 0.9, blue: 0.95, alpha: 1); m.fresnelExponent = 2.5
    m.shaderModifiers = [
      .geometry: """
      #pragma body
      float t = scn_frame.time; float2 q = _geometry.position.xy;
      float a = q.x * 0.8 + t * 1.2, b = q.y * 0.5 + t * 0.9, c = (q.x + q.y) * 1.7 + t * 2.0;
      _geometry.position.z += sin(a) * 0.03 + sin(b) * 0.04 + sin(c) * 0.015 + sin(q.x * 2.6 + q.y * 1.9 + t * 2.4) * 0.012;
      float dx = cos(a) * 0.024 + cos(c) * 0.0255 + cos(q.x * 2.6 + q.y * 1.9 + t * 2.4) * 0.031, dy = cos(b) * 0.02 + cos(c) * 0.0255 + cos(q.x * 2.6 + q.y * 1.9 + t * 2.4) * 0.023;
      _geometry.normal = normalize(float3(-dx, -dy, 1.0));
      """,
      .fragment: """
      #pragma body
      float2 uv = _surface.diffuseTexcoord * float2(48.0, 420.0); float t = scn_frame.time;
      float r = sin(uv.x * 3.1 + t * 1.6) * sin(uv.y * 2.3 - t * 1.2) + sin((uv.x + uv.y) * 5.0 + t * 2.5) * 0.5 + sin((uv.x - uv.y) * 9.0 - t * 3.1) * 0.25;
      _surface.normal = normalize(_surface.normal + float3(r * 0.06, r * 0.06, 0.0));
      _surface.diffuse.rgb += r * 0.035;
      """]
    p.firstMaterial = m
    let n = SCNNode(geometry: p); n.eulerAngles.x = -.pi / 2; n.position = SCNVector3(-34, -0.55, -170); n.name = "water"; scene.rootNode.addChildNode(n)
  }
  func plane(_ w: CGFloat, _ l: CGFloat, _ x: Float, _ y: Float, _ z: Float, _ c: UIColor, _ name: String?) -> SCNNode {
    let p = SCNPlane(width: w, height: l); p.firstMaterial?.diffuse.contents = c; p.firstMaterial?.lightingModel = .blinn
    let n = SCNNode(geometry: p); n.eulerAngles.x = -.pi / 2; n.position = SCNVector3(x, y, z); n.name = name; scene.rootNode.addChildNode(n); return n
  }

  func buildTerrain() {
    let sky = UIColor(red: 0.75, green: 0.86, blue: 0.9, alpha: 1)
    scene.background.contents = sky; scene.fogColor = sky; scene.fogStartDistance = 40; scene.fogEndDistance = 190
    let amb = SCNNode(); amb.light = SCNLight(); amb.light?.type = .ambient; amb.light?.intensity = 650; scene.rootNode.addChildNode(amb)
    let sun = SCNNode(); sun.light = SCNLight(); sun.light?.type = .directional; sun.light?.intensity = 1000; sun.light?.castsShadow = true; sun.light?.shadowRadius = 3; sun.light?.shadowColor = UIColor(white: 0, alpha: 0.45); sun.light?.maximumShadowDistance = 50; sun.light?.automaticallyAdjustsShadowProjection = true
    sun.eulerAngles = SCNVector3(-0.9, -0.6, 0); scene.rootNode.addChildNode(sun); wxSun = sun; wxAmb = amb
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    let grassT = makeTex(C(0.36, 0.52, 0.2), [C(0.25, 0.42, 0.14), C(0.5, 0.66, 0.28), C(0.3, 0.3, 0.15)], 2800, 10, seed: 11)
    let soilT = makeTex(C(0.33, 0.26, 0.19), [C(0.22, 0.17, 0.12), C(0.45, 0.37, 0.26), C(0.3, 0.45, 0.18)], 2800, 14, seed: 12)
    let mudT = makeTex(C(0.2, 0.19, 0.17), [C(0.1, 0.1, 0.09), C(0.35, 0.34, 0.31)], 1800, 9, cracks: 34, crackColor: C(0.03, 0.03, 0.03), crackW: 2, seed: 13)
    let mudMat = mat(mudT, 1, 1)
    tplane(110, 420, 47, -0.02, -170, groundMat(grass: true, 110 / 6, 420 / 6, fallback: grassT), "land")
    tplane(36, 420, 22, -0.015, -170, groundMat(grass: false, 6, 70, fallback: soilT), "land")
    makeBank(mudT)
    makeWater()
    tplane(90, 420, -106, -0.02, -170, groundMat(grass: true, 15, 70, fallback: grassT), nil)
    let cs = [2, 3, 6, 4].enumerated().map { mat(makeTex(C(0.55, 0.57, 0.53), [C(0.4, 0.42, 0.38), C(0.72, 0.72, 0.68), C(0.35, 0.42, 0.3), C(0.92, 0.92, 0.9)], 3000, 6, cracks: $1, crackColor: C(0.13, 0.13, 0.12), seed: UInt64(20 + $0)), 1, 1) }
    extraSeeds.append(Rec(id: "seedS0", item: "Tấm bê tông nứt", x: 3.8, z: 1.2, yaw: -0.5, s: 1))   // tấm bê tông nứt cạnh đường: vật riêng, chọn / xóa / sửa được
    // khối bùn nứt ven bờ: mỗi khối là một vật riêng (seedRn). Giữ đúng thứ tự gọi rng như bản cũ
    for i in 0..<45 { let k = rng.f(0.6, 1.6); _ = rng.f(0.8, 1.4); let px = rng.f(-7.5, -4); _ = rng.f(-0.3, 0.3); let ey = rng.f(0, 6); _ = rng.f(-0.3, 0.3)
      extraSeeds.append(Rec(id: "seedR\(i)", item: "Cục bùn nứt", x: px, z: 4 - Float(i) * 0.9, yaw: ey, s: k)) }
    // cỏ phủ nền: cứ 9 điểm lấy 1 điểm làm mảng cỏ riêng (seedGn) để xóa / di chuyển được
    var tc = 0, gi = 0
    func tuftSpot(_ x0: Float, _ x1: Float) { for _ in 0..<12 { _ = rng.f(0, 1) }   // thay cho tuft() cũ: mỗi tuft tiêu thụ đúng 12 lần rng
      let x = rng.f(x0, x1), z = rng.f(-120, 8)
      if tc % 9 == 0 { extraSeeds.append(Rec(id: "seedG\(gi)", item: "grass", x: x, z: z, yaw: Float(gi) * 0.7, s: 1.5)); gi += 1 }; tc += 1 }
    for _ in 0..<350 { tuftSpot(-8, -1.3) }
    for _ in 0..<450 { tuftSpot(1.3, 30) }
    // gò đất / gò cỏ rải sẵn (vật riêng seedM…, xóa / di chuyển được). Dùng bộ số ngẫu nhiên riêng để không làm lệch vị trí các vật khác
    var mr = RNG(); mr.s = 777
    for i in 0..<30 {
      let sc = mr.f(0.8, 1.8); let x = mr.f(4.6 + 3.5 * sc, 40), z = mr.f(-150, 12)
      extraSeeds.append(Rec(id: "seedM\(i)", item: i % 3 == 0 ? "Gò đất nâu" : "Gò đất cỏ", x: x, z: z, yaw: mr.f(0, 6.28), s: sc)) }
    for i in 30..<38 {
      let sc = mr.f(0.45, 0.7); let x = mr.f(-7.2, -4.6), z = mr.f(-150, 8)
      extraSeeds.append(Rec(id: "seedM\(i)", item: "Gò đất cỏ", x: x, z: z, yaw: mr.f(0, 6.28), s: sc)) }
    cam.camera = SCNCamera(); cam.camera?.fieldOfView = 70; cam.camera?.zFar = 300; cam.position = SCNVector3(0, 1.6, 8); scene.rootNode.addChildNode(cam)
  }

  func seed(spawnNow: Bool = true) {   // dựng lại cảnh trong ảnh bằng các model thật
    var z: Float = 6
    let forest = ["tree", "birch", "cypress", "lombardyPoplar", "pine", "acacia"]
    var k = 0
    while z > -150 {
      let m: Float = z > -60 ? 1 : 2.5
      seedPut("hedge", -1.9, z); seedPut("hedge", 1.9, z)
      if k % 2 == 0 { seedPut("roses-bush", -2.4, z - 1); seedPut("lavender-bush", 2.5, z - 1) }
      if k % Int(3 * m) == 0 { seedPut(k % 2 == 0 ? "palm" : "fanPalm", rng.f(3.5, 6), z); seedPut("coconutTree", rng.f(-11, -9), z) }
      if k % Int(2 * m) == 0 { seedPut(forest[k % forest.count], rng.f(7, 18), z + rng.f(-2, 2)) }
      if k % 9 == 0 && z > -100 { seedPut("coconutTree", rng.f(-70, -64), z); seedPut("weepingWillow", rng.f(-90, -75), z) }
      z -= 2.5 * m; k += 1 }
    seedRecs.removeAll { $0.item == "cypress" }   // bỏ cây cypress to khỏi cảnh dựng sẵn (id các vật còn lại giữ nguyên để không lệch dữ liệu đã lưu)
    finishSeed(spawnNow: spawnNow)
  }

  // ===== Nhà & vườn: mô hình tự dựng chi tiết (lá có gân, chậu tiện, mái lá nhiều lớp...) =====
  // mẫu lấy từ các vật dựng sẵn trong cảnh để đặt ở chỗ khác
  let sampleIds = ["Ao cá miền Tây (chiều sâu)", "Mương nước quê (chiều sâu)", "Đoạn đường có cây 2 bên", "Đoạn đường 3 m", "Tấm bê tông nứt", "Khối bùn nứt", "Cục bùn nứt", "Ao nước", "Gò đất cỏ", "Gò đất nâu", "Hồ tường gạch", "Thị trấn cổ (mẫu)"]
  lazy var crackedSlabMat: SCNMaterial = {
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    return mat(makeTex(C(0.52, 0.54, 0.5), [C(0.4, 0.42, 0.38), C(0.7, 0.7, 0.66), C(0.35, 0.4, 0.3)], 3000, 6, cracks: 22, crackColor: C(0.12, 0.12, 0.11), crackW: 2.2, seed: 29), 1, 1) }()
  lazy var mudSampleMat: SCNMaterial = {
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    let m = mat(makeTex(C(0.2, 0.19, 0.17), [C(0.1, 0.1, 0.09), C(0.35, 0.34, 0.31)], 1800, 9, cracks: 34, crackColor: C(0.03, 0.03, 0.03), crackW: 2, seed: 13), 1, 1); m.isDoubleSided = true; return m }()
  // ===== Mương nước quê có chiều sâu (theo ảnh tham chiếu): bờ đất dốc, nước đục xanh olive, lục bình, chuối, dừa, cầu ván, xuồng, nhà tranh =====
  func mT(_ x: Float, _ y: Float, _ z: Float) -> simd_float4x4 { simd_float4x4(columns: (SIMD4<Float>(1, 0, 0, 0), SIMD4<Float>(0, 1, 0, 0), SIMD4<Float>(0, 0, 1, 0), SIMD4<Float>(x, y, z, 1))) }
  func mRy(_ a: Float) -> simd_float4x4 { let c = cos(a), s = sin(a); return simd_float4x4(columns: (SIMD4<Float>(c, 0, -s, 0), SIMD4<Float>(0, 1, 0, 0), SIMD4<Float>(s, 0, c, 0), SIMD4<Float>(0, 0, 0, 1))) }
  func mRx(_ a: Float) -> simd_float4x4 { let c = cos(a), s = sin(a); return simd_float4x4(columns: (SIMD4<Float>(1, 0, 0, 0), SIMD4<Float>(0, c, s, 0), SIMD4<Float>(0, -s, c, 0), SIMD4<Float>(0, 0, 0, 1))) }
  func mS(_ k: Float) -> simd_float4x4 { simd_float4x4(diagonal: SIMD4<Float>(k, k, k, 1)) }
  func geoNode(_ g: SCNGeometry, _ M: simd_float4x4, _ parent: SCNNode) { let n = SCNNode(geometry: g); n.simdTransform = M; parent.addChildNode(n) }
  func rosetteInto(_ parent: SCNNode, _ base: simd_float4x4, _ n: Int, _ L: Float, _ W: Float, _ m: SCNMaterial, outer: Float, inner: Float, arch: Float, fold: Float, radius: Float = 0, rr: inout RNG) {
    for i in 0..<n {
      let t = Float(i) / Float(max(n - 1, 1)); let g = leafGeo(L * (1 - 0.35 * t), W * (1 - 0.25 * t), arch, fold, m)
      let e = outer + (inner - outer) * t + rr.f(-0.08, 0.08), a = Float(i) * 2.39996 + rr.f(-0.12, 0.12)
      geoNode(g, base * mT(0, 0.008 * Float(i), 0) * mRy(a) * mT(0, 0, radius) * mRx(-e), parent) }
  }
  static let waterFrag = """
  #pragma body
  float2 uv = _surface.diffuseTexcoord; float t = scn_frame.time;
  float d = abs(uv.x - 0.5) * 2.0;
  float3 deep = float3(0.10, 0.13, 0.08); float3 shallow = float3(0.36, 0.38, 0.20);
  float3 col = mix(deep, shallow, smoothstep(0.1, 1.0, d));
  float2 p = float2(uv.x * 14.0, uv.y * 6.0);
  float r = sin(p.x * 3.1 + t * 0.9) * sin(p.y * 2.3 - t * 0.7) + 0.5 * sin((p.x + p.y) * 4.7 + t * 1.6) + 0.3 * sin(p.x * 9.0 - p.y * 7.0 + t * 2.2);
  float3 n = normalize(_surface.normal + float3(r * 0.05, r * 0.05, 0.0));
  _surface.normal = n;
  float fr = pow(1.0 - clamp(dot(n, normalize(_surface.view)), 0.0, 1.0), 3.0);
  col += float3(0.45, 0.58, 0.68) * fr * 0.75;
  col += r * 0.02;
  _surface.diffuse.rgb = col;
  """
  func hullW(_ t: Float) -> Float { 0.5 * pow(max(sin(Float.pi * t), 0.0001), 0.5) }
  func boatHull() -> SCNGeometry {   // xuồng gỗ: mũi và đuôi nhọn, cong vút
    let L: Float = 4.4, nt = 22, ns = 8; var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
    for i in 0...nt { let t = Float(i) / Float(nt), z = (t - 0.5) * L, w = hullW(t), rise = 0.28 * pow(abs(2 * t - 1), 3), dp = 0.32 * pow(max(sin(Float.pi * t), 0.0001), 0.3)
      for j in 0...ns { let s = Float(j) / Float(ns), u = 2 * s - 1
        P.append(SIMD3<Float>(w * u, rise - dp * (1 - u * u), z)); UV.append(SIMD2<Float>(s, t * 3)) } }
    for i in 0..<nt { for j in 0..<ns { let a = Int32(i * (ns + 1) + j), b = a + 1, c = a + Int32(ns + 1), d = c + 1; I += [a, c, b, b, c, d] } }
    return meshGeo(P, UV, I)
  }
  func canalDiorama() -> SCNNode {
    let root = SCNNode(), solid = SCNNode(); var rr = RNG(); rr.s = 77
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    let L: Float = 24, half: Float = 12
    let prof: [(Float, Float)] = [(-11.5, 0), (-10, 0.55), (-8.6, 0.9), (-4.3, 0.9), (-3.3, 0.62), (-2.6, 0.3), (-2.0, 0.16), (2.0, 0.16), (2.6, 0.3), (3.3, 0.62), (4.3, 0.9), (8.6, 0.9), (10, 0.55), (11.5, 0)]
    let np = prof.count
    func nz(_ z: Float, _ k: Float) -> Float { 0.5 * sin(2 * Float.pi * z / L * 2 + k * 1.7) + 0.5 * sin(2 * Float.pi * z / L * 3 + k * 2.9) }
    func pt(_ z: Float, _ j: Int) -> SIMD2<Float> {   // mặt cắt bờ, nhiễu tuần hoàn để hai đầu khớp khi nối nhiều đoạn
      let p = prof[j]; let amp: Float = (j == 0 || j == np - 1 || p.1 > 0.89) ? 0 : 0.05
      return SIMD2<Float>(p.0 + amp * 1.2 * nz(z, Float(j) + 7), amp > 0 ? max(p.1 + amp * nz(z, Float(j)), 0.05) : p.1) }
    func yAt(_ x: Float) -> Float { for j in 0..<(np - 1) { let a = prof[j], b = prof[j + 1]; if x >= a.0 && x <= b.0 { return a.1 + (b.1 - a.1) * (x - a.0) / (b.0 - a.0) } }; return 0 }
    // bờ đất
    let bankM = mat(makeTex(C(0.34, 0.27, 0.18), [C(0.2, 0.16, 0.1), C(0.5, 0.42, 0.28), C(0.3, 0.45, 0.15), C(0.45, 0.52, 0.22)], 3500, 8, cracks: 14, crackColor: C(0.1, 0.08, 0.05), seed: 51), 3, 1); bankM.isDoubleSided = true
    var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32](); let nr = 25
    for k in 0..<nr { let z = -half + Float(k) * L / Float(nr - 1)
      for j in 0..<np { let q = pt(z, j); P.append(SIMD3<Float>(q.x, q.y, z)); UV.append(SIMD2<Float>((q.x + 11.5) / 23, (z + half) / 8)) } }
    for k in 0..<(nr - 1) { for j in 0..<(np - 1) { let a = Int32(k * np + j), b = a + 1, c = a + Int32(np), d = c + 1; I += [a, c, b, b, c, d] } }
    let bg = meshGeo(P, UV, I); bg.firstMaterial = bankM; solid.addChildNode(SCNNode(geometry: bg))
    // mặt cắt đất nhiều lớp ở hai đầu
    let capImg = UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256), format: Game.fmtTex).image { c in
      let g = c.cgContext; let cols = [C(0.36, 0.27, 0.17), C(0.5, 0.4, 0.26), C(0.28, 0.21, 0.13), C(0.58, 0.48, 0.32), C(0.4, 0.3, 0.19)]
      for k in 0..<5 { cols[k].setFill(); g.fill(CGRect(x: 0, y: CGFloat(k) * 51.2, width: 256, height: 52)) }
      for i in 0..<1400 { UIColor(white: CGFloat((i * 37) % 100) / 100, alpha: 0.1).setFill(); g.fill(CGRect(x: CGFloat((i * 53) % 256), y: CGFloat((i * 97) % 256), width: 3, height: 2)) }
      UIColor(red: 0.2, green: 0.15, blue: 0.08, alpha: 0.5).setStroke(); g.setLineWidth(1.2)
      for i in 0..<30 { let x = CGFloat((i * 71) % 256), y = CGFloat((i * 43) % 256); g.move(to: CGPoint(x: x, y: y)); g.addQuadCurve(to: CGPoint(x: x + 20, y: y + CGFloat((i * 13) % 14) - 7), control: CGPoint(x: x + 10, y: y + 8)); g.strokePath() } }
    let capM = mat(capImg, 1, 1); capM.isDoubleSided = true
    for sgn in [Float(-1), 1] {
      let z = sgn * half; var cp = [SIMD3<Float>](), cu = [SIMD2<Float>](), ci = [Int32]()
      for j in 0..<np { let q = pt(z, j)
        cp.append(SIMD3<Float>(q.x, q.y, z)); cu.append(SIMD2<Float>(q.x / 6, q.y))
        cp.append(SIMD3<Float>(q.x, -0.05, z)); cu.append(SIMD2<Float>(q.x / 6, -0.05)) }
      for j in 0..<(np - 1) { let p0 = Int32(2 * j), b0 = p0 + 1, p1 = p0 + 2, b1 = p0 + 3
        if sgn > 0 { ci += [b0, b1, p1, b0, p1, p0] } else { ci += [b0, p1, b1, b0, p0, p1] } }
      let cg = meshGeo(cp, cu, ci); cg.firstMaterial = capM; solid.addChildNode(SCNNode(geometry: cg)) }
    // mặt cỏ trên hai bờ + đường đất ở bờ phải
    let grassImg = makeTex(C(0.34, 0.5, 0.18), [C(0.25, 0.42, 0.14), C(0.5, 0.66, 0.28), C(0.3, 0.3, 0.15)], 2800, 10, seed: 11)
    for cx in [Float(-6.5), 6.5] { let pl = SCNPlane(width: 4.1, height: 24); let gm = mat(grassImg, 0.8, 5); gm.isDoubleSided = true; pl.firstMaterial = gm
      let n = SCNNode(geometry: pl); n.eulerAngles.x = -.pi / 2; n.position = SCNVector3(cx, 0.92, 0); solid.addChildNode(n) }
    let dirtM = roadMat(makeTex(C(0.5, 0.38, 0.24), [C(0.38, 0.28, 0.17), C(0.62, 0.5, 0.34)], 1500, 5, cracks: 4, crackColor: C(0.2, 0.14, 0.08), seed: 61))
    var path = [SIMD2<Float>](); for k in 0...12 { let z = -half + Float(k) * 2; path.append(SIMD2<Float>(5.6 + 0.4 * sin(z * 0.45), z)) }
    if let pn = ribbon(path, 0.9, 0.93, dirtM) { solid.addChildNode(pn) }
    // cỏ, cỏ cao dọc bờ
    let grassLeaf = leafMat("grass")
    func grassAt(_ x: Float, _ z: Float, _ k: Float) {
      let yw = rr.f(0, 6.28); rosetteInto(solid, mT(x, yAt(x) + 0.03, z) * mRy(yw) * mS(k), 6, 0.5, 0.07, grassLeaf, outer: 0.9, inner: 1.35, arch: 0.4, fold: 0.1, rr: &rr) }
    for _ in 0..<110 { let sg: Float = rr.f(0, 1) > 0.5 ? 1 : -1; grassAt(sg * rr.f(4.6, 8.6), rr.f(-11.5, 11.5), rr.f(0.8, 1.4)) }
    for _ in 0..<50 { let sg: Float = rr.f(0, 1) > 0.5 ? 1 : -1; grassAt(sg * rr.f(3.0, 4.3), rr.f(-11.5, 11.5), rr.f(1.0, 1.7)) }
    for _ in 0..<22 { let sg: Float = rr.f(0, 1) > 0.5 ? 1 : -1; grassAt(sg * rr.f(4.4, 5.4), rr.f(-11.5, 11.5), rr.f(1.8, 2.4)) }
    for _ in 0..<20 { let sg: Float = rr.f(0, 1) > 0.5 ? 1 : -1; grassAt(sg * rr.f(9.0, 10.6), rr.f(-11.5, 11.5), rr.f(1.0, 1.6)) }
    // lục bình nổi trên mặt nước
    let hy = leafMat("lettuce")
    for _ in 0..<16 { let cx = rr.f(-2.7, 2.7), cz = rr.f(-11, 11)
      for _ in 0..<5 { let px = cx + rr.f(-0.4, 0.4), pz = cz + rr.f(-0.4, 0.4), k = rr.f(0.8, 1.3), yw = rr.f(0, 6.28)
        rosetteInto(solid, mT(px, 0.535, pz) * mRy(yw) * mS(k), 7, 0.22, 0.24, hy, outer: 0.25, inner: 0.8, arch: -0.1, fold: 0.3, radius: 0.03, rr: &rr) } }
    // chuối
    let bananaLeaf = leafMat("default"), trunkM = pcol(0.52, 0.56, 0.32)
    func banana(_ x: Float, _ z: Float, _ h: Float) {
      let tg = lathe([(0.15, 0), (0.17, 0.3), (0.13, h * 0.8), (0.09, h)], 10); tg.firstMaterial = trunkM; geoNode(tg, mT(x, 0.92, z), solid)
      for i in 0..<10 { let yw = Float(i) * 2.4 + rr.f(0, 0.4), el = 0.5 + rr.f(0, 0.55), sz = rr.f(0.85, 1.15)
        geoNode(leafGeo(2.4, 0.8, -0.5, 0.22, bananaLeaf), mT(x, 0.92 + h, z) * mRy(yw) * mS(sz) * mRx(-el), solid) } }
    for (x, z, h) in [(Float(-7.0), Float(-9.0), Float(3.2)), (-7.7, -8.2, 2.7), (-8.0, -9.6, 3.6), (-7.2, 6.0, 3.0), (7.5, -3.0, 3.1), (8.0, -2.3, 2.6), (7.0, 8.5, 3.3)] { banana(x, z, h) }
    // nhà tranh nhỏ + lu bê tông (bờ trái)
    let wd = mat(woodImg(C(0.45, 0.38, 0.29)), 1, 1), wdD = mat(woodImg(C(0.3, 0.24, 0.17)), 1, 1)
    let thatchM = mat(thatchImg(), 1.5, 1); thatchM.isDoubleSided = true
    let hx: Float = -7.0, hz: Float = 1.5, gy: Float = 0.92
    solid.addChildNode(pbox(3.2, 0.2, 2.6, hx, gy + 0.1, hz, wdD, 0.02)); solid.addChildNode(pbox(3.0, 1.7, 2.4, hx, gy + 1.05, hz, wd, 0.02))
    solid.addChildNode(pbox(0.7, 1.3, 0.06, hx - 0.6, gy + 0.85, hz + 1.22, wdD)); solid.addChildNode(pbox(0.6, 0.5, 0.06, hx + 0.8, gy + 1.4, hz + 1.22, wdD))
    for s in [Float(0), Float(1)] {
      let n = pbox(3.6, 0.12, 2.2, 0, 0, 0, thatchM, 0.02); n.simdTransform = mT(hx, gy + 2.8, hz) * mRy(s * Float.pi) * mRx(0.6) * mT(0, 0, 1.05); solid.addChildNode(n) }
    let rg = pcyl(0.14, 3.7, hx, gy + 2.86, hz, thatchM); rg.eulerAngles.z = .pi / 2; solid.addChildNode(rg)
    let tri = UIBezierPath(); tri.move(to: CGPoint(x: -1.2, y: 0)); tri.addLine(to: CGPoint(x: 1.2, y: 0)); tri.addLine(to: CGPoint(x: 0, y: 0.84)); tri.close()
    for sx in [Float(-1.5), 1.5] { let sh = SCNShape(path: tri, extrusionDepth: 0.1); sh.firstMaterial = wdD; let n = SCNNode(geometry: sh); n.position = SCNVector3(hx + sx, gy + 1.9, hz); n.eulerAngles.y = .pi / 2; solid.addChildNode(n) }
    let wellM = (concreteMats[1].copy() as? SCNMaterial) ?? concreteMats[1]; wellM.isDoubleSided = true
    let wl = lathe([(0.46, 0), (0.5, 0.03), (0.5, 0.58), (0.42, 0.6), (0.4, 0.55), (0.4, 0.08)], 24); wl.firstMaterial = wellM; geoNode(wl, mT(-5.3, gy, 3.3), solid)
    solid.addChildNode(pcyl(0.4, 0.02, -5.3, gy + 0.4, 3.3, pcol(0.04, 0.06, 0.04)))
    // cầu ván ra mặt nước + xuồng
    for i in 0..<12 { solid.addChildNode(pbox(0.24, 0.05, 1.05, -4.3 + Float(i) * 0.26, 0.95, -1.4, i % 3 == 0 ? wdD : wd, 0.008)) }
    for px in [Float(-3.4), -2.2, -1.5] { for sz in [Float(-0.45), 0.45] { solid.addChildNode(pcyl(0.055, 0.95, px, 0.55, -1.4 + sz, wdD)) } }
    for sz in [Float(-0.45), 0.45] { solid.addChildNode(pbox(3.1, 0.07, 0.08, -2.9, 0.9, -1.4 + sz, wdD, 0.01)) }
    let boatM = mat(woodImg(C(0.3, 0.26, 0.2)), 1, 1); boatM.isDoubleSided = true
    let hull = boatHull(); hull.firstMaterial = boatM; let M0 = mT(-0.8, 0.64, -4.6) * mRy(0.06); geoNode(hull, M0, solid)
    for zz in [Float(-1.1), 0.1, 1.2] { let t = zz / 4.4 + 0.5; let th = pbox(CGFloat(1.8 * hullW(t)), 0.05, 0.2, 0, -0.07 + 0.28 * pow(abs(2 * t - 1), 3), zz, wd, 0.008); th.simdTransform = M0 * th.simdTransform; solid.addChildNode(th) }
    let bamboo = pcol(0.72, 0.62, 0.36)
    let pole = pcyl(0.025, 1.8, 1.4, 1.0, -6.2, bamboo); pole.eulerAngles.z = 0.1; solid.addChildNode(pole)
    // cầu ván bắc ngang mương
    for i in 0..<42 { solid.addChildNode(pbox(0.25, 0.05, 0.9, -5.2 + Float(i) * 0.25, 1.4, 6.5, i % 4 == 0 ? wdD : wd, 0.008)) }
    for sz in [Float(-0.4), 0.4] { solid.addChildNode(pbox(10.6, 0.08, 0.09, 0, 1.34, 6.5 + sz, wdD, 0.01)) }
    for px in [Float(-4.6), -2.4, 2.4, 4.6] { for sz in [Float(-0.4), 0.4] { solid.addChildNode(pcyl(0.06, 1.35, px, 0.825, 6.5 + sz, wdD)) } }
    let rail = pcyl(0.03, 10.6, 0, 2.0, 6.08, bamboo); rail.eulerAngles.z = .pi / 2; solid.addChildNode(rail)
    for k in 0..<7 { solid.addChildNode(pcyl(0.03, 0.62, -4.8 + Float(k) * 1.6, 1.7, 6.08, bamboo)) }
    root.addChildNode(solid.flattenedClone())
    // mặt nước: đậm ở giữa, nhạt ven bờ, phản chiếu trời, gợn sóng
    let wm = SCNMaterial(); wm.lightingModel = .blinn; wm.diffuse.contents = C(0.25, 0.28, 0.15); wm.specular.contents = UIColor.white; wm.shininess = 0.95
    wm.isDoubleSided = true; wm.transparency = 0.94; wm.shaderModifiers = [.fragment: Game.waterFrag]
    let wg = meshGeo([SIMD3<Float>(-3.15, 0.52, -half), SIMD3<Float>(3.15, 0.52, -half), SIMD3<Float>(-3.15, 0.52, half), SIMD3<Float>(3.15, 0.52, half)],
                     [SIMD2<Float>(0, 0), SIMD2<Float>(1, 0), SIMD2<Float>(0, 6), SIMD2<Float>(1, 6)], [0, 2, 1, 1, 2, 3])
    wg.firstMaterial = wm; root.addChildNode(SCNNode(geometry: wg))
    // dừa (không flatten để giữ đung đưa)
    for (x, z, yw) in [(Float(-5.2), Float(-9.5), Float(0.4)), (-8.2, 7.5, 1.9), (5.6, -8.0, 3.0), (8.2, 2.0, 4.1), (6.2, 10.0, 5.0)] {
      if let p = proto("coconutTree") { let n = p.clone(); n.position = SCNVector3(x, 0.92, z); n.eulerAngles.y = yw; root.addChildNode(n) } }
    return root
  }
  func sampleModel(_ id: String) -> SCNNode {
    let root = SCNNode()
    switch id {
    case Game.pondId: return pondDiorama()
    case "Mương nước quê (chiều sâu)": return canalDiorama()
    case "Hồ tường gạch": return townPond()
    case "Thị trấn cổ (mẫu)": return townDiorama()
    case "Đoạn đường 3 m":
      let b = SCNBox(width: 2.1, height: 0.12, length: 2.96, chamferRadius: 0); b.firstMaterial = concreteMats[0]; let n = SCNNode(geometry: b); n.position.y = 0.06; root.addChildNode(n)
    case "Tấm bê tông nứt":
      let b = SCNBox(width: 5, height: 0.12, length: 4.5, chamferRadius: 0); b.firstMaterial = crackedSlabMat; let n = SCNNode(geometry: b); n.position.y = 0.06; root.addChildNode(n)
    case "Gò đất cỏ", "Gò đất nâu": moundModel(id, into: root)
    case "Cục bùn nứt":
      let bx = SCNBox(width: 1, height: 0.6, length: 1.1, chamferRadius: 0.15); bx.firstMaterial = mudSampleMat
      let n = SCNNode(geometry: bx); n.position.y = 0.25; root.addChildNode(n)
    case "Khối bùn nứt":
      var rr = RNG(); rr.s = 99
      for _ in 0..<14 { let k = rr.f(0.6, 1.6); let bx = SCNBox(width: CGFloat(k), height: CGFloat(k * 0.6), length: CGFloat(k * rr.f(0.8, 1.4)), chamferRadius: CGFloat(k * 0.15)); bx.firstMaterial = mudSampleMat
        let n = SCNNode(geometry: bx); n.position = SCNVector3(rr.f(-1.6, 1.6), k * 0.25, rr.f(-2.4, 2.4)); n.eulerAngles = SCNVector3(rr.f(-0.3, 0.3), rr.f(0, 6), rr.f(-0.3, 0.3)); root.addChildNode(n) }
      return root.flattenedClone()
    case "Ao nước":
      let ring = lathe([(4.0, 0), (3.3, 0.16), (2.8, 0.14), (2.6, 0.04)], 36); ring.firstMaterial = mudSampleMat; root.addChildNode(SCNNode(geometry: ring))
      let w = SCNCylinder(radius: 2.7, height: 0.02); w.radialSegmentCount = 36; w.firstMaterial = canalWater; let wn = SCNNode(geometry: w); wn.position.y = 0.07; root.addChildNode(wn)
    default:   // đoạn đường 9 m, hàng rào hai bên, hoa, cọ như cảnh chính
      for i in 0..<3 { let b = SCNBox(width: 2.1, height: 0.12, length: 2.96, chamferRadius: 0); b.firstMaterial = concreteMats[i % 4]; let n = SCNNode(geometry: b); n.position = SCNVector3(0, 0.06, Float(i - 1) * 3); root.addChildNode(n) }
      func put(_ item: String, _ x: Float, _ z: Float, _ yw: Float) { if let p = proto(item) { let n = p.clone(); n.position = SCNVector3(x, 0, z); n.eulerAngles.y = yw; root.addChildNode(n) } }
      for (k, z) in [Float(-3.75), -1.25, 1.25, 3.75].enumerated() { put("hedge", -1.9, z, Float(k)); put("hedge", 1.9, z, Float(k) + 2) }
      put("roses-bush", -2.4, -2.5, 0.5); put("roses-bush", -2.4, 2.5, 2); put("lavender-bush", 2.5, 0, 1); put("palm", 4.5, 1.5, 0.7); put("coconutTree", -5, -2, 1.3)
    }
    return root
  }
  let procIds = ["Nhà mái lá", "Luống rau", "Luống cải bắp", "Luống đất", "Chậu cây đỏ", "Hàng chậu", "Giàn leo", "Hàng rào gỗ", "Lu sành", "Hoa hướng dương", "Xuồng ba lá"]
  var moundMats: [String: SCNMaterial] = [:]
  var geoCache: [String: SCNGeometry] = [:]; var leafMats: [String: SCNMaterial] = [:]
  func pcol(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> SCNMaterial {
    let m = SCNMaterial(); m.diffuse.contents = UIColor(red: r, green: g, blue: b, alpha: 1); m.lightingModel = .blinn; m.specular.contents = UIColor(white: 0.08, alpha: 1); return m }
  func pbox(_ w: CGFloat, _ h: CGFloat, _ l: CGFloat, _ x: Float, _ y: Float, _ z: Float, _ m: SCNMaterial, _ ch: CGFloat = 0.012) -> SCNNode {
    let g = SCNBox(width: w, height: h, length: l, chamferRadius: ch); g.firstMaterial = m
    let n = SCNNode(geometry: g); n.position = SCNVector3(x, y, z); return n }
  func pcyl(_ r: CGFloat, _ h: CGFloat, _ x: Float, _ y: Float, _ z: Float, _ m: SCNMaterial) -> SCNNode {
    let g = SCNCylinder(radius: r, height: h); g.radialSegmentCount = 16; g.firstMaterial = m
    let n = SCNNode(geometry: g); n.position = SCNVector3(x, y, z); return n }
  func psph(_ r: CGFloat, _ x: Float, _ y: Float, _ z: Float, _ sy: Float, _ m: SCNMaterial) -> SCNNode {
    let g = SCNSphere(radius: r); g.segmentCount = 20; g.firstMaterial = m
    let n = SCNNode(geometry: g); n.position = SCNVector3(x, y, z); n.scale = SCNVector3(1, sy, 1); return n }

  func meshGeo(_ P: [SIMD3<Float>], _ UV: [SIMD2<Float>], _ I: [Int32]) -> SCNGeometry {
    var N = [SIMD3<Float>](repeating: .zero, count: P.count)
    for t in stride(from: 0, to: I.count, by: 3) { let a = Int(I[t]), b = Int(I[t + 1]), c = Int(I[t + 2]); let n = simd_cross(P[b] - P[a], P[c] - P[a]); N[a] += n; N[b] += n; N[c] += n }
    return SCNGeometry(sources: [SCNGeometrySource(vertices: P.map { SCNVector3($0.x, $0.y, $0.z) }),
      SCNGeometrySource(normals: N.map { n -> SCNVector3 in let l = simd_length(n); let u = l > 0 ? n / l : SIMD3<Float>(0, 1, 0); return SCNVector3(u.x, u.y, u.z) }),
      SCNGeometrySource(textureCoordinates: UV.map { CGPoint(x: CGFloat($0.x), y: CGFloat($0.y)) })],
      elements: [SCNGeometryElement(indices: I, primitiveType: .triangles)])
  }
  // lá thon, cong, có gấp dọc gân giữa
  func leafGeo(_ L: Float, _ W: Float, _ arch: Float, _ fold: Float, _ m: SCNMaterial) -> SCNGeometry {
    let key = "\(L)_\(W)_\(arch)_\(fold)_\(m.name ?? "")"; if let g = geoCache[key] { return g }
    var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32](); let segs = 8
    for i in 0...segs { let t = Float(i) / Float(segs)
      let w = W / 2 * pow(sin(Float.pi * pow(t, 0.75)), 0.9), y = arch * t * t * L, z = t * L * (1 - 0.15 * arch * t)
      for j in 0..<3 { let s = Float(j) - 1; P.append(SIMD3<Float>(s * w, y + fold * abs(s) * w, z)); UV.append(SIMD2<Float>(Float(j) / 2, t)) } }
    for i in 0..<segs { for j in 0..<2 { let a = Int32(i * 3 + j), b = a + 1, c = a + 3, d = a + 4; I += [a, c, b, b, c, d] } }
    let g = meshGeo(P, UV, I); g.firstMaterial = m; geoCache[key] = g; return g
  }
  func lathe(_ prof: [(Float, Float)], _ seg: Int = 28) -> SCNGeometry {
    var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32](); let n = prof.count
    for k in 0...seg { let a = Float(k) / Float(seg) * 2 * Float.pi
      for (r, y) in prof { P.append(SIMD3<Float>(r * cos(a), y, r * sin(a))); UV.append(SIMD2<Float>(Float(k) / Float(seg), y)) } }
    for k in 0..<seg { for j in 0..<(n - 1) { let a = Int32(k * n + j), b = a + 1, c = a + Int32(n), d = c + 1; I += [a, b, c, b, d, c] } }
    return meshGeo(P, UV, I)
  }
  func leafImg(_ a: UIColor, _ b: UIColor, _ v: UIColor) -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 128, height: 256), format: Game.fmtTex).image { c in
      let g = c.cgContext
      if let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [a.cgColor, b.cgColor] as CFArray, locations: [0, 1]) { g.drawLinearGradient(gr, start: CGPoint(x: 0, y: 256), end: CGPoint(x: 0, y: 0), options: []) }
      v.withAlphaComponent(0.35).setStroke(); g.setLineWidth(1.5)
      for k in 1..<12 { let y = CGFloat(k) * 20; for s in [CGFloat(-1), CGFloat(1)] { g.move(to: CGPoint(x: 64, y: y)); g.addQuadCurve(to: CGPoint(x: 64 + s * 58, y: y - 34), control: CGPoint(x: 64 + s * 30, y: y - 6)); g.strokePath() } }
      v.withAlphaComponent(0.85).setStroke(); g.setLineWidth(4); g.move(to: CGPoint(x: 64, y: 256)); g.addLine(to: CGPoint(x: 64, y: 8)); g.strokePath()
      for i in 0..<400 { UIColor(white: CGFloat((i * 37) % 100) / 100, alpha: 0.05).setFill(); g.fill(CGRect(x: CGFloat((i * 53) % 128), y: CGFloat((i * 97) % 256), width: 2, height: 2)) } }
  }
  func leafMat(_ k: String) -> SCNMaterial {
    if let m = leafMats[k] { return m }
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    let t: (UIColor, UIColor, UIColor)
    switch k {
    case "grass": t = (C(0.16, 0.4, 0.09), C(0.58, 0.78, 0.26), C(0.45, 0.62, 0.2))
    case "lettuce": t = (C(0.28, 0.52, 0.14), C(0.64, 0.84, 0.3), C(0.88, 0.96, 0.62))
    case "cabbage": t = (C(0.42, 0.6, 0.48), C(0.8, 0.9, 0.8), C(0.96, 0.98, 0.92))
    case "sun": t = (C(0.12, 0.36, 0.08), C(0.34, 0.6, 0.16), C(0.55, 0.75, 0.35))
    case "lotus": t = (C(0.82, 0.35, 0.5), C(0.98, 0.78, 0.85), C(1, 0.95, 0.96))
    case "palm": t = (C(0.12, 0.3, 0.07), C(0.42, 0.62, 0.16), C(0.78, 0.82, 0.45))
    case "petal": t = (C(0.88, 0.55, 0.02), C(1.0, 0.87, 0.15), C(0.95, 0.7, 0.1))
    default: t = (C(0.1, 0.35, 0.08), C(0.4, 0.66, 0.18), C(0.7, 0.85, 0.45)) }
    let m = mat(leafImg(t.0, t.1, t.2), 1, 1); m.isDoubleSided = true; m.specular.contents = UIColor(white: 0.25, alpha: 1); m.shininess = 0.25; m.name = k
    leafMats[k] = m; return m
  }
  // cụm lá xoay theo góc vàng: dùng cho rau, cỏ, cây chậu, cánh hoa
  func rosette(_ n: Int, _ L: Float, _ W: Float, _ m: SCNMaterial, outer: Float, inner: Float, arch: Float, fold: Float = 0.15, radius: Float = 0, step: Float = 2.39996) -> SCNNode {
    let root = SCNNode()
    for i in 0..<n {
      let t = Float(i) / Float(max(n - 1, 1))
      let ln = SCNNode(geometry: leafGeo(L * (1 - 0.35 * t), W * (1 - 0.25 * t), arch, fold, m)); ln.position.z = radius
      ln.eulerAngles.x = -(outer + (inner - outer) * t + rng.f(-0.08, 0.08))
      let piv = SCNNode(); piv.eulerAngles.y = Float(i) * step + rng.f(-0.12, 0.12); piv.position.y = 0.008 * Float(i)
      piv.addChildNode(ln); root.addChildNode(piv) }
    return root
  }
  func cabbage(_ s: Float) -> SCNNode {
    let n = SCNNode(); let m = leafMat("cabbage")
    let core = SCNSphere(radius: 0.2); core.firstMaterial = m; let cn = SCNNode(geometry: core); cn.position.y = 0.2; cn.scale = SCNVector3(1, 0.9, 1); n.addChildNode(cn)
    n.addChildNode(rosette(7, 0.42, 0.32, m, outer: 0.45, inner: 0.9, arch: -0.25, radius: 0.1))
    let w = rosette(8, 0.5, 0.42, m, outer: 1.15, inner: 1.35, arch: 0.8, fold: 0.25, radius: 0.1); w.position.y = 0.06; n.addChildNode(w)
    n.scale = SCNVector3(s, s, s); return n
  }
  func flower(_ x: Float, _ z: Float, _ h: Float) -> SCNNode {
    let n = SCNNode(); n.position = SCNVector3(x, 0, z)
    n.addChildNode(pcyl(0.006, CGFloat(h), 0, h / 2, 0, pcol(0.2, 0.45, 0.15)))
    let pet = rosette(7, 0.06, 0.03, leafMat("petal"), outer: 0.25, inner: 0.25, arch: 0.15, step: 0.9); pet.position.y = h; n.addChildNode(pet)
    n.addChildNode(psph(0.012, 0, h + 0.012, 0, 1, pcol(0.5, 0.3, 0.05))); return n
  }
  func woodImg(_ base: UIColor) -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256), format: Game.fmtTex).image { c in
      let g = c.cgContext; base.setFill(); g.fill(CGRect(x: 0, y: 0, width: 256, height: 256))
      for i in 0..<90 { let x = CGFloat((i * 53) % 256), a = CGFloat((i * 37) % 100) / 100
        UIColor(white: a > 0.5 ? 0 : 1, alpha: 0.08 + 0.1 * a).setStroke(); g.setLineWidth(CGFloat(1 + i % 3))
        g.move(to: CGPoint(x: x, y: 0)); g.addCurve(to: CGPoint(x: x + CGFloat((i * 7) % 9) - 4, y: 256), control1: CGPoint(x: x + 6, y: 80), control2: CGPoint(x: x - 6, y: 170)); g.strokePath() }
      UIColor(white: 0, alpha: 0.35).setStroke(); g.setLineWidth(2)
      for k in 0..<4 { g.move(to: CGPoint(x: CGFloat(k) * 64, y: 0)); g.addLine(to: CGPoint(x: CGFloat(k) * 64, y: 256)); g.strokePath() } }
  }
  func thatchImg() -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256), format: Game.fmtTex).image { c in
      let g = c.cgContext; UIColor(red: 0.72, green: 0.57, blue: 0.31, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 256, height: 256))
      for i in 0..<1300 { let x = CGFloat((i * 71) % 256), y0 = CGFloat((i * 29) % 256), len = CGFloat(50 + (i * 13) % 90), t = CGFloat((i * 37) % 100) / 100, w = CGFloat((i * 11) % 7) - 3
        UIColor(red: 0.5 + 0.45 * t, green: 0.38 + 0.4 * t, blue: 0.16 + 0.26 * t, alpha: 0.75).setStroke(); g.setLineWidth(CGFloat(1 + i % 3))
        for off in [CGFloat(0), -256] { g.move(to: CGPoint(x: x, y: y0 + off)); g.addQuadCurve(to: CGPoint(x: x + w, y: y0 + off + len), control: CGPoint(x: x + w * 1.6, y: y0 + off + len / 2)); g.strokePath() } }
      UIColor(red: 0.3, green: 0.2, blue: 0.08, alpha: 0.35).setFill(); for k in 0..<4 { g.fill(CGRect(x: 0, y: CGFloat(k) * 64 + 58, width: 256, height: 4)) } }
  }
  // các hàng tranh xếp lớp như ngói, mép dưới tua rua
  func thatchRows(_ m: SCNMaterial, _ M: simd_float4x4) -> [SCNNode] {
    var nodes = [SCNNode](); var r = RNG(); r.s = 4242
    let nx = 72, x0: Float = -5.35, dx: Float = 10.7 / 72, N = 12
    for i in 0..<N {
      let zt: Float = -0.2 + 0.4 * Float(i), yt: Float = 0.1 + 0.02 * Float(N - i), off = r.f(0, 1)
      var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
      for j in 0...nx {
        let x = x0 + Float(j) * dx, len: Float = 0.78 + 0.22 * r.f(0, 1), u = x / 1.6 + off
        P.append(bake(M, SIMD3<Float>(x, yt, zt))); UV.append(SIMD2<Float>(u, 0))
        P.append(bake(M, SIMD3<Float>(x, yt - 0.015 * len, zt + len))); UV.append(SIMD2<Float>(u, len / 1.6)) }
      for j in 0..<nx { let a = Int32(2 * j), b = a + 2, c = a + 1, d = a + 3; I += [a, c, b, b, c, d] }
      let g = meshGeo(P, UV, I); g.firstMaterial = m; nodes.append(SCNNode(geometry: g)) }
    return nodes
  }
  // ma trận mái (tịnh tiến lên nóc * xoay quanh Y * nghiêng quanh X), tự tính để không phụ thuộc node lồng nhau
  func bake(_ M: simd_float4x4, _ p: SIMD3<Float>) -> SIMD3<Float> { let q = M * SIMD4<Float>(p.x, p.y, p.z, 1); return SIMD3<Float>(q.x, q.y, q.z) }
  func roofMatrix(_ ridgeY: Float, _ yawA: Float, _ tiltA: Float) -> simd_float4x4 {
    let cy = cos(yawA), sy = sin(yawA), cx = cos(tiltA), sx = sin(tiltA)
    let ry = simd_float4x4(columns: (SIMD4<Float>(cy, 0, -sy, 0), SIMD4<Float>(0, 1, 0, 0), SIMD4<Float>(sy, 0, cy, 0), SIMD4<Float>(0, 0, 0, 1)))
    let rx = simd_float4x4(columns: (SIMD4<Float>(1, 0, 0, 0), SIMD4<Float>(0, cx, sx, 0), SIMD4<Float>(0, -sx, cx, 0), SIMD4<Float>(0, 0, 0, 1)))
    let t = simd_float4x4(columns: (SIMD4<Float>(1, 0, 0, 0), SIMD4<Float>(0, 1, 0, 0), SIMD4<Float>(0, 0, 1, 0), SIMD4<Float>(0, ridgeY, 0, 1)))
    return t * ry * rx
  }
  func tileImg() -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 128, height: 128), format: Game.fmtTex).image { c in
      let g = c.cgContext; UIColor(red: 0.74, green: 0.74, blue: 0.7, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 128, height: 128))
      UIColor(white: 0.5, alpha: 0.7).setStroke(); g.setLineWidth(3); g.stroke(CGRect(x: 1, y: 1, width: 126, height: 126))
      g.setLineWidth(2); g.strokeEllipse(in: CGRect(x: 28, y: 28, width: 72, height: 72)); g.stroke(CGRect(x: 48, y: 48, width: 32, height: 32))
      for i in 0..<500 { UIColor(white: CGFloat((i * 37) % 100) / 100, alpha: 0.07).setFill(); g.fill(CGRect(x: CGFloat((i * 53) % 128), y: CGFloat((i * 97) % 128), width: 2, height: 2)) } }
  }
  func discImg() -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 128, height: 128), format: Game.fmtTex).image { c in
      let g = c.cgContext; UIColor(red: 0.25, green: 0.14, blue: 0.05, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 128, height: 128))
      for i in 0..<170 { let r = 4.4 * sqrt(CGFloat(i)), a = CGFloat(i) * 2.39996
        (i % 3 == 0 ? UIColor(red: 0.55, green: 0.38, blue: 0.1, alpha: 1) : UIColor(red: 0.12, green: 0.07, blue: 0.03, alpha: 1)).setFill()
        g.fillEllipse(in: CGRect(x: 64 + r * cos(a) - 2.4, y: 64 + r * sin(a) - 2.4, width: 4.8, height: 4.8)) } }
  }

  func potNode(_ s: Float, _ kind: Int) -> SCNNode {
    let n = SCNNode(); let clay = pcol(0.72, 0.16, 0.1); clay.specular.contents = UIColor(white: 0.3, alpha: 1); clay.shininess = 0.35; clay.isDoubleSided = true
    let g = lathe([(0, 0), (0.12, 0), (0.135, 0.02), (0.19, 0.27), (0.205, 0.29), (0.228, 0.3), (0.228, 0.345), (0.205, 0.356), (0.19, 0.335), (0.186, 0.32), (0, 0.312)]); g.firstMaterial = clay
    n.addChildNode(SCNNode(geometry: g)); n.addChildNode(pcyl(0.185, 0.02, 0, 0.316, 0, pcol(0.16, 0.11, 0.08)))
    let pl = rosette(9, 0.26, 0.15, leafMat(kind == 0 ? "default" : "lettuce"), outer: 0.5, inner: 1.2, arch: 0.4); pl.position.y = 0.32; n.addChildNode(pl)
    if kind == 0 { for k in 0..<3 { n.addChildNode(flower(0.08 * cos(Float(k) * 2.1), 0.08 * sin(Float(k) * 2.1), 0.5 + Float(k) * 0.05)) } }
    n.scale = SCNVector3(s, s, s); return n
  }
  func sunflower(_ h: Float) -> SCNNode {
    let n = SCNNode(); let stem = pcol(0.2, 0.42, 0.12); var px: Float = 0, py: Float = 0
    for i in 0..<6 { let seg = h / 6, lean = 0.06 * Float(i)
      let c = pcyl(0.03 - 0.003 * CGFloat(i), CGFloat(seg), px + seg * sin(lean) / 2, py + seg * cos(lean) / 2, 0, stem); c.eulerAngles.z = -lean; n.addChildNode(c); px += seg * sin(lean); py += seg * cos(lean) }
    let sm = leafMat("sun")
    for k in 0..<4 { let ln = SCNNode(geometry: leafGeo(0.32, 0.26, -0.5, 0.15, sm)); ln.eulerAngles.x = -0.35
      let piv = SCNNode(); piv.position = SCNVector3(0, 0.25 + 0.28 * Float(k), 0); piv.eulerAngles.y = Float(k) * 1.6 + 0.4; piv.addChildNode(ln); n.addChildNode(piv) }
    let head = SCNNode(); head.position = SCNVector3(px, py, 0); head.eulerAngles.x = 1.1
    let disc = SCNCylinder(radius: 0.14, height: 0.04); disc.firstMaterial = mat(discImg(), 1, 1); head.addChildNode(SCNNode(geometry: disc))
    for (k, yy) in [(0, Float(-0.012)), (1, 0.0)] { let r = rosette(18, 0.12, 0.045, leafMat("petal"), outer: 0.05, inner: 0.05, arch: 0.1, radius: 0.12, step: 0.349 + Float(k) * 0.17); r.position.y = yy; head.addChildNode(r) }
    n.addChildNode(head); return n
  }
  func houseNode() -> SCNNode {
    let root = SCNNode(); func U(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    let wood = mat(woodImg(U(0.45, 0.27, 0.16)), 1, 1), dark = mat(woodImg(U(0.3, 0.18, 0.1)), 1, 1), light = mat(woodImg(U(0.6, 0.4, 0.24)), 1, 1)
    let thatch = mat(thatchImg(), 2, 7); thatch.isDoubleSided = true; let rowM = mat(thatchImg(), 1, 1); rowM.isDoubleSided = true; let under = pcol(0.28, 0.2, 0.1); let straw = pcol(0.82, 0.68, 0.38)
    root.addChildNode(pbox(9.4, 0.3, 7, 0, 0.17, 0, dark, 0.02))
    for i in 0..<28 { root.addChildNode(pbox(0.33, 0.06, 7, -4.52 + Float(i) * 0.335, 0.36, 0, i % 2 == 0 ? light : wood, 0.01)) }
    root.addChildNode(pbox(2, 0.18, 0.8, 0, 0.09, 3.9, dark)); root.addChildNode(pbox(2, 0.18, 0.8, 0, 0.27, 3.6, wood))
    let post = lathe([(0.16, 0), (0.16, 0.12), (0.12, 0.16), (0.12, 2.35), (0.15, 2.4), (0.15, 2.46)], 16); post.firstMaterial = dark
    for x in [Float(-4.2), 0, 4.2] { for z in [Float(-3.1), 3.1] { let p = SCNNode(geometry: post); p.position = SCNVector3(x, 0.39, z); root.addChildNode(p) } }
    // phía sau để hở như nhà miền Tây trong ảnh tham khảo: chỉ có xà ngang và lan can thấp, không còn vách ván / cửa sổ
    root.addChildNode(pbox(9, 0.12, 0.12, 0, 2.75, -3.1, dark)); root.addChildNode(pbox(8.8, 0.1, 0.1, 0, 1.25, -3.1, dark)); root.addChildNode(pbox(8.8, 0.1, 0.1, 0, 0.5, -3.1, dark))
    for i in 0..<34 { root.addChildNode(pcyl(0.025, 0.7, -4.2 + Float(i) * 0.255, 0.88, -3.1, wood)) }
    for sx in [Float(-4.5), 4.5] { root.addChildNode(pbox(0.1, 0.1, 6.2, sx, 1.25, 0, dark)); root.addChildNode(pbox(0.1, 0.1, 6.2, sx, 0.5, 0, dark))
      for i in 0..<24 { root.addChildNode(pcyl(0.025, 0.7, sx, 0.88, -3 + Float(i) * 0.26, wood)) } }
    for sx in [Float(-2.9), 2.9] { root.addChildNode(pbox(3, 0.1, 0.1, sx, 1.25, 3.2, dark)); root.addChildNode(pbox(3, 0.1, 0.1, sx, 0.5, 3.2, dark))
      for i in 0..<11 { root.addChildNode(pcyl(0.025, 0.7, sx - 1.25 + Float(i) * 0.25, 0.88, 3.2, wood)) } }
    // bàn ghế, đèn lồng
    root.addChildNode(pbox(1.6, 0.08, 0.9, -1.5, 0.85, -1.4, light)); for dx in [Float(-0.7), 0.7] { for dz in [Float(-0.35), 0.35] { root.addChildNode(pcyl(0.04, 0.45, -1.5 + dx, 0.62, -1.4 + dz, wood)) } }
    for sz in [Float(-0.4), Float(-2.4)] { root.addChildNode(pbox(1.8, 0.07, 0.35, -1.5, 0.62, sz, wood)); for dx in [Float(-0.75), 0.75] { root.addChildNode(pcyl(0.035, 0.28, -1.5 + dx, 0.5, sz, dark)) } }
    root.addChildNode(pcyl(0.006, 0.5, 1.2, 2.5, 1.5, pcol(0.1, 0.1, 0.1)))
    let lg = lathe([(0.0, 0), (0.1, 0.02), (0.16, 0.14), (0.12, 0.28), (0.06, 0.3), (0, 0.3)], 14); lg.firstMaterial = pcol(0.85, 0.2, 0.1); let ln = SCNNode(geometry: lg); ln.position = SCNVector3(1.2, 2.0, 1.5); root.addChildNode(ln)
    // mái tranh nhiều lớp
    let ridgeY: Float = 5.35
    for s in [Float(0), Float(1)] {
      let M = roofMatrix(ridgeY, s * Float.pi, 0.62); var parts = [SCNNode]()
      parts.append(pbox(10.6, 0.1, 5.1, 0, 0.0, 2.5, under, 0.02))
      for k in 0..<110 { let len = 0.25 + 0.2 * Float((k * 37) % 10) / 10; let f = pbox(0.045, 0.025, CGFloat(len), -5.2 + Float(k) * 0.095, 0.07, 4.95 + len / 2, straw, 0.005); f.eulerAngles.x = 0.14 + 0.1 * Float((k * 13) % 5) / 5; parts.append(f) }
      if s == 0 { parts.append(pbox(2.6, 0.05, 1.5, -2.2, 0.37, 2.3, mat(solarImg(), 1, 1))); parts.append(pbox(2.7, 0.04, 1.6, -2.2, 0.34, 2.3, pcol(0.75, 0.75, 0.75))) }
      for n in parts { n.simdTransform = M * n.simdTransform; root.addChildNode(n) }
      for n in thatchRows(rowM, M) { root.addChildNode(n) } }
    let ridge = pcyl(0.3, 10.8, 0, ridgeY + 0.1, 0, thatch); ridge.eulerAngles.z = .pi / 2; root.addChildNode(ridge)
    for k in 0..<8 { let b = SCNTorus(ringRadius: 0.305, pipeRadius: 0.025); b.firstMaterial = dark; let bn = SCNNode(geometry: b); bn.position = SCNVector3(-4.8 + Float(k) * 1.37, ridgeY + 0.1, 0); bn.eulerAngles.z = .pi / 2; root.addChildNode(bn) }
    for sx in [Float(-5.4), 5.4] { for a in [Float(0.45), Float(-0.45)] { let p = pcyl(0.04, 1.4, sx, ridgeY + 0.65, 0, pcol(0.7, 0.6, 0.35)); p.eulerAngles.x = a; root.addChildNode(p) } }
    let tri = UIBezierPath(); tri.move(to: CGPoint(x: -3.1, y: 0)); tri.addLine(to: CGPoint(x: 3.1, y: 0)); tri.addLine(to: CGPoint(x: 0, y: 2.3)); tri.close()
    for sx in [Float(-4.95), 4.95] { let sh = SCNShape(path: tri, extrusionDepth: 0.12); sh.firstMaterial = rowM; let n = SCNNode(geometry: sh); n.position = SCNVector3(sx, 2.85, 0); n.eulerAngles.y = .pi / 2; root.addChildNode(n) }
    for z in [Float(-3.6), 3.6] { let p = pcyl(0.05, 10.4, 0, 2.95, z, pcol(0.7, 0.6, 0.35)); p.eulerAngles.z = .pi / 2; root.addChildNode(p) }
    return root
  }
  func solarImg() -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 192, height: 112), format: Game.fmtTex).image { c in
      let g = c.cgContext; UIColor(red: 0.07, green: 0.1, blue: 0.22, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 192, height: 112))
      UIColor(white: 0.7, alpha: 0.6).setStroke(); g.setLineWidth(1.5)
      for i in 0...6 { g.move(to: CGPoint(x: CGFloat(i) * 32, y: 0)); g.addLine(to: CGPoint(x: CGFloat(i) * 32, y: 112)); g.strokePath() }
      for j in 0...4 { g.move(to: CGPoint(x: 0, y: CGFloat(j) * 28)); g.addLine(to: CGPoint(x: 192, y: CGFloat(j) * 28)); g.strokePath() } }
  }
  func bedNode(_ id: String) -> SCNNode {
    let root = SCNNode(); let tile = mat(tileImg(), 1, 12)
    for sx in [Float(-1.22), 1.22] { root.addChildNode(pbox(0.28, 0.22, 6.3, sx, 0.11, 0, tile, 0.035)) }
    let soil = mat(makeTex(UIColor(red: 0.2, green: 0.14, blue: 0.1, alpha: 1), [UIColor(red: 0.1, green: 0.07, blue: 0.05, alpha: 1), UIColor(red: 0.4, green: 0.3, blue: 0.2, alpha: 1)], 1800, 7, seed: 77), 2, 6)
    root.addChildNode(pbox(2.2, 0.16, 6.1, 0, 0.08, 0, soil, 0.06))
    let hose = pcol(0.04, 0.04, 0.04)
    if id != "Luống đất" { let h = pcyl(0.014, 6, 0, 0.19, 0, hose); h.eulerAngles.x = .pi / 2; root.addChildNode(h); for i in 0..<12 { root.addChildNode(psph(0.022, 0.02, 0.2, -2.8 + Float(i) * 0.5, 0.6, pcol(0.1, 0.3, 0.8))) } }
    if id == "Luống rau" {
      for x in [Float(-0.7), 0, 0.7] { for i in 0..<13 { let p = rosette(8, 0.3, 0.17, leafMat(i % 3 == 0 ? "default" : "lettuce"), outer: 0.5, inner: 1.1, arch: 0.45, fold: 0.2)
        let s = rng.f(0.8, 1.25); p.scale = SCNVector3(s, s, s); p.position = SCNVector3(x + rng.f(-0.05, 0.05), 0.15, -2.8 + Float(i) * 0.45 + rng.f(-0.04, 0.04)); root.addChildNode(p) } }
    } else if id == "Luống cải bắp" {
      for x in [Float(-0.65), 0, 0.65] { for i in 0..<7 { let c = cabbage(rng.f(0.85, 1.1)); c.position = SCNVector3(x, 0.14, -2.7 + Float(i) * 0.9); root.addChildNode(c) } }
    } else {
      let ridge = mat(makeTex(UIColor(red: 0.16, green: 0.11, blue: 0.08, alpha: 1), [UIColor(red: 0.3, green: 0.22, blue: 0.14, alpha: 1)], 1200, 6, seed: 78), 1, 6)
      for x in [Float(-0.65), 0, 0.65] { root.addChildNode(pbox(0.5, 0.18, 5.7, x, 0.2, 0, ridge, 0.09))
        for i in 0..<9 { let sp = rosette(3, 0.1, 0.05, leafMat("default"), outer: 0.8, inner: 0.8, arch: 0.3); sp.position = SCNVector3(x, 0.28, -2.6 + Float(i) * 0.65); root.addChildNode(sp) } }
      for _ in 0..<40 { let b = pbox(0.02, 0.01, CGFloat(rng.f(0.1, 0.3)), rng.f(-1, 1), 0.17, rng.f(-2.8, 2.8), pcol(0.8, 0.7, 0.4), 0.004); b.eulerAngles.y = rng.f(0, 3); root.addChildNode(b) } }
    return root
  }
  func procModel(_ id: String) -> SCNNode? {
    let root = SCNNode(); let wood = mat(woodImg(UIColor(red: 0.45, green: 0.3, blue: 0.18, alpha: 1)), 1, 1), bamboo = pcol(0.72, 0.62, 0.36)
    if sampleIds.contains(id) { return sampleModel(id) }
    if Game.townIds.contains(id) { return townModel(id) }
    if Game.beastIds.contains(id) { return beastModel(id) }
    if Game.blossomIds.contains(id) { return blossomModel(id) }
    switch id {
    case "Nhà mái lá": root.addChildNode(houseNode())
    case "Xuồng ba lá": root.addChildNode(sampanNode())
    case "Luống rau", "Luống cải bắp", "Luống đất": root.addChildNode(bedNode(id))
    case "Chậu cây đỏ": root.addChildNode(potNode(1, 0))
    case "Hàng chậu": for i in 0..<6 { let p = potNode(i % 2 == 0 ? 1 : 0.85, i % 2); p.position = SCNVector3(0, 0, Float(i) * 0.55 - 1.4); root.addChildNode(p) }
    case "Giàn leo":
      for i in 0..<5 { let x = -2.4 + Float(i) * 1.2; root.addChildNode(pcyl(0.04, 2.2, x, 1.1, 0, bamboo))
        for k in 1..<5 { let t = SCNTorus(ringRadius: 0.042, pipeRadius: 0.012); t.firstMaterial = pcol(0.5, 0.42, 0.2); let tn = SCNNode(geometry: t); tn.position = SCNVector3(x, Float(k) * 0.42, 0); root.addChildNode(tn) }
        if i > 0 { for s in [Float(-1), 1] { let d = pbox(0.03, 2.4, 0.03, x - 0.6, 1.1, 0, bamboo, 0.005); d.eulerAngles.z = s * 0.5; root.addChildNode(d) } } }
      for y in [Float(0.6), 1.2, 1.8] { let r = pcyl(0.025, 4.8, 0, y, 0, bamboo); r.eulerAngles.z = .pi / 2; root.addChildNode(r) }
      for _ in 0..<24 { let v = rosette(4, 0.12, 0.08, leafMat("default"), outer: 0.6, inner: 0.6, arch: 0.3); v.position = SCNVector3(rng.f(-2.4, 2.4), rng.f(0.3, 2.1), rng.f(-0.06, 0.06)); root.addChildNode(v) }
      for _ in 0..<7 { let f = flower(rng.f(-2.2, 2.2), 0.06, 0.02); f.position.y = rng.f(0.5, 2); root.addChildNode(f) }
    case "Hàng rào gỗ":
      for i in 0..<5 { let x = -3 + Float(i) * 1.5; root.addChildNode(pcyl(0.065, 1.15, x, 0.575, 0, wood)); root.addChildNode(psph(0.07, x, 1.17, 0, 0.8, wood)) }
      for y in [Float(0.5), 0.9] { root.addChildNode(pbox(6, 0.09, 0.06, 0, y, 0, wood, 0.02)) }
      for i in 0..<20 { root.addChildNode(pbox(0.07, 0.95, 0.025, -2.85 + Float(i) * 0.3, 0.5, 0.05, wood, 0.01)) }
    case "Lu sành":
      let g = lathe([(0, 0), (0.2, 0), (0.3, 0.05), (0.42, 0.25), (0.46, 0.45), (0.4, 0.65), (0.28, 0.8), (0.22, 0.88), (0.24, 0.93), (0.27, 0.96), (0.25, 0.985), (0.2, 0.96), (0, 0.94)], 32)
      let clay = pcol(0.45, 0.22, 0.1); clay.specular.contents = UIColor(white: 0.6, alpha: 1); clay.shininess = 0.7; clay.isDoubleSided = true; g.firstMaterial = clay; root.addChildNode(SCNNode(geometry: g))
    case "Hoa hướng dương":
      for k in 0..<6 { let s = sunflower(rng.f(1.2, 1.75)); s.position = SCNVector3(rng.f(-0.7, 0.7), 0, rng.f(-0.7, 0.7)); s.eulerAngles.y = Float(k); root.addChildNode(s) }
    default: return nil }
    return root.flattenedClone()
  }

  // ===== Ảnh xem trước mô hình + thu nhập =====
  @Published var thumbs: [String: UIImage] = [:]
  @Published var weather: Weather = Weather(rawValue: UserDefaults.standard.string(forKey: "weather") ?? "") ?? .clear { didSet { UserDefaults.standard.set(weather.rawValue, forKey: "weather"); weatherSys?.apply(weather) } }
  var weatherSys: WeatherSystem?; var wxAmb: SCNNode?; var wxSun: SCNNode?   // thời tiết (Weather.swift) và hai đèn của cảnh
  var horizonMats: [SCNMaterial] = []; var swayGain: Float = 1               // chân trời (Horizon.swift); gió nhân thêm vào biên độ lay của cây
  @Published var impRev = 0   // tăng khi thư viện mô hình nhập đổi, để thanh chọn vẽ lại
  @Published var impAlert: String? = nil   // thông báo sau khi nhập mô hình
  var thumbQ: [String] = []; var thumbBusy = false
  lazy var thumbRenderer: SCNRenderer? = { MTLCreateSystemDefaultDevice().map { SCNRenderer(device: $0, options: nil) } }()
  func icon(_ i: String) -> String { i == "grass" ? "🌿" : i == "Đường nhựa" ? "🛣️" : i == "Đường đất" ? "🟫" : i == "Mương nước" ? "💧" : i == "Đường bê tông" ? "🧱" : "⏳" }
  func requestThumb(_ id: String) {
    guard thumbs[id] == nil, !thumbQ.contains(id), id != "grass", catOf[id] != "Vẽ đường" else { return }
    thumbQ.append(id); pump()
  }
  func pump() {
    guard loadNote == nil, !thumbBusy, !thumbQ.isEmpty else { return }
    thumbBusy = true; let id = thumbQ.removeFirst()
    DispatchQueue.main.async { self.thumbs[id] = self.renderThumb(id) ?? UIImage(systemName: "questionmark.square")!; self.thumbBusy = false; self.pump() }
  }
  func renderThumb(_ id: String) -> UIImage? {
    guard let r = thumbRenderer, let p = proto(id) else { return nil }
    let sc = SCNScene(); sc.background.contents = UIColor(red: 0.8, green: 0.88, blue: 0.9, alpha: 1)
    let n = p.clone(); sc.rootNode.addChildNode(n)
    let (mn, mx) = n.boundingBox; let c = SCNVector3((mn.x + mx.x) / 2, (mn.y + mx.y) / 2, (mn.z + mx.z) / 2)
    let size = max(mx.x - mn.x, mx.y - mn.y, mx.z - mn.z, 0.1)
    let look = SCNNode(); look.position = c; sc.rootNode.addChildNode(look)
    let cm = SCNNode(); cm.camera = SCNCamera(); cm.camera?.fieldOfView = 35
    cm.position = SCNVector3(c.x + size * 0.9, c.y + size * 0.5, c.z + size * 1.8); cm.constraints = [SCNLookAtConstraint(target: look)]; sc.rootNode.addChildNode(cm)
    let a = SCNNode(); a.light = SCNLight(); a.light?.type = .ambient; a.light?.intensity = 700; sc.rootNode.addChildNode(a)
    let d = SCNNode(); d.light = SCNLight(); d.light?.type = .directional; d.light?.intensity = 900; d.eulerAngles = SCNVector3(-0.7, 0.6, 0); sc.rootNode.addChildNode(d)
    r.scene = sc; r.pointOfView = cm
    return r.snapshot(atTime: 0, with: CGSize(width: 160, height: 160), antialiasingMode: .multisampling4X)
  }

  // ===== Cây, bụi đung đưa =====
  @Published var swayLevel = UserDefaults.standard.object(forKey: "sway") as? Int ?? 1   // 0 tắt, 1 nhẹ, 2 mạnh
  var swayMats: [(SCNMaterial, Float)] = []
  var swayMul: Float { [0, 1, 2.2][min(max(swayLevel, 0), 2)] * swayGain }
  static let swayShader = """
  uniform float amp; uniform float hh; uniform float base;
  #pragma body
  float h = clamp((_geometry.position.y - base) / hh, 0.0, 1.0);
  float dcam = -(scn_node.modelViewTransform * float4(0.0, 0.0, 0.0, 1.0)).z;
  float k = h * h * amp * hh * (1.0 - smoothstep(45.0, 80.0, dcam));
  float t = scn_frame.time;
  float ph = (_geometry.position.x + _geometry.position.z) / hh * 6.0;
  _geometry.position.x += (sin(t * 1.6 + ph) + sin(t * 5.0 + ph * 3.0) * 0.15) * k;
  _geometry.position.z += cos(t * 1.3 + ph * 1.3) * k * 0.7;
  """
  func cycleSway() { setSway((swayLevel + 1) % 3) }
  @Published var sfxOn = SoundFX.shared.sfxOn
  @Published var musicOn = SoundFX.shared.musicOn
  @Published var musicVol = SoundFX.shared.musicVol
  @Published var sfxVol = SoundFX.shared.sfxVol
  @Published var ambVol = SoundFX.shared.ambVol
  @Published var soundSheet = false
  // ngày đêm + sao lưu + chụp ảnh
  @Published var timeMode = UserDefaults.standard.integer(forKey: "timeMode")     // 0 tự động, 1 sáng, 2 trưa, 3 chiều, 4 đêm
  func setTimeMode(_ m: Int) { timeMode = m; UserDefaults.standard.set(m, forKey: "timeMode"); weatherSys?.setTime(mode: m) }
  var horizonDay: CGFloat = 1; var horizonFog: CGFloat = 1     // độ sáng ngày / sương cho rặng cây xa (Horizon.swift)
  @Published var shareItem: ShareItem? = nil                   // bảng chia sẻ ảnh / file sao lưu (Backup.swift)
  @Published var villageAlert: String? = nil
  var importLock = false                                       // sau khi nhập làng: không ghi đè dữ liệu mới nhập cho tới khi mở lại app
  weak var scnView: SCNView?
  func setMusicVol(_ v: Float) { musicVol = v; SoundFX.shared.setMusicVol(v) }
  func setSfxVol(_ v: Float) { sfxVol = v; SoundFX.shared.setSfxVol(v) }
  func setAmbVol(_ v: Float) { ambVol = v; SoundFX.shared.setAmbVol(v) }
  func setSfx(_ on: Bool) { sfxOn = on; SoundFX.shared.setSfx(on) }
  func setMusic(_ on: Bool) { musicOn = on; SoundFX.shared.setMusic(on) }
  func setSway(_ n: Int) {
    SoundFX.shared.setSway(n)
    swayLevel = n; UserDefaults.standard.set(swayLevel, forKey: "sway")
    for (m, a) in swayMats { m.setValue(NSNumber(value: a * swayMul), forKey: "amp") }
  }

  // ===== Vẽ đường / mương: tự nối điểm gần nhau + bo góc =====
  struct RoadRec: Codable { var id: String; var kind: Int; var pts: [[Float]] }
  let kinds = ["Đường nhựa", "Đường đất", "Mương nước", "Đường bê tông"]; let widths: [Float] = [6, 3.5, 2.8, 2.1]
  var roads: [RoadRec] = []; var draft: [[Float]] = []
  @Published var drawing = 0
  var kindIdx: Int { kinds.firstIndex(of: sel) ?? 0 }
  static let canalFrag = """
  #pragma body
  float2 uv = _surface.diffuseTexcoord * float2(4.0, 40.0); float t = scn_frame.time;
  float r = sin(uv.x * 3.1 + t * 1.6) * sin(uv.y * 2.3 - t * 1.2) + sin((uv.x + uv.y) * 5.0 + t * 2.5) * 0.5;
  _surface.normal = normalize(_surface.normal + float3(r * 0.06, r * 0.06, 0.0));
  _surface.diffuse.rgb += r * 0.035;
  """
  func laneImg(_ dirt: Bool) -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256), format: Game.fmtTex).image { c in
      let g = c.cgContext
      (dirt ? UIColor(red: 0.45, green: 0.34, blue: 0.22, alpha: 1) : UIColor(white: 0.22, alpha: 1)).setFill(); g.fill(CGRect(x: 0, y: 0, width: 256, height: 256))
      UIColor(white: dirt ? 0.4 : 0.72, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 30, height: 256)); g.fill(CGRect(x: 226, y: 0, width: 30, height: 256))
      if !dirt { UIColor(red: 0.95, green: 0.8, blue: 0.2, alpha: 1).setFill(); g.fill(CGRect(x: 124, y: 0, width: 8, height: 128)) }
      for i in 0..<900 { UIColor(white: CGFloat((i * 37) % 100) / 100, alpha: 0.08).setFill(); g.fill(CGRect(x: CGFloat((i * 53) % 256), y: CGFloat((i * 97) % 256), width: 3, height: 3)) } }
  }
  func roadMat(_ img: UIImage) -> SCNMaterial { let m = mat(img, 1, 1); m.isDoubleSided = true; return m }
  lazy var asphaltMat = roadMat(laneImg(false))
  lazy var dirtMat = roadMat(laneImg(true))
  lazy var bankMat = roadMat(makeTex(UIColor(white: 0.6, alpha: 1), [UIColor(white: 0.45, alpha: 1), UIColor(white: 0.75, alpha: 1)], 1500, 6, cracks: 6, crackColor: UIColor(white: 0.15, alpha: 1), seed: 41))
  lazy var canalWater: SCNMaterial = {
    let m = SCNMaterial(); m.lightingModel = .blinn; m.diffuse.contents = UIColor(red: 0.28, green: 0.4, blue: 0.3, alpha: 1)
    m.specular.contents = UIColor.white; m.shininess = 0.9; m.isDoubleSided = true; m.shaderModifiers = [.fragment: Game.canalFrag]; return m }()

  func smooth(_ p: [[Float]], _ rad: Float) -> [SIMD2<Float>] {   // bo góc bằng cung bezier
    let q = p.map { SIMD2<Float>($0[0], $0[1]) }; guard q.count > 2 else { return q }
    var out = [q[0]]
    for i in 1..<(q.count - 1) {
      let a = q[i - 1], c = q[i], b = q[i + 1]; let r = min(rad, 0.45 * simd_length(a - c), 0.45 * simd_length(b - c))
      if r < 0.01 { out.append(c); continue }
      let s = c + simd_normalize(a - c) * r, e = c + simd_normalize(b - c) * r
      for k in 0...8 { let t = Float(k) / 8; out.append((1 - t) * (1 - t) * s + 2 * (1 - t) * t * c + t * t * e) } }
    out.append(q[q.count - 1]); return out
  }
  func ribbon(_ p: [SIMD2<Float>], _ w: Float, _ y: Float, _ m: SCNMaterial) -> SCNNode? {
    guard p.count > 1 else { return nil }
    var v = [SCNVector3](), nm = [SCNVector3](), t = [CGPoint](), idx = [Int32](); var d: Float = 0
    for i in 0..<p.count {
      let dv = p[min(i + 1, p.count - 1)] - p[max(i - 1, 0)]; let l = simd_length(dv); let dir = l > 0 ? dv / l : SIMD2<Float>(0, 1)
      if i > 0 { d += simd_length(p[i] - p[i - 1]) }
      let n = SIMD2<Float>(-dir.y, dir.x) * (w / 2)
      v.append(SCNVector3(p[i].x + n.x, y, p[i].y + n.y)); v.append(SCNVector3(p[i].x - n.x, y, p[i].y - n.y))
      nm.append(SCNVector3(0, 1, 0)); nm.append(SCNVector3(0, 1, 0))
      t.append(CGPoint(x: 0, y: CGFloat(d / 8))); t.append(CGPoint(x: 1, y: CGFloat(d / 8)))
      if i > 0 { let b = Int32(2 * i); idx += [b - 2, b, b - 1, b - 1, b, b + 1] } }
    let g = SCNGeometry(sources: [SCNGeometrySource(vertices: v), SCNGeometrySource(normals: nm), SCNGeometrySource(textureCoordinates: t)],
                        elements: [SCNGeometryElement(indices: idx, primitiveType: .triangles)])
    g.firstMaterial = m; return SCNNode(geometry: g)
  }
  func disc(_ pt: SIMD2<Float>, _ r: Float, _ y: Float, _ m: SCNMaterial) -> SCNNode {
    let c = SCNCylinder(radius: CGFloat(r), height: 0.004); c.firstMaterial = m
    let n = SCNNode(geometry: c); n.position = SCNVector3(pt.x, y + 0.002, pt.y); return n
  }
  lazy var concreteMats: [SCNMaterial] = {
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    return [2, 3, 6, 4].enumerated().map { mat(makeTex(C(0.55, 0.57, 0.53), [C(0.4, 0.42, 0.38), C(0.72, 0.72, 0.68), C(0.35, 0.42, 0.3), C(0.92, 0.92, 0.9)], 3000, 6, cracks: $1, crackColor: C(0.13, 0.13, 0.12), seed: UInt64(20 + $0)), 1, 1) }
  }()
  func chaikin(_ q: [SIMD2<Float>], _ it: Int) -> [SIMD2<Float>] {   // làm mượt đường vẽ tay
    var p = q
    for _ in 0..<it { guard p.count > 2 else { break }; var o = [p[0]]
      for i in 0..<(p.count - 1) { o.append(p[i] * 0.75 + p[i + 1] * 0.25); o.append(p[i] * 0.25 + p[i + 1] * 0.75) }
      o.append(p[p.count - 1]); p = o }
    return p
  }
  func concreteRoad(_ pts: [[Float]]) -> SCNNode {   // tấm bê tông 2,1 x 3 m có vết nứt, giống đường chính
    let out = SCNNode(); let p = chaikin(pts.map { SIMD2<Float>($0[0], $0[1]) }, 2); guard p.count > 1 else { return out }
    var cum: [Float] = [0]; for i in 1..<p.count { cum.append(cum[i - 1] + simd_length(p[i] - p[i - 1])) }
    let total = cum[cum.count - 1]; guard total > 0.1 else { return out }
    func at(_ d: Float) -> SIMD2<Float> {
      var i = 1; while i < p.count - 1 && cum[i] < d { i += 1 }
      let seg = cum[i] - cum[i - 1]; let t = seg > 0 ? min(max((d - cum[i - 1]) / seg, 0), 1) : 0
      return p[i - 1] * (1 - t) + p[i] * t }
    let n = max(1, Int((total / 3).rounded(.up))), l = total / Float(n)
    for i in 0..<n {
      let a = at(l * Float(i)), b = at(l * Float(i + 1)), d = b - a, len = max(simd_length(d), 0.3)
      let bx = SCNBox(width: 2.1, height: 0.12, length: CGFloat(len - 0.04), chamferRadius: 0); bx.firstMaterial = concreteMats[i % 4]
      let nd = SCNNode(geometry: bx); nd.position = SCNVector3((a.x + b.x) / 2, 0.06, (a.y + b.y) / 2); nd.eulerAngles.y = atan2(d.x, d.y); out.addChildNode(nd) }
    return out.flattenedClone()
  }
  func roadNode(_ r: RoadRec) -> SCNNode {
    if r.kind == 3 { let n = SCNNode(); n.name = "road:\(r.id)"; n.addChildNode(concreteRoad(r.pts)); return n }
    let n = SCNNode(); n.name = "road:\(r.id)"; let p = smooth(r.pts, 3.5), w = widths[min(max(r.kind, 0), widths.count - 1)]
    guard p.count > 1 else { return n }
    if r.kind == 2 {
      if let a = ribbon(p, w, 0.06, bankMat) { n.addChildNode(a) }; if let b = ribbon(p, w - 1.2, 0.07, canalWater) { n.addChildNode(b) }
      for e in [p.first!, p.last!] { n.addChildNode(disc(e, w / 2, 0.06, bankMat)); n.addChildNode(disc(e, w / 2 - 0.6, 0.07, canalWater)) }
    } else {
      let m = r.kind == 0 ? asphaltMat : dirtMat
      if let a = ribbon(p, w, 0.05, m) { n.addChildNode(a) }; for e in [p.first!, p.last!] { n.addChildNode(disc(e, w / 2, 0.05, m)) } }
    return n
  }
  func snap(_ x: Float, _ z: Float) -> [Float] {   // tự nối vào điểm đường có sẵn trong 2.5 m
    var best: [Float]? = nil; var bd: Float = 2.5
    for r in roads { for p in r.pts { let d = hypot(p[0] - x, p[1] - z); if d < bd { bd = d; best = p } } }
    return best ?? [x, z]
  }
  func addPoint(_ x: Float, _ z: Float) {
    let p = snap(x, z); if let l = draft.last, l == p { return }
    draft.append(p); drawing = draft.count; preview()
  }
  func preview() {
    scene.rootNode.childNode(withName: "draft", recursively: false)?.removeFromParentNode()
    let d = SCNNode(); d.name = "draft"
    for p in draft where !stroking { let s = SCNSphere(radius: 0.35); s.firstMaterial?.diffuse.contents = UIColor.yellow; let n = SCNNode(geometry: s); n.position = SCNVector3(p[0], 0.4, p[1]); d.addChildNode(n) }
    if draft.count > 1 { d.addChildNode(roadNode(RoadRec(id: "d", kind: kindIdx, pts: draft))) }
    scene.rootNode.addChildNode(d)
  }
  // vẽ tay: kéo ngón tay, đường hiện ra tới đâu theo tới đó
  @Published var freeDraw = true
  var stroking = false
  func groundPoint(_ v: SCNView, _ p: CGPoint) -> SIMD2<Float>? {
    let a = v.unprojectPoint(SCNVector3(Float(p.x), Float(p.y), 0)), b = v.unprojectPoint(SCNVector3(Float(p.x), Float(p.y), 1))
    guard a.y - b.y > 0.0001 else { return nil }; let t = a.y / (a.y - b.y); guard t > 0, t < 1 else { return nil }
    return SIMD2<Float>(a.x + (b.x - a.x) * t, a.z + (b.z - a.z) * t)
  }
  func strokeBegin() { stroking = true; if !draft.isEmpty { finish() } }
  func strokeMove(_ v: SCNView, _ loc: CGPoint) {
    guard let g = groundPoint(v, loc) else { return }
    if draft.isEmpty { draft.append(snap(g.x, g.y)); drawing = draft.count; return }
    guard let l = draft.last, hypot(l[0] - g.x, l[1] - g.y) >= 1.2 else { return }
    draft.append([g.x, g.y]); drawing = draft.count; preview()
  }
  func strokeEnd() { stroking = false; finish() }
  func undoPoint() { if !draft.isEmpty { draft.removeLast(); drawing = draft.count; preview() } }
  func length(_ p: [[Float]]) -> Float { zip(p, p.dropFirst()).reduce(0) { $0 + hypot($1.0[0] - $1.1[0], $1.0[1] - $1.1[1]) } }
  func finish() {
    guard draft.count > 1 else { draft = []; drawing = 0; preview(); return }
    let r = RoadRec(id: UUID().uuidString, kind: kindIdx, pts: draft); let idx = roads.count; roads.append(r); scene.rootNode.addChildNode(roadNode(r))
    commit("Vẽ " + kinds[r.kind], toast: false, undo: { [weak self] in self?.delRoad(r.id) }, redo: { [weak self] in self?.addRoad(r, at: idx) })
    draft = []; drawing = 0; preview(); save()
  }
  func removeRoad(_ n: SCNNode, _ id: String) {
    if let i = roads.firstIndex(where: { $0.id == id }) { roads.remove(at: i) }
    if selRoad == id { selectRoad(nil) }
    n.removeFromParentNode(); save()
  }
  func saveRoads() { if !importLock, let d = try? JSONEncoder().encode(roads) { UserDefaults.standard.set(d, forKey: "roads") } }

  // kéo vật đã đặt tới vị trí mới: có dấu chấm + vòng tròn báo trước điểm sẽ đặt
  var dragNode: SCNNode?; var dragId: String?; var dragStartRec: Rec?; var dragMarker: SCNNode?; var dragOff = SIMD2<Float>(0, 0)
  // ===== Chọn vật khi chạm: ưu tiên vật thật hơn cỏ nền và mặt đường (chúng nằm sát đất, hay chắn tia chạm), có thêm vùng chạm rộng cho vật nhỏ =====
  enum Pick { case obj(SCNNode, String), road(String) }
  func rawPick(_ hits: [SCNHitTestResult]) -> (Int, Pick)? {   // 0 vật, 1 mảng cỏ, 2 đường; cùng nhóm thì lấy cái gần nhất (hits đã xếp gần → xa)
    var best: (Int, Pick)? = nil
    for h in hits { var n: SCNNode? = h.node
      while let c = n {
        if let nm = c.name {
          if nm.hasPrefix("placed:") { let id = String(nm.dropFirst(7)); let pr = recOf(id)?.item == "grass" ? 1 : 0
            if best == nil || pr < best!.0 { best = (pr, .obj(c, id)) }; break }
          if nm.hasPrefix("road:") { if best == nil || 2 < best!.0 { best = (2, .road(String(nm.dropFirst(5)))) }; break } }
        n = c.parent } }
    return best
  }
  func pickAt(_ v: SCNView, _ p: CGPoint, near: Bool) -> Pick? {
    func hit(_ q: CGPoint) -> [SCNHitTestResult] { v.hitTest(q, options: [SCNHitTestOption.searchMode: SCNHitTestSearchMode.all.rawValue]) }
    let first = rawPick(hit(p)); if let f = first, f.0 == 0 { return f.1 }
    if near { for rad in [CGFloat(16), 32] { for k in 0..<8 { let a = CGFloat(k) * .pi / 4
      if let f = rawPick(hit(CGPoint(x: p.x + rad * cos(a), y: p.y + rad * sin(a)))), f.0 == 0 { return f.1 } } } }
    return first?.1
  }
  func dragBegin(_ v: SCNView, _ loc: CGPoint) -> Bool {
    if case .obj(let c, let id)? = pickAt(v, loc, near: false) {
          select(c, id); dragNode = c; dragId = id; dragStartRec = recOf(id)
          let g = groundPoint(v, loc) ?? SIMD2<Float>(c.position.x, c.position.z); dragOff = SIMD2<Float>(c.position.x, c.position.z) - g
          let r = max(0.4, min(footRadius(c) * c.scale.x, 6))
          let m = SCNNode()
          let disc = SCNCylinder(radius: CGFloat(r), height: 0.02); disc.firstMaterial?.diffuse.contents = UIColor(red: 1, green: 0.9, blue: 0.1, alpha: 0.35); disc.firstMaterial?.emission.contents = UIColor(red: 1, green: 0.85, blue: 0, alpha: 0.5); disc.firstMaterial?.isDoubleSided = true; m.addChildNode(SCNNode(geometry: disc))
          let ring = SCNTorus(ringRadius: CGFloat(r), pipeRadius: 0.05); ring.firstMaterial?.diffuse.contents = UIColor.yellow; ring.firstMaterial?.emission.contents = UIColor.yellow; m.addChildNode(SCNNode(geometry: ring))
          let pin = SCNCylinder(radius: 0.06, height: 2.5); pin.firstMaterial?.diffuse.contents = UIColor.yellow; pin.firstMaterial?.emission.contents = UIColor.yellow; let pn = SCNNode(geometry: pin); pn.position.y = 1.25; m.addChildNode(pn)
          m.position = SCNVector3(c.position.x, 0.04, c.position.z); scene.rootNode.addChildNode(m); dragMarker = m
          c.position.y = 0.25; return true }
    return false
  }
  func dragMove(_ v: SCNView, _ loc: CGPoint) {
    guard let n = dragNode, let g = groundPoint(v, loc) else { return }
    let x = min(max(g.x + dragOff.x, -14), 100), z = min(g.y + dragOff.y, 38)   // theo phạm vi mặt đất, không kéo vật về lại vùng gần
    n.position = SCNVector3(x, 0.25, z); dragMarker?.position = SCNVector3(x, 0.04, z)
  }
  func dragEnd() {
    if let n = dragNode, let id = dragId, var r = recOf(id) { n.position.y = 0; r.x = n.position.x; r.z = n.position.z; setRec(r); save()
      if let b = dragStartRec, hypot(b.x - r.x, b.z - r.z) > 0.02 { recEdit("Di chuyển", nil, b, r) } }
    dragStartRec = nil; dragMarker?.removeFromParentNode(); dragMarker = nil; dragNode = nil; dragId = nil
  }
  // ===== Tạo hàng: nhân vật đang chọn (hàng rào, bụi, cỏ, hoa, cây...) thành hàng thẳng hoặc cong theo số mét =====
  @Published var rowPanel = false
  var selItem: String { guard let id = selId, let r = recOf(id) else { return "" }; return r.item == "grass" ? "Cỏ" : r.item }
  func isLenModel(_ item: String) -> Bool { if let z = sizes[item], z.count > 1, z[0] == 1 { return true }; return false }
  func defaultSpacing() -> Float {
    guard let id = selId, let r = recOf(id) else { return 1 }
    if r.item == "grass" { return 1.6 * r.s }
    if let z = sizes[r.item], z.count > 1, z[0] == 1 { return max(0.3, z[1] * r.s) }
    if let n = proto(r.item) { let (mn, mx) = n.boundingBox; return max(0.3, max(mx.x - mn.x, mx.z - mn.z) * r.s) }
    return 1
  }
  func makeRow(shape: Int, byObject: Bool, length L: Float, spacing sp0: Float, radius R0: Float) {
    guard let id = selId, let base = recOf(id), L > 0.1 else { return }
    let sp = max(sp0, 0.2), cnt = min(Int(L / sp + 0.001), 300); guard cnt > 0 else { return }
    let start = SIMD2<Float>(base.x, base.z)
    let d: SIMD2<Float> = byObject ? SIMD2<Float>(cos(base.yaw), -sin(base.yaw)) : SIMD2<Float>(-sin(yaw), -cos(yaw))
    let R = max(R0, 1), left = shape == 1
    let nrm = left ? SIMD2<Float>(d.y, -d.x) : SIMD2<Float>(-d.y, d.x), c = start + nrm * R, v0 = start - c
    let len = isLenModel(base.item); var made = [Rec]()
    for k in 1...cnt {
      let dist = sp * Float(k); var pos = start + d * dist, t = d
      if shape > 0 { let th = (left ? -1 : 1) * dist / R, co = cos(th), si = sin(th)
        pos = c + SIMD2<Float>(v0.x * co - v0.y * si, v0.x * si + v0.y * co); t = SIMD2<Float>(d.x * co - d.y * si, d.x * si + d.y * co) }
      let yw = len ? atan2(-t.y, t.x) : base.yaw + rng.f(-0.5, 0.5), sc = len ? base.s : base.s * rng.f(0.92, 1.08)
      let r = Rec(id: UUID().uuidString, item: base.item, x: pos.x, z: pos.y, yaw: yw, s: sc); recs.append(r); spawn(r); made.append(r) }
    save(); let all = made
    commit("Tạo hàng \(all.count) \(itemName(base.item))", undo: { [weak self] in all.forEach { self?.delRec($0.id) } }, redo: { [weak self] in all.forEach { self?.addRec($0) } })
  }
  // ===== Chọn đường / mương → nối thêm đoạn thẳng hoặc cong theo số mét, tự nối liền =====
  @Published var selRoad: String? = nil
  @Published var roadRev = 0
  var roadMarks: SCNNode?
  func selectRoad(_ id: String?) {
    roadMarks?.removeFromParentNode(); roadMarks = nil
    if selRoad != id { selRoad = id }
    guard let id = id, let r = roads.first(where: { $0.id == id }), r.pts.count > 1 else { return }
    let m = SCNNode()
    for (p, c) in [(r.pts[0], UIColor.green), (r.pts[r.pts.count - 1], UIColor.red)] {
      let sp = SCNSphere(radius: 0.5); sp.firstMaterial?.diffuse.contents = c; sp.firstMaterial?.emission.contents = c
      let n = SCNNode(geometry: sp); n.position = SCNVector3(p[0], 0.7, p[1]); m.addChildNode(n) }
    scene.rootNode.addChildNode(m); roadMarks = m
  }
  var selRoadTitle: String {
    _ = roadRev; guard let id = selRoad, let r = roads.first(where: { $0.id == id }) else { return "" }
    return "\(kinds[r.kind]) • dài \(Int(length(r.pts))) m"
  }
  func rebuildRoad(_ id: String) {
    scene.rootNode.childNode(withName: "road:" + id, recursively: false)?.removeFromParentNode()
    if let r = roads.first(where: { $0.id == id }) { scene.rootNode.addChildNode(roadNode(r)) }
    roadRev += 1; save()
  }
  // shape: 0 thẳng, 1 cong trái, 2 cong phải
  func extendRoad(atStart: Bool, shape: Int, length L: Float, radius R0: Float) {
    guard let id = selRoad, let i = roads.firstIndex(where: { $0.id == id }), L > 0.2 else { return }
    let old = roads[i].pts; var pts = old; if atStart { pts.reverse() }
    let e = SIMD2<Float>(pts[pts.count - 1][0], pts[pts.count - 1][1])
    var d = SIMD2<Float>(0, -1)
    for k in stride(from: pts.count - 2, through: 0, by: -1) { let v = e - SIMD2<Float>(pts[k][0], pts[k][1]); if simd_length(v) > 0.05 { d = simd_normalize(v); break } }
    if shape == 0 { let q = e + d * L; pts.append([q.x, q.y]) }
    else {
      let R = max(R0, 1), phi = min(L / R, 2 * Float.pi), n = max(3, Int((L / 1.2).rounded(.up)))
      let left = shape == 1; let nrm = left ? SIMD2<Float>(d.y, -d.x) : SIMD2<Float>(-d.y, d.x)
      let c = e + nrm * R, v0 = e - c
      for k in 1...n { let th = (left ? -1 : 1) * phi * Float(k) / Float(n), co = cos(th), si = sin(th)
        let q = c + SIMD2<Float>(v0.x * co - v0.y * si, v0.x * si + v0.y * co); pts.append([q.x, q.y]) } }
    if atStart { pts.reverse() }
    let newPts = pts
    commit("Nối đường", toast: false, undo: { [weak self] in self?.setRoadPts(id, old) }, redo: { [weak self] in self?.setRoadPts(id, newPts) })
    roads[i].pts = pts; rebuildRoad(id); selectRoad(id)
  }
  func deleteSelRoad() { if let id = selRoad { deleteRoad(id) } }
  func setRoadPts(_ id: String, _ pts: [[Float]]) {
    guard let i = roads.firstIndex(where: { $0.id == id }) else { return }
    roads[i].pts = pts; rebuildRoad(id); if selRoad == id { selectRoad(id) }
  }
  func addRoad(_ r: RoadRec, at i: Int) {
    guard !roads.contains(where: { $0.id == r.id }) else { return }
    roads.insert(r, at: min(max(i, 0), roads.count)); scene.rootNode.addChildNode(roadNode(r)); roadRev += 1; save()
  }
  func delRoad(_ id: String) {
    if let n = scene.rootNode.childNode(withName: "road:" + id, recursively: false) { removeRoad(n, id) }
    else if let i = roads.firstIndex(where: { $0.id == id }) { roads.remove(at: i); save() }
    roadRev += 1
  }
  func deleteRoad(_ id: String) {
    guard let i = roads.firstIndex(where: { $0.id == id }) else { return }
    let r = roads[i]; delRoad(id)
    commit("Xóa " + kinds[r.kind].lowercased(), undo: { [weak self] in self?.addRoad(r, at: i) }, redo: { [weak self] in self?.delRoad(r.id) })
  }

  // ===== Hoàn tác ↩ / Làm lại ↪ (quay lại – tới lui): mọi thao tác đặt, xóa, kéo, xoay, phóng to, vẽ/nối/xóa đường, tạo hàng =====
  struct Act { var name: String; var key: String?; var time: TimeInterval; var undo: () -> Void; var redo: () -> Void }
  var undoStack: [Act] = []; var redoStack: [Act] = []
  @Published var undoCount = 0; @Published var redoCount = 0
  @Published var toast: String? = nil
  var toastTok = 0
  func syncUndo() { undoCount = undoStack.count; redoCount = redoStack.count }
  func showToast(_ t: String) {
    toast = t; toastTok += 1; let k = toastTok
    DispatchQueue.main.asyncAfter(deadline: .now() + 4) { [weak self] in if let s = self, s.toastTok == k { s.toast = nil } }
  }
  // key != nil: các thao tác liên tiếp cùng khóa trong 1,2 giây (chụm ngón, bấm ➕ nhiều lần) gộp thành một bước
  func commit(_ name: String, key: String? = nil, toast show: Bool = true, undo: @escaping () -> Void, redo: @escaping () -> Void) {
    let now = Date.timeIntervalSinceReferenceDate
    if let k = key, let l = undoStack.last, l.key == k, redoStack.isEmpty, now - l.time < 1.2 {
      undoStack[undoStack.count - 1] = Act(name: name, key: k, time: now, undo: l.undo, redo: redo)
    } else {
      undoStack.append(Act(name: name, key: key, time: now, undo: undo, redo: redo)); SoundFX.shared.cue(forAction: name)
      if undoStack.count > 100 { undoStack.removeFirst() }
      if show && key == nil { showToast(name) } }
    redoStack.removeAll(); syncUndo()
  }
  func undoLast() {
    guard let a = undoStack.popLast() else { return }
    a.undo(); redoStack.append(a); syncUndo(); SoundFX.shared.cue(.undo); showToast("Đã hoàn tác: " + a.name)
  }
  func redoLast() {
    guard let a = redoStack.popLast() else { return }
    a.redo(); undoStack.append(a); syncUndo(); SoundFX.shared.cue(.redo); showToast("Đã làm lại: " + a.name)
  }
  func nodeOf(_ id: String) -> SCNNode? { scene.rootNode.childNode(withName: "placed:" + id, recursively: false) }
  func itemName(_ item: String) -> String { item == "grass" ? "cỏ" : ModelLib.isImp(item) ? ModelLib.display(item) : item }
  func addRec(_ r: Rec) {   // dựng lại / thêm một vật (kể cả vật dựng sẵn seedN đã xóa)
    guard nodeOf(r.id) == nil else { return }
    if ModelLib.isImp(r.item), proto(r.item) == nil { return }   // mô hình nhập đã bị xóa khỏi thư viện
    if r.id.hasPrefix("seed") { seedGone.remove(r.id); seedEdits[r.id] = r; if !seedRecs.contains(where: { $0.id == r.id }) { seedRecs.append(r) } }
    else if !recs.contains(where: { $0.id == r.id }) { recs.append(r) }
    spawn(r); save()
  }
  func delRec(_ id: String) { if let n = nodeOf(id) { remove(n, id) } }
  func applyRec(_ r: Rec) {
    setRec(r)
    if let n = nodeOf(r.id) { n.position = SCNVector3(r.x, 0, r.z); n.eulerAngles.y = r.yaw; n.scale = SCNVector3(r.s, r.s, r.s) }
    save()
  }
  func recEdit(_ name: String, _ key: String?, _ before: Rec, _ after: Rec) {
    commit(name + " " + itemName(after.item), key: key.map { $0 + after.id }, undo: { [weak self] in self?.applyRec(before) }, redo: { [weak self] in self?.applyRec(after) })
  }
  func placeRec(_ r: Rec) {
    addRec(r)
    commit("Đặt " + itemName(r.item), toast: false, undo: { [weak self] in self?.delRec(r.id) }, redo: { [weak self] in self?.addRec(r) })
  }
  func deletePlaced(_ id: String) {
    guard let r = recOf(id), nodeOf(id) != nil else { return }
    delRec(id)
    commit("Xóa " + itemName(r.item), undo: { [weak self] in self?.addRec(r) }, redo: { [weak self] in self?.delRec(r.id) })
  }
  func deleteSelected() { if let id = selId { deletePlaced(id) } }
  func moveSelected(_ x: Float, _ z: Float) {
    guard let id = selId, var r = recOf(id), nodeOf(id) != nil else { return }
    let before = r; r.x = min(max(x, -14), 100); r.z = min(z, 38)
    if hypot(before.x - r.x, before.z - r.z) < 0.02 { return }
    applyRec(r); recEdit("Di chuyển", nil, before, r)
  }
  func toggleMove() { moving.toggle(); if moving { showToast("Chạm vào vị trí muốn chuyển tới") } }
  func duplicateSelected() {
    guard let id = selId, let r = recOf(id) else { return }
    var n = r; n.id = UUID().uuidString; n.x = min(r.x + max(defaultSpacing(), 0.8), 60)
    placeRec(n); select(nodeOf(n.id), n.id)
  }
  // chọn / phóng to / thu nhỏ
  @Published var selId: String? = nil
  var ring: SCNNode?
  func select(_ n: SCNNode?, _ id: String?) {
    ring?.removeFromParentNode(); ring = nil; selId = id; moving = false
    guard let n = n else { rowPanel = false; return }
    SoundFX.shared.cue(.select)
    selectRoad(nil)
    let r = footRadius(n) * 0.9 + 0.2
    let t = SCNTorus(ringRadius: CGFloat(r), pipeRadius: CGFloat(max(r * 0.03, 0.03)))
    t.firstMaterial?.diffuse.contents = UIColor.yellow; t.firstMaterial?.emission.contents = UIColor.yellow
    let rn = SCNNode(geometry: t); rn.position.y = 0.05; ring = rn; n.addChildNode(rn)
    let disc = SCNCylinder(radius: CGFloat(r), height: 0.02); disc.firstMaterial?.diffuse.contents = UIColor(red: 1, green: 0.9, blue: 0.1, alpha: 0.28); disc.firstMaterial?.emission.contents = UIColor(red: 1, green: 0.85, blue: 0, alpha: 0.45); disc.firstMaterial?.isDoubleSided = true
    rn.addChildNode(SCNNode(geometry: disc))
    rn.runAction(.repeatForever(.sequence([.scale(to: 1.08, duration: 0.5), .scale(to: 0.96, duration: 0.5)])))
  }
  func resize(_ f: Float) {
    guard let id = selId, var r = recOf(id), let n = nodeOf(id) else { return }
    let before = r; r.s = min(max(r.s * f, 0.2), 8); if abs(r.s - before.s) < 0.0001 { return }
    setRec(r); n.scale = SCNVector3(r.s, r.s, r.s); save(); recEdit("Phóng to / thu nhỏ", "sz:", before, r)
  }
  func rotate(_ a: Float) {
    guard let id = selId, var r = recOf(id), let n = nodeOf(id) else { return }
    let before = r; r.yaw += a; setRec(r); n.eulerAngles.y = r.yaw; save(); recEdit("Xoay", "rt:", before, r)
  }
  // di chuyển kiểu game
  var move = CGVector.zero; var yaw: Float = 0; var pitch: Float = 0
  @Published var run = false
  // nhân vật đi lại + toàn màn hình
  var avatar: SCNNode?; var avLegs: [SCNNode] = []; var avArms: [SCNNode] = []
  // nhân vật có xương nhập vào (RiggedAvatar) — xem CharacterRig.swift / Avatar.swift
  var walkAv: WalkAvatar?; var walkAvSource: String? = nil; var walkNoteTok = 0
  @Published var walkCharacter: String? = UserDefaults.standard.string(forKey: "vb.walkChar")
  @Published var charSheet = false
  @Published var walkNote = ""
  @Published var walkActions: [String] = []
  // đi dạo: va chạm / bậc / leo / camera bay cao / NPC — xem WalkWorld.swift
  var solids: [WSolid] = []; var solidT: Float = 9; var avYT: Float = 0
  var wClimb: WClimb? = nil; var wPush: Float = 0; var wSeat: (pos: SIMD2<Float>, h: Float)? = nil
  var walkDist: Float = 3.6
  @Published var flyMode = false
  var npcs: [NPCEntry] = []; var npcTime: Float = 0; var npcsLoaded = false
  var avPos = SIMD2<Float>(0, 8); var avYaw: Float = 0; var avY: Float = 0; var walkPhase: Float = 0; var lastStepK = 0; var walkAmp: Float = 0; var camY: Float = 1.6
  @Published var walkMode = false { didSet { if walkMode != oldValue { setWalk(walkMode) } } }
  @Published var fullscreen = false { didSet { refreshSketchCam(); if fullscreen != oldValue { fullscreenChanged() } } }
  var walkBeforeFull = false
  @Published var hideUI = false { didSet { refreshSketchCam(); move = .zero } }   // ẩn mọi menu / nút để xem trọn màn hình (chỉ còn nút 👁 mờ và cần điều khiển)
  /// Chụm / mở 2 ngón ở màn hình chính: đổi góc nhìn (zoom ống kính), 25°–85°, mặc định 70°.
  func zoomView(_ scale: Float) {
    guard let c = cam.camera, scale > 0 else { return }
    c.fieldOfView = min(max(c.fieldOfView / CGFloat(scale), 25), 85)
  }
  /// Toàn màn hình = chế độ đi dạo không nút (Immersive.swift); thoát thì trả lại trạng thái cũ.
  func fullscreenChanged() {
    move = .zero; run = false
    if fullscreen {
      walkBeforeFull = walkMode; if !walkMode { walkMode = true }
      note("Cần ở góc trái dưới để đi · vuốt màn hình để nhìn quanh · chụm / mở 2 ngón để thu / phóng · nút ⋯ góc trên phải")
    } else if walkMode != walkBeforeFull { walkMode = walkBeforeFull }
  }
  // bảng vẽ nét 2D (khung dưới) + camera nhìn từ trên (khung trên) — xem Sketch.swift
  @Published var sketchOpen = false { didSet { refreshSketchCam() } }
  var sketchCam = false; var aerialC = SIMD2<Float>(0, 0); var aerialH: Float = 30
  var savedCam: (SCNVector3, Float, Float)? = nil
  lazy var sk: SketchModel = { let s = SketchModel(); s.g = self; return s }()
  func step(_ dt: Float) {
    cullStep(dt)
    moundT += dt; if moundT > 1.5 { moundT = 0; refreshMounds() }
    SoundFX.shared.setStream(max(0, min(1, 1 - (cam.position.x + 8) / 26)))   // gần sông thì nghe nước chảy
    if let w = weatherSys { let p = cam.position; w.cameraMoved(focus: SIMD3<Float>(p.x, 0, p.z), ref: walkMode ? max(walkDist, p.y) : p.y) }   // mưa / tuyết / sương bám theo người xem
    if !npcs.isEmpty { stepNPCs(dt) }
    if sketchCam {
      if move.dx != 0 || move.dy != 0 {
        let sp = aerialH * 0.7 * dt; aerialC.x += Float(move.dx) * sp; aerialC.y -= Float(move.dy) * sp; clampAerial()
        DispatchQueue.main.async { [weak self] in self?.syncFromAerial() } }
      applyAerial(); return }
    let sp: Float = (run ? 9 : 4) * dt, f = Float(move.dy), r = Float(move.dx)
    let dxw = -sin(yaw) * f + cos(yaw) * r, dzw = -cos(yaw) * f - sin(yaw) * r
    if walkMode { stepAvatar(dt, dxw, dzw, hypot(f, r), sp); return }
    var x = cam.position.x + dxw * sp
    var z = cam.position.z + dzw * sp
    x = min(max(x, -14), 60); z = min(z, 8); if z < -200 { z = -200 }
    camY += (groundY(x, z) + 1.6 - camY) * min(1, dt * 10)
    cam.position = SCNVector3(x, camY, z); cam.eulerAngles = SCNVector3(pitch, yaw, 0)
  }
  func look(_ dx: Float, _ dy: Float) { yaw -= dx * 0.005; pitch = min(max(pitch - dy * 0.005, -1.2), 1.2) }
  func home() { cam.camera?.fieldOfView = 70; cam.position = SCNVector3(0, 1.6, 8); camY = 1.6; yaw = 0; pitch = 0; avPos = SIMD2<Float>(0, 8); avY = 0 }

  func tap(_ v: SCNView, _ p: CGPoint) {
    if fullscreen || hideUI || sketchVisible || walkMode { return }
    let hits = v.hitTest(p, options: [SCNHitTestOption.searchMode: SCNHitTestSearchMode.all.rawValue])
    if mode != 0 {
      if moving, selId != nil, let h = hits.first, h.node.name == "land" { moveSelected(h.worldCoordinates.x, h.worldCoordinates.z); moving = false; return }
      switch pickAt(v, p, near: true) {
      case .obj(let c, let id)?: select(c, id); return
      case .road(let id)?: select(nil, nil); selectRoad(id); return
      default: break }
      select(nil, nil); selectRoad(nil); return }
    guard let g = hits.first(where: { $0.node.name == "land" }) else { return }
    let c = g.worldCoordinates; if cat == "Vẽ đường" { if !freeDraw { addPoint(c.x, c.z) }; return }; let item = cat == "Cỏ" ? "grass" : sel
    if cat == ModelLib.category && !ModelLib.isImp(sel) { showToast("Bấm ＋ để nhập mô hình 3D"); return }
    let r = Rec(id: UUID().uuidString, item: item, x: c.x, z: c.z, yaw: Float.random(in: 0...6.28), s: Float.random(in: 0.9...1.15))
    placeRec(r)
  }
  func remove(_ n: SCNNode, _ id: String) {
    dropRec(id)
    if selId == id { select(nil, nil) }
    n.removeFromParentNode(); save()
  }
  func save() { if importLock { return }; saveRoads(); if let d = try? JSONEncoder().encode(seedEdits) { UserDefaults.standard.set(d, forKey: "seedEdits") }; UserDefaults.standard.set(Array(seedGone), forKey: "seedGone"); if let d = try? JSONEncoder().encode(recs) { UserDefaults.standard.set(d, forKey: "recs") } }
}
