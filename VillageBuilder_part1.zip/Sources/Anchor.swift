import SceneKit
import UIKit
import simd

// ===== Tâm đặt vật =====
// Gốc (0,0,0) của mọi mô hình phải nằm DƯỚI CHÂN mô hình: y = 0 là mặt đất, x / z là giữa phần chân.
// Trước đây gốc x / z lấy giữa khung bao cả mô hình, nên cây có tán lệch (đào, liễu, dừa nghiêng…) bị đặt lệch khỏi gốc thân
// (vòng chọn, xoay, phóng to đều quay quanh điểm sai). Nay lấy giữa khung bao của lớp đỉnh thấp nhất (3% chiều cao).
extension Game {
    /// Tâm chân (x, z) của mô hình trong hệ tọa độ của `root` (nil nếu không đọc được đỉnh).
    func baseCenter(_ root: SCNNode) -> (x: Float, z: Float)? {
        func f32(_ raw: UnsafeRawBufferPointer, _ o: Int) -> Float {
            var v: Float = 0
            withUnsafeMutableBytes(of: &v) { $0.copyMemory(from: UnsafeRawBufferPointer(rebasing: raw[o..<(o + 4)])) }
            return v
        }
        var pts: [SIMD3<Float>] = []
        let inv = root.simdWorldTransform.inverse
        root.enumerateHierarchy { n, _ in
            guard let g = n.geometry, let src = g.sources(for: .vertex).first,
                  src.usesFloatComponents, src.bytesPerComponent == 4, src.componentsPerVector >= 3 else { return }
            let T = inv * n.simdWorldTransform
            let step = max(1, src.vectorCount / 60000)
            src.data.withUnsafeBytes { (raw: UnsafeRawBufferPointer) in
                var i = 0
                while i < src.vectorCount {
                    let o = src.dataOffset + i * src.dataStride
                    if o + 12 <= raw.count {
                        let q = T * SIMD4<Float>(f32(raw, o), f32(raw, o + 4), f32(raw, o + 8), 1)
                        if q.x.isFinite && q.y.isFinite && q.z.isFinite { pts.append(SIMD3<Float>(q.x, q.y, q.z)) }
                    }
                    i += step
                }
            }
        }
        guard pts.count >= 3, let lo = pts.map({ $0.y }).min(), let hi = pts.map({ $0.y }).max() else { return nil }
        let cut = lo + max((hi - lo) * 0.03, 0.02)
        var mnx = Float.greatestFiniteMagnitude, mxx = -Float.greatestFiniteMagnitude
        var mnz = Float.greatestFiniteMagnitude, mxz = -Float.greatestFiniteMagnitude
        var cnt = 0
        for p in pts where p.y <= cut { mnx = min(mnx, p.x); mxx = max(mxx, p.x); mnz = min(mnz, p.z); mxz = max(mxz, p.z); cnt += 1 }
        guard cnt > 0 else { return nil }
        return ((mnx + mxx) / 2, (mnz + mxz) / 2)
    }

    /// Bán kính vòng chọn: theo cỡ mô hình nhưng tính từ gốc (chân), không phải từ giữa khung bao.
    func footRadius(_ n: SCNNode) -> Float {
        let (mn, mx) = n.boundingBox
        let half = max(mx.x - mn.x, mx.z - mn.z) / 2
        let reach = max(max(abs(mn.x), abs(mx.x)), max(abs(mn.z), abs(mx.z)))
        return max(half, 0.6 * reach)
    }
}
