import SceneKit
import ModelIO
import SceneKit.ModelIO
import UIKit
import ZIPFoundation

/// Kho nhân vật nhập vào (Documents/Characters) + đọc mô hình. Mỗi mục là một file lẻ hoặc một thư mục.
/// Tên mục (lastPathComponent) dùng làm mã nhân vật.
enum CharFiles {
    static let modelExtensions = ["usdz", "usd", "usda", "usdc", "scn", "dae", "obj", "glb", "gltf", "vrm"]
    /// Người mẫu có sẵn trong game (mannequinMale): dùng để gắn xương thử.
    static let builtinName = "Người mẫu có sẵn"
    /// Game gán: trả về bản sao mô hình người mẫu (đã đúng cỡ).
    static var builtinProvider: (() -> SCNNode?)? = nil
    static var lastError: String? = nil

    static var directory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("Characters", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static func display(_ name: String) -> String {
        name == builtinName ? name : (name as NSString).deletingPathExtension
    }

    /// Danh sách nhân vật đã nhập (không gồm người mẫu có sẵn).
    static func list() -> [String] {
        let items = (try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)) ?? []
        return items.map { $0.lastPathComponent }.filter { !$0.hasPrefix(".") }
            .sorted { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }
    }

    static func findMainModel(in dir: URL) -> URL? {
        guard let en = FileManager.default.enumerator(at: dir, includingPropertiesForKeys: nil) else { return nil }
        var best: (rank: Int, url: URL)? = nil
        for case let u as URL in en {
            if u.path.contains("__MACOSX") || u.lastPathComponent.hasPrefix(".") { continue }
            guard let r = modelExtensions.firstIndex(of: u.pathExtension.lowercased()) else { continue }
            if best == nil || r < best!.rank { best = (r, u) }
        }
        return best?.url
    }

    static func mainModelURL(for name: String) -> URL? {
        let url = directory.appendingPathComponent(name)
        var isDir: ObjCBool = false
        guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir) else { return nil }
        return isDir.boolValue ? findMainModel(in: url) : url
    }

    /// Đọc mô hình: glTF bằng GLTFLoader, còn lại thử SceneKit rồi ModelIO (OBJ).
    static func loadScene(at url: URL) -> SCNScene? {
        lastError = nil
        let ext = url.pathExtension.lowercased()
        if GLTFLoader.handles(ext) {
            do { return try GLTFLoader.load(at: url).scene }
            catch { lastError = error.localizedDescription; return nil }
        }
        if ext == "obj", let s = loadViaModelIO(at: url) { return s }
        if let s = try? SCNScene(url: url, options: nil), !s.rootNode.childNodes.isEmpty { return s }
        if MDLAsset.canImportFileExtension(ext) { return loadViaModelIO(at: url) }
        return nil
    }

    static func loadViaModelIO(at url: URL) -> SCNScene? {
        guard MDLAsset.canImportFileExtension(url.pathExtension.lowercased()) else { return nil }
        let asset = MDLAsset(url: url)
        let meshes = (asset.childObjects(of: MDLMesh.self) as? [MDLMesh]) ?? []
        for mesh in meshes where mesh.vertexAttributeData(forAttributeNamed: MDLVertexAttributeNormal) == nil {
            mesh.addNormals(withAttributeNamed: MDLVertexAttributeNormal, creaseThreshold: 0.5)
        }
        asset.loadTextures()
        let s = SCNScene(mdlAsset: asset)
        return s.rootNode.childNodes.isEmpty ? nil : s
    }

    static func remove(_ name: String) {
        try? FileManager.default.removeItem(at: directory.appendingPathComponent(name))
        RigStore.remove(name)
        UserDefaults.standard.removeObject(forKey: "walk.face." + name)
    }

    private static func unique(_ base: String, ext: String = "") -> String {
        let fm = FileManager.default
        var name = base + (ext.isEmpty ? "" : "." + ext)
        var n = 2
        while fm.fileExists(atPath: directory.appendingPathComponent(name).path) {
            name = "\(base) \(n)" + (ext.isEmpty ? "" : "." + ext); n += 1
        }
        return name
    }

    /// Nhập nhân vật: .zip (kèm ảnh), hoặc file lẻ .usdz/.glb/.dae/.obj… (kèm .mtl, ảnh, .bin nếu có).
    static func add(_ urls: [URL]) -> (added: [String], problems: [String]) {
        let fm = FileManager.default
        var added: [String] = [], problems: [String] = [], loose: [URL] = []
        for u in urls {
            let ext = u.pathExtension.lowercased()
            if ext == "zip" {
                let tmp = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
                do { try fm.createDirectory(at: tmp, withIntermediateDirectories: true); try fm.unzipItem(at: u, to: tmp) }
                catch { try? fm.removeItem(at: tmp); problems.append("\(u.lastPathComponent): không giải nén được"); continue }
                guard let main = findMainModel(in: tmp) else {
                    try? fm.removeItem(at: tmp); problems.append("\(u.lastPathComponent): không thấy mô hình (USDZ, GLB, DAE, OBJ…)"); continue }
                guard loadScene(at: main) != nil else {
                    try? fm.removeItem(at: tmp); problems.append("\(u.lastPathComponent): mô hình không đọc được"); continue }
                let name = unique(u.deletingPathExtension().lastPathComponent)
                do { try fm.moveItem(at: tmp, to: directory.appendingPathComponent(name, isDirectory: true)); added.append(name) }
                catch { try? fm.removeItem(at: tmp); problems.append("\(u.lastPathComponent): không lưu được") }
            } else if ext == "fbx" {
                problems.append("\(u.lastPathComponent): FBX chưa đọc trực tiếp, hãy chuyển sang GLB / USDZ / DAE")
            } else { loose.append(u) }
        }
        let models = loose.filter { modelExtensions.contains($0.pathExtension.lowercased()) }
        let support = loose.filter { !modelExtensions.contains($0.pathExtension.lowercased()) }
        if models.isEmpty && !loose.isEmpty { problems.append("Không thấy file mô hình trong những file đã chọn") }
        for m in models {
            let base = m.deletingPathExtension().lastPathComponent
            var created: URL, main: URL, name: String
            do {
                if support.isEmpty {
                    name = unique(base, ext: m.pathExtension.lowercased())
                    created = directory.appendingPathComponent(name)
                    try fm.copyItem(at: m, to: created); main = created
                } else {
                    name = unique(base)
                    created = directory.appendingPathComponent(name, isDirectory: true)
                    try fm.createDirectory(at: created, withIntermediateDirectories: true)
                    for f in [m] + support { try fm.copyItem(at: f, to: created.appendingPathComponent(f.lastPathComponent)) }
                    main = created.appendingPathComponent(m.lastPathComponent)
                }
            } catch { problems.append("\(m.lastPathComponent): không lưu được"); continue }
            if loadScene(at: main) == nil {
                try? fm.removeItem(at: created)
                problems.append("\(m.lastPathComponent): " + (lastError ?? "mô hình không đọc được"))
            } else { added.append(name) }
        }
        return (added, problems)
    }
}
