#import "ObjCTry.h"
BOOL VBTry(void (NS_NOESCAPE ^block)(void)) {
    @try { block(); return YES; }
    @catch (NSException *e) { NSLog(@"VBTry caught: %@ %@", e.name, e.reason); return NO; }
}
