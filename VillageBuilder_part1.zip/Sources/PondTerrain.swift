import SceneKit
import UIKit
import simd

// ===== Ao cá miền Tây: địa hình (đáy ao, bờ đất, bờ ao), mặt nước nhiều lớp =====
// Hệ tọa độ: tâm ao ở (0,0); mặt đất ngoài cùng y = 0; mặt nước y = 0.62; đáy y ~ 0.04 (sâu ~0.58 m); mặt bờ y ~ 1.1.
extension Game {
  static let pondId = "Ao cá miền Tây (chiều sâu)"
  static let pondWater: Float = 0.62
  static let pondTop: Float = 1.1

  // đường viền ao: siêu elip hơi méo (số hài là số nguyên nên khép kín)
  func pondR(_ th: Float) -> Float {
    let c = abs(cos(th)) / 5.6, s = abs(sin(th)) / 3.9
    let r = pow(pow(c, 3.2) + pow(s, 3.2), -1 / 3.2)
    return r * (1 + 0.03 * sin(3 * th + 1) + 0.025 * sin(5 * th + 2))
  }
  func pondP(_ th: Float) -> SIMD2<Float> { let r = pondR(th); return SIMD2<Float>(r * cos(th), r * sin(th)) }
  func pondN(_ th: Float) -> SIMD2<Float> {   // pháp tuyến hướng ra ngoài
    let e: Float = 0.01; let t = pondP(th + e) - pondP(th - e); let l = max(simd_length(t), 0.0001)
    return SIMD2<Float>(t.y, -t.x) / l
  }
  func pondS(_ x: Float, _ z: Float) -> Float { simd_length(SIMD2<Float>(x, z)) / pondR(atan2(z, x)) }   // 0 tâm, 1 mép nước
  func pondInside(_ x: Float, _ z: Float, _ margin: Float) -> Bool { let th = atan2(z, x); return simd_length(SIMD2<Float>(x, z)) < pondR(th) - margin }
  static let bedProf: [(Float, Float)] = [(0.02, 0.04), (0.3, 0.05), (0.55, 0.09), (0.75, 0.16), (0.87, 0.28), (0.95, 0.42), (1.0, 0.62)]
  func pondBedY(_ s: Float) -> Float {
    let p = Game.bedProf; if s <= p[0].0 { return p[0].1 }
    for i in 0..<(p.count - 1) where s <= p[i + 1].0 { let t = (s - p[i].0) / (p[i + 1].0 - p[i].0); return p[i].1 + (p[i + 1].1 - p[i].1) * t }
    return p[p.count - 1].1
  }
  // độ cao mặt bờ theo khoảng cách d tính từ mép nước ra ngoài
  static let bankProf: [(Float, Float)] = [(0, 0.62), (0.15, 0.78), (0.4, 0.98), (0.8, 1.1), (1.5, 1.12), (2.1, 1.04), (2.8, 0.55), (3.5, 0)]
  func pondBankY(_ d: Float) -> Float {
    let p = Game.bankProf; if d <= 0 { return p[0].1 }
    for i in 0..<(p.count - 1) where d <= p[i + 1].0 { let t = (d - p[i].0) / (p[i + 1].0 - p[i].0); return p[i].1 + (p[i + 1].1 - p[i].1) * t }
    return 0
  }
  // điểm trên mặt bờ cách mép nước d theo hướng th
  func pondBankPt(_ th: Float, _ d: Float) -> SIMD3<Float> {
    let p = pondP(th) + pondN(th) * d; return SIMD3<Float>(p.x, pondBankY(d), p.y)
  }

  func ringMesh(_ nr: Int, _ pos: (Float, Int) -> SIMD3<Float>, _ uv: (Float, Int, SIMD3<Float>) -> SIMD2<Float>) -> SCNGeometry {
    let N = 72; var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
    for k in 0...N {
      let th = Float(k % N) / Float(N) * 2 * Float.pi
      for j in 0..<nr { let p = pos(th, j); P.append(p); UV.append(uv(Float(k) / Float(N), j, p)) } }
    for k in 0..<N { for j in 0..<(nr - 1) { let a = Int32(k * nr + j), b = a + 1, c = a + Int32(nr), d = c + 1; I += [a, c, b, b, c, d] } }
    return meshGeo(P, UV, I)
  }

  func pondBedImg() -> UIImage {
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    return UIGraphicsImageRenderer(size: CGSize(width: 512, height: 256), format: Game.fmtTex).image { c in
      let g = c.cgContext
      if let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [C(0.03, 0.05, 0.04).cgColor, C(0.1, 0.13, 0.08).cgColor, C(0.3, 0.27, 0.15).cgColor, C(0.42, 0.34, 0.2).cgColor] as CFArray, locations: [0, 0.4, 0.8, 1]) {
        g.drawLinearGradient(gr, start: CGPoint(x: 0, y: 0), end: CGPoint(x: 512, y: 0), options: []) }
      var r = RNG(); r.s = 313
      for _ in 0..<2600 {
        let x = CGFloat(r.f(0, 512)), y = CGFloat(r.f(0, 256)), w = CGFloat(r.f(1, 9))
        let t = x / 512
        (r.f(0, 1) > 0.5 ? C(0.02, 0.04, 0.02) : C(0.45 + 0.2 * t, 0.4 + 0.15 * t, 0.25)).withAlphaComponent(CGFloat(r.f(0.08, 0.3))).setFill()
        UIBezierPath(ovalIn: CGRect(x: x, y: y, width: w, height: w * CGFloat(r.f(0.4, 1.2)))).fill() }
      C(0.08, 0.2, 0.06).withAlphaComponent(0.35).setStroke()   // rong rêu, lá mục
      for _ in 0..<60 { let x = CGFloat(r.f(0, 512)), y = CGFloat(r.f(0, 256)); g.setLineWidth(CGFloat(r.f(1, 3)))
        g.move(to: CGPoint(x: x, y: y)); g.addQuadCurve(to: CGPoint(x: x + CGFloat(r.f(-30, 30)), y: y + CGFloat(r.f(-12, 12))), control: CGPoint(x: x + 10, y: y + 6)); g.strokePath() } }
  }

  static let pondWaterFrag = """
  #pragma body
  float2 uv = _surface.diffuseTexcoord; float t = scn_frame.time;
  float s = uv.x; float a = uv.y * 6.2832;
  float3 deep = float3(0.04, 0.11, 0.08); float3 shallow = float3(0.2, 0.3, 0.16);
  float3 col = mix(deep, shallow, smoothstep(0.15, 1.0, s));
  float r = sin(a * 9.0 + s * 14.0 + t * 1.1) * sin(a * 5.0 - s * 9.0 - t * 0.8) + 0.5 * sin(a * 14.0 + s * 30.0 + t * 1.9) + 0.3 * sin(a * 23.0 - s * 21.0 + t * 2.4);
  float3 n = normalize(_surface.normal + float3(r * 0.05, r * 0.05, 0.0));
  _surface.normal = n;
  float fr = pow(1.0 - clamp(dot(n, normalize(_surface.view)), 0.0, 1.0), 3.0);
  col += float3(0.45, 0.58, 0.68) * fr * 0.7;
  col += r * 0.02;
  float rim = smoothstep(0.8, 1.0, s);
  col += rim * 0.05 * (0.5 + 0.5 * sin(a * 70.0 + s * 90.0 - t * 2.2));
  _surface.diffuse.rgb = col;
  """

  func pondTerrain(_ solid: SCNNode, _ root: SCNNode, _ rr: inout RNG) {
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    let bp = Game.bedProf
    // đáy ao: bùn sẫm ở giữa, sáng dần ra ven (sâu cảm nhận được qua nước trong mờ)
    let bedM = mat(pondBedImg(), 1, 6); bedM.isDoubleSided = true
    let bed = ringMesh(bp.count, { th, j in let p = self.pondP(th) * bp[j].0; return SIMD3<Float>(p.x, bp[j].1, p.y) }, { u, j, _ in SIMD2<Float>(bp[j].0, u) })
    bed.firstMaterial = bedM; solid.addChildNode(SCNNode(geometry: bed))
    // bờ: sườn bùn ướt (0 → 0.8 m) rồi mặt bờ cỏ, sườn ngoài thoải xuống đất
    let slopeM = mat(makeTex(C(0.3, 0.24, 0.15), [C(0.18, 0.14, 0.09), C(0.46, 0.38, 0.25), C(0.28, 0.4, 0.14)], 3200, 9, cracks: 16, crackColor: C(0.09, 0.07, 0.04), seed: 71), 3, 1); slopeM.isDoubleSided = true
    let topM = mat(makeTex(C(0.33, 0.48, 0.17), [C(0.24, 0.4, 0.12), C(0.5, 0.64, 0.26), C(0.42, 0.32, 0.18), C(0.3, 0.3, 0.15)], 3200, 10, seed: 72), 3, 1); topM.isDoubleSided = true
    let dS: [Float] = [0, 0.08, 0.15, 0.28, 0.4, 0.6, 0.8], dT: [Float] = [0.8, 1.1, 1.5, 1.8, 2.1, 2.5, 2.8, 3.15, 3.5]
    let sg = ringMesh(dS.count, { th, j in self.pondBankPt(th, dS[j]) }, { _, _, p in SIMD2<Float>(p.x / 3, p.z / 3) })
    sg.firstMaterial = slopeM; solid.addChildNode(SCNNode(geometry: sg))
    let tg = ringMesh(dT.count, { th, j in self.pondBankPt(th, dT[j]) }, { _, _, p in SIMD2<Float>(p.x / 3, p.z / 3) })
    tg.firstMaterial = topM; solid.addChildNode(SCNNode(geometry: tg))
    // mặt nước: trong mờ, đậm ở giữa, nhạt ven, gợn sóng + phản chiếu trời
    let ws: [Float] = [0.02, 0.25, 0.5, 0.7, 0.85, 0.95, 1.015]
    let wg = ringMesh(ws.count, { th, j in let p = self.pondP(th) * ws[j]; return SIMD3<Float>(p.x, Game.pondWater, p.y) }, { u, j, _ in SIMD2<Float>(ws[j], u) })
    let wm = SCNMaterial(); wm.lightingModel = .blinn; wm.diffuse.contents = C(0.1, 0.2, 0.12); wm.specular.contents = UIColor.white; wm.shininess = 0.95
    wm.isDoubleSided = true; wm.transparency = 0.62; wm.shaderModifiers = [.fragment: Game.pondWaterFrag]
    wg.firstMaterial = wm; let wn = SCNNode(geometry: wg); wn.renderingOrder = 10; root.addChildNode(wn)
    // đường mòn đất trên bờ (phía trước và bên trái)
    let dirtM = roadMat(makeTex(C(0.5, 0.38, 0.24), [C(0.38, 0.28, 0.17), C(0.62, 0.5, 0.34)], 1500, 5, cracks: 4, crackColor: C(0.2, 0.14, 0.08), seed: 61))
    var path = [SIMD2<Float>]()
    for k in 0...30 { let th = 0.35 + Float(k) / 30 * 3.3; let q = pondBankPt(th, 1.15); path.append(SIMD2<Float>(q.x, q.z)) }
    if let pn = ribbon(path, 0.8, 1.115, dirtM) { solid.addChildNode(pn) }
  }
}
