import SceneKit
import simd

// ===== Đi dạo trong thế giới: va chạm vách, bước lên bậc / sàn / mái, tự leo, ngồi lên công trình,
// camera bay cao, và NPC (chuyển từ CityBuilder, viết lại cho vật đặt của Làng Quê) =====

/// Vật đặt trong cảnh có thể cản đường / đứng lên.
struct WSolid {
  var node: SCNNode
  var cx: Float; var cz: Float
  var radius: Float      // bán kính bao quanh trên mặt bằng
  var top: Float         // độ cao đỉnh (thế giới)
  var low: Bool          // cây, bụi: chỉ cản ở ngang gối, không đứng lên được
}
struct WClimb { var from: SIMD3<Float>; var to: SIMD3<Float>; var t: Float; var dur: Float }

final class NPCEntry {
  let id: String; let char: String; let behavior: Int
  var x: Float; var z: Float
  let holder = SCNNode(); let avatar: RiggedAvatar; let driver: NPCDriver
  init(id: String, char: String, behavior: Int, x: Float, z: Float, avatar: RiggedAvatar) {
    self.id = id; self.char = char; self.behavior = behavior; self.x = x; self.z = z; self.avatar = avatar
    driver = NPCDriver(avatar: avatar, behavior: behavior, seed: UInt64(abs(id.hashValue % 100000)) + 7)
    holder.name = "npc:" + id; holder.addChildNode(avatar.root) }
}
struct NPCSave: Codable { var id: String; var char: String; var behavior: Int; var x: Float; var z: Float }

extension Game {
  static let stepUp: Float = 0.55        // bước lên được bậc cao tới đây
  static let climbReach: Float = 3.3     // với tay leo được tới đây so với chỗ đang đứng
  static let rayOpts: [String: Any] = [SCNHitTestOption.searchMode.rawValue: SCNHitTestSearchMode.all.rawValue]
  static let npcNames = ["", "Đi lang thang", "Múa", "Nhảy", "Làm việc", "Vẫy tay"]

  // ---------- danh sách vật cản ----------
  func buildSolids() {
    var out: [WSolid] = []
    let skipCats: Set<String> = ["Cỏ", "Hoa & cây cảnh", "Động vật", "Nhân vật", "Vẽ đường", "Mẫu có sẵn"]
    for n in scene.rootNode.childNodes {
      guard let nm = n.name, nm.hasPrefix("placed:") else { continue }
      let id = String(nm.dropFirst(7)); guard let r = recOf(id) else { continue }
      if r.item == Game.pondId || r.item == "grass" || id.hasPrefix("seedGn") || id.hasPrefix("seedRn") || id.hasPrefix("seedS0") { continue }
      let cat = catOf[r.item] ?? ""; if skipCats.contains(cat) { continue }
      let (mn, mx) = n.boundingBox
      var lo = SIMD3<Float>(repeating: .greatestFiniteMagnitude), hi = SIMD3<Float>(repeating: -.greatestFiniteMagnitude)
      for cx in [mn.x, mx.x] { for cy in [mn.y, mx.y] { for cz in [mn.z, mx.z] {
        let w = n.convertPosition(SCNVector3(cx, cy, cz), to: nil)
        lo = simd_min(lo, SIMD3<Float>(w.x, w.y, w.z)); hi = simd_max(hi, SIMD3<Float>(w.x, w.y, w.z)) } } }
      guard lo.x.isFinite, hi.y - lo.y > 0.12 else { continue }
      out.append(WSolid(node: n, cx: (lo.x + hi.x) / 2, cz: (lo.z + hi.z) / 2, radius: hypot(hi.x - lo.x, hi.z - lo.z) / 2, top: hi.y, low: cat == "Cây cối"))
    }
    solids = out
  }
  func nearSolid(_ s: WSolid, _ p: SIMD2<Float>, margin: Float = 1.5) -> Bool { simd_length(p - SIMD2<Float>(s.cx, s.cz)) < s.radius + margin }

  func rayHits(_ s: WSolid, from a: SIMD3<Float>, to b: SIMD3<Float>) -> [SCNHitTestResult] {
    let la = s.node.convertPosition(SCNVector3(a.x, a.y, a.z), from: nil)
    let lb = s.node.convertPosition(SCNVector3(b.x, b.y, b.z), from: nil)
    return s.node.hitTestWithSegment(from: la, to: lb, options: Game.rayOpts)
  }

  /// Độ cao mặt đứng được tại p: bắn tia từ ngang đầu gối xuống, lấy mặt nằm ngang / dốc thoải cao nhất (sàn, bậc, nền, mái).
  func supportHeight(at p: SIMD2<Float>, ref: Float) -> Float {
    var best: Float = 0
    let startY = ref + Game.stepUp
    let offs: [SIMD2<Float>] = [SIMD2<Float>(0, 0), SIMD2<Float>(0.18, 0), SIMD2<Float>(-0.18, 0), SIMD2<Float>(0, 0.18), SIMD2<Float>(0, -0.18)]
    for s in solids where !s.low && nearSolid(s, p) {
      for o in offs {
        let q = p + o
        let hs = rayHits(s, from: SIMD3<Float>(q.x, startY, q.y), to: SIMD3<Float>(q.x, -0.3, q.y))
        // bỏ mặt quá xa dưới tầm (đang đứng trên mái thì không rơi xuống mặt thấp hơn do tia bắt đầu từ ref + bước chân)
        if let h = hs.first(where: { $0.worldNormal.y > 0.55 }) { best = max(best, h.worldCoordinates.y) }
      }
    }
    return best
  }

  /// Đi từ p tới q qua các vách: bắn tia ngang ở hai độ cao (cao hơn bậc, ngang ngực) và ba vị trí bề ngang.
  /// Chạm vách thì dừng cách vách một bán kính rồi trượt dọc tường.
  func sweepWalls(from p: SIMD2<Float>, to q: SIMD2<Float>, elev: Float, depth: Int) -> (pos: SIMD2<Float>, normal: SIMD2<Float>?) {
    let d = q - p; let len = simd_length(d)
    guard len > 0.0001 else { return (q, nil) }
    let dir = d / len, side = SIMD2<Float>(-dir.y, dir.x), rad: Float = 0.32
    var best = Float.greatestFiniteMagnitude; var bestN: SIMD2<Float>? = nil
    let lateral: [Float] = [-0.24, 0, 0.24]
    for s in solids where nearSolid(s, p) {
      let heights: [Float] = s.low ? [0.6] : [Game.stepUp, 1.3]
      for hg in heights { for off in lateral {
        let o = side * off
        let a = SIMD3<Float>(p.x + o.x, elev + hg, p.y + o.y)
        let e = p + dir * (len + rad) + o
        let b = SIMD3<Float>(e.x, elev + hg, e.y)
        guard let h = rayHits(s, from: a, to: b).first else { continue }
        let dist = (h.worldCoordinates.x - a.x) * dir.x + (h.worldCoordinates.z - a.z) * dir.y
        if dist < best {
          best = dist
          let n = SIMD2<Float>(h.worldNormal.x, h.worldNormal.z); let nl = simd_length(n)
          bestN = nl > 0.2 ? n / nl : -dir } } }
    }
    guard let n = bestN else { return (q, nil) }
    let allowed = min(len, max(0, best - rad)); let stop = p + dir * allowed
    let rest = d * ((len - allowed) / len); let slide = rest - n * simd_dot(rest, n)
    if depth == 0, simd_length(slide) > 0.0005 {
      let r = sweepWalls(from: stop, to: stop + slide, elev: elev, depth: 1); return (r.pos, n) }
    return (stop, n)
  }

  /// Tìm chỗ đặt chân phía trên vật cản trước mặt (trong tầm với, đủ rộng, đủ chỗ cho đầu).
  func findClimbTop(from p: SIMD2<Float>, dir: SIMD2<Float>, elev: Float) -> SIMD3<Float>? {
    let low = elev + Game.stepUp, high = elev + Game.climbReach
    let dists: [Float] = [0.15, 0.35, 0.6, 0.9, 1.3]
    let around: [SIMD2<Float>] = [SIMD2<Float>(0.2, 0), SIMD2<Float>(-0.2, 0), SIMD2<Float>(0, 0.2), SIMD2<Float>(0, -0.2)]
    for dist in dists {
      let q = p + dir * dist
      for s in solids where !s.low && nearSolid(s, q, margin: 0.5) {
        guard let h = rayHits(s, from: SIMD3<Float>(q.x, s.top + 0.5, q.y), to: SIMD3<Float>(q.x, low - 0.3, q.y)).first else { continue }
        let y = h.worldCoordinates.y
        guard h.worldNormal.y > 0.55, y >= low, y <= high else { continue }
        var firm = 0
        for o in around {
          let r = q + o
          let hs = rayHits(s, from: SIMD3<Float>(r.x, y + 0.5, r.y), to: SIMD3<Float>(r.x, y - 0.4, r.y))
          if let f = hs.first, f.worldNormal.y > 0.55 { firm += 1 } }
        guard firm >= 3 else { continue }
        if rayHits(s, from: SIMD3<Float>(q.x, y + 0.08, q.y), to: SIMD3<Float>(q.x, y + 1.7, q.y)).isEmpty { return SIMD3<Float>(q.x, y, q.y) }
      }
    }
    return nil
  }

  func startClimb(dir: SIMD2<Float>) {
    guard wClimb == nil, let to = findClimbTop(from: avPos, dir: dir, elev: avYT) else { return }
    let from = SIMD3<Float>(avPos.x, avY, avPos.y), rise = to.y - from.y
    wClimb = WClimb(from: from, to: to, t: 0, dur: min(max(0.6 + rise * 0.4, 0.8), 2.0))
    avYaw = atan2(dir.x, dir.y); wSeat = nil
    if let a = walkAv { _ = a.perform(.climb) }
    note("Leo lên"); SoundFX.shared.cue(.climb)
  }

  /// Tìm chỗ ngồi trên công trình ngay trước mặt: tia từ trên xuống, chỉ nhận mặt nằm ngang ở độ cao 0,2–3,5 m.
  func findSeat() -> (pos: SIMD2<Float>, height: Float)? {
    let fwd = SIMD2<Float>(sin(avYaw), cos(avYaw))
    for r in [Float(0.6), 1.0, 1.5, 0.0] {
      let p = avPos + fwd * r
      for s in solids where !s.low && nearSolid(s, p, margin: 0.5) {
        guard let top = rayHits(s, from: SIMD3<Float>(p.x, avYT + 1.5 + (avYT > 0.5 ? 0 : 6.5), p.y), to: SIMD3<Float>(p.x, -0.2, p.y)).first else { continue }
        let y = top.worldCoordinates.y
        if y > 0.2 && y < 3.5 && top.worldNormal.y > 0.7 { return (p, y) }
      }
    }
    return nil
  }

  // ---------- camera bay cao ----------
  func toggleFly() {
    flyMode.toggle(); walkDist = flyMode ? 40 : 3.6; pitch = flyMode ? -1.15 : 0
    SoundFX.shared.cue(flyMode ? .jump : .land)
    note(flyMode ? "Đang xem từ trên cao. Dùng ➖ ➕ để lên cao / xuống thấp." : "Đã hạ xuống sau lưng nhân vật.")
  }
  func walkZoom(_ k: Float) { walkDist = min(max(walkDist * k, 1.6), 90) }

  // ---------- NPC ----------
  func addNPC(char: String, behavior: Int) {
    guard let av = RiggedAvatar.load(modelName: char) else { note("Không đọc được nhân vật cho NPC"); return }
    let fx: Float, fz: Float
    if walkMode { fx = avPos.x + sin(avYaw) * 2.5; fz = avPos.y + cos(avYaw) * 2.5 }
    else { fx = cam.position.x - sin(yaw) * 4; fz = cam.position.z - cos(yaw) * 4 }
    let e = NPCEntry(id: UUID().uuidString, char: char, behavior: behavior, x: fx, z: min(fz, 8), avatar: av)
    e.holder.position = SCNVector3(e.x, 0, e.z); scene.rootNode.addChildNode(e.holder)
    npcs.append(e); saveNPCs(); objectWillChange.send()
    note("Đã thả NPC: \(CharFiles.display(char)) (\(Game.npcNames[behavior]))")
  }
  func removeNPC(_ id: String) {
    npcs.filter { $0.id == id }.forEach { $0.holder.removeFromParentNode() }
    npcs.removeAll { $0.id == id }; saveNPCs(); objectWillChange.send()
  }
  func saveNPCs() {
    if importLock { return }
    let s = npcs.map { NPCSave(id: $0.id, char: $0.char, behavior: $0.behavior, x: $0.x, z: $0.z) }
    if let d = try? JSONEncoder().encode(s) { UserDefaults.standard.set(d, forKey: "vb.npcs") }
  }
  func restoreNPCs() {
    guard !npcsLoaded else { return }; npcsLoaded = true; ensureCharHooks()
    guard let d = UserDefaults.standard.data(forKey: "vb.npcs"), let list = try? JSONDecoder().decode([NPCSave].self, from: d) else { return }
    for s in list {
      guard let av = RiggedAvatar.load(modelName: s.char) else { continue }
      let e = NPCEntry(id: s.id, char: s.char, behavior: s.behavior, x: s.x, z: s.z, avatar: av)
      e.holder.position = SCNVector3(s.x, 0, s.z); scene.rootNode.addChildNode(e.holder); npcs.append(e) }
  }
  func stepNPCs(_ dt: Float) {
    npcTime += dt
    for n in npcs {
      n.driver.tick(npcTime)
      let o = n.driver.offset
      n.avatar.root.position.y = groundY(n.x + o.x, n.z + o.y)
    }
  }
}
