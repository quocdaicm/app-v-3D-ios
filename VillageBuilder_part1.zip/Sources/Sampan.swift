import SceneKit
import UIKit
import simd

// ===== Xuồng ba lá miền Tây: thân ghép ván cũ, mũi/lái cong vút, 3 ghế ngồi, sườn gỗ, dây buộc, mái chèo =====
// Gốc ở tâm đáy (y = 0 là đáy xuồng), mũi hướng +z, dài ~3,2 m, rộng ~0,76 m.
extension Game {
  func plankImg(_ base: UIColor, _ seed: UInt64) -> UIImage {
    var rc: CGFloat = 0, gc: CGFloat = 0, bc: CGFloat = 0; base.getRed(&rc, green: &gc, blue: &bc, alpha: nil)
    return UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256)).image { c in
      let g = c.cgContext; var r = RNG(); r.s = seed
      for k in 0..<4 {
        let v = CGFloat(r.f(0.82, 1.18)), y = CGFloat(k) * 64
        UIColor(red: min(rc * v, 1), green: min(gc * v, 1), blue: min(bc * v, 1), alpha: 1).setFill(); g.fill(CGRect(x: 0, y: y, width: 256, height: 64))
        for _ in 0..<46 { let gy = y + CGFloat(r.f(2, 62)), x0 = CGFloat(r.f(-20, 220)), len = CGFloat(r.f(40, 180))   // vân gỗ chạy dọc ván
          (r.f(0, 1) > 0.45 ? UIColor.black : UIColor.white).withAlphaComponent(CGFloat(r.f(0.04, 0.16))).setStroke(); g.setLineWidth(CGFloat(r.f(0.6, 2)))
          g.move(to: CGPoint(x: x0, y: gy)); g.addCurve(to: CGPoint(x: x0 + len, y: gy + CGFloat(r.f(-3, 3))), control1: CGPoint(x: x0 + len / 3, y: gy + CGFloat(r.f(-2, 2))), control2: CGPoint(x: x0 + len * 0.7, y: gy + CGFloat(r.f(-2, 2)))); g.strokePath() }
        for _ in 0..<2 { let kx = CGFloat(r.f(20, 236)), ky = y + CGFloat(r.f(14, 50)), kw = CGFloat(r.f(6, 14))   // mắt gỗ
          UIColor(white: 0, alpha: 0.35).setFill(); UIBezierPath(ovalIn: CGRect(x: kx, y: ky, width: kw, height: kw * 0.55)).fill()
          UIColor(white: 0, alpha: 0.18).setStroke(); g.setLineWidth(1); UIBezierPath(ovalIn: CGRect(x: kx - 4, y: ky - 3, width: kw + 8, height: kw * 0.55 + 6)).stroke() }
        UIColor(white: 0, alpha: 0.65).setFill(); g.fill(CGRect(x: 0, y: y + 61, width: 256, height: 3))   // khe ghép ván
        UIColor(white: 1, alpha: 0.12).setFill(); g.fill(CGRect(x: 0, y: y + 58, width: 256, height: 1.5))
        UIColor(white: 0.05, alpha: 0.8).setFill()   // đinh
        for nx in [CGFloat(10), 246] { g.fill(CGRect(x: nx, y: y + 8, width: 3, height: 3)); g.fill(CGRect(x: nx, y: y + 50, width: 3, height: 3)) } }
      for _ in 0..<30 { UIColor(white: 0.85, alpha: CGFloat(r.f(0.03, 0.09))).setFill(); let w = CGFloat(r.f(10, 50)); UIBezierPath(ovalIn: CGRect(x: CGFloat(r.f(0, 256)), y: CGFloat(r.f(0, 256)), width: w, height: w * 0.4)).fill() }   // muối bạc, phai nắng
      for i in 0..<600 { UIColor(white: CGFloat((i * 37) % 100) / 100, alpha: 0.05).setFill(); g.fill(CGRect(x: CGFloat((i * 53) % 256), y: CGFloat((i * 97) % 256), width: 2, height: 2)) } }
  }

  func sampanNode() -> SCNNode {
    let root = SCNNode()
    let L: Float = 3.2, W: Float = 0.38, nt = 30, nq = 20
    func wAt(_ t: Float) -> Float { W * pow(max(sin(Float.pi * t), 0.0001), 0.55) }
    func topAt(_ t: Float) -> Float { 0.4 + 0.3 * pow(abs(2 * t - 1), 2.4) }
    func botAt(_ t: Float) -> Float { 0.05 + 0.1 * pow(abs(2 * t - 1), 2.0) }
    func sec(_ t: Float, _ q: Float) -> SIMD3<Float> {
      let a = abs(q), w = wAt(t), bt = botAt(t), tp = topAt(t); var x: Float, y: Float
      if a < 0.4 { x = w * 0.45 * (a / 0.4); y = bt } else { let b = (a - 0.4) / 0.6; x = w * (0.45 + 0.55 * pow(b, 0.7)); y = bt + (tp - bt) * pow(b, 1.3) }
      let sg: Float = t < 0.5 ? -1 : 1
      return SIMD3<Float>(q < 0 ? -x : x, y, (t - 0.5) * L + sg * 0.35 * pow(abs(2 * t - 1), 3) * (y - bt))   // mũi, đuôi vênh ra phía trước
    }
    func halfW(_ t: Float, _ b: Float) -> Float { wAt(t) * (0.45 + 0.55 * pow(b, 0.7)) }
    func yAtB(_ t: Float, _ b: Float) -> Float { botAt(t) + (topAt(t) - botAt(t)) * pow(b, 1.3) }
    let hullM = mat(plankImg(pc(0.4, 0.31, 0.22), 21), 1, 1); hullM.isDoubleSided = true; hullM.specular.contents = UIColor(white: 0.1, alpha: 1)
    let seatM = mat(plankImg(pc(0.5, 0.4, 0.29), 33), 1, 1), darkM = mat(plankImg(pc(0.27, 0.2, 0.14), 45), 1, 1), floorM = mat(plankImg(pc(0.36, 0.28, 0.2), 57), 1, 1)
    // thân: lưới mặt cắt, ván xếp dọc thân
    var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
    for i in 0...nt { let t = Float(i) / Float(nt)
      for j in 0...nq { let q = -1 + 2 * Float(j) / Float(nq); P.append(sec(t, q)); UV.append(SIMD2<Float>(t * L / 1.2, abs(q) * 1.2)) } }
    for i in 0..<nt { for j in 0..<nq { let a = Int32(i * (nq + 1) + j), b = a + 1, c = a + Int32(nq + 1), d = c + 1; I += [a, b, c, b, d, c] } }
    let hull = meshGeo(P, UV, I); hull.firstMaterial = hullM; root.addChildNode(SCNNode(geometry: hull))
    // mép thành (cạp ngoài + cạp trong)
    for sd in [Float(-1), 1] {
      let outer = (0...nt).map { sec(Float($0) / Float(nt), sd) + SIMD3<Float>(0, 0.01, 0) }, inn = (0...nt).map { sec(Float($0) / Float(nt), sd * 0.9) + SIMD3<Float>(0, 0.005, 0) }
      let go = tube(outer, 0.03, 0.03, 8, 0.6); go.firstMaterial = darkM; root.addChildNode(SCNNode(geometry: go))
      let gi = tube(inn, 0.02, 0.02, 8, 0.6); gi.firstMaterial = darkM; root.addChildNode(SCNNode(geometry: gi)) }
    // sườn gỗ cong bên trong
    for t in [Float(0.14), 0.26, 0.38, 0.62, 0.74, 0.86] {
      let rib = (0...nq).map { sec(t, -0.97 + 1.94 * Float($0) / Float(nq)) + SIMD3<Float>(0, 0.012, 0) }; let rg = tube(rib, 0.018, 0.018, 6, 1); rg.firstMaterial = darkM; root.addChildNode(SCNNode(geometry: rg)) }
    // ván sàn lót đáy
    for i in 0..<9 { let t = 0.16 + 0.68 * (Float(i) + 0.5) / 9; root.addChildNode(pbox(CGFloat(1.5 * wAt(t)), 0.025, 0.3, 0, botAt(t) + 0.03, (t - 0.5) * L, floorM, 0.004)) }
    // ba ghế ngồi: hai tấm ván, đệm đỡ hai đầu, nẹp góc
    for t in [Float(0.2), 0.5, 0.78] {
      let b: Float = 0.55, hx = halfW(t, b) - 0.02, y = yAtB(t, b), z = (t - 0.5) * L
      for dz in [Float(-0.065), 0.065] { root.addChildNode(pbox(CGFloat(hx * 2), 0.035, 0.125, 0, y, z + dz, seatM, 0.006)) }
      for sx in [Float(-1), 1] { root.addChildNode(pbox(0.045, 0.1, 0.27, sx * (hx - 0.03), y - 0.065, z, darkM, 0.006))
        root.addChildNode(rod(SIMD3<Float>(sx * (hx - 0.01), y - 0.02, z + 0.1), SIMD3<Float>(sx * (hx - 0.13), y - 0.2, z + 0.1), 0.014, darkM)) } }
    // đầu mũi / đuôi: khối chặn + dây thừng quấn
    let rope = pcol(0.62, 0.5, 0.3); rope.specular.contents = UIColor(white: 0.15, alpha: 1)
    for sg in [Float(-1), 1] { let tp = sec(sg > 0 ? 1 : 0, 1)
      let bk = pbox(0.085, 0.15, 0.14, tp.x, tp.y + 0.02, tp.z, darkM, 0.01); bk.eulerAngles.x = -sg * 0.25; root.addChildNode(bk)
      for k in 0..<3 { let tr = SCNTorus(ringRadius: 0.06, pipeRadius: 0.011); tr.firstMaterial = rope; let n = SCNNode(geometry: tr); n.position = SCNVector3(tp.x, tp.y + 0.02, tp.z - sg * (0.05 + 0.03 * Float(k))); n.eulerAngles.x = .pi / 2; root.addChildNode(n) } }
    // dây thừng cuộn dưới đuôi + mái chèo gác ngang ghế
    for k in 0..<3 { let tr = SCNTorus(ringRadius: CGFloat(0.13 - 0.025 * Float(k)), pipeRadius: 0.012); tr.firstMaterial = rope; let n = SCNNode(geometry: tr); n.position = SCNVector3(0.08, botAt(0.1) + 0.05 + 0.02 * Float(k), -1.15); root.addChildNode(n) }
    root.addChildNode(rod(SIMD3<Float>(-0.3, 0.37, -0.95), SIMD3<Float>(0.28, 0.3, 0.75), 0.02, darkM))
    let blade = pbox(0.13, 0.015, 0.5, 0, 0, 0, seatM, 0.004); blade.simdTransform = mT(0.31, 0.295, 0.98) * mRy(0.3); root.addChildNode(blade)
    root.addChildNode(rod(SIMD3<Float>(0.28, 0.3, 0.75), SIMD3<Float>(0.33, 0.29, 1.2), 0.012, darkM))
    return root
  }
}
