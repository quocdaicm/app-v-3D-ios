import SceneKit
import UIKit
import simd

// ===== Khu nhà sân vườn miền Tây (mẫu ghép sẵn): nhà ngói + nhà tôn, sân vườn, dừa – chuối – xoài, mương nước có chiều sâu,
// ruộng lúa, luống rau, hàng rào, đường quê, xuồng. Gốc (0,0) ở giữa khu; mét, Y lên, mặt trước +z. =====
extension Game {
  static let westGardenId = "Khu nhà sân vườn miền Tây (mẫu)"

  func wgTin(_ k: String) -> SCNMaterial {
    let key = "WG:" + k; if let c = leafMats[key] { return c }
    let m: SCNMaterial
    switch k {
    case "silver": m = pcol(0.72, 0.74, 0.76); m.specular.contents = UIColor(white: 0.8, alpha: 1); m.shininess = 0.6
    case "blue": m = pcol(0.15, 0.4, 0.7); m.specular.contents = UIColor(white: 0.6, alpha: 1); m.shininess = 0.5
    case "glass": m = pcol(0.25, 0.38, 0.48); m.specular.contents = UIColor(white: 0.9, alpha: 1); m.shininess = 0.8
    case "white": m = pcol(0.93, 0.92, 0.88)
    case "grass": m = pcol(0.3, 0.5, 0.16)
    case "soil": m = pcol(0.36, 0.25, 0.15)
    case "dirt": m = pcol(0.55, 0.42, 0.28)
    case "paddy": m = pcol(0.3, 0.2, 0.12)
    case "trunk": m = pcol(0.42, 0.32, 0.2)
    default: m = pcol(0.5, 0.5, 0.5)
    }
    m.isDoubleSided = true; leafMats[key] = m; return m
  }

  /// mái hai dốc: nóc dọc trục x, tâm (0, wallTop, 0)
  func wgGableRoof(_ root: SCNNode, W: Float, D: Float, wallTop: Float, rise: Float, out: Float, mat m: SCNMaterial, tileSize: Float) {
    let hw = W / 2 + out, hd = D / 2 + out, yE = wallTop - rise * out / (D / 2), yR = wallTop + rise
    var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
    for s in [Float(1), Float(-1)] {
      let b = Int32(P.count)
      let slope = sqrt(hd * hd + (yR - yE) * (yR - yE))
      P += [SIMD3<Float>(-hw, yE, s * hd), SIMD3<Float>(hw, yE, s * hd), SIMD3<Float>(-hw, yR, 0), SIMD3<Float>(hw, yR, 0)]
      UV += [SIMD2<Float>(0, 0), SIMD2<Float>(2 * hw / tileSize, 0), SIMD2<Float>(0, slope / tileSize), SIMD2<Float>(2 * hw / tileSize, slope / tileSize)]
      if s > 0 { I += [b, b + 1, b + 2, b + 1, b + 3, b + 2] } else { I += [b, b + 2, b + 1, b + 1, b + 2, b + 3] }
    }
    let g = meshGeo(P, UV, I); g.firstMaterial = m; root.addChildNode(SCNNode(geometry: g))
    // diềm mái
    root.addChildNode(pbox(CGFloat(2 * hw + 0.1), 0.1, 0.1, 0, yR + 0.04, 0, wgTin("white"), 0.02))
    for s in [Float(1), Float(-1)] { root.addChildNode(pbox(CGFloat(2 * hw), 0.1, 0.08, 0, yE - 0.03, s * hd, wgTin("white"), 0.01)) }
    // đầu hồi
    let hd2 = D / 2
    for sx in [Float(1), Float(-1)] {
      let x = sx * W / 2
      let Q = [SIMD3<Float>(x, wallTop, -hd2), SIMD3<Float>(x, wallTop, hd2), SIMD3<Float>(x, yR - 0.05, 0)]
      let gg = meshGeo(Q, [SIMD2<Float>(0, 0), SIMD2<Float>(D / 2.5, 0), SIMD2<Float>(D / 5, rise / 2.5)], sx > 0 ? [0, 2, 1] : [0, 1, 2])
      gg.firstMaterial = tmat("plaster", 1, 1); root.addChildNode(SCNNode(geometry: gg))
    }
  }

  /// nhà: nền, tường (chân gạch + thân vôi), cửa chính + cửa sổ, hiên có cột, mái
  func wgHouse(W: Float, D: Float, H: Float, roof: String, wall: String, porch: Bool) -> SCNNode {
    let r = SCNNode(); let fl: Float = 0.3
    r.addChildNode(tBox(W + 1.0, fl, D + 1.0, 0, fl / 2, 0, "stoneBlock", 2.5, 2.5, 0.02))
    r.addChildNode(tBox(W, H, D, 0, fl + H / 2, 0, wall, 2.5, 2.5, 0.01))
    r.addChildNode(tBox(W + 0.04, 0.7, D + 0.04, 0, fl + 0.35, 0, "brickGray", 2.5, 2.5, 0.01))
    let wood = tLac("wood"), white = wgTin("white"), glass = wgTin("glass")
    // cửa chính giữa mặt trước
    r.addChildNode(pbox(1.5, 2.3, 0.1, 0, fl + 1.15, D / 2 + 0.03, white, 0.01))
    r.addChildNode(pbox(0.7, 2.15, 0.08, -0.36, fl + 1.1, D / 2 + 0.08, wood, 0.01)); r.addChildNode(pbox(0.7, 2.15, 0.08, 0.36, fl + 1.1, D / 2 + 0.08, wood, 0.01))
    // cửa sổ hai bên
    var xs = [Float]()
    var x = -W / 2 + 1.6; while x < W / 2 - 1.0 { if abs(x) > 1.6 { xs.append(x) }; x += 2.4 }
    for wx in xs {
      r.addChildNode(pbox(1.3, 1.3, 0.1, wx, fl + 1.6, D / 2 + 0.03, white, 0.01))
      r.addChildNode(pbox(1.1, 1.1, 0.12, wx, fl + 1.6, D / 2 + 0.05, glass, 0.005))
      r.addChildNode(pbox(0.05, 1.1, 0.14, wx, fl + 1.6, D / 2 + 0.06, white, 0.005))
    }
    for sx in [Float(-1), Float(1)] { r.addChildNode(pbox(0.1, 1.2, 1.3, sx * (W / 2 + 0.03), fl + 1.6, 0, glass, 0.005)) }
    if porch {
      let pd: Float = 2.2
      r.addChildNode(tBox(W, 0.12, pd, 0, fl + 0.06, D / 2 + pd / 2, "stoneBlock", 2.5, 2.5, 0.01))
      var px = -W / 2 + 0.3; while px <= W / 2 - 0.2 {
        r.addChildNode(pbox(0.22, CGFloat(H - 0.2), 0.22, px, fl + (H - 0.2) / 2, D / 2 + pd - 0.2, white, 0.02)); px += (W - 0.6) / 4 }
      r.addChildNode(pbox(CGFloat(W + 0.2), 0.2, 0.3, 0, fl + H - 0.1, D / 2 + pd - 0.2, white, 0.02))
      // mái hiên thoải
      let hw = W / 2 + 0.3
      let P = [SIMD3<Float>(-hw, fl + H + 0.5, D / 2), SIMD3<Float>(hw, fl + H + 0.5, D / 2), SIMD3<Float>(-hw, fl + H - 0.05, D / 2 + pd + 0.2), SIMD3<Float>(hw, fl + H - 0.05, D / 2 + pd + 0.2)]
      let g = meshGeo(P, [SIMD2<Float>(0, 0), SIMD2<Float>(2 * hw / 1.6, 0), SIMD2<Float>(0, 1.6), SIMD2<Float>(2 * hw / 1.6, 1.6)], [0, 2, 1, 1, 2, 3])
      g.firstMaterial = roof.hasPrefix("tin") ? wgTin(String(roof.dropFirst(3))) : tmat(roof, 1, 1); r.addChildNode(SCNNode(geometry: g))
    }
    let rm: SCNMaterial = roof.hasPrefix("tin") ? wgTin(String(roof.dropFirst(3))) : tmat(roof, 1, 1)
    let up = SCNNode(); wgGableRoof(up, W: W, D: D, wallTop: 0, rise: D * 0.3, out: 0.7, mat: rm, tileSize: roof.hasPrefix("tin") ? 1.2 : 1.6)
    up.position.y = fl + H; r.addChildNode(up)
    return r.flattenedClone()
  }

  func wgPlace(_ id: String, _ x: Float, _ z: Float, _ s: Float, _ yaw: Float, into root: SCNNode) {
    guard let p = proto(id) else { return }
    let n = p.clone(); n.position = SCNVector3(x, 0, z); n.scale = SCNVector3(s, s, s); n.eulerAngles.y = yaw; root.addChildNode(n)
  }

  func wgBanana(_ x: Float, _ z: Float, _ s: Float, into root: SCNNode) {
    let n = SCNNode(); n.addChildNode(pcyl(0.11, 2.2, 0, 1.1, 0, wgTin("trunk")))
    let ro = rosette(8, 1.9, 0.62, leafMat("palm"), outer: 0.95, inner: 0.15, arch: 0.55, fold: 0.1); ro.position.y = 2.15; n.addChildNode(ro)
    n.position = SCNVector3(x, 0, z); n.scale = SCNVector3(s, s, s); root.addChildNode(n)
  }

  func wgRice(_ x0: Float, _ x1: Float, _ z0: Float, _ z1: Float, into root: SCNNode) {
    let f = SCNNode()
    let w = pbox(CGFloat(x1 - x0), 0.04, CGFloat(z1 - z0), (x0 + x1) / 2, -0.16, (z0 + z1) / 2, wgTin("paddy"), 0); f.addChildNode(w)
    var x = x0 + 0.4; var k = 0
    while x < x1 - 0.2 {
      var z = z0 + 0.4
      while z < z1 - 0.2 {
        let ro = rosette(4, 0.7, 0.07, leafMat("grass"), outer: 0.35, inner: 0.1, arch: 0.35, fold: 0.05)
        ro.position = SCNVector3(x + Float(k % 3) * 0.05, -0.14, z + Float((k * 7) % 5) * 0.04); f.addChildNode(ro); z += 0.45; k += 1 }
      x += 0.45 }
    root.addChildNode(f.flattenedClone())
    // bờ ruộng
    root.addChildNode(pbox(CGFloat(x1 - x0 + 0.6), 0.2, 0.3, (x0 + x1) / 2, -0.05, z0 - 0.15, wgTin("soil"), 0.02))
    root.addChildNode(pbox(CGFloat(x1 - x0 + 0.6), 0.2, 0.3, (x0 + x1) / 2, -0.05, z1 + 0.15, wgTin("soil"), 0.02))
  }

  func wgFence(_ x0: Float, _ x1: Float, _ z: Float, into root: SCNNode) {
    let wood = tLac("wood"); var x = x0
    while x <= x1 { root.addChildNode(pbox(0.12, 1.2, 0.12, x, 0.6, z, wood, 0.01)); x += 1.2 }
    for y in [Float(0.45), 0.95] { root.addChildNode(pbox(CGFloat(x1 - x0), 0.08, 0.06, (x0 + x1) / 2, y, z, wood, 0.01)) }
  }

  func westGardenDiorama() -> SCNNode {
    let root = SCNNode()
    let gm = wgTin("grass")
    // --- mặt đất: phần sau (z < 8), phần trước (z > 15), mương ở giữa có chiều sâu ---
    func slab(_ x0: Float, _ x1: Float, _ z0: Float, _ z1: Float, _ top: Float, _ bot: Float, _ m: SCNMaterial) {
      root.addChildNode(pbox(CGFloat(x1 - x0), CGFloat(top - bot), CGFloat(z1 - z0), (x0 + x1) / 2, (top + bot) / 2, (z0 + z1) / 2, m, 0)) }
    slab(-34, 34, -24, 8, 0, -1.2, gm)
    slab(-34, 34, 15, 26, 0, -1.2, gm)
    slab(-34, 34, 8, 15, -1.2, -1.5, wgTin("soil"))              // đáy mương
    slab(-34, 34, 8, 9.2, -0.6, -1.2, wgTin("soil")); slab(-34, 34, 13.8, 15, -0.6, -1.2, wgTin("soil"))   // bờ dốc (bậc)
    let wg = SCNBox(width: 68, height: 0.02, length: 5.2, chamferRadius: 0); wg.firstMaterial = canalWater
    let wn = SCNNode(geometry: wg); wn.position = SCNVector3(0, -0.55, 11.5); root.addChildNode(wn)
    // đường quê trước nhà
    root.addChildNode(pbox(68, 0.04, 3.0, 0, 0.02, 22, wgTin("dirt"), 0))
    // sân nhà lát
    root.addChildNode(tBox(34, 0.06, 14, -4, 0.03, -3, "pave", 2.4, 2.4, 0.0))
    // --- nhà ---
    func house(_ x: Float, _ z: Float, _ W: Float, _ D: Float, _ H: Float, _ roof: String, _ wall: String, _ porch: Bool, _ yaw: Float = 0) {
      let h = wgHouse(W: W, D: D, H: H, roof: roof, wall: wall, porch: porch); h.position = SCNVector3(x, 0, z); h.eulerAngles.y = yaw; root.addChildNode(h) }
    house(-14, -8, 9, 6, 3.0, "tileRed", "plaster", true)
    house(1, -11, 8, 5.5, 3.0, "tileGray", "plaster", true)
    house(15, -8, 8, 5, 2.8, "tinsilver", "plaster", false)
    house(-2, 2, 5, 3.6, 2.6, "tinblue", "plaster", false)
    // --- cây: dừa, xoài/da, hoa ---
    let coco: [(Float, Float, Float)] = [(-27, -16, 1.0), (-22, -20, 1.1), (-9, -19, 1.0), (7, -20, 1.2), (12, -16, 1.0), (24, -14, 1.1), (28, -8, 1.0), (-28, 2, 1.1), (-20, 4, 0.95), (20, 4, 1.05), (29, 5, 1.0), (-5, 19, 1.0), (6, 19.5, 1.1), (-25, 19, 1.0)]
    for (i, c) in coco.enumerated() { wgPlace(i % 4 == 3 ? "coconutTreeBended" : "coconutTree", c.0, c.1, c.2, Float(i) * 1.3, into: root) }
    for (i, c) in [(Float(-19), Float(-2)), (-8, 5), (8, 3), (19, 1), (-24, -9)].enumerated() { wgPlace("ficusTree", c.0, c.1, 0.8 + 0.1 * Float(i % 3), Float(i) * 2.1, into: root) }
    for (i, c) in [(Float(-18), Float(-4)), (-11, -4.5), (-6, -7), (-3, -4), (4, -8), (10, -8.5), (19, -4.5), (12, -4.5)].enumerated() { wgPlace(i % 2 == 0 ? "roses-bush" : "hydrangea", c.0, c.1, 1.0, Float(i), into: root) }
    for c in [(Float(-30), Float(-12)), (-24, -3), (-26, 8), (24, 10), (31, -2), (-12, 6), (11, 6)] { wgBanana(c.0, c.1, 1.0, into: root) }
    for (i, x) in [Float(-30), -26, -18, 18, 26, 30].enumerated() { wgPlace("bush", x, i % 2 == 0 ? -21 : 6.5, 1.0, Float(i), into: root) }
    // --- luống rau ---
    for (i, id) in ["Luống rau", "Luống cải bắp", "Luống rau", "Luống đất"].enumerated() { wgPlace(id, -26 + Float(i) * 0.0, -5 + Float(i) * 2.6, 1.0, 0, into: root) }
    // --- ruộng lúa ---
    wgRice(22, 32, -22, -17, into: root); wgRice(22, 32, -14, -9, into: root)
    // --- hàng rào ---
    wgFence(-33, -22, 6.5, into: root); wgFence(22, 33, 6.5, into: root)
    // cổng: hai trụ gạch
    for sx in [Float(-1), Float(1)] { root.addChildNode(tBox(0.6, 1.8, 0.6, sx * 2.2, 0.9, 6.5, "brickGray", 2.5, 2.5, 0.02)) }
    // --- xuồng ---
    let boat = sampanNode(); boat.position = SCNVector3(-8, -0.5, 11.5); boat.eulerAngles.y = 0.2; root.addChildNode(boat)
    let boat2 = sampanNode(); boat2.position = SCNVector3(14, -0.5, 11.2); boat2.eulerAngles.y = -0.15; boat2.scale = SCNVector3(0.85, 0.85, 0.85); root.addChildNode(boat2)
    return root
  }
}
