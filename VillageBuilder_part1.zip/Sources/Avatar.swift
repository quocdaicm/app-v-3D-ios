import SceneKit
import UIKit
import simd

// ===== Nhân vật đi lại như game: lấy mô hình người ra, joystick điều khiển, camera theo sau, tay chân đung đưa =====
extension Game {
  // độ cao mặt đất tại (x, z): đi lên bờ ao, lội xuống đáy ao với các ao cá đã đặt
  func groundY(_ x: Float, _ z: Float) -> Float {
    var best: Float = 0
    for r in recs where r.item == Game.pondId {
      let dx = x - r.x, dz = z - r.z, c = cos(r.yaw), s = sin(r.yaw)
      let lx = (dx * c - dz * s) / r.s, lz = (dx * s + dz * c) / r.s
      let dist = hypot(lx, lz), R = pondR(atan2(lz, lx)), d = dist - R
      if d > 3.5 { continue }
      let y: Float = d <= 0 ? pondBedY(min(max(dist / R, 0.02), 1)) : pondBankY(d)
      best = max(best, y * r.s) }
    return best
  }
  func angDiff(_ a: Float, _ b: Float) -> Float { var d = b - a; while d > Float.pi { d -= 2 * Float.pi }; while d < -Float.pi { d += 2 * Float.pi }; return d }

  // gom các bộ phận thành một nhóm quay quanh khớp (đỉnh hộp bao của bộ phận đầu tiên): hông cho chân, vai cho tay
  func limbGroup(_ names: [String: SCNNode], _ keys: [String]) -> SCNNode? {
    let parts = names.filter { kv in keys.contains { kv.key.contains($0) } }.map { $0.value }
    guard let first = parts.first(where: { $0.name?.contains(keys[0]) == true }), let par = first.parent else { return nil }
    let (mn, mx) = first.boundingBox
    let pv = first.convertPosition(SCNVector3((mn.x + mx.x) / 2, mx.y, (mn.z + mx.z) / 2), to: par)
    let g = SCNNode(); g.position = pv; g.pivot = SCNMatrix4MakeTranslation(pv.x, pv.y, pv.z); par.addChildNode(g)
    for p in parts where p.parent === par { p.removeFromParentNode(); g.addChildNode(p) }
    return g
  }
  func buildAvatar() {
    guard avatar == nil, let p = proto("mannequinMale") else { return }
    let n = p.clone(); var names: [String: SCNNode] = [:]
    n.enumerateHierarchy { c, _ in if let nm = c.name { names[nm] = c } }
    avLegs = [limbGroup(names, ["right_thigh", "right_knee", "right_leg", "right_ankle", "right_foot"]), limbGroup(names, ["left_thigh", "left_knee", "left_leg", "left_ankle", "left_foot"])].compactMap { $0 }
    avArms = [limbGroup(names, ["right_arm", "right_elbow", "right_forearm", "right_wrist", "right_hand"]), limbGroup(names, ["left_arm", "left_elbow", "left_forearm", "left_wrist", "left_hand"])].compactMap { $0 }
    n.name = "avatar"; n.isHidden = true; scene.rootNode.addChildNode(n); avatar = n
  }
  func setWalk(_ on: Bool) {
    if on {
      buildAvatar(); avPos = SIMD2<Float>(cam.position.x, cam.position.z); avYaw = yaw + Float.pi; avY = groundY(avPos.x, avPos.y)
      avatar?.isHidden = false; avatar?.position = SCNVector3(avPos.x, avY, avPos.y); avatar?.eulerAngles.y = avYaw
    } else {
      avatar?.isHidden = true; camY = avY + 1.6
      cam.position = SCNVector3(avPos.x, camY, avPos.y); cam.eulerAngles = SCNVector3(pitch, yaw, 0) }
  }

  // một bước khi ở chế độ nhân vật: (dxw, dzw) hướng đi theo camera, mag độ nghiêng cần gạt, sp quãng đi
  func stepAvatar(_ dt: Float, _ dxw: Float, _ dzw: Float, _ mag: Float, _ sp: Float) {
    let moving = mag > 0.05
    var x = avPos.x + dxw * sp, z = avPos.y + dzw * sp
    x = min(max(x, -14), 60); z = min(z, 8); if z < -200 { z = -200 }
    avPos = SIMD2<Float>(x, z)
    if moving { avYaw += angDiff(avYaw, atan2(dxw, dzw)) * min(1, dt * 10) }
    avY += (groundY(x, z) - avY) * min(1, dt * 12)
    walkPhase += dt * (run ? 11 : 7) * (moving ? 1 : 0)
    walkAmp += ((moving ? (run ? 0.8 : 0.55) : 0) - walkAmp) * min(1, dt * 10)
    let sw = sin(walkPhase) * walkAmp, bob = abs(sin(walkPhase)) * 0.03 * (walkAmp / 0.55)
    if avLegs.count == 2 { avLegs[0].eulerAngles.x = sw; avLegs[1].eulerAngles.x = -sw }
    if avArms.count == 2 { avArms[0].eulerAngles.x = -sw * 0.8; avArms[1].eulerAngles.x = sw * 0.8 }
    avatar?.position = SCNVector3(x, avY + bob, z); avatar?.eulerAngles.y = avYaw
    // camera đi sau lưng: kéo xuống để nhìn từ trên cao, kéo lên để nhìn thấp
    let e = min(max(0.25 - pitch, -0.1), 1.25), dist: Float = 3.6
    let tgt = SIMD3<Float>(x, avY + 1.25, z)
    var cp = tgt + SIMD3<Float>(sin(yaw) * cos(e), sin(e), cos(yaw) * cos(e)) * dist
    cp.y = max(cp.y, groundY(cp.x, cp.z) + 0.35)
    cam.position = SCNVector3(cp.x, cp.y, cp.z); cam.look(at: SCNVector3(tgt.x, tgt.y, tgt.z))
  }
}
