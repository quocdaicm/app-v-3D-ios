import SceneKit
import UIKit
import simd

// ===== Nhân vật đi lại như game: lấy mô hình người ra, joystick điều khiển, camera theo sau, tay chân đung đưa =====
extension Game {
  // độ cao mặt đất tại (x, z): đi lên bờ ao, lội xuống đáy ao với các ao cá đã đặt
  func groundY(_ x: Float, _ z: Float) -> Float {
    var best: Float = 0
    for r in recs where r.item == Game.pondId {
      let dx = x - r.x, dz = z - r.z, c = cos(r.yaw), s = sin(r.yaw)
      let lx = (dx * c - dz * s) / r.s, lz = (dx * s + dz * c) / r.s
      let dist = hypot(lx, lz), R = pondR(atan2(lz, lx)), d = dist - R
      if d > 3.5 { continue }
      let y: Float = d <= 0 ? pondBedY(min(max(dist / R, 0.02), 1)) : pondBankY(d)
      best = max(best, y * r.s) }
    return best
  }
  func angDiff(_ a: Float, _ b: Float) -> Float { var d = b - a; while d > Float.pi { d -= 2 * Float.pi }; while d < -Float.pi { d += 2 * Float.pi }; return d }

  // gom các bộ phận thành một nhóm quay quanh khớp (đỉnh hộp bao của bộ phận đầu tiên): hông cho chân, vai cho tay
  func limbGroup(_ names: [String: SCNNode], _ keys: [String]) -> SCNNode? {
    let parts = names.filter { kv in keys.contains { kv.key.contains($0) } }.map { $0.value }
    guard let first = parts.first(where: { $0.name?.contains(keys[0]) == true }), let par = first.parent else { return nil }
    let (mn, mx) = first.boundingBox
    let pv = first.convertPosition(SCNVector3((mn.x + mx.x) / 2, mx.y, (mn.z + mx.z) / 2), to: par)
    let g = SCNNode(); g.position = pv; g.pivot = SCNMatrix4MakeTranslation(pv.x, pv.y, pv.z); par.addChildNode(g)
    for p in parts where p.parent === par { p.removeFromParentNode(); g.addChildNode(p) }
    return g
  }
  func buildAvatar() {
    guard avatar == nil, let p = proto("mannequinMale") else { return }
    let n = p.clone(); var names: [String: SCNNode] = [:]
    n.enumerateHierarchy { c, _ in if let nm = c.name { names[nm] = c } }
    avLegs = [limbGroup(names, ["right_thigh", "right_knee", "right_leg", "right_ankle", "right_foot"]), limbGroup(names, ["left_thigh", "left_knee", "left_leg", "left_ankle", "left_foot"])].compactMap { $0 }
    avArms = [limbGroup(names, ["right_arm", "right_elbow", "right_forearm", "right_wrist", "right_hand"]), limbGroup(names, ["left_arm", "left_elbow", "left_forearm", "left_wrist", "left_hand"])].compactMap { $0 }
    n.name = "avatar"; n.isHidden = true; scene.rootNode.addChildNode(n); avatar = n
  }
  // ----- nhân vật có xương nhập vào -----
  func ensureCharHooks() {
    CharFiles.builtinProvider = { [weak self] in self?.proto("mannequinMale")?.clone() }
  }
  func note(_ s: String) {
    walkNote = s; walkNoteTok += 1; let t = walkNoteTok
    DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { [weak self] in if let self = self, self.walkNoteTok == t { self.walkNote = "" } }
  }
  // dựng (hoặc dùng lại) người đi dạo: nhân vật có xương đã chọn, không có thì người mẫu có sẵn đung đưa tay chân
  func makeWalker(force: Bool = false) {
    ensureCharHooks()
    if force { walkAv?.root.removeFromParentNode(); walkAv = nil }
    if let a = walkAv, walkAvSource == walkCharacter { a.root.isHidden = false; return }
    walkAv?.root.removeFromParentNode(); walkAv = nil; walkAvSource = nil
    if let name = walkCharacter {
      if let rig = RiggedAvatar.load(modelName: name) {
        walkAv = rig; walkAvSource = name; scene.rootNode.addChildNode(rig.root); walkActions = rig.customActions; return }
      note("Không đọc được nhân vật, dùng người mẫu có sẵn") }
    walkActions = []; buildAvatar()
  }
  func placeWalker() {
    let p = SCNVector3(avPos.x, avY, avPos.y)
    if let a = walkAv { avatar?.isHidden = true; a.root.isHidden = false; a.root.position = p; a.root.eulerAngles.y = avYaw }
    else { avatar?.isHidden = false; avatar?.position = p; avatar?.eulerAngles.y = avYaw }
  }
  /// Chọn nhân vật đi dạo (nil = người mẫu có sẵn đung đưa tay chân); tải lại cả khi vừa gắn xương / nhập hoạt ảnh.
  func useCharacter(_ name: String?) {
    walkCharacter = name; UserDefaults.standard.set(name, forKey: "vb.walkChar")
    walkAv?.root.removeFromParentNode(); walkAv = nil; walkAvSource = nil
    if walkMode { makeWalker(); placeWalker() }
    note("Nhân vật: " + (name.map { CharFiles.display($0) } ?? "có sẵn"))
  }
  func reloadWalker() { if walkMode { makeWalker(force: true); placeWalker() } else { walkAv?.root.removeFromParentNode(); walkAv = nil; walkAvSource = nil } }
  func walkDoAction() { if let a = walkAv { note(a.doAction()) } else { note("Người mẫu có sẵn chưa có hoạt ảnh: hãy chọn nhân vật có xương hoặc gắn xương") } }
  func walkPerform(_ e: WalkEmote) { if let a = walkAv { if e.sitting { wSeat = findSeat().map { (pos: $0.pos, h: $0.height) } } else { wSeat = nil }; note(a.perform(e) + (wSeat != nil ? " (trên công trình)" : "")) } else { note("Cần nhân vật có xương (👤 → Gắn xương) để dùng hoạt ảnh này") } }
  func walkCustom(_ i: Int) { if let a = walkAv { let s = a.playCustom(i); if !s.isEmpty { note(s) } } }
  func walkStop() { wSeat = nil; walkAv?.stopEmote() }
  func walkTurnFace() { if let a = walkAv { a.turnFacing(); note("Đã xoay mặt nhân vật 90°") } else { note("Người mẫu có sẵn không cần xoay mặt") } }

  func setWalk(_ on: Bool) {
    if on {
      makeWalker(); avPos = SIMD2<Float>(cam.position.x, cam.position.z); avYaw = yaw + Float.pi; avY = groundY(avPos.x, avPos.y); avYT = avY
      wClimb = nil; wSeat = nil; wPush = 0; flyMode = false; walkDist = 3.6; buildSolids(); solidT = 0; placeWalker()
    } else {
      wClimb = nil; wSeat = nil; flyMode = false; avatar?.isHidden = true; walkAv?.root.isHidden = true; camY = avY + 1.6
      cam.position = SCNVector3(avPos.x, camY, avPos.y); cam.eulerAngles = SCNVector3(pitch, yaw, 0) }
  }

  // một bước khi ở chế độ nhân vật: (dxw, dzw) hướng đi theo camera, mag độ nghiêng cần gạt, sp quãng đi
  // Có va chạm vách, bước lên bậc / sàn / mái (tới 0,55 m), tự leo (đẩy vào vật cản), ngồi lên công trình.
  func stepAvatar(_ dt: Float, _ dxw: Float, _ dzw: Float, _ mag: Float, _ spIn: Float) {
    let moving = mag > 0.05
    let sp = spIn * max(1, walkDist / 10)          // camera ở cao thì đi xa nhanh hơn
    solidT += dt; if solidT > 1 { solidT = 0; buildSolids() }
    let px = avPos.x, pz = avPos.y
    var x = px, z = pz
    if var c = wClimb {
      c.t += dt; let u = min(c.t / c.dur, 1), e = u * u * (3 - 2 * u)
      x = c.from.x + (c.to.x - c.from.x) * e; z = c.from.z + (c.to.z - c.from.z) * e
      avY = c.from.y + (c.to.y - c.from.y) * e; avPos = SIMD2<Float>(x, z)
      if u >= 1 { wClimb = nil; avYT = c.to.y; avY = c.to.y; walkAv?.stopEmote() } else { wClimb = c }
    } else {
      var q = SIMD2<Float>(px + dxw * sp, pz + dzw * sp)
      q.x = min(max(q.x, -14), 60); q.y = min(q.y, 8); if q.y < -200 { q.y = -200 }
      if moving { wSeat = nil; walkAv?.stopEmote() }
      if let s = wSeat { q = avPos + (s.pos - avPos) * min(1, dt * 4) }      // trượt nhẹ tới chỗ ngồi
      else if moving {
        let r = sweepWalls(from: avPos, to: q, elev: avYT, depth: 0)
        if r.normal != nil {
          wPush += dt
          if wPush > 0.35 { wPush = 0; startClimb(dir: simd_normalize(q - avPos)) }
        } else { wPush = 0 }
        q = r.pos
      } else { wPush = 0 }
      if wClimb != nil { q = avPos }
      avPos = q; x = q.x; z = q.y
      avYT = wSeat?.h ?? max(groundY(x, z), supportHeight(at: q, ref: avYT))
      avY += (avYT - avY) * min(1, dt * (avYT > avY ? 14 : 9))
    }
    if moving && wClimb == nil { avYaw += angDiff(avYaw, atan2(dxw, dzw)) * min(1, dt * 10) }
    walkPhase += dt * (run ? 11 : 7) * (moving ? 1 : 0)
    walkAmp += ((moving ? (run ? 0.8 : 0.55) : 0) - walkAmp) * min(1, dt * 10)
    let sw = sin(walkPhase) * walkAmp, bob = abs(sin(walkPhase)) * 0.03 * (walkAmp / 0.55)
    if let a = walkAv {
      // nhân vật có xương: clip Đứng / Đi / Chạy theo vận tốc thật (m/s), chân không trượt
      let spd: Float = dt > 0 && moving && wClimb == nil ? min(hypot(x - px, z - pz) / dt, run ? 9 : 4) : 0
      a.root.position = SCNVector3(x, avY, z); a.root.eulerAngles.y = avYaw; a.animate(speed: spd, dt: dt)
    } else {
      if avLegs.count == 2 { avLegs[0].eulerAngles.x = sw; avLegs[1].eulerAngles.x = -sw }
      if avArms.count == 2 { avArms[0].eulerAngles.x = -sw * 0.8; avArms[1].eulerAngles.x = sw * 0.8 }
      avatar?.position = SCNVector3(x, avY + bob, z); avatar?.eulerAngles.y = avYaw }
    // camera đi sau lưng: kéo xuống để nhìn từ trên cao, kéo lên để nhìn thấp
    let e = min(max(0.25 - pitch, -0.1), 1.45), dist = walkDist
    let tgt = SIMD3<Float>(x, avY + 1.25, z)
    var cp = tgt + SIMD3<Float>(sin(yaw) * cos(e), sin(e), cos(yaw) * cos(e)) * dist
    cp.y = max(cp.y, groundY(cp.x, cp.z) + 0.35)
    // Hướng camera tính thẳng từ yaw (trục phải luôn nằm ngang) — KHÔNG dùng cam.look(at:): nó có thể xoay vòng / nghiêng
    // (roll) khi kéo qua lại nhanh hoặc khi nhìn gần thẳng đứng, làm cả cảnh nghiêng và khó chỉnh lại.
    let fwd = simd_normalize(tgt - cp), right = SIMD3<Float>(cos(yaw), 0, -sin(yaw)), up = simd_cross(right, fwd)
    cam.simdPosition = cp
    cam.simdOrientation = simd_quatf(simd_float3x3(columns: (right, up, -fwd)))
  }
}
