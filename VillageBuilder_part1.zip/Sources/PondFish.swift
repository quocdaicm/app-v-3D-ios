import SceneKit
import UIKit
import simd

// ===== Ao cá: cá bơi dưới nước (3 loại, có vảy + đuôi vẫy), lưới nuôi, hiệu ứng sống =====
extension Game {
  // vị trí / hướng cá trên quỹ đạo elip: v = [cx, cz, a, b, y, w, phase, dir]
  func fishPose(_ v: [Float], _ th: Float) -> (SCNVector3, Float) {
    let cx = v[0], cz = v[1], a = v[2], b = v[3], y0 = v[4], dir = v[7]
    let x = cx + a * cos(th) + 0.12 * sin(3 * th), z = cz + b * sin(th)
    let dx = dir * (-a * sin(th) + 0.36 * cos(3 * th)), dz = dir * (b * cos(th))
    return (SCNVector3(x, y0 + 0.035 * sin(2 * th + v[6]), z), atan2(dx, dz))
  }

  // cụm lá có RNG riêng (tránh truyền inout cùng lúc với rr.f trong đối số)
  func rosy(_ parent: SCNNode, _ base: simd_float4x4, _ n: Int, _ L: Float, _ W: Float, _ m: SCNMaterial, outer: Float, inner: Float, arch: Float, fold: Float, radius: Float = 0) {
    var r = RNG(); r.s = UInt64(abs(base.columns.3.x) * 1000) &* 31 &+ UInt64(abs(base.columns.3.z) * 1000) &+ 7
    rosetteInto(parent, base, n, L, W, m, outer: outer, inner: inner, arch: arch, fold: fold, radius: radius, rr: &r)
  }
  func fishImg(_ dark: UIColor, _ mid: UIColor, _ light: UIColor, _ spot: UIColor?) -> UIImage {
    UIGraphicsImageRenderer(size: CGSize(width: 128, height: 256), format: Game.fmtTex).image { c in
      let g = c.cgContext
      if let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [mid.cgColor, dark.cgColor, mid.cgColor, light.cgColor, mid.cgColor] as CFArray, locations: [0, 0.25, 0.5, 0.75, 1]) {
        g.drawLinearGradient(gr, start: CGPoint(x: 0, y: 0), end: CGPoint(x: 128, y: 0), options: []) }
      UIColor(white: 0, alpha: 0.18).setStroke(); g.setLineWidth(1)   // vảy xếp lớp
      for row in 0..<26 { let y = CGFloat(row) * 10 + 4
        for col in 0..<10 { let x = CGFloat(col) * 13 + (row % 2 == 0 ? 0 : 6)
          g.addArc(center: CGPoint(x: x, y: y), radius: 7, startAngle: -.pi / 2.2, endAngle: .pi / 2.2, clockwise: false); g.strokePath() } }
      UIColor(white: 1, alpha: 0.12).setStroke()
      for row in 0..<26 { let y = CGFloat(row) * 10 + 4
        for col in 0..<10 { let x = CGFloat(col) * 13 + (row % 2 == 0 ? 0 : 6) + 2
          g.addArc(center: CGPoint(x: x, y: y - 2), radius: 5, startAngle: -.pi / 2.4, endAngle: .pi / 2.4, clockwise: false); g.strokePath() } }
      if let sp = spot { var r = RNG(); r.s = 17; sp.withAlphaComponent(0.5).setFill()
        for _ in 0..<26 { let x = CGFloat(r.f(0, 128)), y = CGFloat(r.f(30, 230)), w = CGFloat(r.f(3, 9)); UIBezierPath(ovalIn: CGRect(x: x, y: y, width: w, height: w * 0.8)).fill() } }
      UIColor(white: 0, alpha: 0.28).setFill(); g.fill(CGRect(x: 0, y: 230, width: 128, height: 26))   // đầu sẫm hơn
    }
  }

  func fishBodyGeo() -> SCNGeometry {
    let L: Float = 0.5, nt = 14, ns = 10
    var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
    for i in 0...nt { let t = Float(i) / Float(nt), z = (t - 0.5) * L
      let f = pow(max(sin(Float.pi * pow(t, 0.8)), 0.0001), 0.65)
      let rx = 0.07 * f, ry = 0.115 * f
      for j in 0...ns { let ph = Float(j) / Float(ns) * 2 * Float.pi
        P.append(SIMD3<Float>(rx * cos(ph), ry * sin(ph) - 0.008 * f, z)); UV.append(SIMD2<Float>(Float(j) / Float(ns), t)) } }
    for i in 0..<nt { for j in 0..<ns { let a = Int32(i * (ns + 1) + j), b = a + 1, c = a + Int32(ns + 1), d = c + 1; I += [a, b, c, b, d, c] } }
    return meshGeo(P, UV, I)
  }
  func finGeo(_ pts: [SIMD3<Float>], _ tri: [Int32], _ u: Float) -> SCNGeometry {
    meshGeo(pts, pts.map { SIMD2<Float>(u, 0.2 + 0.6 * ($0.z + 0.3)) }, tri)
  }
  // một con cá: thân + vây lưng + hai vây ngực + mắt (gộp một mảnh), đuôi là node riêng để vẫy
  func fishTemplate(_ m: SCNMaterial) -> SCNNode {
    let holder = SCNNode(); let eye = pcol(0.02, 0.02, 0.02); eye.specular.contents = UIColor.white
    let bodyG = fishBodyGeo(); bodyG.firstMaterial = m; holder.addChildNode(SCNNode(geometry: bodyG))
    let dorsal = finGeo([SIMD3<Float>(0, 0.105, 0.1), SIMD3<Float>(0, 0.1, -0.1), SIMD3<Float>(0, 0.2, -0.07)], [0, 1, 2], 0.25); dorsal.firstMaterial = m; holder.addChildNode(SCNNode(geometry: dorsal))
    for s in [Float(-1), 1] {
      let pf = finGeo([SIMD3<Float>(s * 0.05, -0.04, 0.1), SIMD3<Float>(s * 0.055, -0.05, 0.05), SIMD3<Float>(s * 0.13, -0.09, 0.0)], [0, 1, 2], 0.7); pf.firstMaterial = m; holder.addChildNode(SCNNode(geometry: pf))
      holder.addChildNode(psph(0.012, s * 0.03, 0.025, 0.215, 1, eye)) }
    let body = holder.flattenedClone(); body.name = "body"
    let tg = finGeo([SIMD3<Float>(0, 0.025, 0), SIMD3<Float>(0, 0.15, -0.16), SIMD3<Float>(0, 0, -0.09), SIMD3<Float>(0, -0.15, -0.16), SIMD3<Float>(0, -0.025, 0)], [0, 1, 2, 0, 2, 4, 2, 3, 4], 0.5)
    tg.firstMaterial = m; let tail = SCNNode(geometry: tg); tail.name = "tail"; tail.position = SCNVector3(0, 0, -0.245)
    let t = SCNNode(); t.addChildNode(body); t.addChildNode(tail); return t
  }

  func pondFish(_ root: SCNNode, _ rr: inout RNG) {
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    let imgs = [fishImg(C(0.72, 0.3, 0.04), C(0.95, 0.58, 0.14), C(0.99, 0.86, 0.55), C(0.98, 0.95, 0.85)),   // cá chép vàng
                fishImg(C(0.2, 0.25, 0.15), C(0.5, 0.55, 0.38), C(0.86, 0.86, 0.76), nil),                  // cá trắm
                fishImg(C(0.26, 0.27, 0.3), C(0.6, 0.52, 0.46), C(0.88, 0.58, 0.52), C(0.15, 0.15, 0.15))]  // cá rô phi
    let tpls: [SCNNode] = imgs.map { img in let m = mat(img, 1, 1); m.isDoubleSided = true; m.specular.contents = UIColor(white: 0.35, alpha: 1); m.shininess = 0.3; return fishTemplate(m) }
    func place(_ sp: Int, _ v: [Float], _ k: Float) {
      let n = tpls[sp].clone(); let (p, yaw) = fishPose(v, v[6])
      n.name = "fish:" + v.map { String(format: "%.4f", $0) }.joined(separator: ","); n.position = p; n.eulerAngles.y = yaw; n.scale = SCNVector3(k, k, k); root.addChildNode(n) }
    // cá thả tự do: quỹ đạo elip nằm gọn trong ao, tránh lưới nuôi và guồng quạt
    func fits(_ a: Float, _ b: Float, _ cx: Float, _ cz: Float) -> Bool {
      for q in 0..<32 { let th = Float(q) / 32 * 2 * Float.pi; let x = cx + a * cos(th) + 0.15 * sin(3 * th), z = cz + b * sin(th)
        if !pondInside(x, z, 0.6) { return false }
        if x > -4.4 && x < -1.6 && z > -3.0 && z < -0.8 { return false }
        if simd_length(SIMD2<Float>(x - 2.8, z - 0.7)) < 1.1 { return false } }
      return true }
    var made = 0, tries = 0
    while made < 26 && tries < 600 { tries += 1
      let a = rr.f(0.8, 4.2), b = rr.f(0.6, 2.6), cx = rr.f(-1.5, 2.5), cz = rr.f(-0.6, 1.0)
      guard fits(a, b, cx, cz) else { continue }
      let sp = made % 3 == 0 ? 0 : (made % 3 == 1 ? 1 : 2)
      place(sp, [cx, cz, a, b, rr.f(0.2, 0.5), rr.f(0.14, 0.32), rr.f(0, 6.28), rr.f(0, 1) > 0.5 ? 1 : -1], rr.f(0.85, 1.5)); made += 1 }
    for i in 0..<9 {   // cá trong lưới nuôi: quần tụ dày
      place(i % 2 == 0 ? 0 : 2, [-3.0, -1.9, rr.f(0.45, 0.65), rr.f(0.25, 0.38), rr.f(0.18, 0.45), rr.f(0.35, 0.6), rr.f(0, 6.28), i % 3 == 0 ? -1 : 1], rr.f(0.8, 1.2)) }
  }

  // lưới nuôi: 4 cọc tre, lưới xanh có mắt cáo, dây phao, phao nhựa
  func netImg() -> UIImage {
    let f = UIGraphicsImageRendererFormat(); f.opaque = false; f.scale = 1
    return UIGraphicsImageRenderer(size: CGSize(width: 128, height: 128), format: f).image { c in
      let g = c.cgContext; g.clear(CGRect(x: 0, y: 0, width: 128, height: 128))
      UIColor(red: 0.16, green: 0.5, blue: 0.4, alpha: 0.95).setStroke(); g.setLineWidth(2)
      for k in -8..<9 { let o = CGFloat(k) * 16
        g.move(to: CGPoint(x: o, y: 0)); g.addLine(to: CGPoint(x: o + 128, y: 128)); g.strokePath()
        g.move(to: CGPoint(x: o + 128, y: 0)); g.addLine(to: CGPoint(x: o, y: 128)); g.strokePath() } }
  }
  func pondNet(_ solid: SCNNode, _ root: SCNNode, _ cx: Float, _ cz: Float, _ w: Float, _ l: Float) {
    let bamboo = pcol(0.72, 0.62, 0.36), rope = pcol(0.8, 0.78, 0.7), buoy = pcol(0.95, 0.5, 0.1)
    let nm = SCNMaterial(); nm.lightingModel = .constant; nm.diffuse.contents = netImg(); nm.transparent.contents = netImg(); nm.transparencyMode = .aOne
    nm.isDoubleSided = true; nm.writesToDepthBuffer = false; nm.diffuse.wrapS = .repeat; nm.diffuse.wrapT = .repeat
    let yb: Float = 0.06, yt: Float = 0.98, h = yt - yb
    let corners: [(Float, Float)] = [(-w / 2, -l / 2), (w / 2, -l / 2), (w / 2, l / 2), (-w / 2, l / 2)]
    for i in 0..<4 {
      let (x0, z0) = corners[i], (x1, z1) = corners[(i + 1) % 4]; let len = hypot(x1 - x0, z1 - z0)
      let p = SCNPlane(width: CGFloat(len), height: CGFloat(h)); let m = (nm.copy() as? SCNMaterial) ?? nm
      m.diffuse.contentsTransform = SCNMatrix4MakeScale(len / 0.6, h / 0.6, 1); m.transparent.contentsTransform = m.diffuse.contentsTransform
      m.diffuse.wrapS = .repeat; m.diffuse.wrapT = .repeat; m.transparent.wrapS = .repeat; m.transparent.wrapT = .repeat
      p.firstMaterial = m; let n = SCNNode(geometry: p); n.position = SCNVector3(cx + (x0 + x1) / 2, yb + h / 2, cz + (z0 + z1) / 2); n.eulerAngles.y = atan2(x1 - x0, z1 - z0) - .pi / 2
      n.renderingOrder = 20; root.addChildNode(n)
      // dây thừng trên mép lưới + phao
      let r = pcyl(0.012, CGFloat(len), cx + (x0 + x1) / 2, yt, cz + (z0 + z1) / 2, rope); r.eulerAngles = SCNVector3(0, atan2(-(z1 - z0), x1 - x0), .pi / 2)
      solid.addChildNode(r)
      for k in 1..<6 { let t = Float(k) / 6; solid.addChildNode(psph(0.035, cx + x0 + (x1 - x0) * t, yt, cz + z0 + (z1 - z0) * t, 0.8, buoy)) } }
    for (x, z) in corners { let pole = pcyl(0.035, 1.3, cx + x, 0.06 + 0.65, cz + z, bamboo); pole.eulerAngles.z = 0.03; solid.addChildNode(pole)
      for k in 0..<3 { solid.addChildNode(pcyl(0.042, 0.015, cx + x, 0.4 + Float(k) * 0.3, cz + z, pcol(0.5, 0.42, 0.2))) } }
  }

  // bật chuyển động cho bản đặt trong cảnh: cá bơi, đuôi vẫy, guồng quạt quay, tia nước đổ, vòng sóng lan
  func startPondLife(_ root: SCNNode) {
    root.enumerateHierarchy { node, _ in
      guard let nm = node.name else { return }
      if nm.hasPrefix("fish:") {
        let v = nm.dropFirst(5).split(separator: ",").compactMap { Float($0) }
        guard v.count == 8, v[5] > 0.01 else { return }
        let w = v[5], ph = v[6], dir = v[7]; let T = 2 * Float.pi / w
        node.removeAllActions()
        node.runAction(.repeatForever(.customAction(duration: TimeInterval(T)) { n, el in
          let th = ph + dir * w * Float(el); let (p, yaw) = self.fishPose(v, th); n.position = p; n.eulerAngles.y = yaw }))
        if let tail = node.childNode(withName: "tail", recursively: false) {
          let d = 0.18 + 0.12 * Double(abs(sin(ph * 7)))
          tail.removeAllActions()
          tail.runAction(.repeatForever(.sequence([.rotateTo(x: 0, y: 0.55, z: 0, duration: d, usesShortestUnitArc: true), .rotateTo(x: 0, y: -0.55, z: 0, duration: d, usesShortestUnitArc: true)]))) }
      } else if nm == "wheel" {
        node.removeAllActions(); node.runAction(.repeatForever(.rotateBy(x: CGFloat(-2 * Float.pi), y: 0, z: 0, duration: 1.4)))
      } else if nm == "jet", let m = node.geometry?.firstMaterial {
        node.removeAllActions()
        node.runAction(.repeatForever(.customAction(duration: 1) { _, el in m.diffuse.contentsTransform = SCNMatrix4MakeTranslation(0, -Float(el) * 2, 0) }))
      } else if nm.hasPrefix("ripple:") {
        let i = Double(nm.dropFirst(7)) ?? 0
        node.removeAllActions()
        let reset = SCNAction.run { n in n.scale = SCNVector3(0.25, 1, 0.25); n.opacity = 0.9 }
        let grow = SCNAction.group([SCNAction.scale(to: 1.0, duration: 2.4), SCNAction.fadeOut(duration: 2.4)])
        node.runAction(SCNAction.sequence([SCNAction.wait(duration: i * 0.8), SCNAction.repeatForever(SCNAction.sequence([reset, grow]))]))
      } }
  }
}
