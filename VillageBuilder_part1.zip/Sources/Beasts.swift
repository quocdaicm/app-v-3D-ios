import SceneKit
import UIKit
import simd

// =====================================================================
//  Quái vật / Boss vẽ bằng mã, theo ảnh Võ Lâm Truyền Kỳ (hổ, báo, sói, hồ ly, heo, hươu, nhím, voi)
//  Mọi con đều dựng bằng ống nội suy Catmull-Rom (bLoft) + texture lông vẽ bằng mã + chi tiết nhỏ
//  (tai, mắt, mũi, ria, nanh, túm lông, móng / móng guốc, gạc, ngà, vòi, lông nhím).
//  Gốc ở giữa chân (y = 0 là mặt đất), mặt hướng +z. Có hoạt ảnh đi quanh chỗ đặt (startBeastLife).
//  CHƯA BIÊN DỊCH khi viết (không có Swift): nếu GitHub Actions báo lỗi thì sửa theo log, giữ nguyên phong cách.
// =====================================================================

typealias V3 = SIMD3<Float>

struct BeastSpec {
  var coat = "tiger"
  var bodyLen: Float = 1.25      // từ hông tới vai
  var bodyH: Float = 0.27        // bán kính đứng của thân
  var bodyW: Float = 0.21        // bán kính ngang của thân
  var legLen: Float = 0.45       // mặt đất tới bụng
  var legR: Float = 0.075
  var hind = true                // chân sau gập (đi bằng đầu ngón)
  var neckLen: Float = 0.26
  var neckRise: Float = 0.05
  var neckR: Float = 0.17
  var head = "cat"
  var headS: Float = 1.25
  var headPitch: Float = 0.12    // > 0: cúi mũi xuống
  var tail = "long"              // long, bushy, short
  var tailLen: Float = 1.0
  var tailR: Float = 0.045
  var roam: Float = 1.4          // bán kính đi quanh chỗ đặt (m)
  var period: Float = 16         // giây cho một vòng số 8
  var legAmp: Float = 0.5
  var cycles: Int = 19           // số nhịp chân trong một vòng (số nguyên để không giật)
  var eye = UIColor(red: 0.95, green: 0.7, blue: 0.1, alpha: 1)
  var feet = "paw"               // paw, hoof, foot
  var extra = ""                 // ruff, bristle, quills
}

struct BMesh {
  var P = [V3](), N = [V3](), UV = [SIMD2<Float>](), I = [Int32]()
  mutating func vert(_ p: V3, _ n: V3, _ uv: SIMD2<Float>) -> Int32 {
    P.append(p); N.append(n); UV.append(uv); return Int32(P.count - 1)
  }
  mutating func tri(_ a: Int32, _ b: Int32, _ c: Int32) { I.append(a); I.append(b); I.append(c) }
  var isEmpty: Bool { return P.isEmpty }
}

extension Game {
  static var beastImgs: [String: UIImage] = [:]
  static let beastIds = ["Hổ Đông Bắc", "Hổ Hoa Nam", "Bạch Hổ", "Hỏa Hổ (Boss)", "Kim Tiền Báo", "Báo Trắng",
                         "Sói Xám", "Sói Đỏ", "Sói Xanh", "Sói Tuyết", "Hồ Ly", "Heo Rừng", "Heo Trắng",
                         "Hươu Đốm", "Kim Miêu", "Nhím", "Đại Tượng (Boss)"]

  // ---------------------------------------------------------------- thông số từng con
  func beastSpec(_ id: String) -> BeastSpec? {
    var s = BeastSpec()
    switch id {
    case "Hổ Đông Bắc":
      s.coat = "tiger"
    case "Hổ Hoa Nam":
      s.coat = "tiger2"; s.bodyLen = 1.15; s.bodyH = 0.25; s.bodyW = 0.2; s.legLen = 0.42; s.headS = 1.18; s.tailLen = 0.95
    case "Bạch Hổ":
      s.coat = "white"; s.eye = UIColor(red: 0.45, green: 0.7, blue: 0.95, alpha: 1)
    case "Hỏa Hổ (Boss)":
      s.coat = "fire"; s.bodyLen = 1.6; s.bodyH = 0.34; s.bodyW = 0.27; s.legLen = 0.56; s.legR = 0.095; s.neckLen = 0.32; s.neckR = 0.22
      s.headS = 1.55; s.tailLen = 1.3; s.tailR = 0.058; s.roam = 2.2; s.period = 22; s.cycles = 24; s.legAmp = 0.45
      s.eye = UIColor(red: 1, green: 0.85, blue: 0.1, alpha: 1)
    case "Kim Tiền Báo":
      s.coat = "leopard"; s.bodyLen = 1.0; s.bodyH = 0.21; s.bodyW = 0.16; s.legLen = 0.36; s.legR = 0.055; s.neckLen = 0.22; s.neckR = 0.12
      s.headS = 0.95; s.tailLen = 0.95; s.tailR = 0.035; s.roam = 1.2; s.cycles = 21
    case "Báo Trắng":
      s.coat = "snow"; s.bodyLen = 1.0; s.bodyH = 0.21; s.bodyW = 0.16; s.legLen = 0.36; s.legR = 0.055; s.neckLen = 0.22; s.neckR = 0.12
      s.headS = 0.95; s.tailLen = 1.0; s.tailR = 0.04; s.roam = 1.2; s.cycles = 21; s.eye = UIColor(red: 0.5, green: 0.8, blue: 0.9, alpha: 1)
    case "Sói Xám", "Sói Đỏ", "Sói Xanh", "Sói Tuyết":
      s.coat = id == "Sói Xám" ? "wolfgrey" : id == "Sói Đỏ" ? "wolfred" : id == "Sói Xanh" ? "wolfblue" : "wolfsnow"
      s.bodyLen = 1.0; s.bodyH = 0.2; s.bodyW = 0.14; s.legLen = 0.5; s.legR = 0.048; s.neckLen = 0.22; s.neckRise = 0.08; s.neckR = 0.11
      s.head = "wolf"; s.headS = 1.15; s.headPitch = 0.1; s.tail = "bushy"; s.tailLen = 0.6; s.tailR = 0.05; s.extra = "ruff"
      s.roam = 1.6; s.cycles = 21; s.eye = UIColor(red: 0.95, green: 0.75, blue: 0.2, alpha: 1)
      if id == "Sói Đỏ" { s.eye = UIColor(red: 1, green: 0.3, blue: 0.1, alpha: 1) }
      if id == "Sói Xanh" || id == "Sói Tuyết" { s.eye = UIColor(red: 0.5, green: 0.85, blue: 1, alpha: 1) }
    case "Hồ Ly":
      s.coat = "fox"; s.bodyLen = 0.55; s.bodyH = 0.11; s.bodyW = 0.085; s.legLen = 0.26; s.legR = 0.03; s.neckLen = 0.13; s.neckRise = 0.05
      s.neckR = 0.065; s.head = "fox"; s.headS = 0.62; s.headPitch = 0.1; s.tail = "bushy"; s.tailLen = 0.5; s.tailR = 0.05; s.extra = "ruff"
      s.roam = 1.0; s.period = 12; s.cycles = 20; s.eye = UIColor(red: 0.3, green: 0.2, blue: 0.05, alpha: 1)
    case "Heo Rừng", "Heo Trắng":
      s.coat = id == "Heo Rừng" ? "boar" : "pig"
      s.bodyLen = 0.95; s.bodyH = 0.3; s.bodyW = 0.26; s.legLen = 0.32; s.legR = 0.055; s.hind = false; s.neckLen = 0.1; s.neckRise = 0.0
      s.neckR = 0.25; s.head = "boar"; s.headS = 1.0; s.headPitch = 0.28; s.tail = "short"; s.tailLen = 0.22; s.tailR = 0.014
      s.feet = "hoof"; s.extra = id == "Heo Rừng" ? "bristle" : ""; s.roam = 1.3; s.period = 15; s.cycles = 22; s.legAmp = 0.45
      s.eye = id == "Heo Rừng" ? UIColor(red: 0.85, green: 0.25, blue: 0.1, alpha: 1) : UIColor(red: 0.1, green: 0.07, blue: 0.05, alpha: 1)
    case "Hươu Đốm":
      s.coat = "deer"; s.bodyLen = 0.85; s.bodyH = 0.17; s.bodyW = 0.125; s.legLen = 0.72; s.legR = 0.034; s.neckLen = 0.3; s.neckRise = 0.38
      s.neckR = 0.07; s.head = "deer"; s.headS = 1.0; s.headPitch = 0.55; s.tail = "short"; s.tailLen = 0.16; s.tailR = 0.03
      s.feet = "hoof"; s.roam = 1.8; s.period = 18; s.cycles = 20; s.legAmp = 0.42; s.eye = UIColor(red: 0.12, green: 0.07, blue: 0.04, alpha: 1)
    case "Kim Miêu":
      s.coat = "goldcat"; s.bodyLen = 0.5; s.bodyH = 0.1; s.bodyW = 0.08; s.legLen = 0.16; s.legR = 0.026; s.neckLen = 0.1; s.neckR = 0.06
      s.headS = 0.5; s.tailLen = 0.42; s.tailR = 0.02; s.roam = 0.8; s.period = 11; s.cycles = 18; s.eye = UIColor(red: 0.3, green: 0.85, blue: 0.3, alpha: 1)
    case "Nhím":
      s.coat = "porc"; s.bodyLen = 0.55; s.bodyH = 0.16; s.bodyW = 0.14; s.legLen = 0.1; s.legR = 0.03; s.hind = false; s.neckLen = 0.08; s.neckR = 0.09
      s.neckRise = 0; s.head = "porc"; s.headS = 1.0; s.headPitch = 0.15; s.tail = "short"; s.tailLen = 0.1; s.tailR = 0.02; s.extra = "quills"
      s.roam = 0.8; s.period = 14; s.cycles = 22; s.legAmp = 0.5; s.eye = UIColor(red: 0.05, green: 0.04, blue: 0.03, alpha: 1)
    case "Đại Tượng (Boss)":
      s.coat = "elephant"; s.bodyLen = 2.2; s.bodyH = 0.85; s.bodyW = 0.66; s.legLen = 1.05; s.legR = 0.24; s.hind = false; s.neckLen = 0.35
      s.neckRise = 0.1; s.neckR = 0.5; s.head = "elephant"; s.headS = 1.0; s.headPitch = 0.1; s.tail = "short"; s.tailLen = 0.9; s.tailR = 0.035
      s.feet = "foot"; s.roam = 3.5; s.period = 42; s.cycles = 30; s.legAmp = 0.3; s.eye = UIColor(red: 0.1, green: 0.07, blue: 0.05, alpha: 1)
    default: return nil
    }
    return s
  }

  // ---------------------------------------------------------------- vật liệu
  func bcol(_ key: String, _ c: UIColor, spec: CGFloat = 0.1, shine: CGFloat = 0.2) -> SCNMaterial {
    let k = "BC:" + key
    if let m = leafMats[k] { return m }
    let m = SCNMaterial(); m.diffuse.contents = c; m.lightingModel = .blinn
    m.specular.contents = UIColor(white: spec, alpha: 1); m.shininess = shine; m.isDoubleSided = true; m.name = k
    leafMats[k] = m; return m
  }
  func bcol(_ key: String, _ r: CGFloat, _ g: CGFloat, _ b: CGFloat, spec: CGFloat = 0.1, shine: CGFloat = 0.2) -> SCNMaterial {
    return bcol(key, UIColor(red: r, green: g, blue: b, alpha: 1), spec: spec, shine: shine)
  }
  func beastMat(_ key: String, tail: Bool = false) -> SCNMaterial {
    let k = "B:\(key):\(tail ? 1 : 0)"
    if let m = leafMats[k] { return m }
    var img = Game.beastImgs[k]
    if img == nil {
      img = UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256), format: Game.fmtTex).image { c in beastDraw(key, tail, c.cgContext) }
      Game.beastImgs[k] = img
    }
    let m = mat(img!, 1, 1); m.name = k; m.isDoubleSided = true
    m.specular.contents = UIColor(white: key == "elephant" || key == "pig" ? 0.04 : 0.12, alpha: 1); m.shininess = 0.15
    if key == "fire" { m.emission.contents = img!; m.emission.intensity = 0.45 }
    leafMats[k] = m; return m
  }

  func beastPalette(_ key: String) -> (UIColor, UIColor, UIColor, String, UIColor?) {
    func c(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { return UIColor(red: r, green: g, blue: b, alpha: 1) }
    switch key {
    case "tiger": return (c(0.9, 0.56, 0.16), c(0.97, 0.92, 0.78), c(0.08, 0.05, 0.03), "stripes", c(0.08, 0.05, 0.03))
    case "tiger2": return (c(0.8, 0.42, 0.12), c(0.95, 0.86, 0.68), c(0.07, 0.04, 0.02), "stripes", c(0.07, 0.04, 0.02))
    case "white": return (c(0.93, 0.93, 0.91), c(0.99, 0.99, 0.98), c(0.3, 0.33, 0.38), "stripes", c(0.25, 0.27, 0.3))
    case "fire": return (c(0.82, 0.18, 0.05), c(1, 0.62, 0.18), c(0.14, 0.02, 0.02), "stripes", c(0.14, 0.02, 0.02))
    case "leopard": return (c(0.84, 0.68, 0.36), c(0.96, 0.91, 0.76), c(0.12, 0.08, 0.04), "rosettes", c(0.12, 0.08, 0.04))
    case "snow": return (c(0.84, 0.85, 0.86), c(0.96, 0.96, 0.96), c(0.3, 0.32, 0.36), "rosettes", c(0.3, 0.32, 0.36))
    case "wolfgrey": return (c(0.52, 0.5, 0.47), c(0.86, 0.83, 0.77), c(0.16, 0.15, 0.14), "fur", c(0.14, 0.13, 0.12))
    case "wolfred": return (c(0.66, 0.3, 0.14), c(0.92, 0.78, 0.58), c(0.28, 0.1, 0.05), "fur", c(0.25, 0.08, 0.04))
    case "wolfblue": return (c(0.36, 0.5, 0.58), c(0.8, 0.88, 0.9), c(0.12, 0.2, 0.26), "fur", c(0.1, 0.17, 0.22))
    case "wolfsnow": return (c(0.9, 0.92, 0.96), c(1, 1, 1), c(0.58, 0.64, 0.74), "fur", c(0.55, 0.6, 0.7))
    case "fox": return (c(0.9, 0.42, 0.1), c(0.99, 0.96, 0.9), c(0.35, 0.12, 0.04), "fur", c(0.99, 0.97, 0.93))
    case "boar": return (c(0.24, 0.18, 0.14), c(0.36, 0.28, 0.22), c(0.08, 0.06, 0.05), "bristle", c(0.08, 0.06, 0.05))
    case "pig": return (c(0.94, 0.85, 0.83), c(0.98, 0.92, 0.9), c(0.8, 0.62, 0.6), "plain", nil)
    case "deer": return (c(0.74, 0.46, 0.22), c(0.96, 0.92, 0.84), c(0.3, 0.17, 0.08), "spots", c(0.97, 0.95, 0.9))
    case "goldcat": return (c(0.92, 0.72, 0.22), c(0.99, 0.92, 0.66), c(0.5, 0.3, 0.08), "fur", c(0.45, 0.27, 0.07))
    case "elephant": return (c(0.5, 0.5, 0.52), c(0.62, 0.6, 0.6), c(0.2, 0.2, 0.22), "wrinkle", nil)
    case "porc": return (c(0.36, 0.26, 0.19), c(0.62, 0.52, 0.42), c(0.12, 0.08, 0.05), "fur", nil)
    default: return (c(0.5, 0.5, 0.5), c(0.8, 0.8, 0.8), c(0.2, 0.2, 0.2), "fur", nil)
    }
  }

  /// Texture lông: trục x chạy dọc thân, trục y quanh thân (y = 0 và y = 256 là sống lưng, y = 128 là bụng). Đối xứng nên không lộ đường nối.
  func beastDraw(_ key: String, _ tail: Bool, _ g: CGContext) {
    let S: CGFloat = 256
    let (base, belly, dark, pat, tip) = beastPalette(key)
    var seed: UInt64 = 7
    for u in key.unicodeScalars { seed = seed &* 31 &+ UInt64(u.value) }
    var r = RNG(s: seed &+ (tail ? 99 : 0))
    func R(_ a: CGFloat, _ b: CGFloat) -> CGFloat { return CGFloat(r.f(Float(a), Float(b))) }
    func mirror(_ body: () -> Void) {
      body()
      g.saveGState(); g.translateBy(x: 0, y: S); g.scaleBy(x: 1, y: -1); body(); g.restoreGState()
    }
    // nền: lưng -> bụng
    func grad(_ y0: CGFloat, _ y1: CGFloat) {
      let cols = [base.cgColor, base.cgColor, belly.cgColor] as CFArray
      guard let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: cols, locations: [0, 0.5, 1]) else { return }
      g.saveGState(); g.clip(to: CGRect(x: 0, y: min(y0, y1), width: S, height: abs(y1 - y0)))
      g.drawLinearGradient(gr, start: CGPoint(x: 0, y: y0), end: CGPoint(x: 0, y: y1), options: [])
      g.restoreGState()
    }
    grad(0, 128); grad(256, 128)
    switch pat {
    case "stripes":
      mirror {
        for i in 0..<15 {
          let x = (CGFloat(i) + R(0.1, 0.9)) * S / 15
          let ln = R(55, 118), wd = R(5, 10), sw = R(-9, 9)
          g.setFillColor(dark.withAlphaComponent(0.93).cgColor)
          g.beginPath()
          g.move(to: CGPoint(x: x - wd, y: -4))
          g.addQuadCurve(to: CGPoint(x: x + sw, y: ln), control: CGPoint(x: x - wd * 0.3 + sw * 0.5, y: ln * 0.5))
          g.addQuadCurve(to: CGPoint(x: x + wd, y: -4), control: CGPoint(x: x + wd * 0.5 + sw * 0.5, y: ln * 0.45))
          g.closePath(); g.fillPath()
          if R(0, 1) > 0.4 {   // vằn phụ ngắn giữa hai vằn lớn
            let x2 = x + S / 30, l2 = R(25, 60)
            g.beginPath(); g.move(to: CGPoint(x: x2 - 3, y: -2))
            g.addQuadCurve(to: CGPoint(x: x2 + 2, y: l2), control: CGPoint(x: x2, y: l2 * 0.5))
            g.addQuadCurve(to: CGPoint(x: x2 + 3, y: -2), control: CGPoint(x: x2 + 3, y: l2 * 0.5))
            g.closePath(); g.fillPath()
          }
        }
      }
    case "rosettes":
      mirror {
        for _ in 0..<48 {
          let x = R(0, S), y = R(6, 112), rad = R(4.5, 8.5)
          g.setFillColor(dark.withAlphaComponent(0.16).cgColor); g.fillEllipse(in: CGRect(x: x - rad, y: y - rad * 0.8, width: rad * 2, height: rad * 1.6))
          g.setStrokeColor(dark.cgColor); g.setLineWidth(2.6); g.strokeEllipse(in: CGRect(x: x - rad, y: y - rad * 0.8, width: rad * 2, height: rad * 1.6))
        }
        for _ in 0..<70 {
          let x = R(0, S), y = R(4, 122), rd = R(1.2, 2.6)
          g.setFillColor(dark.cgColor); g.fillEllipse(in: CGRect(x: x - rd, y: y - rd, width: rd * 2, height: rd * 2))
        }
      }
    case "spots":
      mirror {
        g.setFillColor(dark.withAlphaComponent(0.55).cgColor); g.fill(CGRect(x: 0, y: 0, width: S, height: 6))
        for _ in 0..<80 {
          let x = R(0, S), y = R(4, 96), rd = R(2.2, 4.2)
          g.setFillColor(tip!.withAlphaComponent(0.95).cgColor); g.fillEllipse(in: CGRect(x: x - rd, y: y - rd * 0.85, width: rd * 2, height: rd * 1.7))
        }
      }
    case "fur", "bristle":
      let n = pat == "bristle" ? 1300 : 800
      for i in 0..<n {
        let x = R(0, S), y = R(0, S), ln = R(8, 22)
        let col = i % 3 == 0 ? belly : dark
        g.setStrokeColor(col.withAlphaComponent(pat == "bristle" ? 0.22 : 0.13).cgColor); g.setLineWidth(pat == "bristle" ? 1.6 : 1.2)
        g.move(to: CGPoint(x: x, y: y)); g.addLine(to: CGPoint(x: x + ln, y: y + R(-3, 3))); g.strokePath()
      }
      // yên lưng sẫm
      let sad = [dark.withAlphaComponent(0.5).cgColor, dark.withAlphaComponent(0).cgColor] as CFArray
      if let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: sad, locations: [0, 1]) {
        mirror { g.saveGState(); g.clip(to: CGRect(x: 0, y: 0, width: S, height: 64)); g.drawLinearGradient(gr, start: CGPoint(x: 0, y: 0), end: CGPoint(x: 0, y: 64), options: []); g.restoreGState() }
      }
    case "wrinkle":
      for _ in 0..<170 {
        let x = R(0, S), y = R(0, S), ln = R(14, 46)
        g.setStrokeColor(dark.withAlphaComponent(R(0.18, 0.4)).cgColor); g.setLineWidth(R(1, 2.2))
        g.move(to: CGPoint(x: x, y: y)); g.addQuadCurve(to: CGPoint(x: x + R(-8, 8), y: y + ln), control: CGPoint(x: x + R(-14, 14), y: y + ln * 0.5)); g.strokePath()
      }
      for i in 0..<32 {   // nếp da quanh vòi / chân
        let x = CGFloat(i) * S / 32 + R(-2, 2)
        g.setStrokeColor(dark.withAlphaComponent(0.28).cgColor); g.setLineWidth(1.4)
        g.move(to: CGPoint(x: x, y: 0)); g.addLine(to: CGPoint(x: x + R(-3, 3), y: S)); g.strokePath()
      }
    default:   // plain (heo trắng): vết hồng
      for _ in 0..<40 {
        let x = R(0, S), y = R(0, S), rd = R(6, 16)
        g.setFillColor(dark.withAlphaComponent(0.1).cgColor); g.fillEllipse(in: CGRect(x: x - rd, y: y - rd, width: rd * 2, height: rd * 1.4))
      }
    }
    // nhiễu lông mịn chung
    for i in 0..<900 {
      let x = R(0, S), y = R(0, S)
      g.setFillColor((i % 2 == 0 ? UIColor.white : UIColor.black).withAlphaComponent(0.05).cgColor)
      g.fill(CGRect(x: x, y: y, width: 2, height: 1.4))
    }
    // đuôi: đầu đuôi đổi màu
    if tail, let tp = tip {
      let cols = [tp.withAlphaComponent(0).cgColor, tp.cgColor] as CFArray
      if let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: cols, locations: [0, 1]) {
        g.drawLinearGradient(gr, start: CGPoint(x: S * 0.72, y: 0), end: CGPoint(x: S * 0.86, y: 0), options: [.drawsAfterEndLocation])
      }
    }
  }

  // ---------------------------------------------------------------- hình học: ống nội suy
  func bCrom(_ p0: V3, _ p1: V3, _ p2: V3, _ p3: V3, _ t: Float) -> V3 {
    let t2 = t * t, t3 = t2 * t
    let a = p1 * 2
    let b = (p2 - p0) * t
    let c0 = p0 * 2 - p1 * 5
    let c1 = p2 * 4 - p3
    let c = (c0 + c1) * t2
    let d0 = p1 * 3 - p0
    let d1 = p3 - p2 * 3
    let d = (d0 + d1) * t3
    return (a + b + c + d) * 0.5
  }
  func bGeo(_ P: [V3], _ N: [V3], _ UV: [SIMD2<Float>], _ I: [Int32]) -> SCNGeometry {
    let nn = N.map { n -> SCNVector3 in
      let l = simd_length(n); let u: V3 = l > 1e-8 ? n / l : V3(0, 1, 0); return SCNVector3(u.x, u.y, u.z) }
    let src = SCNGeometrySource(vertices: P.map { SCNVector3($0.x, $0.y, $0.z) })
    let nor = SCNGeometrySource(normals: nn)
    let tex = SCNGeometrySource(textureCoordinates: UV.map { CGPoint(x: CGFloat($0.x), y: CGFloat($0.y)) })
    return SCNGeometry(sources: [src, nor, tex], elements: [SCNGeometryElement(indices: I, primitiveType: .triangles)])
  }
  func bMeshGeo(_ b: BMesh) -> SCNGeometry { return bGeo(b.P, b.N, b.UV, b.I) }

  /// Ống tròn / elip đi qua các điểm (Catmull-Rom), bán kính hai trục. u chạy dọc ống từ u0 tới u1, v quanh ống.
  func bLoft(_ pts: [V3], _ rx: [Float], _ ry: [Float], side: V3 = V3(1, 0, 0), samples: Int = 5, seg: Int = 14, u0: Float = 0, u1: Float = 1) -> SCNGeometry {
    let n = pts.count
    var PP = [V3](), RR = [V3]()
    PP.append(pts[0]); PP.append(contentsOf: pts); PP.append(pts[n - 1])
    RR.append(V3(rx[0], ry[0], 0))
    for i in 0..<n { RR.append(V3(rx[i], ry[i], 0)) }
    RR.append(V3(rx[n - 1], ry[n - 1], 0))
    var cen = [V3](), rad = [V3]()
    for sg in 0..<(n - 1) {
      for k in 0..<samples {
        let t = Float(k) / Float(samples)
        cen.append(bCrom(PP[sg], PP[sg + 1], PP[sg + 2], PP[sg + 3], t))
        rad.append(bCrom(RR[sg], RR[sg + 1], RR[sg + 2], RR[sg + 3], t))
      }
    }
    cen.append(pts[n - 1]); rad.append(RR[n])
    let m = cen.count
    var cum = [Float](repeating: 0, count: m)
    for i in 1..<m { cum[i] = cum[i - 1] + simd_length(cen[i] - cen[i - 1]) }
    let total = max(cum[m - 1], 0.0001)
    var C = [V3](), AX = [V3](), AY = [V3](), U = [Float]()
    for i in 0..<m {
      let a = cen[max(i - 1, 0)], b = cen[min(i + 1, m - 1)]
      var T = b - a
      if simd_length(T) < 1e-6 { T = V3(0, 0, 1) }
      T = simd_normalize(T)
      var ax = side - T * simd_dot(side, T)
      if simd_length(ax) < 1e-3 { let alt = V3(0, 0, 1); ax = alt - T * simd_dot(alt, T) }
      if simd_length(ax) < 1e-3 { let alt = V3(0, 1, 0); ax = alt - T * simd_dot(alt, T) }
      ax = simd_normalize(ax)
      let ay = simd_cross(T, ax)
      C.append(cen[i]); AX.append(ax * max(rad[i].x, 0.0005)); AY.append(ay * max(rad[i].y, 0.0005))
      U.append(u0 + (u1 - u0) * cum[i] / total)
    }
    // nắp hai đầu: vòng bán kính 0 cùng tâm
    C.insert(C[0], at: 0); AX.insert(V3.zero, at: 0); AY.insert(V3.zero, at: 0); U.insert(U[0], at: 0)
    C.append(C[C.count - 1]); AX.append(V3.zero); AY.append(V3.zero); U.append(U[U.count - 1])
    let rc = C.count, rn = seg + 1
    var Pv = [V3](), UVv = [SIMD2<Float>](), Iv = [Int32]()
    Pv.reserveCapacity(rc * rn)
    for i in 0..<rc {
      for j in 0..<rn {
        let ph = Float(j) / Float(seg) * 2 * Float.pi
        let off = AX[i] * sin(ph) + AY[i] * cos(ph)
        Pv.append(C[i] + off)
        UVv.append(SIMD2<Float>(U[i], Float(j) / Float(seg)))
      }
    }
    for i in 0..<(rc - 1) {
      for j in 0..<seg {
        let a = Int32(i * rn + j), b = a + 1, c = a + Int32(rn), d = c + 1
        Iv.append(a); Iv.append(c); Iv.append(b); Iv.append(b); Iv.append(c); Iv.append(d)
      }
    }
    var N = [V3](repeating: V3.zero, count: Pv.count)
    var t = 0
    while t < Iv.count {
      let a = Int(Iv[t]), b = Int(Iv[t + 1]), c = Int(Iv[t + 2])
      let nn = simd_cross(Pv[b] - Pv[a], Pv[c] - Pv[a])
      N[a] += nn; N[b] += nn; N[c] += nn; t += 3
    }
    for i in 0..<rc { let sm = N[i * rn] + N[i * rn + seg]; N[i * rn] = sm; N[i * rn + seg] = sm }
    return bGeo(Pv, N, UVv, Iv)
  }
  func bTube(_ pts: [V3], _ r: [Float], seg: Int = 8, samples: Int = 4) -> SCNGeometry {
    return bLoft(pts, r, r, samples: samples, seg: seg)
  }
  func bTubeNode(_ pts: [V3], _ r: [Float], _ m: SCNMaterial, at p: V3 = V3.zero, seg: Int = 8) -> SCNNode {
    let g = bTube(pts, r, seg: seg); g.firstMaterial = m
    let n = SCNNode(geometry: g); n.position = SCNVector3(p.x, p.y, p.z); return n
  }
  /// tai voi: tấm phẳng hơi võng, s = +1 phải / -1 trái
  func bEar(_ w: Float, _ h: Float, _ cup: Float, _ s: Float) -> SCNGeometry {
    var P = [V3](), UV = [SIMD2<Float>](), I = [Int32]()
    let ra = 5, an = 22
    let cx = s * w * 0.9, cy = -h * 0.15
    for k in 0...ra {
      let f = Float(k) / Float(ra)
      for j in 0...an {
        let th = Float(j) / Float(an) * 2 * Float.pi
        let x = cx + s * w * f * cos(th), y = cy + h * f * sin(th)
        let z = -cup * f * f + 0.03 * h * sin(th * 3) * f
        P.append(V3(x, y, z)); UV.append(SIMD2<Float>(0.1 + 0.3 * f * (0.5 + 0.5 * cos(th)), 0.1 + 0.3 * f * (0.5 + 0.5 * sin(th))))
      }
    }
    for k in 0..<ra {
      for j in 0..<an {
        let a = Int32(k * (an + 1) + j), b = a + 1, c = a + Int32(an + 1), d = c + 1
        if s > 0 { I += [a, b, c, b, d, c] } else { I += [a, c, b, b, c, d] }
      }
    }
    var N = [V3](repeating: V3.zero, count: P.count)
    var t = 0
    while t < I.count {
      let a = Int(I[t]), b = Int(I[t + 1]), c = Int(I[t + 2])
      let nn = simd_cross(P[b] - P[a], P[c] - P[a]); N[a] += nn; N[b] += nn; N[c] += nn; t += 3
    }
    return bGeo(P, N, UV, I)
  }

  // ---------------------------------------------------------------- khối nhỏ
  func bSph(_ r: Float, _ p: V3, _ m: SCNMaterial, scale: V3 = V3(1, 1, 1), seg: Int = 16) -> SCNNode {
    let g = SCNSphere(radius: CGFloat(r)); g.segmentCount = seg; g.firstMaterial = m
    let n = SCNNode(geometry: g); n.position = SCNVector3(p.x, p.y, p.z); n.scale = SCNVector3(scale.x, scale.y, scale.z); return n
  }
  func bConeGeo(_ r: Float, _ h: Float, _ m: SCNMaterial) -> SCNGeometry {
    let c = SCNCone(topRadius: 0, bottomRadius: CGFloat(r), height: CGFloat(h)); c.radialSegmentCount = 12; c.firstMaterial = m; return c
  }
  /// túm lông nhọn: pivot quay quanh y (yaw) rồi lá nghiêng quanh x (pitch)
  func btuft(_ m: SCNMaterial, _ L: Float, _ W: Float, _ arch: Float, at p: V3, yaw: Float, pitch: Float) -> SCNNode {
    let piv = SCNNode(); piv.position = SCNVector3(p.x, p.y, p.z); piv.eulerAngles.y = yaw
    let lf = SCNNode(geometry: leafGeo(L, W, arch, 0.1, m)); lf.eulerAngles.x = pitch
    piv.addChildNode(lf); return piv
  }

  // ---------------------------------------------------------------- dựng cả con
  func beastModel(_ id: String) -> SCNNode? {
    guard let s = beastSpec(id) else { return nil }
    let root = SCNNode()
    let roam = SCNNode(); roam.name = "roam:\(s.roam):\(s.period):\(s.legAmp):\(s.cycles)"
    roam.addChildNode(quadruped(s, id))
    root.addChildNode(roam)
    return root
  }

  func quadruped(_ s: BeastSpec, _ id: String) -> SCNNode {
    let g = SCNNode()
    var r = RNG(s: 4242)
    let coat = beastMat(s.coat), tailM = beastMat(s.coat, tail: true)
    let L = s.bodyLen, h = s.bodyH, w = s.bodyW, ll = s.legLen
    // ----- thân: các vòng cắt từ hông (z âm) tới vai (z dương)
    let prof: [[Float]] = [[-0.62, 0.62, 0.62, 0.10], [-0.50, 0.92, 0.92, 0.04], [-0.25, 0.92, 0.88, 0.05], [0.0, 0.84, 0.82, 0.09],
                           [0.28, 0.98, 0.94, 0.03], [0.50, 1.0, 0.96, 0.0], [0.66, 0.84, 0.8, 0.06], [0.76, 0.58, 0.58, 0.14]]
    var bp = [V3](), bx = [Float](), by = [Float]()
    for q in prof {
      let ry = h * q[1]
      bp.append(V3(0, ll + h * q[3] * 2 + ry, L * q[0])); bx.append(w * q[2]); by.append(ry)
    }
    func bodyAt(_ z: Float) -> (y: Float, rx: Float, ry: Float) {
      if z <= bp[0].z { return (bp[0].y, bx[0], by[0]) }
      for i in 1..<bp.count {
        if z <= bp[i].z {
          let t = (z - bp[i - 1].z) / (bp[i].z - bp[i - 1].z)
          return (bp[i - 1].y + (bp[i].y - bp[i - 1].y) * t, bx[i - 1] + (bx[i] - bx[i - 1]) * t, by[i - 1] + (by[i] - by[i - 1]) * t)
        }
      }
      let k = bp.count - 1; return (bp[k].y, bx[k], by[k])
    }
    let bodyGeo = bLoft(bp, bx, by, samples: 5, seg: 18, u0: 0, u1: 1); bodyGeo.firstMaterial = coat
    g.addChildNode(SCNNode(geometry: bodyGeo))
    // ----- cổ
    let ny0 = ll + h * 1.05, nz0 = L * 0.48
    let np: [V3] = [V3(0, ny0, nz0), V3(0, ny0 + s.neckRise * 0.45 + h * 0.1, nz0 + s.neckLen * 0.5), V3(0, ny0 + s.neckRise + h * 0.1, nz0 + s.neckLen)]
    let nr = s.neckR
    let neckGeo = bLoft(np, [nr * 1.1, nr, nr * 0.85], [nr * 1.15, nr * 1.05, nr * 0.9], samples: 5, seg: 16, u0: 0.7, u1: 1.0); neckGeo.firstMaterial = coat
    g.addChildNode(SCNNode(geometry: neckGeo))
    // ----- đầu
    let head = beastHead(s, id, coat)
    head.position = SCNVector3(np[2].x, np[2].y, np[2].z); head.eulerAngles.x = s.headPitch
    g.addChildNode(head)
    // ----- chân
    let hipY = ll + h * 0.6, xs = w * 0.72, zf = L * 0.38, zh = -L * 0.40
    let legPos: [(Int, Float, Float, Bool)] = [(0, xs, zf, true), (1, -xs, zf, true), (2, xs, zh, false), (3, -xs, zh, false)]
    for lp in legPos {
      let leg = beastLeg(s, coat, front: lp.3, hipY: hipY, id: id)
      leg.position = SCNVector3(lp.1, hipY, lp.2); leg.name = "leg:\(lp.0)"
      g.addChildNode(leg)
    }
    // ----- đuôi
    if s.tail != "none" {
      let T = s.tailLen, tr = s.tailR
      let y0 = ll + h * 0.9, z0 = -L * 0.58
      var tp = [V3](), trr = [Float]()
      switch s.tail {
      case "long":
        tp = [V3(0, 0, 0), V3(0, -0.02, -0.30 * T), V3(0, -0.10 * T, -0.65 * T), V3(0, -0.08 * T, -0.92 * T), V3(0, 0.05 * T, -T)]
        trr = [tr, tr * 0.95, tr * 0.85, tr * 0.8, tr * 0.55]
      case "bushy":
        tp = [V3(0, 0, 0), V3(0, -0.04 * T, -0.28 * T), V3(0, -0.14 * T, -0.58 * T), V3(0, -0.3 * T, -0.82 * T), V3(0, -0.42 * T, -0.95 * T)]
        trr = [tr * 0.5, tr * 1.0, tr * 1.55, tr * 1.4, tr * 0.5]
      default:
        tp = [V3(0, 0, 0), V3(0, -0.3 * T, -0.25 * T), V3(0, -0.7 * T, -0.3 * T), V3(0, -T, -0.28 * T)]
        trr = [tr * 1.3, tr * 1.1, tr * 0.9, tr * 0.8]
      }
      let tg = bLoft(tp, trr, trr, samples: 5, seg: 12, u0: 0, u1: 1); tg.firstMaterial = tailM
      let tn = SCNNode(); tn.position = SCNVector3(0, y0, z0); tn.name = "tail"
      tn.addChildNode(SCNNode(geometry: tg))
      if s.coat == "elephant" { tn.addChildNode(bSph(0.05, tp[tp.count - 1] + V3(0, -0.04, 0), bcol("tuft", 0.14, 0.13, 0.13), scale: V3(0.8, 1.6, 0.8))) }
      g.addChildNode(tn)
    }
    // ----- chi tiết thêm theo loài
    if s.extra == "ruff" {   // bờm cổ
      let mid = V3(0, ny0 + s.neckRise * 0.4 + h * 0.1, nz0 + s.neckLen * 0.35)
      for k in 0..<18 {
        let a = Float(k) / 18 * 2 * Float.pi
        let pz = SCNNode(); pz.position = SCNVector3(mid.x, mid.y, mid.z + Float(k % 3) * 0.04); pz.eulerAngles.z = -a
        pz.addChildNode(btuft(coat, 0.13 * s.headS, 0.05 * s.headS, -0.15, at: V3(0, nr * 0.85, 0), yaw: Float.pi, pitch: -0.35))
        g.addChildNode(pz)
      }
    }
    if s.extra == "bristle" {   // lông gáy dựng đứng dọc sống lưng
      for k in 0..<22 {
        let z = L * (0.74 - Float(k) / 21 * 1.15)
        let ba = bodyAt(z)
        let yy = ba.y + ba.ry * 0.96
        g.addChildNode(btuft(bcol("bristle", 0.07, 0.05, 0.04), 0.11, 0.035, -0.1, at: V3(r.f(-0.02, 0.02), yy, z), yaw: 0, pitch: -1.9))
      }
    }
    if s.extra == "quills" {   // lông nhím
      let g1 = bConeGeo(0.007, 0.16, quillMat()), g2 = bConeGeo(0.008, 0.2, quillMat()), g3 = bConeGeo(0.009, 0.25, quillMat())
      let geos = [g1, g2, g3]
      for k in 0..<110 {
        let z = L * r.f(-0.55, 0.62)
        let ba = bodyAt(z)
        let fx = r.f(-0.95, 0.95)
        let x = fx * ba.rx
        let yy = ba.y + ba.ry * sqrt(max(0.05, 1 - fx * fx)) * 0.97
        let gg = geos[k % 3]
        let hh = Float(k % 3) * 0.04 + 0.16
        let pz = SCNNode(); pz.position = SCNVector3(x, yy, z); pz.eulerAngles.z = -fx * 1.0
        let px = SCNNode(); px.eulerAngles.x = -(0.8 + r.f(0, 0.6))
        let cn = SCNNode(geometry: gg); cn.position = SCNVector3(0, hh / 2, 0)
        px.addChildNode(cn); pz.addChildNode(px); g.addChildNode(pz)
      }
    }
    return g
  }

  func quillMat() -> SCNMaterial {
    let k = "BQ:quill"
    if let m = leafMats[k] { return m }
    let img = UIGraphicsImageRenderer(size: CGSize(width: 16, height: 64), format: Game.fmtTex).image { c in
      let g = c.cgContext
      UIColor(red: 0.16, green: 0.1, blue: 0.07, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 16, height: 64))
      UIColor(red: 0.93, green: 0.9, blue: 0.8, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 18, width: 16, height: 18))
      UIColor(red: 0.12, green: 0.08, blue: 0.06, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 36, width: 16, height: 14))
      UIColor(red: 0.9, green: 0.87, blue: 0.78, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 50, width: 16, height: 14))
    }
    let m = mat(img, 1, 1); m.isDoubleSided = true; m.name = k; leafMats[k] = m; return m
  }

  // ---------------------------------------------------------------- chân
  func beastLeg(_ s: BeastSpec, _ coat: SCNMaterial, front: Bool, hipY: Float, id: String) -> SCNNode {
    let n = SCNNode()
    let R = s.legR
    var pts = [V3](), rr = [Float]()
    if front || !s.hind {
      pts = [V3(0, 0, 0), V3(0, -hipY * 0.42, -0.015), V3(0, -hipY * 0.8, 0), V3(0, -hipY + R * 0.5, 0.01)]
      rr = [1.25, 1.0, 0.72, 0.78]
    } else {
      let b = min(hipY * 0.16, 0.1)
      pts = [V3(0, 0, 0), V3(0, -hipY * 0.34, b), V3(0, -hipY * 0.68, -b * 0.6), V3(0, -hipY + R * 0.5, 0.01)]
      rr = [1.7, 1.0, 0.7, 0.75]
    }
    let rx = rr.map { $0 * R }, ry = rr.map { $0 * R * 0.95 }
    let lg = bLoft(pts, rx, ry, samples: 4, seg: 10, u0: 0.02, u1: 0.3); lg.firstMaterial = coat
    n.addChildNode(SCNNode(geometry: lg))
    let low = -hipY
    switch s.feet {
    case "hoof":
      let hm = bcol("hoof", 0.12, 0.09, 0.07, spec: 0.3, shine: 0.4)
      let bx = SCNBox(width: CGFloat(R * 1.25), height: 0.07, length: CGFloat(R * 1.6), chamferRadius: 0.012); bx.firstMaterial = hm
      let hn = SCNNode(geometry: bx); hn.position = SCNVector3(0, low + 0.035, 0.012); n.addChildNode(hn)
      let cleft = SCNBox(width: 0.004, height: 0.05, length: CGFloat(R * 1.62), chamferRadius: 0); cleft.firstMaterial = bcol("hoofline", 0.03, 0.02, 0.02)
      let cn = SCNNode(geometry: cleft); cn.position = SCNVector3(0, low + 0.04, 0.012); n.addChildNode(cn)
    case "foot":
      let cyl = SCNCylinder(radius: CGFloat(R * 1.15), height: 0.14); cyl.radialSegmentCount = 20; cyl.firstMaterial = coat
      let fn = SCNNode(geometry: cyl); fn.position = SCNVector3(0, low + 0.07, 0.02); n.addChildNode(fn)
      let nail = bcol("nail", 0.76, 0.72, 0.64, spec: 0.2, shine: 0.3)
      for k in 0..<4 {
        let a = (Float(k) - 1.5) * 0.5
        n.addChildNode(bSph(R * 0.2, V3(sin(a) * R * 1.1, low + 0.04, 0.02 + cos(a) * R * 1.1), nail, scale: V3(1, 0.7, 0.8)))
      }
    default:
      n.addChildNode(bSph(R * 0.95, V3(0, low + R * 0.55, 0.01 + R * 0.35), coat, scale: V3(1, 0.55, 1.5)))
      for k in 0..<3 {   // ngón
        let x = (Float(k) - 1) * R * 0.55
        n.addChildNode(bSph(R * 0.38, V3(x, low + R * 0.3, 0.01 + R * 1.35), coat, scale: V3(1, 0.8, 1.1), seg: 10))
        if s.head == "wolf" || s.head == "fox" {   // móng sói / cáo
          let cl = SCNNode(geometry: bConeGeo(R * 0.12, R * 0.5, bcol("claw", 0.12, 0.1, 0.09, spec: 0.3, shine: 0.4)))
          cl.eulerAngles.x = Float.pi / 2 + 0.5; cl.position = SCNVector3(x, low + R * 0.12, 0.01 + R * 1.95); n.addChildNode(cl)
        }
      }
    }
    return n
  }

  // ---------------------------------------------------------------- đầu
  func beastHead(_ s: BeastSpec, _ id: String, _ coat: SCNMaterial) -> SCNNode {
    let head = SCNNode(); head.name = "head"
    let S = s.headS, kind = s.head
    let hp: [[Float]]
    switch kind {
    case "cat":
      hp = [[-0.07, 0.06, 0.07, 0], [0, 0.105, 0.10, 0], [0.07, 0.115, 0.105, -0.005], [0.13, 0.095, 0.085, -0.02], [0.19, 0.075, 0.062, -0.035], [0.23, 0.058, 0.048, -0.04], [0.255, 0.03, 0.03, -0.04]]
    case "wolf":
      hp = [[-0.06, 0.05, 0.06, 0], [0, 0.08, 0.085, 0], [0.07, 0.085, 0.085, 0], [0.14, 0.06, 0.06, -0.015], [0.22, 0.048, 0.045, -0.025], [0.30, 0.04, 0.037, -0.03], [0.34, 0.022, 0.022, -0.03]]
    case "fox":
      hp = [[-0.06, 0.055, 0.06, 0], [0, 0.085, 0.08, 0], [0.07, 0.08, 0.075, -0.005], [0.15, 0.055, 0.05, -0.02], [0.24, 0.04, 0.035, -0.03], [0.32, 0.03, 0.028, -0.035], [0.36, 0.014, 0.014, -0.035]]
    case "boar":
      hp = [[-0.10, 0.09, 0.12, 0], [0, 0.15, 0.17, 0], [0.12, 0.13, 0.15, -0.01], [0.24, 0.10, 0.11, -0.03], [0.36, 0.08, 0.08, -0.05], [0.44, 0.07, 0.07, -0.06], [0.47, 0.06, 0.06, -0.06]]
    case "deer":
      hp = [[-0.06, 0.05, 0.06, 0], [0, 0.075, 0.08, 0], [0.08, 0.07, 0.075, -0.01], [0.17, 0.05, 0.055, -0.03], [0.27, 0.038, 0.04, -0.05], [0.33, 0.03, 0.03, -0.055], [0.35, 0.018, 0.018, -0.055]]
    case "elephant":
      hp = [[-0.22, 0.3, 0.4, 0], [0, 0.42, 0.5, 0], [0.2, 0.38, 0.46, 0], [0.36, 0.25, 0.3, -0.08], [0.46, 0.15, 0.2, -0.17]]
    default:
      hp = [[-0.04, 0.05, 0.055, 0], [0, 0.07, 0.075, 0], [0.06, 0.065, 0.065, -0.01], [0.12, 0.045, 0.045, -0.02], [0.17, 0.03, 0.03, -0.025], [0.19, 0.015, 0.015, -0.025]]
    }
    let pts = hp.map { V3(0, $0[3] * S, $0[0] * S) }
    let rxs = hp.map { $0[1] * S }, rys = hp.map { $0[2] * S }
    let skg = bLoft(pts, rxs, rys, samples: 4, seg: 16, u0: 0.55, u1: 1.0); skg.firstMaterial = coat
    head.addChildNode(SCNNode(geometry: skg))
    func at(_ z: Float) -> (cy: Float, rx: Float, ry: Float) {
      for i in 1..<hp.count {
        if z <= hp[i][0] {
          let t = max(0, min(1, (z - hp[i - 1][0]) / (hp[i][0] - hp[i - 1][0])))
          return (hp[i - 1][3] + (hp[i][3] - hp[i - 1][3]) * t, hp[i - 1][1] + (hp[i][1] - hp[i - 1][1]) * t, hp[i - 1][2] + (hp[i][2] - hp[i - 1][2]) * t)
        }
      }
      let l = hp[hp.count - 1]; return (l[3], l[1], l[2])
    }
    func P(_ x: Float, _ y: Float, _ z: Float) -> V3 { return V3(x * S, y * S, z * S) }
    let pink = bcol("earpink", 0.88, 0.58, 0.58), black = bcol("pupil", 0.02, 0.02, 0.02, spec: 0.9, shine: 0.9)
    let eyeM = bcol("eye:" + id, s.eye, spec: 0.9, shine: 0.9)
    let white = bcol("furwhite", 0.97, 0.94, 0.88)
    let tipZ = hp[hp.count - 1][0], tipY = hp[hp.count - 1][3]

    // mắt chung (z tính theo đơn vị đầu)
    func eyes(_ z: Float, _ yk: Float, _ rad: Float, slit: Bool, shine: Bool) {
      let e = at(z)
      for sd in [Float(-1), 1] {
        let ep = P(sd * e.rx * 0.95, e.cy + e.ry * yk, z)
        head.addChildNode(bSph(rad * S, ep, eyeM, scale: V3(0.6, 1, 1)))
        let pp = ep + V3(sd * rad * S * 0.62, 0, rad * S * 0.2)
        head.addChildNode(bSph(rad * S * 0.55, pp, black, scale: V3(0.5, slit ? 1.5 : 1.1, 1.0), seg: 10))
        if shine { head.addChildNode(bSph(rad * S * 0.22, pp + V3(sd * rad * S * 0.2, rad * S * 0.35, rad * S * 0.35), bcol("glint", 1, 1, 1, spec: 1, shine: 1), seg: 6)) }
      }
    }

    switch kind {
    case "cat":
      for sd in [Float(-1), 1] {   // tai tròn
        let pv = SCNNode(); let pp = P(sd * 0.085, 0.1, -0.02); pv.position = SCNVector3(pp.x, pp.y, pp.z); pv.eulerAngles.z = -sd * 0.3
        pv.name = sd > 0 ? "ear:R" : "ear:L"
        pv.addChildNode(bSph(0.042 * S, V3(0, 0.02 * S, 0), coat, scale: V3(1, 1, 0.4)))
        pv.addChildNode(bSph(0.03 * S, V3(0, 0.018 * S, 0.012 * S), pink, scale: V3(1, 1, 0.4)))
        head.addChildNode(pv)
      }
      eyes(0.115, 0.3, 0.016, slit: true, shine: true)
      let eb = at(0.1)
      for sd in [Float(-1), 1] {   // gò mày
        head.addChildNode(bSph(0.03 * S, P(sd * eb.rx * 0.8, eb.cy + eb.ry * 0.62, 0.095), coat, scale: V3(1, 0.45, 1.4)))
        head.addChildNode(bSph(0.032 * S, P(sd * 0.03, -0.043, 0.205), white, scale: V3(1, 0.8, 1.15)))   // má môi trắng
      }
      head.addChildNode(bSph(0.02 * S, P(0, tipY + 0.008, tipZ - 0.004), bcol("nose", 0.55, 0.25, 0.25, spec: 0.5, shine: 0.6), scale: V3(1.2, 0.8, 0.9)))
      head.addChildNode(bSph(0.036 * S, P(0, -0.05, 0.19), white, scale: V3(1.1, 0.7, 1.2)))   // cằm
      for sd in [Float(-1), 1] {   // ria
        for k in 0..<3 {
          let pv = SCNNode(); let pp = P(sd * 0.045, -0.038 + (Float(k) - 1) * 0.012, 0.2); pv.position = SCNVector3(pp.x, pp.y, pp.z); pv.eulerAngles.y = sd * (0.3 + Float(k) * 0.25)
          let cy = SCNCylinder(radius: CGFloat(0.0012 * S), height: CGFloat(0.13 * S)); cy.firstMaterial = white
          let cn = SCNNode(geometry: cy); cn.eulerAngles.z = Float.pi / 2; cn.position = SCNVector3(sd * 0.065 * S, 0, 0)
          pv.addChildNode(cn); head.addChildNode(pv)
        }
        for k in 0..<5 {   // túm lông má
          head.addChildNode(btuft(coat, 0.085 * S, 0.035 * S, -0.2, at: P(sd * (0.08 + 0.008 * Float(k)), -0.02 - 0.012 * Float(k), 0.04 - 0.02 * Float(k)), yaw: sd * (2.2 + 0.2 * Float(k)), pitch: 0))
        }
      }
      if id.contains("Hổ") {   // nanh
        for sd in [Float(-1), 1] {
          let fn = SCNNode(geometry: bConeGeo(0.008 * S, 0.035 * S, bcol("ivory", 0.95, 0.92, 0.82, spec: 0.5, shine: 0.5)))
          let fp = P(sd * 0.03, -0.062, 0.2); fn.position = SCNVector3(fp.x, fp.y, fp.z); fn.eulerAngles.x = Float.pi; head.addChildNode(fn)
        }
      }
    case "wolf", "fox":
      let big: Float = kind == "fox" ? 1.35 : 1.0
      for sd in [Float(-1), 1] {
        let pv = SCNNode(); let pp = P(sd * 0.05, 0.1, -0.03); pv.position = SCNVector3(pp.x, pp.y, pp.z); pv.eulerAngles.z = -sd * 0.22
        pv.name = sd > 0 ? "ear:R" : "ear:L"
        let oc = SCNNode(geometry: bConeGeo(0.04 * S * big, 0.12 * S * big, coat)); oc.position = SCNVector3(0, 0.06 * S * big, 0); oc.scale = SCNVector3(1, 1, 0.55)
        pv.addChildNode(oc)
        let ic = SCNNode(geometry: bConeGeo(0.028 * S * big, 0.09 * S * big, kind == "fox" ? white : pink)); ic.position = SCNVector3(0, 0.05 * S * big, 0.012 * S); ic.scale = SCNVector3(1, 1, 0.4)
        pv.addChildNode(ic)
        head.addChildNode(pv)
      }
      eyes(0.1, 0.3, 0.014, slit: false, shine: true)
      head.addChildNode(bSph(0.022 * S, P(0, tipY + 0.006, tipZ - 0.004), black, scale: V3(1.2, 0.85, 1.0)))
      for sd in [Float(-1), 1] {
        for k in 0..<4 {
          head.addChildNode(btuft(coat, 0.1 * S, 0.04 * S, -0.2, at: P(sd * (0.07 + 0.008 * Float(k)), -0.02 - 0.012 * Float(k), 0.03 - 0.02 * Float(k)), yaw: sd * (2.2 + 0.2 * Float(k)), pitch: 0))
        }
        head.addChildNode(bSph(0.02 * S, P(sd * 0.022, -0.04, 0.2), white, scale: V3(1, 0.8, 1.6)))   // má trắng
      }
    case "boar":
      for sd in [Float(-1), 1] {
        let pv = SCNNode(); let pp = P(sd * 0.1, 0.16, -0.05); pv.position = SCNVector3(pp.x, pp.y, pp.z); pv.eulerAngles.z = -sd * 0.6
        pv.name = sd > 0 ? "ear:R" : "ear:L"
        let oc = SCNNode(geometry: bConeGeo(0.05 * S, 0.1 * S, coat)); oc.position = SCNVector3(0, 0.05 * S, 0); oc.scale = SCNVector3(1, 1, 0.5)
        pv.addChildNode(oc); head.addChildNode(pv)
      }
      eyes(0.15, 0.3, 0.011, slit: false, shine: true)
      let snoutM = bcol("snout:" + s.coat, s.coat == "pig" ? UIColor(red: 0.9, green: 0.6, blue: 0.6, alpha: 1) : UIColor(red: 0.3, green: 0.22, blue: 0.2, alpha: 1), spec: 0.4, shine: 0.5)
      let dk = SCNCylinder(radius: CGFloat(0.065 * S), height: CGFloat(0.045 * S)); dk.radialSegmentCount = 20; dk.firstMaterial = snoutM
      let dn = SCNNode(geometry: dk); let dp = P(0, -0.06, 0.48); dn.position = SCNVector3(dp.x, dp.y, dp.z); dn.eulerAngles.x = Float.pi / 2; head.addChildNode(dn)
      for sd in [Float(-1), 1] { head.addChildNode(bSph(0.011 * S, P(sd * 0.023, -0.058, 0.503), black, scale: V3(0.8, 1.3, 0.5), seg: 8)) }
      if id == "Heo Rừng" {
        let iv = bcol("ivory", 0.95, 0.92, 0.82, spec: 0.5, shine: 0.5)
        for sd in [Float(-1), 1] {
          let b = P(sd * 0.055, -0.075, 0.36)
          let tp: [V3] = [V3.zero, P(sd * 0.01, 0.01, 0.06), P(sd * 0.02, 0.045, 0.11), P(sd * 0.015, 0.085, 0.125)]
          head.addChildNode(bTubeNode(tp, [0.016 * S, 0.012 * S, 0.007 * S, 0.002 * S], iv, at: b))
        }
        for k in 0..<7 {   // lông trán
          head.addChildNode(btuft(bcol("bristle", 0.07, 0.05, 0.04), 0.1 * S, 0.03 * S, -0.1, at: P((Float(k) - 3) * 0.03, 0.15 + abs(Float(k) - 3) * -0.004, -0.02 + Float(k % 2) * 0.05), yaw: 0, pitch: -1.7))
        }
      }
    case "deer":
      let dkc = bcol("deerdark", 0.18, 0.1, 0.06)
      for sd in [Float(-1), 1] {
        let pv = SCNNode(); let pp = P(sd * 0.055, 0.06, -0.04); pv.position = SCNVector3(pp.x, pp.y, pp.z); pv.eulerAngles.z = -sd * 0.9
        pv.name = sd > 0 ? "ear:R" : "ear:L"
        pv.addChildNode(bSph(0.05 * S, V3(0, 0.03 * S, 0), coat, scale: V3(0.35, 1.0, 0.18)))
        pv.addChildNode(bSph(0.04 * S, V3(0, 0.03 * S, 0.004 * S), pink, scale: V3(0.2, 0.9, 0.12)))
        head.addChildNode(pv)
      }
      eyes(0.1, 0.3, 0.017, slit: false, shine: true)
      head.addChildNode(bSph(0.02 * S, P(0, tipY + 0.004, tipZ - 0.004), dkc, scale: V3(1.2, 0.85, 1.0)))
      let ant = bcol("antler", 0.55, 0.42, 0.3, spec: 0.2, shine: 0.3)
      for sd in [Float(-1), 1] {
        let b = P(sd * 0.03, 0.075, -0.03)
        let beam: [V3] = [V3.zero, P(sd * 0.015, 0.11, -0.04), P(sd * 0.045, 0.22, -0.03), P(sd * 0.08, 0.32, 0.02), P(sd * 0.09, 0.4, 0.07)]
        head.addChildNode(bTubeNode(beam, [0.012 * S, 0.01 * S, 0.008 * S, 0.006 * S, 0.003 * S], ant, at: b))
        let t1: [V3] = [V3.zero, P(sd * 0.01, 0.06, 0.07), P(sd * 0.015, 0.11, 0.12)]
        head.addChildNode(bTubeNode(t1, [0.007 * S, 0.005 * S, 0.002 * S], ant, at: b + beam[1]))
        let t2: [V3] = [V3.zero, P(sd * 0.03, 0.07, 0.05), P(sd * 0.045, 0.12, 0.09)]
        head.addChildNode(bTubeNode(t2, [0.007 * S, 0.005 * S, 0.002 * S], ant, at: b + beam[2]))
        let t3: [V3] = [V3.zero, P(0, 0.05, 0.07)]
        head.addChildNode(bTubeNode(t3, [0.006 * S, 0.002 * S], ant, at: b + beam[3]))
      }
    case "elephant":
      for sd in [Float(-1), 1] {   // tai voi
        let pv = SCNNode(); let pp = P(sd * 0.34, 0.2, -0.05); pv.position = SCNVector3(pp.x, pp.y, pp.z); pv.eulerAngles.y = sd * 0.3
        pv.name = sd > 0 ? "ear:R" : "ear:L"
        let eg = bEar(0.55 * S, 0.5 * S, 0.08 * S, sd); eg.firstMaterial = coat
        pv.addChildNode(SCNNode(geometry: eg)); head.addChildNode(pv)
        head.addChildNode(bSph(0.2 * S, P(sd * 0.12, 0.3, 0.1), coat, scale: V3(1, 0.9, 1)))   // gò trán
      }
      eyes(0.2, 0.15, 0.018, slit: false, shine: true)
      let trunkP: [V3] = [V3.zero, P(0, -0.13, 0.08), P(0, -0.43, 0.13), P(0, -0.78, 0.13), P(0, -1.08, 0.18), P(0, -1.23, 0.3)]
      let tr = bTube(trunkP, [0.2 * S, 0.17 * S, 0.14 * S, 0.115 * S, 0.095 * S, 0.07 * S], seg: 14, samples: 5); tr.firstMaterial = coat
      let trn = SCNNode(geometry: tr); let tpp = P(0, -0.12, 0.42); trn.position = SCNVector3(tpp.x, tpp.y, tpp.z); trn.name = "trunk"
      trn.addChildNode(bSph(0.035 * S, trunkP[5] + P(0, -0.025, 0.03), bcol("nostril", 0.18, 0.12, 0.12), scale: V3(1.3, 0.7, 1.0)))
      head.addChildNode(trn)
      let iv = bcol("ivory", 0.95, 0.92, 0.82, spec: 0.5, shine: 0.5)
      for sd in [Float(-1), 1] {   // ngà
        let tp: [V3] = [V3.zero, P(sd * 0.04, -0.12, 0.18), P(sd * 0.1, -0.2, 0.45), P(sd * 0.14, -0.12, 0.78), P(sd * 0.14, 0.05, 0.95)]
        head.addChildNode(bTubeNode(tp, [0.07 * S, 0.06 * S, 0.045 * S, 0.03 * S, 0.01 * S], iv, at: P(sd * 0.16, -0.22, 0.38), seg: 10))
      }
    default:   // nhím
      for sd in [Float(-1), 1] {
        let pv = SCNNode(); let pp = P(sd * 0.05, 0.07, -0.02); pv.position = SCNVector3(pp.x, pp.y, pp.z); pv.eulerAngles.z = -sd * 0.3
        pv.name = sd > 0 ? "ear:R" : "ear:L"
        pv.addChildNode(bSph(0.025 * S, V3.zero, coat, scale: V3(1, 1, 0.5))); head.addChildNode(pv)
      }
      eyes(0.06, 0.3, 0.01, slit: false, shine: true)
      head.addChildNode(bSph(0.015 * S, P(0, tipY + 0.004, tipZ - 0.003), black))
      for sd in [Float(-1), 1] {
        for k in 0..<3 {
          let pv = SCNNode(); let pp = P(sd * 0.03, -0.02 + (Float(k) - 1) * 0.01, 0.14); pv.position = SCNVector3(pp.x, pp.y, pp.z); pv.eulerAngles.y = sd * (0.3 + Float(k) * 0.25)
          let cy = SCNCylinder(radius: CGFloat(0.001 * S), height: CGFloat(0.08 * S)); cy.firstMaterial = white
          let cn = SCNNode(geometry: cy); cn.eulerAngles.z = Float.pi / 2; cn.position = SCNVector3(sd * 0.04 * S, 0, 0)
          pv.addChildNode(cn); head.addChildNode(pv)
        }
      }
    }
    return head
  }

  // ---------------------------------------------------------------- hoạt ảnh: đi vòng số 8 quanh chỗ đặt, chân bước, đuôi vẫy, tai giật
  /// gọi từ Game.spawn (clone không chắc giữ action nên bật lại cho từng bản đặt)
  func startBeastLife(_ root: SCNNode) {
    var found: SCNNode? = nil
    root.enumerateHierarchy { n, _ in if let nm = n.name, nm.hasPrefix("roam:") { found = n } }
    guard let roam = found, let nm = roam.name else { return }
    let v = nm.split(separator: ":").dropFirst().compactMap { Float($0) }
    guard v.count >= 4 else { return }
    let R = v[0], T = max(v[1], 4), amp = v[2], cyc = v[3]
    let legs: [SCNNode?] = (0..<4).map { roam.childNode(withName: "leg:\($0)", recursively: true) }
    let tail = roam.childNode(withName: "tail", recursively: true)
    let head = roam.childNode(withName: "head", recursively: true)
    let trunk = roam.childNode(withName: "trunk", recursively: true)
    let earL = roam.childNode(withName: "ear:L", recursively: true), earR = roam.childNode(withName: "ear:R", recursively: true)
    let headRest = head?.eulerAngles.x ?? 0
    let earRestL = earL?.eulerAngles.z ?? 0, earRestR = earR?.eulerAngles.z ?? 0
    let off = Float(abs((root.name ?? "x").hashValue % 628)) / 100
    let w = 2 * Float.pi / T
    let vmax = max(R * w * 1.3, 0.001)
    roam.removeAllActions()
    roam.runAction(.repeatForever(.customAction(duration: TimeInterval(T)) { node, el in
      let t = Float(el) + off * T / (2 * Float.pi)
      let a = w * t
      let vx = R * w * cos(a), vz = R * 1.2 * w * cos(2 * a)
      node.position = SCNVector3(R * sin(a), 0, R * 0.6 * sin(2 * a))
      node.eulerAngles.y = atan2(vx, vz)
      let sp = min(1, sqrt(vx * vx + vz * vz) / vmax)
      let k = amp * (0.3 + 0.7 * sp)
      let ph = 2 * Float.pi * cyc * t / T
      legs[0]?.eulerAngles.x = k * sin(ph)
      legs[3]?.eulerAngles.x = k * sin(ph)
      legs[1]?.eulerAngles.x = -k * sin(ph)
      legs[2]?.eulerAngles.x = -k * sin(ph)
      tail?.eulerAngles.y = 0.35 * sin(t * 1.7 + off)
      head?.eulerAngles.x = headRest + 0.05 * sin(ph * 0.5)
      trunk?.eulerAngles.x = 0.1 * sin(t * 0.9)
      let flick = max(0, sin(t * 0.7 + off * 3) - 0.85) * 3
      earL?.eulerAngles.z = earRestL + flick * 0.3
      earR?.eulerAngles.z = earRestR - flick * 0.3
    }))
  }
}
