import SceneKit
import UIKit

// ===== Địa hình thật hơn (Terrain.swift) =====
// • Texture cỏ / đất vẽ bằng nhiễu nhiều tầng (mảng đậm nhạt, sợi cỏ, cục đất, nứt, sỏi, rêu) + bản đồ pháp tuyến (normal map) để ánh sáng tạo gồ ghề.
// • Lớp "multiply" quy mô lớn (~40 m) phá cảm giác lặp của texture.
// • Gò đất / gò cỏ: mô hình thật nhô lên khỏi mặt phẳng, rải sẵn khi dựng cảnh (id seedM…, chọn / xóa / di chuyển được; thêm thủ công ở nhóm "Mẫu có sẵn").
// Texture dựng ở luồng nền: lúc đầu hiện ảnh cũ, vài giây sau tự thay bằng ảnh mới.

/// Nhiễu giá trị lặp ô (tileable): u, v trong [0, 1).
final class TNoise {
    let fx: Int, fy: Int
    private var g: [Float]
    init(_ fx: Int, _ fy: Int, seed: UInt32) {
        self.fx = fx; self.fy = fy
        g = [Float](repeating: 0, count: fx * fy)
        var s = seed &* 2654435761 &+ 12345
        for i in 0..<g.count { s = s &* 1664525 &+ 1013904223; g[i] = Float(s >> 8) / Float(1 << 24) }
    }
    @inline(__always) func at(_ u: Float, _ v: Float) -> Float {
        let x = u * Float(fx), y = v * Float(fy)
        let x0f = floorf(x), y0f = floorf(y)
        var xi = Int(x0f) % fx; if xi < 0 { xi += fx }
        var yi = Int(y0f) % fy; if yi < 0 { yi += fy }
        let x1 = (xi + 1) % fx, y1 = (yi + 1) % fy
        var tx = x - x0f, ty = y - y0f
        tx = tx * tx * (3 - 2 * tx); ty = ty * ty * (3 - 2 * ty)
        let a = g[yi * fx + xi], b = g[yi * fx + x1], c = g[y1 * fx + xi], d = g[y1 * fx + x1]
        return (a + (b - a) * tx) + ((c + (d - c) * tx) - (a + (b - a) * tx)) * ty
    }
}

enum TerrainTex {
    static let size = 768
    static var imgs: [Bool: (UIImage, UIImage)] = [:]        // true = cỏ, false = đất: (màu, pháp tuyến)
    static var macroImg: UIImage?
    static var started = false
    static var pending: [(SCNMaterial, Bool, Float, Float)] = []

    @inline(__always) static func mix3(_ a: SIMD3<Float>, _ b: SIMD3<Float>, _ t: Float) -> SIMD3<Float> { a + (b - a) * t }
    @inline(__always) static func sstep(_ a: Float, _ b: Float, _ x: Float) -> Float { let t = min(max((x - a) / (b - a), 0), 1); return t * t * (3 - 2 * t) }

    static func image(_ px: [UInt8], _ w: Int, _ h: Int, linear: Bool) -> UIImage? {
        var buf = px
        let cs = linear ? CGColorSpaceCreateDeviceRGB() : (CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB())
        guard let ctx = CGContext(data: &buf, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4, space: cs,
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue), let cg = ctx.makeImage() else { return nil }
        return UIImage(cgImage: cg, scale: 1, orientation: .up)
    }

    static func build(grass: Bool) -> (UIImage, UIImage)? {
        let W = size, F = Float(W)
        let sd: UInt32 = grass ? 11 : 12
        let n4 = TNoise(4, 4, seed: sd + 1), n6 = TNoise(6, 6, seed: sd + 2), n8 = TNoise(8, 8, seed: sd + 3), n16 = TNoise(16, 16, seed: sd + 4)
        let n32 = TNoise(32, 32, seed: sd + 5), n64 = TNoise(64, 64, seed: sd + 6), n128 = TNoise(128, 128, seed: sd + 7)
        let bladeA = TNoise(192, 22, seed: sd + 8), bladeB = TNoise(96, 11, seed: sd + 9)       // sợi cỏ: dọc theo trục v
        let crk = TNoise(10, 10, seed: sd + 10), crk2 = TNoise(22, 22, seed: sd + 11), moss = TNoise(7, 7, seed: sd + 12)
        var rgb = [Float](repeating: 0, count: W * W * 3)
        var hgt = [Float](repeating: 0, count: W * W)
        for y in 0..<W {
            let v = Float(y) / F
            for x in 0..<W {
                let u = Float(x) / F
                let i = y * W + x
                let a8 = n8.at(u, v), a16 = n16.at(u, v), a32 = n32.at(u, v), a64 = n64.at(u, v), a128 = n128.at(u, v)
                let p = n4.at(u, v) * 0.45 + a8 * 0.30 + a16 * 0.25
                if grass {
                    let bl = bladeA.at(u, v) * 0.6 + bladeB.at(u, v) * 0.4
                    let deep = SIMD3<Float>(0.13, 0.29, 0.07), mid = SIMD3<Float>(0.29, 0.47, 0.12), light = SIMD3<Float>(0.50, 0.62, 0.21)
                    let t = min(max((p - 0.25) / 0.5, 0), 1)
                    var c = t < 0.5 ? mix3(deep, mid, t * 2) : mix3(mid, light, (t - 0.5) * 2)
                    c = mix3(c, SIMD3<Float>(0.58, 0.54, 0.25), sstep(0.62, 0.86, n6.at(u, v)) * 0.45)       // mảng cỏ úa
                    let lum = 0.80 + 0.34 * (bl - 0.5) + 0.22 * (a128 - 0.5) + 0.18 * (a32 - 0.5)
                    let h = 0.40 * a8 + 0.30 * a16 + 0.30 * a32 + 0.25 * bl + 0.15 * a64
                    hgt[i] = h
                    let ao = 0.78 + 0.35 * min(max(h - 0.3, 0), 0.8)
                    let f = c * lum * ao
                    rgb[i * 3] = f.x; rgb[i * 3 + 1] = f.y; rgb[i * 3 + 2] = f.z
                } else {
                    let dark = SIMD3<Float>(0.21, 0.145, 0.095), light = SIMD3<Float>(0.47, 0.36, 0.24)
                    var c = mix3(dark, light, min(max(p * 1.15 - 0.1, 0), 1))
                    let ridge = 1 - abs(2 * a16 - 1)
                    let h = 0.40 * a8 + 0.45 * ridge + 0.30 * a32 + 0.20 * a64 + 0.10 * a128
                    let crackLine = 1 - sstep(0.0, 0.028, abs(crk.at(u, v) - 0.5))
                    let crackFine = 1 - sstep(0.0, 0.02, abs(crk2.at(u, v) - 0.5))
                    var lum = 0.86 + 0.30 * (a32 - 0.5) + 0.20 * (a128 - 0.5)
                    lum *= 1 - 0.55 * max(crackLine, crackFine * 0.6)
                    c = mix3(c, SIMD3<Float>(0.62, 0.5, 0.36), sstep(0.7, 0.95, h) * 0.30)                  // đỉnh cục đất khô, sáng hơn
                    let mg = sstep(0.60, 0.80, moss.at(u, v)) * (0.6 + 0.4 * bladeA.at(u, v))              // rêu / cỏ mọc xen
                    c = mix3(c, SIMD3<Float>(0.24, 0.37, 0.11), mg * 0.8)
                    hgt[i] = h - crackLine * 0.5 - crackFine * 0.2 + mg * 0.1
                    let f = c * lum
                    rgb[i * 3] = f.x; rgb[i * 3 + 1] = f.y; rgb[i * 3 + 2] = f.z
                }
            }
        }
        // sỏi nhỏ rải trên đất (và vài viên đá trên nền cỏ)
        var s: UInt32 = grass ? 4242 : 9191
        func rnd() -> Float { s = s &* 1664525 &+ 1013904223; return Float(s >> 8) / Float(1 << 24) }
        let nPeb = grass ? 60 : 340
        for _ in 0..<nPeb {
            let cx = Int(rnd() * F), cy = Int(rnd() * F)
            let r = 2 + Int(rnd() * (grass ? 3 : 6))
            let tone = 0.62 + rnd() * 0.5
            let col = SIMD3<Float>(0.52, 0.47, 0.40) * tone
            for dy in -r...r { for dx in -r...r {
                let d2 = Float(dx * dx + dy * dy) / Float(r * r)
                if d2 >= 1 { continue }
                let xx = (cx + dx + W) % W, yy = (cy + dy + W) % W
                let k = (yy * W + xx)
                let dome = sqrtf(1 - d2)
                hgt[k] += dome * 0.9
                let shade = 0.75 + 0.35 * (Float(-dx - dy) / Float(2 * r))         // sáng phía trên trái, tối phía dưới phải
                let m: Float = min(1, (1 - d2) * 3)
                for ch in 0..<3 { rgb[k * 3 + ch] = rgb[k * 3 + ch] * (1 - m) + col[ch] * shade * m }
            } }
        }
        // pháp tuyến từ bản đồ độ cao
        let kk: Float = grass ? 11 : 15
        var colPx = [UInt8](repeating: 255, count: W * W * 4)
        var nPx = [UInt8](repeating: 255, count: W * W * 4)
        for y in 0..<W {
            let ym = ((y - 1) + W) % W, yp = (y + 1) % W
            for x in 0..<W {
                let xm = ((x - 1) + W) % W, xp = (x + 1) % W
                let dx = (hgt[y * W + xp] - hgt[y * W + xm]) * 0.5
                let dv = (hgt[ym * W + x] - hgt[yp * W + x]) * 0.5       // v hướng lên trên ảnh
                var n = SIMD3<Float>(-dx * kk, -dv * kk, 1); n /= simd_length(n)
                let i = (y * W + x) * 4
                nPx[i] = UInt8(max(0, min(255, (n.x * 0.5 + 0.5) * 255)))
                nPx[i + 1] = UInt8(max(0, min(255, (n.y * 0.5 + 0.5) * 255)))
                nPx[i + 2] = UInt8(max(0, min(255, (n.z * 0.5 + 0.5) * 255)))
                let j = (y * W + x) * 3
                colPx[i] = UInt8(max(0, min(255, rgb[j] * 255)))
                colPx[i + 1] = UInt8(max(0, min(255, rgb[j + 1] * 255)))
                colPx[i + 2] = UInt8(max(0, min(255, rgb[j + 2] * 255)))
            }
        }
        guard let ci = image(colPx, W, W, linear: false), let ni = image(nPx, W, W, linear: true) else { return nil }
        return (ci, ni)
    }

    /// Lớp nhấn màu quy mô lớn, nhân lên màu nền để các ô lặp 6 m không lộ ra.
    static func buildMacro() -> UIImage? {
        let W = 256, F = Float(W)
        let a3 = TNoise(3, 3, seed: 31), a6 = TNoise(6, 6, seed: 32), a12 = TNoise(12, 12, seed: 33)
        let b3 = TNoise(3, 3, seed: 41), b7 = TNoise(7, 7, seed: 42)
        var px = [UInt8](repeating: 255, count: W * W * 4)
        for y in 0..<W { for x in 0..<W {
            let u = Float(x) / F, v = Float(y) / F
            let a = a3.at(u, v) * 0.5 + a6.at(u, v) * 0.3 + a12.at(u, v) * 0.2
            let b = b3.at(u, v) * 0.6 + b7.at(u, v) * 0.4
            let r = 0.74 + 0.26 * a, g = 0.80 + 0.20 * (a * 0.6 + b * 0.4), bl = 0.70 + 0.22 * a
            let i = (y * W + x) * 4
            px[i] = UInt8(min(255, r * 255)); px[i + 1] = UInt8(min(255, g * 255)); px[i + 2] = UInt8(min(255, bl * 255))
        } }
        return image(px, W, W, linear: false)
    }

    static func apply(_ m: SCNMaterial, grass: Bool, _ sx: Float, _ sy: Float) {
        guard let (ci, ni) = imgs[grass] else { return }
        m.diffuse.contents = ci
        m.normal.contents = ni
        for p in [m.diffuse, m.normal] { p.wrapS = .repeat; p.wrapT = .repeat; p.mipFilter = .linear; p.maxAnisotropy = 8 }
        m.diffuse.contentsTransform = SCNMatrix4MakeScale(sx, sy, 1)
        m.normal.contentsTransform = SCNMatrix4MakeScale(sx, sy, 1)
        m.normal.intensity = 1.0
        m.specular.contents = UIColor(white: grass ? 0.05 : 0.04, alpha: 1)
    }

    static func ensureStarted() {
        guard !started else { return }
        started = true
        DispatchQueue.global(qos: .userInitiated).async {
            let g = build(grass: true), d = build(grass: false), mc = buildMacro()
            DispatchQueue.main.async {
                if let g = g { imgs[true] = g }
                if let d = d { imgs[false] = d }
                macroImg = mc
                for (m, gr, sx, sy) in pending {
                    apply(m, grass: gr, sx, sy)
                    if let mc = macroImg { applyMacro(m, mc) }
                }
                pending.removeAll()
            }
        }
    }
    static func applyMacro(_ m: SCNMaterial, _ img: UIImage) {
        m.multiply.contents = img
        m.multiply.wrapS = .repeat; m.multiply.wrapT = .repeat; m.multiply.mipFilter = .linear
        let t = m.diffuse.contentsTransform                    // cùng kích thước mặt phẳng, nhưng ô lặp ~40 m thay vì 6 m
        m.multiply.contentsTransform = SCNMatrix4MakeScale(Float(t.m11) / 6.5, Float(t.m22) / 6.5, 1)
    }
}

extension Game {
    /// Chất liệu nền: ảnh cũ (fallback) hiện ngay, texture mới thay vào khi dựng xong ở luồng nền.
    func groundMat(grass: Bool, _ sx: Float, _ sy: Float, fallback: UIImage, macro: Bool = true) -> SCNMaterial {
        let m = mat(fallback, sx, sy)
        if TerrainTex.imgs[grass] != nil {
            TerrainTex.apply(m, grass: grass, sx, sy)
            if macro, let mc = TerrainTex.macroImg { TerrainTex.applyMacro(m, mc) }
        } else {
            TerrainTex.pending.append((m, grass, sx, sy))
            TerrainTex.ensureStarted()
        }
        return m
    }

    /// Một gò đất: lưới tròn có viền lượn, đỉnh cao `H`, bán kính `R`, mượt về 0 ở rìa để liền với nền.
    func moundGeo(_ R: Float, _ H: Float, seed: Float, uvOff: SIMD2<Float>) -> SCNGeometry {
        let nr = 12, na = 32
        var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
        func rr(_ th: Float) -> Float { R * (1 + 0.16 * sin(th * 2 + seed) + 0.09 * sin(th * 3 + seed * 1.7) + 0.05 * sin(th * 5 + seed * 2.3)) }
        func hh(_ t: Float, _ th: Float) -> Float {
            let b = (1 - t * t); return H * b * b * (1 + 0.12 * sin(th * 3 + seed) * t)
        }
        P.append(SIMD3<Float>(0, H, 0)); UV.append(uvOff)
        for i in 1...nr {
            let t = Float(i) / Float(nr)
            for j in 0..<na {
                let th = Float(j) / Float(na) * 2 * Float.pi
                let r = rr(th) * t
                let x = cos(th) * r, z = sin(th) * r
                P.append(SIMD3<Float>(x, hh(t, th) + (i == nr ? 0 : 0.0), z)); UV.append(SIMD2<Float>(x / 6, z / 6) + uvOff)
            }
        }
        for j in 0..<na { let a = Int32(0), b = Int32(1 + j), c = Int32(1 + (j + 1) % na); I += [a, c, b] }
        for i in 0..<(nr - 1) {
            for j in 0..<na {
                let a = Int32(1 + i * na + j), b = Int32(1 + i * na + (j + 1) % na), c = Int32(1 + (i + 1) * na + j), d = Int32(1 + (i + 1) * na + (j + 1) % na)
                I += [a, b, c, b, d, c]
            }
        }
        return meshGeo(P, UV, I)
    }

    func moundMat(grass: Bool) -> SCNMaterial {
        let key = grass ? "mound.grass" : "mound.soil"
        if let m = moundMats[key] { return m }
        let fb = makeTex(grass ? UIColor(red: 0.36, green: 0.52, blue: 0.2, alpha: 1) : UIColor(red: 0.33, green: 0.26, blue: 0.19, alpha: 1),
                         grass ? [UIColor(red: 0.25, green: 0.42, blue: 0.14, alpha: 1), UIColor(red: 0.5, green: 0.66, blue: 0.28, alpha: 1)] : [UIColor(red: 0.22, green: 0.17, blue: 0.12, alpha: 1), UIColor(red: 0.45, green: 0.37, blue: 0.26, alpha: 1)],
                         1200, 10, seed: grass ? 11 : 12)
        let m = groundMat(grass: grass, 1, 1, fallback: fb, macro: false)
        m.isDoubleSided = true
        moundMats[key] = m
        return m
    }

    /// Gò đất cỏ / gò đất nâu: 1 gò chính + 1–2 gò phụ chồng lên cho tự nhiên.
    func moundModel(_ id: String, into root: SCNNode) {
        let grass = id == "Gò đất cỏ"
        let m = moundMat(grass: grass)
        let parts: [(Float, Float, Float, Float, Float)] = grass
            ? [(3.4, 0.26, 0, 0, 1.3), (2.1, 0.17, 2.0, 1.1, 4.1), (1.7, 0.12, -1.6, -1.5, 2.6)]
            : [(3.0, 0.30, 0, 0, 0.7), (1.9, 0.20, -1.7, 1.3, 3.3)]
        for (i, p) in parts.enumerated() {
            let g = moundGeo(p.0, p.1, seed: p.4, uvOff: SIMD2<Float>(Float(i) * 0.37, Float(i) * 0.61))
            g.firstMaterial = m
            let n = SCNNode(geometry: g); n.position = SCNVector3(p.2, 0, p.3); n.castsShadow = false; root.addChildNode(n)
        }
    }
}
