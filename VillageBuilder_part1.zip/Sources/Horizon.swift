import SceneKit
import UIKit
import simd

// ===== Chân trời miền Tây: đồng ruộng xa, rặng dừa / cây ăn trái / tre / chuối / nhà mái lá quanh khu đất,
// và ba lớp rặng cây xa vẽ bằng mã (mờ dần trong sương). Dùng đúng phong cách HUONG_DAN mục 1:
// lá có cong và gân, thân dừa có đốt, tán cây lốm đốm lá, không khối hộp / cầu trơn. =====
// Không dùng `Game.rng` (để không làm lệch cảnh dựng sẵn): mọi ngẫu nhiên dùng RNG riêng (hr).

private typealias HT = (P: [SIMD3<Float>], UV: [SIMD2<Float>], I: [Int32])

/// Lưới gộp: nhiều bản sao của cùng một mẫu, đã nhân sẵn ma trận → mỗi chất liệu chỉ một lần vẽ.
private struct HMesh {
  var P: [SIMD3<Float>] = [], UV: [SIMD2<Float>] = [], I: [Int32] = []
  mutating func add(_ t: HT, _ M: simd_float4x4) {
    let b = Int32(P.count)
    for q in t.P { let r = M * SIMD4<Float>(q.x, q.y, q.z, 1); P.append(SIMD3<Float>(r.x, r.y, r.z)) }
    UV += t.UV; I += t.I.map { $0 + b }
  }
}

// ---------- mẫu hình học ----------
/// Lá thon cong, gấp dọc gân giữa (giống leafGeo). arch < 0: rủ xuống.
private func hLeaf(_ L: Float, _ W: Float, _ arch: Float, _ fold: Float, segs: Int = 6) -> HT {
  var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
  for i in 0...segs { let t = Float(i) / Float(segs)
    let w = W / 2 * pow(sin(Float.pi * pow(t, 0.75)), 0.9), y = arch * t * t * L, z = t * L * (1 - 0.15 * arch * t)
    for j in 0..<3 { let s = Float(j) - 1; P.append(SIMD3<Float>(s * w, y + fold * abs(s) * w, z)); UV.append(SIMD2<Float>(Float(j) / 2, t)) } }
  for i in 0..<segs { for j in 0..<2 { let a = Int32(i * 3 + j), b = a + 1, c = a + 3, d = a + 4; I += [a, c, b, b, c, d] } }
  return (P, UV, I)
}
/// Ống thon cong (thân dừa, tre, cành): bend = độ lệch ngọn theo x, z; v = số lần lặp texture theo chiều cao.
private func hTube(_ r0: Float, _ r1: Float, _ h: Float, bend: SIMD2<Float>, sides: Int, rings: Int, v: Float) -> HT {
  var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
  for i in 0...rings { let t = Float(i) / Float(rings), r = r0 + (r1 - r0) * t
    let c = SIMD3<Float>(bend.x * t * t, h * t, bend.y * t * t)
    for k in 0...sides { let a = Float(k) / Float(sides) * 2 * Float.pi
      P.append(c + SIMD3<Float>(r * cos(a), 0, r * sin(a))); UV.append(SIMD2<Float>(Float(k) / Float(sides), t * v)) } }
  let n = sides + 1
  for i in 0..<rings { for k in 0..<sides { let a = Int32(i * n + k), b = a + 1, c = a + Int32(n), d = c + 1; I += [a, c, b, c, d, b] } }
  return (P, UV, I)
}
/// Khối tán lá lồi lõm (cầu đơn vị bị nhiễu, đáy dẹt hơn). Nhân ma trận để co giãn theo từng trục.
private func hBlob(lat: Int, lon: Int, amp: Float, seed: Float) -> HT {
  var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
  for i in 0...lat { let ph = Float(i) / Float(lat) * Float.pi
    for j in 0...lon { let th = Float(j) / Float(lon) * 2 * Float.pi
      let d = SIMD3<Float>(sin(ph) * cos(th), cos(ph), sin(ph) * sin(th))
      let n = sin(d.x * 5.1 + seed) * sin(d.y * 4.3 + seed * 1.7) + 0.6 * sin(d.z * 6.2 + seed * 0.6)
      let k = 1 + amp * n; var y = d.y * k; if y < 0 { y *= 0.55 }
      P.append(SIMD3<Float>(d.x * k, y, d.z * k)); UV.append(SIMD2<Float>(Float(j) / Float(lon) * 2, Float(i) / Float(lat) * 2)) } }
  let n = lon + 1
  for i in 0..<lat { for j in 0..<lon { let a = Int32(i * n + j), b = a + 1, c = a + Int32(n), d = c + 1; I += [a, b, c, b, d, c] } }
  return (P, UV, I)
}
private func hQuad(_ a: SIMD3<Float>, _ b: SIMD3<Float>, _ c: SIMD3<Float>, _ d: SIMD3<Float>, _ u: Float = 1, _ v: Float = 1) -> HT {
  ([a, b, c, d], [SIMD2<Float>(0, 0), SIMD2<Float>(u, 0), SIMD2<Float>(u, v), SIMD2<Float>(0, v)], [0, 1, 2, 0, 2, 3])
}
/// Hộp (5–6 mặt) dựng từ hQuad, pháp tuyến hướng ra ngoài.
private func hBoxT(_ x0: Float, _ x1: Float, _ y0: Float, _ y1: Float, _ z0: Float, _ z1: Float, _ u: Float = 1, _ v: Float = 1) -> HT {
  func P(_ x: Float, _ y: Float, _ z: Float) -> SIMD3<Float> { SIMD3<Float>(x, y, z) }
  return hJoin([hQuad(P(x0, y1, z1), P(x1, y1, z1), P(x1, y1, z0), P(x0, y1, z0), u, v),
                hQuad(P(x0, y0, z1), P(x1, y0, z1), P(x1, y1, z1), P(x0, y1, z1), u, v),
                hQuad(P(x1, y0, z0), P(x0, y0, z0), P(x0, y1, z0), P(x1, y1, z0), u, v),
                hQuad(P(x0, y0, z0), P(x0, y0, z1), P(x0, y1, z1), P(x0, y1, z0), u, v),
                hQuad(P(x1, y0, z1), P(x1, y0, z0), P(x1, y1, z0), P(x1, y1, z1), u, v)])
}
private func hJoin(_ ts: [HT]) -> HT {
  var r: HT = ([], [], [])
  for t in ts { let b = Int32(r.P.count); r.P += t.P; r.UV += t.UV; r.I += t.I.map { $0 + b } }
  return r
}
private func hRing(_ R: Float, _ y0: Float, _ y1: Float, seg: Int, rep: Float) -> HT {
  var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
  for k in 0...seg { let a = Float(k) / Float(seg) * 2 * Float.pi, u = Float(k) / Float(seg) * rep
    P.append(SIMD3<Float>(cos(a) * R, y0, sin(a) * R)); UV.append(SIMD2<Float>(u, 1))
    P.append(SIMD3<Float>(cos(a) * R, y1, sin(a) * R)); UV.append(SIMD2<Float>(u, 0)) }
  for k in 0..<seg { let a = Int32(k * 2), b = a + 1, c = a + 2, d = a + 3; I += [a, c, b, b, c, d] }
  return (P, UV, I)
}
private func mSc(_ x: Float, _ y: Float, _ z: Float) -> simd_float4x4 { simd_float4x4(diagonal: SIMD4<Float>(x, y, z, 1)) }

// ---------- texture vẽ bằng mã ----------
private func hShade(_ c: UIColor, _ k: CGFloat, a: CGFloat = 1) -> UIColor {
  var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, al: CGFloat = 0; c.getRed(&r, green: &g, blue: &b, alpha: &al)
  return UIColor(red: min(r * k, 1), green: min(g * k, 1), blue: min(b * k, 1), alpha: a)
}
private func hImage(_ w: Int, _ h: Int, opaque: Bool, _ draw: (CGContext) -> Void) -> UIImage {
  let f = UIGraphicsImageRendererFormat(); f.scale = 1; f.opaque = opaque
  return UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: f).image { draw($0.cgContext) }
}
/// Vỏ thân dừa: các đốt vòng ngang + vệt dọc.
private func hBarkImg() -> UIImage {
  var r = RNG(s: 31)
  return hImage(64, 128, opaque: true) { g in
    UIColor(red: 0.46, green: 0.37, blue: 0.27, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 64, height: 128))
    for _ in 0..<90 { UIColor(white: CGFloat(r.f(0, 1)), alpha: 0.10).setFill(); g.fill(CGRect(x: CGFloat(r.f(0, 64)), y: CGFloat(r.f(0, 128)), width: CGFloat(r.f(1, 3)), height: CGFloat(r.f(6, 30)))) }
    var y: CGFloat = 0
    while y < 128 { UIColor(red: 0.22, green: 0.16, blue: 0.1, alpha: 0.55).setStroke(); g.setLineWidth(CGFloat(r.f(1.4, 2.6)))
      g.move(to: CGPoint(x: 0, y: y)); g.addQuadCurve(to: CGPoint(x: 64, y: y + CGFloat(r.f(-1.5, 1.5))), control: CGPoint(x: 32, y: y + CGFloat(r.f(-2.5, 2.5)))); g.strokePath()
      UIColor(red: 0.7, green: 0.6, blue: 0.45, alpha: 0.22).setStroke(); g.setLineWidth(1); g.move(to: CGPoint(x: 0, y: y + 3)); g.addLine(to: CGPoint(x: 64, y: y + 3)); g.strokePath()
      y += CGFloat(r.f(7, 11)) } }
}
/// Tán lá: nền xanh + hàng trăm chiếc lá nhỏ, trên sáng dưới tối.
private func hCanopyImg(_ base: UIColor, seed: UInt64) -> UIImage {
  var r = RNG(s: seed)
  return hImage(256, 256, opaque: true) { g in
    base.setFill(); g.fill(CGRect(x: 0, y: 0, width: 256, height: 256))
    for _ in 0..<1100 {
      let x = CGFloat(r.f(0, 256)), y = CGFloat(r.f(0, 256)), lum = CGFloat(0.62 + 0.75 * (1 - y / 256) * CGFloat(r.f(0.6, 1.1)))
      g.saveGState(); g.translateBy(x: x, y: y); g.rotate(by: CGFloat(r.f(0, 6.28)))
      hShade(base, lum).setFill(); g.fillEllipse(in: CGRect(x: -CGFloat(r.f(3, 6)), y: -CGFloat(r.f(1.2, 2.4)), width: CGFloat(r.f(6, 12)), height: CGFloat(r.f(2.4, 4.8))))
      g.restoreGState() }
    for _ in 0..<5 { hShade(base, 0.55, a: 0.25).setFill(); g.fillEllipse(in: CGRect(x: CGFloat(r.f(0, 200)), y: CGFloat(r.f(120, 230)), width: CGFloat(r.f(40, 90)), height: CGFloat(r.f(20, 50)))) } }
}
private func hBambooImg() -> UIImage {
  var r = RNG(s: 77)
  return hImage(32, 128, opaque: true) { g in
    UIColor(red: 0.62, green: 0.64, blue: 0.24, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 32, height: 128))
    for _ in 0..<40 { UIColor(white: CGFloat(r.f(0, 1)), alpha: 0.12).setFill(); g.fill(CGRect(x: CGFloat(r.f(0, 32)), y: CGFloat(r.f(0, 128)), width: 1.5, height: CGFloat(r.f(10, 40)))) }
    for k in 0..<4 { let y = CGFloat(k) * 32 + 4; UIColor(red: 0.3, green: 0.3, blue: 0.1, alpha: 0.8).setFill(); g.fill(CGRect(x: 0, y: y, width: 32, height: 3)); UIColor(red: 0.85, green: 0.85, blue: 0.5, alpha: 0.5).setFill(); g.fill(CGRect(x: 0, y: y + 3, width: 32, height: 1.5)) } }
}
/// Đồng ruộng nhìn từ xa: các thửa lúa xanh / vàng non / đất, bờ ruộng sáng, luống kẻ, kênh nhỏ. Lát liền nhau được.
private func hFieldImg() -> UIImage {
  var r = RNG(s: 4242); let S: CGFloat = 512
  return hImage(512, 512, opaque: true) { g in
    UIColor(red: 0.40, green: 0.55, blue: 0.23, alpha: 1).setFill(); g.fill(CGRect(x: 0, y: 0, width: S, height: S))
    let cols: [UIColor] = [UIColor(red: 0.33, green: 0.52, blue: 0.2, alpha: 1), UIColor(red: 0.5, green: 0.64, blue: 0.25, alpha: 1), UIColor(red: 0.62, green: 0.68, blue: 0.3, alpha: 1),
                           UIColor(red: 0.28, green: 0.45, blue: 0.2, alpha: 1), UIColor(red: 0.46, green: 0.4, blue: 0.24, alpha: 1), UIColor(red: 0.7, green: 0.7, blue: 0.38, alpha: 1)]
    for _ in 0..<28 {
      let w = CGFloat(r.f(50, 170)), h = CGFloat(r.f(40, 130)), x = CGFloat(r.f(0, 512)), y = CGFloat(r.f(0, 512)), col = cols[Int(r.f(0, 5.99))], horiz = r.f(0, 1) < 0.5
      for ox in [-S, 0, S] { for oy in [-S, 0, S] {
        let rc = CGRect(x: x + ox, y: y + oy, width: w, height: h)
        if rc.maxX < 0 || rc.minX > S || rc.maxY < 0 || rc.minY > S { continue }
        col.setFill(); g.fill(rc)
        hShade(col, 0.78, a: 0.35).setStroke(); g.setLineWidth(1)
        if horiz { var yy = rc.minY; while yy < rc.maxY { g.move(to: CGPoint(x: rc.minX, y: yy)); g.addLine(to: CGPoint(x: rc.maxX, y: yy)); yy += 5 } }
        else { var xx = rc.minX; while xx < rc.maxX { g.move(to: CGPoint(x: xx, y: rc.minY)); g.addLine(to: CGPoint(x: xx, y: rc.maxY)); xx += 5 } }
        g.strokePath()
        UIColor(red: 0.66, green: 0.7, blue: 0.42, alpha: 0.8).setStroke(); g.setLineWidth(2); g.stroke(rc) } } }
    // kênh nhỏ cắt ngang (nước đục hơi xanh, mép sáng)
    for (yy, k) in [(CGFloat(180), CGFloat(1)), (CGFloat(400), CGFloat(-1))] {
      let path = UIBezierPath(); path.move(to: CGPoint(x: 0, y: yy)); path.addCurve(to: CGPoint(x: S, y: yy), controlPoint1: CGPoint(x: 150, y: yy + 28 * k), controlPoint2: CGPoint(x: 360, y: yy - 28 * k))
      UIColor(red: 0.62, green: 0.68, blue: 0.5, alpha: 1).setStroke(); path.lineWidth = 11; path.stroke()
      UIColor(red: 0.36, green: 0.46, blue: 0.4, alpha: 1).setStroke(); path.lineWidth = 7; path.stroke()
      UIColor(red: 0.7, green: 0.82, blue: 0.85, alpha: 0.45).setStroke(); path.lineWidth = 2; path.stroke() }
    for _ in 0..<3500 { UIColor(white: CGFloat(r.f(0, 1)), alpha: 0.05).setFill(); g.fill(CGRect(x: CGFloat(r.f(0, 512)), y: CGFloat(r.f(0, 512)), width: 2, height: 2)) } }
}
/// Rặng cây xa (ảnh có alpha, 4096 x 256): hàng cây thấp liền nhau + dừa (thân cong, tàu lá xòe) + cây tán tròn + cây nhọn;
/// mpp = số mét trên một điểm ảnh, để cây vẽ đúng cỡ thật; lớp sương mờ dần về chân cây. Nối liền hai đầu.
private func hTreeline(seed: UInt64, mpp: Float, tint: UIColor, haze: UIColor) -> UIImage {
  var r = RNG(s: seed); let W = 4096, H = 256, Wc = CGFloat(W), base = CGFloat(H - 4)
  func px(_ m: Float) -> CGFloat { CGFloat(m / mpp) }
  return hImage(W, H, opaque: false) { g in
    func blob(_ x: CGFloat, _ y: CGFloat, _ rad: CGFloat, _ col: UIColor) { col.setFill(); for o in [-Wc, 0, Wc] { g.fillEllipse(in: CGRect(x: x + o - rad, y: y - rad * 0.85, width: rad * 2, height: rad * 1.7)) } }
    var x: CGFloat = 0
    while x < Wc { let rad = px(r.f(2.5, 5)); blob(x, base - px(r.f(1.5, 3.5)), rad, hShade(tint, CGFloat(r.f(0.8, 1.05)))); x += rad * 0.9 }
    g.setFillColor(hShade(tint, 0.9).cgColor); g.fill(CGRect(x: 0, y: base - px(2), width: Wc, height: px(2) + 4))
    var tx: CGFloat = 0
    while tx < Wc {
      tx += px(r.f(10, 38)); let kind = r.f(0, 1)
      if kind < 0.42 {   // dừa
        let h = px(r.f(14, 24)), lean = px(r.f(-3, 3)), top = CGPoint(x: tx + lean, y: base - h), len = px(r.f(4.5, 6.5))
        g.setStrokeColor(hShade(tint, 0.62).cgColor); g.setLineWidth(max(1.2, px(0.55)))
        for o in [-Wc, 0, Wc] { g.move(to: CGPoint(x: tx + o, y: base - px(2))); g.addQuadCurve(to: CGPoint(x: top.x + o, y: top.y), control: CGPoint(x: tx + o + lean * 0.2, y: base - h * 0.55)); g.strokePath() }
        g.setStrokeColor(hShade(tint, 0.8).cgColor); g.setLineWidth(max(1.1, px(0.7)))
        for i in 0..<9 {
          let a = -Double.pi + (Double(i) + 0.5) / 9 * Double.pi + Double(r.f(-0.1, 0.1)), dx = CGFloat(cos(a)) * len, dy = CGFloat(sin(a)) * len * 0.55
          for o in [-Wc, 0, Wc] { g.move(to: CGPoint(x: top.x + o, y: top.y)); g.addQuadCurve(to: CGPoint(x: top.x + o + dx, y: top.y + dy + len * 0.35), control: CGPoint(x: top.x + o + dx * 0.55, y: top.y + dy - len * 0.2)); g.strokePath() } }
      } else if kind < 0.86 {   // cây tán tròn (xoài, mít, cây rừng)
        let h = px(r.f(9, 17)), col = hShade(tint, CGFloat(r.f(0.85, 1.1)))
        for _ in 0..<7 { blob(tx + CGFloat(r.f(-1, 1)) * h * 0.45, base - h * CGFloat(r.f(0.4, 0.8)), h * CGFloat(r.f(0.22, 0.38)), col) }
        blob(tx - h * 0.1, base - h * 0.85, h * CGFloat(0.22), hShade(tint, 1.22))
      } else {   // cây thân thẳng, tán hẹp (cau, bạch đàn)
        let h = px(r.f(14, 22)); hShade(tint, 0.85).setFill()
        for o in [-Wc, 0, Wc] { g.fillEllipse(in: CGRect(x: tx + o - px(1.6), y: base - h, width: px(3.2), height: h)) } } }
    g.saveGState(); g.setBlendMode(.sourceAtop)
    if let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [haze.withAlphaComponent(0.10).cgColor, haze.withAlphaComponent(0.65).cgColor] as CFArray, locations: [0, 1]) {
      g.drawLinearGradient(gr, start: CGPoint(x: 0, y: base - px(26)), end: CGPoint(x: 0, y: base), options: [.drawsBeforeStartLocation, .drawsAfterEndLocation]) }
    g.restoreGState() }
}

// ---------- chân trời ----------
extension Game {
  /// Khung địa hình hiện có (xem buildTerrain): cỏ x −151…102, z −380…40.
  func horizonNode() -> SCNNode {
    var hr = RNG(s: 20261022)
    let root = SCNNode(); root.name = "horizon"
    func C(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
    let x0: Float = -151, x1: Float = 102, z0: Float = -380, z1: Float = 40, cx: Float = -24.5, cz: Float = -170

    // ---- đồng ruộng trải tới chân trời: bốn mảnh quanh khu đất (không chồng lên địa hình) ----
    let field = hFieldImg()
    func ground(_ xa: Float, _ xb: Float, _ za: Float, _ zb: Float) {
      let w = xb - xa, l = zb - za
      let p = SCNPlane(width: CGFloat(w), height: CGFloat(l)); p.firstMaterial = mat(field, w / 70, l / 70)
      let n = SCNNode(geometry: p); n.eulerAngles.x = -.pi / 2; n.position = SCNVector3((xa + xb) / 2, -0.1, (za + zb) / 2); n.castsShadow = false; root.addChildNode(n)
    }
    ground(-1800, 1800, z1 - 1, 1800)        // sau lưng (z > 40)
    ground(-1800, 1800, -1800, z0 + 1)       // phía xa (z < −380)
    ground(-1800, x0 + 1, z0, z1)            // bên trái sông
    ground(x1 - 1, 1800, z0, z1)             // bên phải

    // ---- vật liệu ----
    let bark = mat(hBarkImg(), 1, 1)
    let palmLeaf = leafMat("palm"), leaf = leafMat("default")
    let canopies = [mat(hCanopyImg(C(0.17, 0.38, 0.14), seed: 5), 1, 1), mat(hCanopyImg(C(0.27, 0.46, 0.17), seed: 6), 1, 1), mat(hCanopyImg(C(0.36, 0.5, 0.18), seed: 7), 1, 1)]
    let bam = mat(hBambooImg(), 1, 1)
    let thatch = mat(thatchImg(), 1, 1); thatch.isDoubleSided = true
    let postMat = mat(woodImg(C(0.50, 0.21, 0.11)), 1, 1); postMat.isDoubleSided = true       // cột gỗ nâu đỏ
    let wall = mat(woodImg(C(0.42, 0.28, 0.17)), 1, 1); wall.isDoubleSided = true
    let nutMat = pcol(0.3, 0.4, 0.14)
    for m in [bark, bam] { m.specular.contents = UIColor(white: 0.05, alpha: 1) }
    for m in canopies { m.specular.contents = UIColor(white: 0.1, alpha: 1) }

    // ---- mẫu dùng chung ----
    let fronds = [hLeaf(5.2, 1.5, -0.8, 0.2), hLeaf(4.6, 1.3, -0.6, 0.15), hLeaf(5.6, 1.2, -1.0, 0.25)]
    let bamLeaf = hLeaf(1.7, 0.4, -0.4, 0.1, segs: 4), banLeaf = hLeaf(3.4, 1.2, -0.55, 0.1)
    let nut = hBlob(lat: 4, lon: 6, amp: 0.1, seed: 2), limb = hTube(0.22, 0.1, 3.5, bend: SIMD2<Float>(0.3, 0), sides: 5, rings: 2, v: 2)
    let blobs: [[HT]] = [(0..<6).map { hBlob(lat: 10, lon: 16, amp: 0.13, seed: Float($0) * 1.9 + 0.5) }, (0..<6).map { hBlob(lat: 7, lon: 12, amp: 0.12, seed: Float($0) * 1.9 + 0.5) }]   // tán tròn trịa, nhiều mặt hơn: hết cảm giác "tảng đá" góc cạnh
    // nhà sàn mái tranh miền Tây kiểu trong ảnh tham khảo: KHÔNG có vách, chỉ có sàn gỗ, hàng cột gỗ, lan can thấp, mái tranh dốc hai mái + mái chái thấp phía trước
    func P3(_ x: Float, _ y: Float, _ z: Float) -> SIMD3<Float> { SIMD3<Float>(x, y, z) }
    let roofT = hJoin([
      hQuad(P3(-5.3, 3.5, 3.9), P3(5.3, 3.5, 3.9), P3(5.3, 6.5, 0), P3(-5.3, 6.5, 0), 5, 3),          // mái trước
      hQuad(P3(5.3, 3.5, -3.9), P3(-5.3, 3.5, -3.9), P3(-5.3, 6.5, 0), P3(5.3, 6.5, 0), 5, 3),        // mái sau
      hQuad(P3(5.15, 3.5, 3.9), P3(5.15, 3.5, -3.9), P3(5.15, 6.5, 0), P3(5.15, 6.5, 0), 3, 2),       // đầu hồi bằng tranh (hai đầu)
      hQuad(P3(-5.15, 3.5, -3.9), P3(-5.15, 3.5, 3.9), P3(-5.15, 6.5, 0), P3(-5.15, 6.5, 0), 3, 2),
      hQuad(P3(-5.5, 2.6, 5.7), P3(5.5, 2.6, 5.7), P3(5.5, 3.55, 3.85), P3(-5.5, 3.55, 3.85), 5, 1.2), // mái chái phía trước, thấp hơn
      hBoxT(-5.6, 5.6, 6.35, 6.8, -0.32, 0.32, 6, 1)])                                                 // nóc úp tranh
    let deckT = hBoxT(-4.7, 4.7, 0.0, 0.7, -3.4, 3.4, 4, 1)
    let postT = hTube(0.15, 0.13, 2.85, bend: SIMD2<Float>(0, 0), sides: 6, rings: 1, v: 2)
    let beamsT = hJoin([hBoxT(-4.4, 4.4, 3.45, 3.68, -3.07, -2.83, 6, 1), hBoxT(-4.4, 4.4, 3.45, 3.68, 2.83, 3.07, 6, 1),
                        hBoxT(-4.4, 4.4, 3.2, 3.38, -0.1, 0.1, 6, 1)])                                   // xà ngang + đòn tay
    let railT = hJoin([hBoxT(-4.4, 4.4, 1.2, 1.32, -3.05, -2.89, 6, 1), hBoxT(-4.4, 4.4, 0.85, 0.95, -3.05, -2.89, 6, 1),       // lan can sau
                       hBoxT(-4.4, -0.9, 1.2, 1.32, 2.89, 3.05, 4, 1), hBoxT(0.9, 4.4, 1.2, 1.32, 2.89, 3.05, 4, 1),            // lan can trước (chừa lối vào giữa)
                       hBoxT(-4.4, -0.9, 0.85, 0.95, 2.89, 3.05, 4, 1), hBoxT(0.9, 4.4, 0.85, 0.95, 2.89, 3.05, 4, 1),
                       hBoxT(4.35, 4.5, 1.2, 1.32, -3.0, 3.0, 4, 1), hBoxT(-4.5, -4.35, 1.2, 1.32, -3.0, 3.0, 4, 1)])           // hai bên
    let stepT = hBoxT(-0.9, 0.9, 0.0, 0.35, 3.4, 4.0, 1, 1)

    // ---- lưới gộp theo chất liệu ----
    var mTrunk = HMesh(), mFrond = HMesh(), mLeaf = HMesh(), mBam = HMesh(), mNut = HMesh(), mThatch = HMesh(), mWall = HMesh(), mPost = HMesh()
    var mC = [HMesh(), HMesh(), HMesh()]

    func palm(_ x: Float, _ z: Float, _ h: Float, _ lod: Int) {
      let yaw = hr.f(0, 6.28), lx = hr.f(-1.6, 1.6), lz = hr.f(-1.6, 1.6), k = h / 16
      let M = mT(x, 0, z) * mRy(yaw), crown = M * mT(lx, h, lz)
      mTrunk.add(hTube(0.5 * k, 0.28 * k, h, bend: SIMD2<Float>(lx, lz), sides: 6, rings: 5, v: h / 2.5), M)
      let nf = lod == 0 ? 10 : 7
      for i in 0..<nf {
        let a = Float(i) * 2.4 + hr.f(-0.3, 0.3), e = hr.f(0.15, 1.15), s = hr.f(0.85, 1.2) * k
        mFrond.add(fronds[Int(hr.f(0, 2.99))], crown * mRy(a) * mRx(-e) * mS(s)) }
      if lod == 0 { for _ in 0..<3 { mNut.add(nut, crown * mT(hr.f(-0.4, 0.4), -0.3, hr.f(-0.4, 0.4)) * mS(k)) } }
    }
    func broad(_ x: Float, _ z: Float, _ sz: Float, _ lod: Int) {
      let M = mT(x, 0, z) * mRy(hr.f(0, 6.28)) * mS(sz), th = hr.f(4, 6.5), ci = Int(hr.f(0, 2.99))
      mTrunk.add(hTube(0.5, 0.28, th, bend: SIMD2<Float>(hr.f(-0.6, 0.6), hr.f(-0.6, 0.6)), sides: 6, rings: 3, v: th / 2), M)
      if lod == 0 { for _ in 0..<2 { mTrunk.add(limb, M * mT(0, th * 0.65, 0) * mRy(hr.f(0, 6.28)) * mRx(-hr.f(0.6, 1.0))) } }
      for _ in 0..<(lod == 0 ? 9 : 6) {        // nhiều cụm lá nhỏ chụm lại thành tán tròn tự nhiên (thay vì vài khối to chồng nhau)
        let r = hr.f(1.5, 2.6)
        mC[ci].add(blobs[lod][Int(hr.f(0, 5.99))], M * mT(hr.f(-2.4, 2.4), th + hr.f(0.9, 4.0), hr.f(-2.4, 2.4)) * mSc(r * hr.f(1, 1.25), r * hr.f(0.8, 1.0), r * hr.f(1, 1.25))) }
    }
    func bamboo(_ x: Float, _ z: Float, _ lod: Int) {
      let M = mT(x, 0, z) * mRy(hr.f(0, 6.28))
      for _ in 0..<(lod == 0 ? 8 : 5) {
        let h = hr.f(7, 12), lean = hr.f(0.05, 0.3) * h, B = M * mRy(hr.f(0, 6.28)) * mT(hr.f(0, 0.8), 0, 0)
        mBam.add(hTube(0.09, 0.04, h, bend: SIMD2<Float>(lean, 0), sides: 5, rings: 4, v: h / 0.9), B)
        let top = B * mT(lean, h, 0)
        for _ in 0..<3 { mLeaf.add(bamLeaf, top * mRy(hr.f(0, 6.28)) * mRx(-hr.f(0.2, 0.9)) * mS(hr.f(0.8, 1.3))) } }
    }
    func banana(_ x: Float, _ z: Float, _ s: Float) {
      let M = mT(x, 0, z) * mRy(hr.f(0, 6.28)) * mS(s)
      mBam.add(hTube(0.22, 0.16, 2.6, bend: SIMD2<Float>(0.2, 0), sides: 6, rings: 2, v: 2), M)
      for i in 0..<6 { mLeaf.add(banLeaf, M * mT(0.2, 2.6, 0) * mRy(Float(i) * 1.05 + hr.f(-0.2, 0.2)) * mRx(-hr.f(0.5, 1.1))) }
    }
    func house(_ x: Float, _ z: Float, _ s: Float) {
      let M = mT(x, 0, z) * mRy(hr.f(0, 6.28)) * mS(s * 0.7)
      mThatch.add(roofT, M); mWall.add(deckT, M); mWall.add(stepT, M); mPost.add(beamsT, M); mPost.add(railT, M)
      for px in [Float(-4.1), -2.05, 0, 2.05, 4.1] { for pz in [Float(-2.95), 2.95] { mPost.add(postT, M * mT(px, 0.7, pz)) } }
    }

    // ---- rặng cây dày quanh khu đất (ba hàng xa dần) ----
    let W = x1 - x0, D = z1 - z0, per = 2 * (W + D)
    func rim(_ s: Float, _ off: Float) -> SIMD2<Float> {
      var t = s.truncatingRemainder(dividingBy: per)
      if t < W { return SIMD2<Float>(x0 + t, z0 - off) }
      t -= W; if t < D { return SIMD2<Float>(x1 + off, z0 + t) }
      t -= D; if t < W { return SIMD2<Float>(x1 - t, z1 + off) }
      t -= W; return SIMD2<Float>(x0 - off, z1 - t)
    }
    var s: Float = 0
    while s < per {
      s += hr.f(6, 13)
      for row in 0..<3 {
        if hr.f(0, 1) < 0.25 { continue }
        let p = rim(s + hr.f(-3, 3), 6 + Float(row) * 22 + hr.f(0, 14)), q = hr.f(0, 1), lod = row == 2 ? 1 : 0
        if q < 0.36 { palm(p.x, p.y, hr.f(12, 21), lod) }
        else if q < 0.68 { broad(p.x, p.y, hr.f(0.8, 1.5), lod) }
        else if q < 0.80 { bamboo(p.x, p.y, lod) }
        else if q < 0.93 { banana(p.x, p.y, hr.f(0.9, 1.4)) }
        else if row < 2 { house(p.x, p.y, hr.f(1.0, 1.6)) }
        else { broad(p.x, p.y, hr.f(0.8, 1.5), lod) } }
    }
    // ---- cây rải xa hơn trên đồng (ít chi tiết) ----
    var placed = 0, tries = 0
    while placed < 150 && tries < 2500 {
      tries += 1
      let a = hr.f(0, 6.2832), rad = hr.f(120, 680), px = cx + cos(a) * rad, pz = cz + sin(a) * rad
      if px > x0 - 75 && px < x1 + 75 && pz > z0 - 75 && pz < z1 + 75 { continue }
      placed += 1; let q = hr.f(0, 1)
      if q < 0.45 { palm(px, pz, hr.f(14, 22), 1) } else if q < 0.9 { broad(px, pz, hr.f(1.3, 2.2), 1) } else { house(px, pz, hr.f(1.1, 1.7)) }
    }

    func emit(_ m: HMesh, _ material: SCNMaterial) {
      guard !m.P.isEmpty else { return }
      let g = meshGeo(m.P, m.UV, m.I); g.firstMaterial = material
      let n = SCNNode(geometry: g); n.castsShadow = false; root.addChildNode(n)
    }
    emit(mTrunk, bark); emit(mFrond, palmLeaf); emit(mLeaf, leaf); emit(mBam, bam); emit(mNut, nutMat); emit(mThatch, thatch); emit(mWall, wall); emit(mPost, postMat)
    for i in 0..<3 { emit(mC[i], canopies[i]) }

    // ---- ba lớp rặng cây xa (ảnh có alpha trên vòng trụ, đậm → nhạt dần theo sương) ----
    let layers: [(Float, UIColor, UIColor, UInt64, Int)] = [
      (780, C(0.20, 0.36, 0.20), C(0.66, 0.77, 0.82), 11, -50),
      (1050, C(0.30, 0.46, 0.34), C(0.70, 0.80, 0.86), 12, -51),
      (1400, C(0.46, 0.60, 0.54), C(0.76, 0.85, 0.90), 13, -52)]
    horizonMats = []
    let ring = SCNNode(); ring.position = SCNVector3(cx, 0, cz); ring.name = "treeline"; root.addChildNode(ring)
    for (R, tint, haze, seed, order) in layers {
      let mpp = Float.pi * R / 4096, img = hTreeline(seed: seed, mpp: mpp, tint: tint, haze: haze)
      let m = SCNMaterial(); m.lightingModel = .constant; m.diffuse.contents = img; m.diffuse.wrapS = .repeat; m.transparent.contents = img; m.transparencyMode = .aOne
      m.transparent.wrapS = .repeat; m.diffuse.mipFilter = .linear; m.transparent.mipFilter = .linear
      m.isDoubleSided = true; m.writesToDepthBuffer = false; horizonMats.append(m)
      let t = hRing(R, -4, -4 + 256 * mpp, seg: 120, rep: 2)
      let g = meshGeo(t.P, t.UV, t.I); g.firstMaterial = m
      let n = SCNNode(geometry: g); n.renderingOrder = order; n.castsShadow = false; ring.addChildNode(n)
    }
    return root
  }

  /// Đồng bộ độ sáng rặng cây xa với thời tiết (sương dày / trời tối thì mờ và tối đi).
  func setHorizonTone(_ fog: CGFloat) {
    horizonFog = fog
    let k = (0.45 + 0.55 * min(max(fog, 0), 1)) * (0.16 + 0.84 * horizonDay)      // đêm thì rặng cây xa tối đi
    for m in horizonMats { m.diffuse.intensity = k }
  }

  /// Dựng thời tiết + chân trời, gọi một lần ở cuối init (sau buildTerrain).
  func setupHorizon() { scene.rootNode.addChildNode(horizonNode()) }
  func setupWeather() {
    guard let amb = wxAmb, let sun = wxSun else { return }
    cam.camera?.zFar = 3000
    let ws = WeatherSystem(scene: scene, camera: cam, ambient: amb, sun: sun)
    ws.onFog = { [weak self] f in
      guard let self = self else { return }
      self.scene.fogStartDistance = 80 * f; self.scene.fogEndDistance = 1600 * f; self.setHorizonTone(f) }
    ws.onWind = { [weak self] g in
      guard let self = self else { return }
      self.swayGain = min(g, 2.2); for (m, a) in self.swayMats { m.setValue(NSNumber(value: a * self.swayMul), forKey: "amp") } }
    ws.onDay = { [weak self] d in
      guard let self = self else { return }
      self.horizonDay = d; self.setHorizonTone(self.horizonFog) }
    ws.timeMode = timeMode
    ws.hour = WeatherSystem.presetHour(timeMode) ?? (UserDefaults.standard.object(forKey: "timeHour") as? Float ?? 8.5)
    weatherSys = ws
    ws.apply(weather)
  }
}
