import SwiftUI
import SceneKit

struct SceneUI: UIViewRepresentable {
  let g: Game
  func makeUIView(context: Context) -> SCNView {
    let v = SCNView(); v.scene = g.scene; v.pointOfView = g.cam; v.allowsCameraControl = false
    v.antialiasingMode = .multisampling4X; v.rendersContinuously = true; v.preferredFramesPerSecond = 60
    v.delegate = context.coordinator
    v.addGestureRecognizer(UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tap(_:))))
    v.addGestureRecognizer(UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pan(_:))))
    v.addGestureRecognizer(UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pinch(_:))))
    return v }
  func updateUIView(_ v: SCNView, context: Context) {}
  func makeCoordinator() -> Coordinator { Coordinator(g) }
  final class Coordinator: NSObject, SCNSceneRendererDelegate {
    let g: Game; var last: TimeInterval = 0; init(_ g: Game) { self.g = g }
    func renderer(_ r: SCNSceneRenderer, updateAtTime t: TimeInterval) { let dt = last == 0 ? 0 : min(Float(t - last), 0.1); last = t; g.step(dt) }
    @objc func tap(_ r: UITapGestureRecognizer) { guard let v = r.view as? SCNView else { return }; g.tap(v, r.location(in: v)) }
    @objc func pinch(_ r: UIPinchGestureRecognizer) {
      if g.sketchVisible { if r.state == .changed { g.aerialZoom(Float(r.scale)); r.scale = 1 }; return }
      if r.state == .changed && g.mode != 0 { g.resize(Float(r.scale)); r.scale = 1 } }
    var dragging = false
    @objc func pan(_ r: UIPanGestureRecognizer) {
      if g.fullscreen { let d = r.translation(in: r.view); r.setTranslation(.zero, in: r.view); g.look(Float(d.x), Float(d.y)); return }
      if g.sketchVisible { let d = r.translation(in: r.view); r.setTranslation(.zero, in: r.view); g.aerialPan(Float(d.x), Float(d.y)); return }
      if g.mode != 0, let v = r.view as? SCNView {
        if r.state == .began { dragging = g.dragBegin(v, r.location(in: v)) }
        if dragging {
          if r.state == .changed { g.dragMove(v, r.location(in: v)) }
          else if r.state == .ended || r.state == .cancelled || r.state == .failed { g.dragEnd(); dragging = false }
          return } }
      if g.cat == "Vẽ đường" && g.mode == 0 && g.freeDraw, let v = r.view as? SCNView {
        switch r.state {
        case .began: g.strokeBegin(); g.strokeMove(v, r.location(in: v))
        case .changed: g.strokeMove(v, r.location(in: v))
        case .ended, .cancelled, .failed: g.strokeEnd()
        default: break }
        return }
      let d = r.translation(in: r.view); r.setTranslation(.zero, in: r.view); g.look(Float(d.x), Float(d.y)) } }
}

struct Joystick: View {
  var onChange: (CGVector) -> Void
  @State private var off = CGSize.zero
  var body: some View {
    ZStack {
      Circle().fill(.ultraThinMaterial).frame(width: 130, height: 130)
      Circle().fill(Color.white.opacity(0.85)).frame(width: 54, height: 54).offset(off)
    }
    .gesture(DragGesture(minimumDistance: 0).onChanged { v in
      let r: CGFloat = 50; var dx = v.translation.width, dy = v.translation.height; let d = hypot(dx, dy)
      if d > r { dx *= r / d; dy *= r / d }
      off = CGSize(width: dx, height: dy); onChange(CGVector(dx: dx / r, dy: -dy / r))
    }.onEnded { _ in off = .zero; onChange(.zero) })
  }
}

struct NumSlider: View {
  let title: String; @Binding var v: Float; let r: ClosedRange<Float>; let step: Float; let fmt: String
  var body: some View {
    HStack(spacing: 6) {
      Text(title).font(.footnote).frame(width: 64, alignment: .leading)
      Slider(value: $v, in: r, step: step).tint(.green)
      Text(String(format: fmt, v)).font(.footnote.monospacedDigit()).frame(width: 40, alignment: .trailing)
    }
  }
}

struct RoadPanel: View {
  @ObservedObject var g: Game
  @State private var shape = 0; @State private var atStart = false
  @State private var len: Float = 20; @State private var rad: Float = 12
  var body: some View {
    VStack(spacing: 6) {
      HStack { Text(g.selRoadTitle).font(.subheadline.bold()).lineLimit(1); Spacer(); Button { g.selectRoad(nil) } label: { Text("✕").font(.title3) } }
      Picker("", selection: $shape) { Text("Thẳng").tag(0); Text("Cong trái").tag(1); Text("Cong phải").tag(2) }.pickerStyle(.segmented)
      Picker("", selection: $atStart) { Text("Nối cuối 🔴").tag(false); Text("Nối đầu 🟢").tag(true) }.pickerStyle(.segmented)
      NumSlider(title: "Dài (m)", v: $len, r: 1...100, step: 1, fmt: "%.0f")
      if shape > 0 { NumSlider(title: "Bán kính", v: $rad, r: 2...60, step: 1, fmt: "%.0f") }
      HStack {
        Button { g.extendRoad(atStart: atStart, shape: shape, length: len, radius: rad) } label: { Text("➕ Nối thêm").frame(maxWidth: .infinity) }.buttonStyle(.borderedProminent).tint(.green)
        Button { g.deleteSelRoad() } label: { Text("🗑 Xóa").frame(maxWidth: .infinity) }.buttonStyle(.bordered).tint(.red) }
    }.padding(10).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
  }
}

struct RowPanel: View {
  @ObservedObject var g: Game
  @State private var shape = 0; @State private var byObj = false
  @State private var len: Float = 10; @State private var gap: Float = 1; @State private var rad: Float = 12
  var body: some View {
    VStack(spacing: 6) {
      HStack { Text("Tạo hàng: \(g.selItem)").font(.subheadline.bold()).lineLimit(1); Spacer(); Button { g.rowPanel = false } label: { Text("✕").font(.title3) } }
      Picker("", selection: $shape) { Text("Thẳng").tag(0); Text("Cong trái").tag(1); Text("Cong phải").tag(2) }.pickerStyle(.segmented)
      Picker("", selection: $byObj) { Text("Hướng nhìn").tag(false); Text("Theo vật").tag(true) }.pickerStyle(.segmented)
      NumSlider(title: "Dài (m)", v: $len, r: 1...100, step: 1, fmt: "%.0f")
      NumSlider(title: "Cách (m)", v: $gap, r: 0.2...10, step: 0.1, fmt: "%.1f")
      if shape > 0 { NumSlider(title: "Bán kính", v: $rad, r: 2...60, step: 1, fmt: "%.0f") }
      Button { g.makeRow(shape: shape, byObject: byObj, length: len, spacing: gap, radius: rad) } label: { Text("➕ Tạo hàng").frame(maxWidth: .infinity) }.buttonStyle(.borderedProminent).tint(.green)
    }.padding(10).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
    .onAppear { gap = min(max((g.defaultSpacing() * 10).rounded() / 10, 0.2), 10); byObj = g.isLenModel(g.recOf(g.selId ?? "")?.item ?? "") }
  }
}

struct ActionBar: View {
  @ObservedObject var g: Game
  func btn(_ icon: String, _ label: String, _ color: Color, active: Bool = false, _ act: @escaping () -> Void) -> some View {
    Button(action: act) {
      VStack(spacing: 2) { Text(icon).font(.title2); Text(label).font(.caption2).lineLimit(1) }
        .frame(width: 66, height: 58)
        .background(active ? Color.green.opacity(0.65) : color.opacity(0.35), in: RoundedRectangle(cornerRadius: 10))
    }.foregroundColor(.primary)
  }
  var body: some View {
    VStack(spacing: 6) {
      HStack { Text("Đã chọn: \(g.selItem)").font(.subheadline.bold()).lineLimit(1); Spacer(); Button { g.select(nil, nil) } label: { Text("✕").font(.title3) } }
      ScrollView(.horizontal, showsIndicators: false) {
        HStack(spacing: 8) {
          btn("🗑", "Xóa", .red) { g.deleteSelected() }
          btn("✥", "Di chuyển", .blue, active: g.moving) { g.toggleMove() }
          btn("↻", "Xoay", .white) { g.rotate(0.26) }
          btn("➕", "Phóng to", .white) { g.resize(1.2) }
          btn("➖", "Thu nhỏ", .white) { g.resize(1 / 1.2) }
          btn("⧉", "Nhân bản", .white) { g.duplicateSelected() }
          btn("▦", "Tạo hàng", .white) { g.rowPanel = true }
        }
      }.frame(height: 62)
    }.padding(10).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
  }
}

struct ContentView: View {
  @StateObject var g = Game()
  var roadPanelOpen: Bool { !g.fullscreen && g.selRoad != nil && g.mode != 0 }
  var rowPanelOpen: Bool { !g.fullscreen && !roadPanelOpen && g.rowPanel && g.selId != nil && g.mode != 0 }
  var actionBarOpen: Bool { !g.fullscreen && g.selId != nil && g.mode != 0 }
  var sketchShown: Bool { g.sketchVisible }
  var body: some View {
    GeometryReader { geo in
    VStack(spacing: 0) {
    ZStack {
      SceneUI(g: g).ignoresSafeArea(edges: sketchShown ? Edge.Set.top : Edge.Set.all)
      if g.walkMode { WalkPad(g: g) }
      VStack {
        HStack {
          Color.clear.frame(width: 56, height: 56)
          Spacer()
          if !g.fullscreen { Picker("", selection: $g.mode) { Text("Đặt").tag(0); Text("Chọn").tag(1); Text("Xóa").tag(2) }.pickerStyle(.segmented).frame(width: 210) }
          Spacer()
          Button { g.fullscreen.toggle() } label: { Text(g.fullscreen ? "⤡" : "⛶").font(.title).frame(width: 56, height: 56).background(Color.white.opacity(0.4), in: Circle()) }
        }.padding(.top, sketchShown ? 4 : 54)
        if g.walkMode && !g.walkNote.isEmpty { Text(g.walkNote).font(.footnote.bold()).padding(.horizontal, 14).padding(.vertical, 8).background(.ultraThinMaterial, in: Capsule()).padding(.top, 6) }
        if let t = g.toast, !g.fullscreen {
          HStack(spacing: 14) {
            Text(t).font(.footnote.bold()).lineLimit(1).minimumScaleFactor(0.7)
            if g.undoCount > 0 { Button { g.undoLast() } label: { Image(systemName: "arrow.uturn.backward.circle.fill").font(.title2).foregroundColor(.orange) } }
            if g.redoCount > 0 { Button { g.redoLast() } label: { Image(systemName: "arrow.uturn.forward.circle.fill").font(.title2).foregroundColor(.blue) } }
          }.padding(.horizontal, 14).padding(.vertical, 8).background(.ultraThinMaterial, in: Capsule()).padding(.top, 6)
        }
        Spacer()
        HStack(alignment: .bottom) {
          VStack(alignment: .leading, spacing: 10) {
            if !g.fullscreen && !(g.cat == "Vẽ đường" && g.drawing > 0 && !g.freeDraw) {
              HStack(spacing: 10) {
                Button { g.undoLast() } label: { Image(systemName: "arrow.uturn.backward").font(.title3.bold()).frame(width: 52, height: 52).background(Color.orange.opacity(g.undoCount > 0 ? 0.7 : 0.25), in: Circle()) }.disabled(g.undoCount == 0)
                Button { g.redoLast() } label: { Image(systemName: "arrow.uturn.forward").font(.title3.bold()).frame(width: 52, height: 52).background(Color.blue.opacity(g.redoCount > 0 ? 0.6 : 0.25), in: Circle()) }.disabled(g.redoCount == 0)
              }.foregroundColor(.primary)
            }
            if roadPanelOpen { RoadPanel(g: g).frame(maxWidth: 290) }
            else if rowPanelOpen { RowPanel(g: g).frame(maxWidth: 290) }
            if !g.walkMode { Joystick { g.move = $0 } }
          }
          Spacer()
          VStack(spacing: 10) {
            if sketchShown {
              Button { g.aerialZoom(1.3) } label: { Text("＋").font(.title2.bold()).frame(width: 52, height: 52).background(Color.white.opacity(0.5), in: Circle()) }.foregroundColor(.primary)
              Button { g.aerialZoom(1 / 1.3) } label: { Text("－").font(.title2.bold()).frame(width: 52, height: 52).background(Color.white.opacity(0.5), in: Circle()) }.foregroundColor(.primary)
            } else {
            if !g.fullscreen {
            if g.mode == 0 {
              Button { g.sketchOpen.toggle() } label: { Text("✍️").font(.title2).frame(width: 52, height: 52).background(Color.white.opacity(0.4), in: Circle()) }
            }
            if g.cat == "Vẽ đường" && g.mode == 0 {
              Button { g.freeDraw.toggle() } label: { Text("✏️").font(.title2).frame(width: 52, height: 52).background(g.freeDraw ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Circle()) }
            }
            if g.cat == "Vẽ đường" && g.drawing > 0 && !g.freeDraw {
              Button { g.finish() } label: { Text("✔").font(.title2).frame(width: 52, height: 52).background(Color.green.opacity(0.6), in: Circle()) }
              Button { g.undoPoint() } label: { Text("↩").font(.title).frame(width: 52, height: 52).background(Color.white.opacity(0.5), in: Circle()) }
            }
            Button { g.cycleSway() } label: { Text(["🍃✖", "🍃", "🍃🍃"][g.swayLevel]).font(.title3).frame(width: 56, height: 56).background(g.swayLevel > 0 ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Circle()) }
            }
            Button { g.ensureCharHooks(); g.charSheet = true } label: { Text("👤").font(.title).frame(width: 56, height: 56).background(Color.white.opacity(0.4), in: Circle()) }
            if g.walkMode { WalkTools(g: g) }
            Button { g.walkMode.toggle() } label: { Text("🚶").font(.title).frame(width: 56, height: 56).background(g.walkMode ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Circle()) }
            Button { g.run.toggle() } label: { Text("🏃").font(.title).frame(width: 56, height: 56).background(g.run ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Circle()) }
            Button { g.home() } label: { Text("🏠").font(.title).frame(width: 56, height: 56).background(Color.white.opacity(0.4), in: Circle()) }
            }
          }
        }.padding(.horizontal, 12)
        if g.fullscreen || g.walkMode || roadPanelOpen || rowPanelOpen || sketchShown { EmptyView() } else if actionBarOpen { ActionBar(g: g).padding(.bottom, 20) } else {
        VStack(spacing: 6) {
          ScrollView(.horizontal, showsIndicators: false) {
            HStack { ForEach(g.order, id: \.self) { c in
              Button { g.cat = c; if let f = g.items[c]?.first { g.sel = f }; g.sketchOpen = g.isPathItem(g.sel) && g.mode == 0 } label: {
                Text(c).font(.caption.bold()).padding(.horizontal, 10).padding(.vertical, 6)
                  .background(g.cat == c ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Capsule()) }.foregroundColor(.primary) } }
          }.frame(height: 38)
          ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack {
              if g.cat == ModelLib.category {
                Button { g.importModels() } label: {
                  VStack(spacing: 2) {
                    Text("＋").font(.largeTitle).frame(width: 66, height: 66).background(Color.white.opacity(0.6), in: RoundedRectangle(cornerRadius: 8))
                    Text("Nhập 3D").font(.caption2).lineLimit(1).frame(width: 70)
                  }.padding(8).background(Color.white.opacity(0.4), in: RoundedRectangle(cornerRadius: 10))
                }.foregroundColor(.primary)
              }
              ForEach(g.items[g.cat] ?? [], id: \.self) { i in
              Button { g.sel = i; g.mode = 0; g.sketchOpen = g.isPathItem(i) } label: {
                VStack(spacing: 2) {
                  Group { if let im = g.thumbs[i] { Image(uiImage: im).resizable().scaledToFit() } else { Text(g.icon(i)).font(.title) } }
                    .frame(width: 66, height: 66).background(Color.white.opacity(0.6), in: RoundedRectangle(cornerRadius: 8))
                  Text(g.label(i)).font(.caption2).lineLimit(1).frame(width: 70)
                  }
                  .onAppear { g.requestThumb(i) }
                  .padding(8).background(g.sel == i ? Color.green.opacity(0.5) : Color.white.opacity(0.4), in: RoundedRectangle(cornerRadius: 10)) }.foregroundColor(.primary)
                .contextMenu { if ModelLib.isImp(i) { Button(role: .destructive) { g.deleteImported(i) } label: { Label("Xóa khỏi thư viện (cả bản đã đặt)", systemImage: "trash") } } } } }
          }.frame(height: 118)
        }.padding(10).background(.ultraThinMaterial).padding(.bottom, 20) }
      }.padding(.horizontal, 8)
    }
    if sketchShown { SketchPanel(g: g, sk: g.sk).frame(height: geo.size.height * 0.46) }
    }
    }
    .statusBarHidden(g.fullscreen)
    .persistentSystemOverlays(g.fullscreen ? .hidden : .automatic)
    .sheet(isPresented: $g.charSheet) { CharacterSheet(g: g) }
    .alert("Nhập mô hình", isPresented: Binding(get: { g.impAlert != nil }, set: { if !$0 { g.impAlert = nil } })) { Button("OK", role: .cancel) {} } message: { Text(g.impAlert ?? "") }
    .onAppear { g.restoreNPCs() }
  }
}
