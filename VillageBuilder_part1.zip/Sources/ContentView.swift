import SwiftUI
import SceneKit

struct SceneUI: UIViewRepresentable {
  let g: Game
  func makeUIView(context: Context) -> SCNView {
    let v = SCNView(); v.scene = g.scene; v.pointOfView = g.cam; v.allowsCameraControl = false
    v.antialiasingMode = .multisampling4X; v.rendersContinuously = true; v.preferredFramesPerSecond = 60
    v.delegate = context.coordinator
    v.addGestureRecognizer(UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tap(_:))))
    v.addGestureRecognizer(UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pan(_:))))
    v.addGestureRecognizer(UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pinch(_:))))
    return v }
  func updateUIView(_ v: SCNView, context: Context) {}
  func makeCoordinator() -> Coordinator { Coordinator(g) }
  final class Coordinator: NSObject, SCNSceneRendererDelegate {
    let g: Game; var last: TimeInterval = 0; init(_ g: Game) { self.g = g }
    func renderer(_ r: SCNSceneRenderer, updateAtTime t: TimeInterval) { let dt = last == 0 ? 0 : min(Float(t - last), 0.1); last = t; g.step(dt) }
    @objc func tap(_ r: UITapGestureRecognizer) { guard let v = r.view as? SCNView else { return }; g.tap(v, r.location(in: v)) }
    @objc func pinch(_ r: UIPinchGestureRecognizer) { if r.state == .changed && g.mode == 1 { g.resize(Float(r.scale)); r.scale = 1 } }
    @objc func pan(_ r: UIPanGestureRecognizer) { let d = r.translation(in: r.view); r.setTranslation(.zero, in: r.view); g.look(Float(d.x), Float(d.y)) } }
}

struct Joystick: View {
  var onChange: (CGVector) -> Void
  @State private var off = CGSize.zero
  var body: some View {
    ZStack {
      Circle().fill(.ultraThinMaterial).frame(width: 130, height: 130)
      Circle().fill(Color.white.opacity(0.85)).frame(width: 54, height: 54).offset(off)
    }
    .gesture(DragGesture(minimumDistance: 0).onChanged { v in
      let r: CGFloat = 50; var dx = v.translation.width, dy = v.translation.height; let d = hypot(dx, dy)
      if d > r { dx *= r / d; dy *= r / d }
      off = CGSize(width: dx, height: dy); onChange(CGVector(dx: dx / r, dy: -dy / r))
    }.onEnded { _ in off = .zero; onChange(.zero) })
  }
}

struct ContentView: View {
  @StateObject var g = Game()
  var body: some View {
    ZStack {
      SceneUI(g: g)
      VStack {
        HStack {
          Picker("", selection: $g.mode) { Text("Đặt").tag(0); Text("Chọn").tag(1); Text("Xóa").tag(2) }.pickerStyle(.segmented).frame(width: 210)
        }.padding(.top, 54)
        Spacer()
        HStack(alignment: .bottom) {
          Joystick { g.move = $0 }
          Spacer()
          VStack(spacing: 10) {
            if g.cat == "Vẽ đường" && g.drawing > 0 {
              Button { g.finish() } label: { Text("✔").font(.title2).frame(width: 52, height: 52).background(Color.green.opacity(0.6), in: Circle()) }
              Button { g.undoPoint() } label: { Text("↩").font(.title).frame(width: 52, height: 52).background(Color.white.opacity(0.5), in: Circle()) }
            }
            if g.mode == 1 && g.selId != nil {
              Button { g.resize(1.2) } label: { Text("➕").font(.title2).frame(width: 52, height: 52).background(Color.white.opacity(0.5), in: Circle()) }
              Button { g.resize(1 / 1.2) } label: { Text("➖").font(.title2).frame(width: 52, height: 52).background(Color.white.opacity(0.5), in: Circle()) }
              Button { g.rotate(0.26) } label: { Text("↻").font(.title).frame(width: 52, height: 52).background(Color.white.opacity(0.5), in: Circle()) }
            }
            Button { g.cycleSway() } label: { Text(["🍃✖", "🍃", "🍃🍃"][g.swayLevel]).font(.title3).frame(width: 56, height: 56).background(g.swayLevel > 0 ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Circle()) }
            Button { g.run.toggle() } label: { Text("🏃").font(.title).frame(width: 56, height: 56).background(g.run ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Circle()) }
            Button { g.home() } label: { Text("🏠").font(.title).frame(width: 56, height: 56).background(Color.white.opacity(0.4), in: Circle()) }
          }
        }.padding(.horizontal, 12)
        VStack(spacing: 6) {
          ScrollView(.horizontal, showsIndicators: false) {
            HStack { ForEach(g.order, id: \.self) { c in
              Button { g.cat = c; if let f = g.items[c]?.first { g.sel = f } } label: {
                Text(c).font(.caption.bold()).padding(.horizontal, 10).padding(.vertical, 6)
                  .background(g.cat == c ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Capsule()) }.foregroundColor(.primary) } }
          }
          ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack { ForEach(g.items[g.cat] ?? [], id: \.self) { i in
              Button { g.sel = i; g.mode = 0 } label: {
                VStack(spacing: 2) {
                  Group { if let im = g.thumbs[i] { Image(uiImage: im).resizable().scaledToFit() } else { Text(g.icon(i)).font(.title) } }
                    .frame(width: 66, height: 66).background(Color.white.opacity(0.6), in: RoundedRectangle(cornerRadius: 8))
                  Text(i == "grass" ? "Cỏ" : i).font(.caption2).lineLimit(1).frame(width: 70)
                  }
                  .onAppear { g.requestThumb(i) }
                  .padding(8).background(g.sel == i ? Color.green.opacity(0.5) : Color.white.opacity(0.4), in: RoundedRectangle(cornerRadius: 10)) }.foregroundColor(.primary) } }
          }
        }.padding(10).background(.ultraThinMaterial).padding(.bottom, 20)
      }.padding(.horizontal, 8)
    }
  }
}
