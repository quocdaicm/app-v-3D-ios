import SwiftUI
import SceneKit

struct SceneUI: UIViewRepresentable {
  let g: Game
  func makeUIView(context: Context) -> SCNView {
    let v = SCNView(); v.scene = g.scene; v.pointOfView = g.cam; v.allowsCameraControl = false
    v.antialiasingMode = .multisampling4X; v.rendersContinuously = true; v.preferredFramesPerSecond = 60
    v.delegate = context.coordinator
    v.addGestureRecognizer(UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tap(_:))))
    v.addGestureRecognizer(UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pan(_:))))
    v.addGestureRecognizer(UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pinch(_:))))
    return v }
  func updateUIView(_ v: SCNView, context: Context) {}
  func makeCoordinator() -> Coordinator { Coordinator(g) }
  final class Coordinator: NSObject, SCNSceneRendererDelegate {
    let g: Game; var last: TimeInterval = 0; init(_ g: Game) { self.g = g }
    func renderer(_ r: SCNSceneRenderer, updateAtTime t: TimeInterval) { let dt = last == 0 ? 0 : min(Float(t - last), 0.1); last = t; g.step(dt) }
    @objc func tap(_ r: UITapGestureRecognizer) { guard let v = r.view as? SCNView else { return }; g.tap(v, r.location(in: v)) }
    @objc func pinch(_ r: UIPinchGestureRecognizer) { if r.state == .changed && g.mode == 1 { g.resize(Float(r.scale)); r.scale = 1 } }
    var dragging = false
    @objc func pan(_ r: UIPanGestureRecognizer) {
      if g.mode == 1, let v = r.view as? SCNView {
        if r.state == .began { dragging = g.dragBegin(v, r.location(in: v)) }
        if dragging {
          if r.state == .changed { g.dragMove(v, r.location(in: v)) }
          else if r.state == .ended || r.state == .cancelled || r.state == .failed { g.dragEnd(); dragging = false }
          return } }
      if g.cat == "Vẽ đường" && g.mode == 0 && g.freeDraw, let v = r.view as? SCNView {
        switch r.state {
        case .began: g.strokeBegin(); g.strokeMove(v, r.location(in: v))
        case .changed: g.strokeMove(v, r.location(in: v))
        case .ended, .cancelled, .failed: g.strokeEnd()
        default: break }
        return }
      let d = r.translation(in: r.view); r.setTranslation(.zero, in: r.view); g.look(Float(d.x), Float(d.y)) } }
}

struct Joystick: View {
  var onChange: (CGVector) -> Void
  @State private var off = CGSize.zero
  var body: some View {
    ZStack {
      Circle().fill(.ultraThinMaterial).frame(width: 130, height: 130)
      Circle().fill(Color.white.opacity(0.85)).frame(width: 54, height: 54).offset(off)
    }
    .gesture(DragGesture(minimumDistance: 0).onChanged { v in
      let r: CGFloat = 50; var dx = v.translation.width, dy = v.translation.height; let d = hypot(dx, dy)
      if d > r { dx *= r / d; dy *= r / d }
      off = CGSize(width: dx, height: dy); onChange(CGVector(dx: dx / r, dy: -dy / r))
    }.onEnded { _ in off = .zero; onChange(.zero) })
  }
}

struct RoadPanel: View {
  @ObservedObject var g: Game
  @State private var shape = 0; @State private var atStart = false
  @State private var len = "20"; @State private var rad = "12"
  func num(_ t: String) -> Float { Float(t.replacingOccurrences(of: ",", with: ".")) ?? 0 }
  var body: some View {
    VStack(spacing: 8) {
      HStack { Text(g.selRoadTitle).font(.headline); Spacer(); Button { g.selectRoad(nil) } label: { Text("✕").font(.title3) } }
      Picker("", selection: $shape) { Text("Thẳng").tag(0); Text("Cong trái").tag(1); Text("Cong phải").tag(2) }.pickerStyle(.segmented)
      Picker("", selection: $atStart) { Text("Nối cuối 🔴").tag(false); Text("Nối đầu 🟢").tag(true) }.pickerStyle(.segmented)
      HStack {
        Text("Dài (m)"); TextField("20", text: $len).keyboardType(.decimalPad).textFieldStyle(.roundedBorder).frame(width: 70)
        if shape > 0 { Text("Bán kính (m)"); TextField("12", text: $rad).keyboardType(.decimalPad).textFieldStyle(.roundedBorder).frame(width: 70) }
        Spacer() }
      HStack {
        Button { g.extendRoad(atStart: atStart, shape: shape, length: num(len), radius: num(rad)) } label: { Text("➕ Nối thêm").frame(maxWidth: .infinity) }.buttonStyle(.borderedProminent).tint(.green)
        Button { g.deleteSelRoad() } label: { Text("🗑 Xóa").frame(maxWidth: .infinity) }.buttonStyle(.bordered).tint(.red) }
    }.padding(12).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
  }
}

struct RowPanel: View {
  @ObservedObject var g: Game
  @State private var shape = 0; @State private var byObj = false
  @State private var len = "10"; @State private var gap = "1"; @State private var rad = "12"
  func num(_ t: String) -> Float { Float(t.replacingOccurrences(of: ",", with: ".")) ?? 0 }
  var body: some View {
    VStack(spacing: 8) {
      HStack { Text("Tạo hàng: \(g.selItem)").font(.headline); Spacer(); Button { g.rowPanel = false } label: { Text("✕").font(.title3) } }
      Picker("", selection: $shape) { Text("Thẳng").tag(0); Text("Cong trái").tag(1); Text("Cong phải").tag(2) }.pickerStyle(.segmented)
      Picker("", selection: $byObj) { Text("Hướng nhìn").tag(false); Text("Theo vật").tag(true) }.pickerStyle(.segmented)
      HStack {
        Text("Dài (m)"); TextField("10", text: $len).keyboardType(.decimalPad).textFieldStyle(.roundedBorder).frame(width: 62)
        Text("Cách (m)"); TextField("1", text: $gap).keyboardType(.decimalPad).textFieldStyle(.roundedBorder).frame(width: 62)
        Spacer() }
      if shape > 0 { HStack { Text("Bán kính (m)"); TextField("12", text: $rad).keyboardType(.decimalPad).textFieldStyle(.roundedBorder).frame(width: 70); Spacer() } }
      Button { g.makeRow(shape: shape, byObject: byObj, length: num(len), spacing: num(gap), radius: num(rad)) } label: { Text("➕ Tạo hàng").frame(maxWidth: .infinity) }.buttonStyle(.borderedProminent).tint(.green)
    }.padding(12).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
    .onAppear { gap = String(format: "%.1f", g.defaultSpacing()); byObj = g.isLenModel(g.recOf(g.selId ?? "")?.item ?? "") }
  }
}

struct ContentView: View {
  @StateObject var g = Game()
  var body: some View {
    ZStack {
      SceneUI(g: g)
      VStack {
        HStack {
          Picker("", selection: $g.mode) { Text("Đặt").tag(0); Text("Chọn").tag(1); Text("Xóa").tag(2) }.pickerStyle(.segmented).frame(width: 210)
        }.padding(.top, 54)
        Spacer()
        HStack(alignment: .bottom) {
          Joystick { g.move = $0 }
          Spacer()
          VStack(spacing: 10) {
            if g.cat == "Vẽ đường" && g.mode == 0 {
              Button { g.freeDraw.toggle() } label: { Text("✏️").font(.title2).frame(width: 52, height: 52).background(g.freeDraw ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Circle()) }
            }
            if g.cat == "Vẽ đường" && g.drawing > 0 && !g.freeDraw {
              Button { g.finish() } label: { Text("✔").font(.title2).frame(width: 52, height: 52).background(Color.green.opacity(0.6), in: Circle()) }
              Button { g.undoPoint() } label: { Text("↩").font(.title).frame(width: 52, height: 52).background(Color.white.opacity(0.5), in: Circle()) }
            }
            if g.undoCount > 0 && !(g.cat == "Vẽ đường" && g.drawing > 0 && !g.freeDraw) {
              Button { g.undoLast() } label: { Text("↩").font(.title).frame(width: 52, height: 52).background(Color.orange.opacity(0.6), in: Circle()) }
            }
            if g.mode == 1 && g.selId != nil {
              Button { g.rowPanel.toggle() } label: { Text("▦").font(.title2).frame(width: 52, height: 52).background(g.rowPanel ? Color.green.opacity(0.6) : Color.white.opacity(0.5), in: Circle()) }
              Button { g.deleteSelected() } label: { Text("🗑").font(.title2).frame(width: 52, height: 52).background(Color.red.opacity(0.5), in: Circle()) }
              Button { g.resize(1.2) } label: { Text("➕").font(.title2).frame(width: 52, height: 52).background(Color.white.opacity(0.5), in: Circle()) }
              Button { g.resize(1 / 1.2) } label: { Text("➖").font(.title2).frame(width: 52, height: 52).background(Color.white.opacity(0.5), in: Circle()) }
              Button { g.rotate(0.26) } label: { Text("↻").font(.title).frame(width: 52, height: 52).background(Color.white.opacity(0.5), in: Circle()) }
            }
            Button { g.cycleSway() } label: { Text(["🍃✖", "🍃", "🍃🍃"][g.swayLevel]).font(.title3).frame(width: 56, height: 56).background(g.swayLevel > 0 ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Circle()) }
            Button { g.run.toggle() } label: { Text("🏃").font(.title).frame(width: 56, height: 56).background(g.run ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Circle()) }
            Button { g.home() } label: { Text("🏠").font(.title).frame(width: 56, height: 56).background(Color.white.opacity(0.4), in: Circle()) }
          }
        }.padding(.horizontal, 12)
        if g.selRoad != nil && g.mode == 1 { RoadPanel(g: g).padding(.bottom, 20) } else if g.rowPanel && g.selId != nil && g.mode == 1 { RowPanel(g: g).padding(.bottom, 20) } else {
        VStack(spacing: 6) {
          ScrollView(.horizontal, showsIndicators: false) {
            HStack { ForEach(g.order, id: \.self) { c in
              Button { g.cat = c; if let f = g.items[c]?.first { g.sel = f } } label: {
                Text(c).font(.caption.bold()).padding(.horizontal, 10).padding(.vertical, 6)
                  .background(g.cat == c ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Capsule()) }.foregroundColor(.primary) } }
          }.frame(height: 38)
          ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack { ForEach(g.items[g.cat] ?? [], id: \.self) { i in
              Button { g.sel = i; g.mode = 0 } label: {
                VStack(spacing: 2) {
                  Group { if let im = g.thumbs[i] { Image(uiImage: im).resizable().scaledToFit() } else { Text(g.icon(i)).font(.title) } }
                    .frame(width: 66, height: 66).background(Color.white.opacity(0.6), in: RoundedRectangle(cornerRadius: 8))
                  Text(i == "grass" ? "Cỏ" : i).font(.caption2).lineLimit(1).frame(width: 70)
                  }
                  .onAppear { g.requestThumb(i) }
                  .padding(8).background(g.sel == i ? Color.green.opacity(0.5) : Color.white.opacity(0.4), in: RoundedRectangle(cornerRadius: 10)) }.foregroundColor(.primary) } }
          }.frame(height: 118)
        }.padding(10).background(.ultraThinMaterial).padding(.bottom, 20) }
      }.padding(.horizontal, 8)
    }
  }
}
