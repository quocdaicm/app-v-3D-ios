import SwiftUI
import SceneKit

struct SceneUI: UIViewRepresentable {
  let g: Game
  func makeUIView(context: Context) -> SCNView {
    let v = SCNView(); v.scene = g.scene; v.pointOfView = g.cam; v.allowsCameraControl = false
    v.antialiasingMode = .multisampling4X; v.rendersContinuously = true; v.preferredFramesPerSecond = 60
    v.delegate = context.coordinator; g.scnView = v
    v.addGestureRecognizer(UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tap(_:))))
    v.addGestureRecognizer(UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pan(_:))))
    v.addGestureRecognizer(UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pinch(_:))))
    return v }
  func updateUIView(_ v: SCNView, context: Context) {}
  func makeCoordinator() -> Coordinator { Coordinator(g) }
  final class Coordinator: NSObject, SCNSceneRendererDelegate {
    let g: Game; var last: TimeInterval = 0; init(_ g: Game) { self.g = g }
    var touchedAt: CFTimeInterval = 0; var fps = 60   // 60fps khi đang chạm / đi, 30fps khi đứng yên: hình giữ nguyên, GPU đỡ nóng
    func renderer(_ r: SCNSceneRenderer, updateAtTime t: TimeInterval) {
      let dt = last == 0 ? 0 : min(Float(t - last), 0.1); last = t; g.step(dt)
      let now = CACurrentMediaTime()
      if g.move.dx != 0 || g.move.dy != 0 { touchedAt = now }
      let want = now - touchedAt < 1.5 ? 60 : 30
      if want != fps { fps = want; DispatchQueue.main.async { (r as? SCNView)?.preferredFramesPerSecond = want; (r as? SCNView)?.antialiasingMode = want == 60 ? .multisampling2X : .multisampling4X } } }
    @objc func tap(_ r: UITapGestureRecognizer) { touchedAt = CACurrentMediaTime(); guard let v = r.view as? SCNView else { return }; g.tap(v, r.location(in: v)) }
    @objc func pinch(_ r: UIPinchGestureRecognizer) {
      touchedAt = CACurrentMediaTime()
      guard r.state == .changed else { return }
      if g.walkMode { g.walkZoom(Float(1 / r.scale)) }                                    // đi dạo: mở 2 ngón = lại gần, chụm = ra xa
      else if g.sketchVisible { g.aerialZoom(Float(r.scale)) }
      else if g.mode != 0 && g.selId != nil && !g.hideUI { g.resize(Float(r.scale)) }   // đang chọn vật: chụm để phóng / thu vật
      else { g.zoomView(Float(r.scale)) }                                               // còn lại: phóng / thu khung nhìn
      r.scale = 1 }
    var dragging = false
    @objc func pan(_ r: UIPanGestureRecognizer) {
      touchedAt = CACurrentMediaTime()
      if g.fullscreen || g.hideUI || g.walkMode { let d = r.translation(in: r.view); r.setTranslation(.zero, in: r.view); g.look(Float(d.x), Float(d.y)); return }
      if g.sketchVisible { let d = r.translation(in: r.view); r.setTranslation(.zero, in: r.view); g.aerialPan(Float(d.x), Float(d.y)); return }
      if g.mode != 0, let v = r.view as? SCNView {
        if r.state == .began { dragging = g.dragBegin(v, r.location(in: v)) }
        if dragging {
          if r.state == .changed { g.dragMove(v, r.location(in: v)) }
          else if r.state == .ended || r.state == .cancelled || r.state == .failed { g.dragEnd(); dragging = false }
          return } }
      if g.cat == "Vẽ đường" && g.mode == 0 && g.freeDraw, let v = r.view as? SCNView {
        switch r.state {
        case .began: g.strokeBegin(); g.strokeMove(v, r.location(in: v))
        case .changed: g.strokeMove(v, r.location(in: v))
        case .ended, .cancelled, .failed: g.strokeEnd()
        default: break }
        return }
      let d = r.translation(in: r.view); r.setTranslation(.zero, in: r.view); g.look(Float(d.x), Float(d.y)) } }
}

struct Joystick: View {
  var scale: CGFloat = 1          // 0,8 khi xoay ngang cho vừa màn hình thấp
  var onChange: (CGVector) -> Void
  @State private var off = CGSize.zero
  var body: some View {
    ZStack {
      Circle().fill(.ultraThinMaterial).frame(width: 130 * scale, height: 130 * scale)
      Circle().fill(Color.white.opacity(0.85)).frame(width: 54 * scale, height: 54 * scale).offset(off)
    }
    .gesture(DragGesture(minimumDistance: 0).onChanged { v in
      let r: CGFloat = 50 * scale; var dx = v.translation.width, dy = v.translation.height; let d = hypot(dx, dy)
      if d > r { dx *= r / d; dy *= r / d }
      off = CGSize(width: dx, height: dy); onChange(CGVector(dx: dx / r, dy: -dy / r))
    }.onEnded { _ in off = .zero; onChange(.zero) })
  }
}

struct NumSlider: View {
  let title: String; @Binding var v: Float; let r: ClosedRange<Float>; let step: Float; let fmt: String
  var body: some View {
    HStack(spacing: 6) {
      Text(title).font(.footnote).frame(width: 64, alignment: .leading)
      Slider(value: $v, in: r, step: step).tint(.green)
      Text(String(format: fmt, v)).font(.footnote.monospacedDigit()).frame(width: 40, alignment: .trailing)
    }
  }
}

struct RoadPanel: View {
  @ObservedObject var g: Game
  @State private var shape = 0; @State private var atStart = false
  @State private var len: Float = 20; @State private var rad: Float = 12
  var body: some View {
    VStack(spacing: 6) {
      HStack { Text(g.selRoadTitle).font(.subheadline.bold()).lineLimit(1); Spacer(); Button { g.selectRoad(nil) } label: { Text("✕").font(.title3) } }
      Picker("", selection: $shape) { Text("Thẳng").tag(0); Text("Cong trái").tag(1); Text("Cong phải").tag(2) }.pickerStyle(.segmented)
      Picker("", selection: $atStart) { Text("Nối cuối 🔴").tag(false); Text("Nối đầu 🟢").tag(true) }.pickerStyle(.segmented)
      NumSlider(title: "Dài (m)", v: $len, r: 1...100, step: 1, fmt: "%.0f")
      if shape > 0 { NumSlider(title: "Bán kính", v: $rad, r: 2...60, step: 1, fmt: "%.0f") }
      HStack {
        Button { g.extendRoad(atStart: atStart, shape: shape, length: len, radius: rad) } label: { Text("➕ Nối thêm").frame(maxWidth: .infinity) }.buttonStyle(.borderedProminent).tint(.green)
        Button { g.deleteSelRoad() } label: { Text("🗑 Xóa").frame(maxWidth: .infinity) }.buttonStyle(.bordered).tint(.red) }
    }.padding(10).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
  }
}

struct RowPanel: View {
  @ObservedObject var g: Game
  @State private var shape = 0; @State private var byObj = false
  @State private var len: Float = 10; @State private var gap: Float = 1; @State private var rad: Float = 12
  var body: some View {
    VStack(spacing: 6) {
      HStack { Text("Tạo hàng: \(g.selItem)").font(.subheadline.bold()).lineLimit(1); Spacer(); Button { g.rowPanel = false } label: { Text("✕").font(.title3) } }
      Picker("", selection: $shape) { Text("Thẳng").tag(0); Text("Cong trái").tag(1); Text("Cong phải").tag(2) }.pickerStyle(.segmented)
      Picker("", selection: $byObj) { Text("Hướng nhìn").tag(false); Text("Theo vật").tag(true) }.pickerStyle(.segmented)
      NumSlider(title: "Dài (m)", v: $len, r: 1...100, step: 1, fmt: "%.0f")
      NumSlider(title: "Cách (m)", v: $gap, r: 0.2...10, step: 0.1, fmt: "%.1f")
      if shape > 0 { NumSlider(title: "Bán kính", v: $rad, r: 2...60, step: 1, fmt: "%.0f") }
      Button { g.makeRow(shape: shape, byObject: byObj, length: len, spacing: gap, radius: rad) } label: { Text("➕ Tạo hàng").frame(maxWidth: .infinity) }.buttonStyle(.borderedProminent).tint(.green)
    }.padding(10).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
    .onAppear { gap = min(max((g.defaultSpacing() * 10).rounded() / 10, 0.2), 10); byObj = g.isLenModel(g.recOf(g.selId ?? "")?.item ?? "") }
  }
}

struct ActionBar: View {
  @ObservedObject var g: Game
  func btn(_ icon: String, _ label: String, _ color: Color, active: Bool = false, _ act: @escaping () -> Void) -> some View {
    Button(action: act) {
      VStack(spacing: 2) { Text(icon).font(.title2); Text(label).font(.caption2).lineLimit(1) }
        .frame(width: 66, height: 58)
        .background(active ? Color.green.opacity(0.65) : color.opacity(0.35), in: RoundedRectangle(cornerRadius: 10))
    }.foregroundColor(.primary)
  }
  var body: some View {
    VStack(spacing: 6) {
      HStack { Text("Đã chọn: \(g.selItem)").font(.subheadline.bold()).lineLimit(1); Spacer(); Button { g.select(nil, nil) } label: { Text("✕").font(.title3) } }
      ScrollView(.horizontal, showsIndicators: false) {
        HStack(spacing: 8) {
          btn("🗑", "Xóa", .red) { g.deleteSelected() }
          btn("✥", "Di chuyển", .blue, active: g.moving) { g.toggleMove() }
          btn("↻", "Xoay", .white) { g.rotate(0.26) }
          btn("➕", "Phóng to", .white) { g.resize(1.2) }
          btn("➖", "Thu nhỏ", .white) { g.resize(1 / 1.2) }
          btn("⧉", "Nhân bản", .white) { g.duplicateSelected() }
          btn("▦", "Tạo hàng", .white) { g.rowPanel = true }
        }
      }.frame(height: 62)
    }.padding(10).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
  }
}

// ===== Thành phần giao diện dùng chung =====
/// Biểu tượng tròn thống nhất cho mọi nút nổi (SF Symbols; `active` = đang bật).
struct ToolIcon: View {
  let symbol: String; var active = false; var tint: Color = .green; var size: CGFloat = 44
  var body: some View {
    Image(systemName: symbol).font(.system(size: 18, weight: .semibold))
      .frame(width: size, height: size)
      .foregroundColor(active ? .white : .primary)
      .background(active ? tint : Color.clear, in: Circle())
      .contentShape(Circle())
  }
}
/// Nhóm nút nổi: một viên thuốc mờ chứa các nút cùng chức năng.
struct Dock<Content: View>: View {
  let vertical: Bool; let content: Content
  init(vertical: Bool = true, @ViewBuilder _ content: () -> Content) { self.vertical = vertical; self.content = content() }
  var body: some View {
    Group { if vertical { VStack(spacing: 2) { content } } else { HStack(spacing: 2) { content } } }
      .padding(4).background(.ultraThinMaterial, in: Capsule()).shadow(color: .black.opacity(0.15), radius: 4, y: 1)
  }
}

/// Thanh chọn vật để đặt: hàng nhóm (có nút thu gọn) + hàng mô hình có ảnh xem trước.
struct CatalogBar: View {
  @ObservedObject var g: Game
  @Binding var open: Bool
  private func thumb(_ i: String, _ size: CGFloat) -> some View {
    Group { if let im = g.thumbs[i] { Image(uiImage: im).resizable().scaledToFit() } else { Text(g.icon(i)).font(size > 40 ? .title : .body) } }
      .frame(width: size, height: size)
  }
  private func cell(_ i: String) -> some View {
    Button { g.sel = i; g.mode = 0; g.sketchOpen = g.isPathItem(i) } label: {
      VStack(spacing: 3) {
        thumb(i, 62).background(Color.white.opacity(0.6), in: RoundedRectangle(cornerRadius: 10))
          .overlay(RoundedRectangle(cornerRadius: 10).stroke(g.sel == i ? Color.green : Color.clear, lineWidth: 3))
        Text(g.label(i)).font(.caption2).lineLimit(1).frame(width: 68)
      }.onAppear { g.requestThumb(i) }
    }.foregroundColor(.primary)
    .contextMenu { if ModelLib.isImp(i) { Button(role: .destructive) { g.deleteImported(i) } label: { Label("Xóa khỏi thư viện (cả bản đã đặt)", systemImage: "trash") } } }
  }
  var body: some View {
    if open {
      VStack(spacing: 8) {
        HStack(spacing: 8) {
          ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) { ForEach(g.order, id: \.self) { c in
              Button { g.cat = c; if let f = g.items[c]?.first { g.sel = f }; g.sketchOpen = g.isPathItem(g.sel) && g.mode == 0 } label: {
                Text(c).font(.footnote.weight(.semibold)).padding(.horizontal, 12).padding(.vertical, 7)
                  .foregroundColor(g.cat == c ? .white : .primary)
                  .background(g.cat == c ? Color.green : Color.primary.opacity(0.08), in: Capsule()) } } }
          }
          Button { withAnimation(.easeInOut(duration: 0.2)) { open = false } } label: {
            Image(systemName: "chevron.down").font(.system(size: 14, weight: .bold)).frame(width: 34, height: 34).background(Color.primary.opacity(0.08), in: Circle())
          }.foregroundColor(.primary)
        }.frame(height: 36)
        ScrollView(.horizontal, showsIndicators: false) {
          LazyHStack(spacing: 8) {
            if g.cat == ModelLib.category {
              Button { g.importModels() } label: {
                VStack(spacing: 3) {
                  Image(systemName: "plus").font(.system(size: 24, weight: .semibold)).frame(width: 62, height: 62)
                    .background(Color.white.opacity(0.6), in: RoundedRectangle(cornerRadius: 10))
                    .overlay(RoundedRectangle(cornerRadius: 10).strokeBorder(Color.green, style: StrokeStyle(lineWidth: 2, dash: [5, 4])))
                  Text("Nhập 3D").font(.caption2).lineLimit(1).frame(width: 68)
                }
              }.foregroundColor(.primary)
            }
            ForEach(g.items[g.cat] ?? [], id: \.self) { i in cell(i) }
          }
        }.frame(height: 96)
      }.padding(10).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18)).shadow(color: .black.opacity(0.15), radius: 4, y: 1)
    } else {
      Button { withAnimation(.easeInOut(duration: 0.2)) { open = true } } label: {
        HStack(spacing: 8) {
          thumb(g.sel, 28)
          Text(g.label(g.sel)).font(.footnote.weight(.semibold)).lineLimit(1)
          Image(systemName: "chevron.up").font(.system(size: 12, weight: .bold))
        }.padding(.horizontal, 14).padding(.vertical, 8).background(.ultraThinMaterial, in: Capsule()).shadow(color: .black.opacity(0.15), radius: 4, y: 1)
      }.foregroundColor(.primary)
    }
  }
}

struct ContentView: View {
  @StateObject var g = Game()
  @State private var catalogOpen = true
  @State private var showWestMap = false
  var roadPanelOpen: Bool { !g.fullscreen && g.selRoad != nil && g.mode != 0 }
  var rowPanelOpen: Bool { !g.fullscreen && !roadPanelOpen && g.rowPanel && g.selId != nil && g.mode != 0 }
  var actionBarOpen: Bool { !g.fullscreen && g.selId != nil && g.mode != 0 }
  var sketchShown: Bool { g.sketchVisible }
  var drawingPath: Bool { g.cat == "Vẽ đường" && g.drawing > 0 && !g.freeDraw }

  /// Hàng trên: ⚙ cảnh (thời tiết, gió) · Đặt / Chọn / Xóa · toàn màn hình.
  @ViewBuilder var topBar: some View {
    if g.fullscreen { HStack { Spacer(); ImmersiveMenu(g: g) } } else {
    HStack(spacing: 8) {
      if !g.fullscreen {
        Menu {
          sceneMenuSections(g)
        } label: { Dock(vertical: false) { ToolIcon(symbol: "gearshape.fill") } }.foregroundColor(.primary)
      }
      Spacer()
      if !g.fullscreen { Picker("", selection: $g.mode) { Text("Đặt").tag(0); Text("Chọn").tag(1); Text("Xóa").tag(2) }.pickerStyle(.segmented).frame(minWidth: 120, maxWidth: 190) }
      Spacer()
      Dock(vertical: false) {
        Button { showWestMap = true } label: { ToolIcon(symbol: "map") }
        Button { g.hideUI = true } label: { ToolIcon(symbol: "eye.slash") }
        Button { g.fullscreen.toggle() } label: { ToolIcon(symbol: "arrow.up.left.and.arrow.down.right") }
      }.foregroundColor(.primary)
    }
    }
  }
  /// Cột trái dưới: hoàn tác / làm lại, bảng tạo đường / hàng, cần điều khiển.
  func leftColumn(_ land: Bool) -> some View {
    VStack(alignment: .leading, spacing: 10) {
      if !g.fullscreen && !drawingPath {
        Dock(vertical: false) {
          Button { g.undoLast() } label: { ToolIcon(symbol: "arrow.uturn.backward", active: false).opacity(g.undoCount > 0 ? 1 : 0.35) }.disabled(g.undoCount == 0)
          Button { g.redoLast() } label: { ToolIcon(symbol: "arrow.uturn.forward", active: false).opacity(g.redoCount > 0 ? 1 : 0.35) }.disabled(g.redoCount == 0)
        }
      }
      if roadPanelOpen { RoadPanel(g: g).frame(maxWidth: 290) }
      else if rowPanelOpen { RowPanel(g: g).frame(maxWidth: 290) }
      Joystick(scale: land ? 0.8 : 1) { g.move = $0 }   // đi dạo cũng dùng đúng cần này (như lúc không có người)
    }
  }
  /// Cột phải: nhóm Vẽ (chỉ khi đang đặt) và nhóm Đi dạo (nhân vật, đi bộ, chạy, về nhà).
  func rightColumn(_ land: Bool) -> some View {
    VStack(spacing: 10) {
      if sketchShown {
        Dock(vertical: !land) {
          Button { g.aerialZoom(1.3) } label: { ToolIcon(symbol: "plus") }
          Button { g.aerialZoom(1 / 1.3) } label: { ToolIcon(symbol: "minus") }
        }.foregroundColor(.primary)
      } else {
        if (!g.fullscreen && g.mode == 0) || drawingPath {
          Dock(vertical: !land) {
            if !g.fullscreen && g.mode == 0 { Button { g.sketchOpen.toggle() } label: { ToolIcon(symbol: "pencil.and.scribble", active: g.sketchOpen) } }
            if g.cat == "Vẽ đường" && g.mode == 0 && !g.fullscreen { Button { g.freeDraw.toggle() } label: { ToolIcon(symbol: "scribble", active: g.freeDraw) } }
            if drawingPath {
              Button { g.finish() } label: { ToolIcon(symbol: "checkmark", active: true) }
              Button { g.undoPoint() } label: { ToolIcon(symbol: "arrow.uturn.backward.circle") }
            }
          }.foregroundColor(.primary)
        }
        if g.walkMode { WalkTools(g: g, vertical: !land) }
        Dock(vertical: !land) {
          Button { g.ensureCharHooks(); g.charSheet = true } label: { ToolIcon(symbol: "person.crop.circle") }
          Button { g.walkMode.toggle() } label: { ToolIcon(symbol: "figure.walk", active: g.walkMode) }
          Button { g.run.toggle() } label: { ToolIcon(symbol: "hare.fill", active: g.run) }
          Button { g.home() } label: { ToolIcon(symbol: "house.fill") }
        }.foregroundColor(.primary)
      }
    }
  }
  var body: some View {
    GeometryReader { geo in
    let land = geo.size.width > geo.size.height   // xoay ngang: màn hình thấp nên nút xếp ngang, cần gạt nhỏ lại
    VStack(spacing: 0) {
    ZStack {
      SceneUI(g: g).ignoresSafeArea(edges: sketchShown ? Edge.Set.top : Edge.Set.all)
      VStack(spacing: 6) {
        if g.hideUI {
          HStack { Spacer(); Button { g.hideUI = false } label: { Image(systemName: "eye").font(.system(size: 18, weight: .semibold)).frame(width: 44, height: 44).background(.ultraThinMaterial, in: Circle()).opacity(0.5) }.foregroundColor(.primary) }.padding(.top, 10)
        } else { topBar.padding(.top, sketchShown ? 4 : 10) }
        if g.walkMode && !g.walkNote.isEmpty { Text(g.walkNote).font(.footnote.bold()).padding(.horizontal, 14).padding(.vertical, 8).background(.ultraThinMaterial, in: Capsule()) }
        if let t = g.toast, !g.fullscreen, !g.hideUI { Text(t).font(.footnote.bold()).lineLimit(1).minimumScaleFactor(0.7).padding(.horizontal, 14).padding(.vertical, 8).background(.ultraThinMaterial, in: Capsule()) }
        Spacer()
        if g.hideUI { HStack(alignment: .bottom) { Joystick(scale: land ? 0.8 : 1) { g.move = $0 }.opacity(0.7); Spacer() } }
        else if !g.fullscreen { HStack(alignment: .bottom) { leftColumn(land); Spacer(); rightColumn(land) } }
        else { HStack(alignment: .bottom) { Joystick(scale: land ? 0.8 : 1) { g.move = $0 }.opacity(0.7); Spacer() }.padding(.bottom, 12) }
        if g.fullscreen || g.hideUI || g.walkMode || roadPanelOpen || rowPanelOpen || sketchShown { EmptyView() }
        else if actionBarOpen { ActionBar(g: g).padding(.bottom, 6) }
        else { CatalogBar(g: g, open: $catalogOpen).padding(.bottom, 6) }
      }.padding(.horizontal, 10).frame(width: geo.size.width)   // không bao giờ rộng hơn màn hình (trước đây tràn mép phải)
    }
    if sketchShown { SketchPanel(g: g, sk: g.sk).frame(height: geo.size.height * 0.46) }
    }
    }
    .overlay { if let t = g.loadNote { ZStack { Color.black.opacity(0.85).ignoresSafeArea(); VStack(spacing: 14) { ProgressView().tint(.white).scaleEffect(1.4); Text("Làng Quê").font(.title2.bold()).foregroundColor(.white); Text(t).font(.footnote).foregroundColor(.white.opacity(0.8)) } } } }
    .background(Color.black.ignoresSafeArea())
    .statusBarHidden(g.fullscreen || g.hideUI)
    .persistentSystemOverlays(g.fullscreen || g.hideUI ? .hidden : .automatic)
    .fullScreenCover(isPresented: $showWestMap) { WestMapScreen { showWestMap = false } }
    .sheet(isPresented: $g.charSheet) { CharacterSheet(g: g) }
    .sheet(isPresented: $g.soundSheet) { SoundSheet(g: g) }
    .sheet(item: $g.shareItem) { ShareSheet(items: $0.items) }
    .alert("Làng Quê", isPresented: Binding(get: { g.villageAlert != nil }, set: { if !$0 && !g.importLock { g.villageAlert = nil } })) {
      if g.importLock { Button("Thoát app") { UserDefaults.standard.synchronize(); exit(0) } } else { Button("OK", role: .cancel) {} }
    } message: { Text(g.villageAlert ?? "") }
    .alert("Nhập mô hình", isPresented: Binding(get: { g.impAlert != nil }, set: { if !$0 { g.impAlert = nil } })) { Button("OK", role: .cancel) {} } message: { Text(g.impAlert ?? "") }
    .onAppear { g.restoreNPCs() }
  }
}
