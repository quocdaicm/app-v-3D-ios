import SceneKit
import UIKit
import UniformTypeIdentifiers
import ZIPFoundation

/// Kho mô hình 3D nhập vào (Documents/Models) để đặt trong cảnh như mọi mô hình khác.
/// Mỗi mục là một file lẻ (.usdz, .glb…) hoặc một thư mục (.obj + .mtl + ảnh). Mã mô hình trong `Rec.item` = "imp:" + tên mục.
enum ModelLib {
    static let prefix = "imp:"
    static let category = "Mô hình nhập"
    static var lastError: String? = nil

    static var directory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("Models", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static func isImp(_ id: String) -> Bool { id.hasPrefix(prefix) }
    static func entry(_ id: String) -> String { isImp(id) ? String(id.dropFirst(prefix.count)) : id }
    static func id(_ entry: String) -> String { prefix + entry }
    /// Tên hiện trên thanh chọn: bỏ "imp:" và đuôi file mô hình.
    static func display(_ id: String) -> String {
        let e = entry(id)
        let ext = (e as NSString).pathExtension.lowercased()
        return CharFiles.modelExtensions.contains(ext) ? (e as NSString).deletingPathExtension : e
    }

    /// Các mục đang có (chỉ lấy mục đọc được file mô hình chính).
    static func list() -> [String] {
        let items = (try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)) ?? []
        return items.map { $0.lastPathComponent }
            .filter { !$0.hasPrefix(".") && mainModelURL($0) != nil }
            .sorted { $0.localizedStandardCompare($1) == .orderedAscending }
    }

    static func mainModelURL(_ entry: String) -> URL? {
        let url = directory.appendingPathComponent(entry)
        var isDir: ObjCBool = false
        guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir) else { return nil }
        return isDir.boolValue ? CharFiles.findMainModel(in: url) : url
    }

    /// OBJ đọc bằng bộ đọc riêng (giữ đúng màu / texture trong .mtl); định dạng khác đi qua CharFiles (GLB, USDZ, DAE, SCN…).
    static func loadScene(at url: URL) -> SCNScene? {
        lastError = nil
        if url.pathExtension.lowercased() == "obj", let s = ObjLoader.loadOBJScene(at: url) { return s }
        let s = CharFiles.loadScene(at: url)
        if s == nil { lastError = CharFiles.lastError }
        return s
    }

    static func remove(_ entry: String) {
        try? FileManager.default.removeItem(at: directory.appendingPathComponent(entry))
    }

    private static func unique(_ base: String, ext: String = "") -> String {
        let fm = FileManager.default
        var name = base + (ext.isEmpty ? "" : "." + ext)
        var n = 2
        while fm.fileExists(atPath: directory.appendingPathComponent(name).path) {
            name = "\(base) \(n)" + (ext.isEmpty ? "" : "." + ext); n += 1
        }
        return name
    }

    /// Nhập: .zip (kèm ảnh), file lẻ .usdz/.glb/.dae/.obj…, hoặc chọn cùng lúc .obj + .mtl + ảnh.
    static func add(_ urls: [URL]) -> (added: [String], problems: [String]) {
        let fm = FileManager.default
        var added: [String] = [], problems: [String] = [], loose: [URL] = []
        for u in urls {
            let ext = u.pathExtension.lowercased()
            if ext == "zip" {
                let tmp = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
                do { try fm.createDirectory(at: tmp, withIntermediateDirectories: true); try fm.unzipItem(at: u, to: tmp) }
                catch { try? fm.removeItem(at: tmp); problems.append("\(u.lastPathComponent): không giải nén được"); continue }
                guard let main = CharFiles.findMainModel(in: tmp) else {
                    try? fm.removeItem(at: tmp); problems.append("\(u.lastPathComponent): không thấy mô hình (USDZ, GLB, DAE, OBJ…)"); continue }
                guard loadScene(at: main) != nil else {
                    try? fm.removeItem(at: tmp); problems.append("\(u.lastPathComponent): " + (lastError ?? "mô hình không đọc được")); continue }
                let name = unique(u.deletingPathExtension().lastPathComponent)
                do { try fm.moveItem(at: tmp, to: directory.appendingPathComponent(name, isDirectory: true)); added.append(name) }
                catch { try? fm.removeItem(at: tmp); problems.append("\(u.lastPathComponent): không lưu được") }
            } else if ext == "fbx" {
                problems.append("\(u.lastPathComponent): FBX chưa đọc trực tiếp, hãy chuyển sang GLB / USDZ / DAE")
            } else { loose.append(u) }
        }
        let models = loose.filter { CharFiles.modelExtensions.contains($0.pathExtension.lowercased()) }
        let support = loose.filter { !CharFiles.modelExtensions.contains($0.pathExtension.lowercased()) }
        if models.isEmpty && !loose.isEmpty { problems.append("Không thấy file mô hình trong những file đã chọn") }
        for m in models {
            let base = m.deletingPathExtension().lastPathComponent
            var created: URL, main: URL, name: String
            do {
                if support.isEmpty {
                    name = unique(base, ext: m.pathExtension.lowercased())
                    created = directory.appendingPathComponent(name)
                    try fm.copyItem(at: m, to: created); main = created
                } else {
                    name = unique(base)
                    created = directory.appendingPathComponent(name, isDirectory: true)
                    try fm.createDirectory(at: created, withIntermediateDirectories: true)
                    for f in [m] + support { try fm.copyItem(at: f, to: created.appendingPathComponent(f.lastPathComponent)) }
                    main = created.appendingPathComponent(m.lastPathComponent)
                }
            } catch { problems.append("\(m.lastPathComponent): không lưu được"); continue }
            if loadScene(at: main) == nil {
                try? fm.removeItem(at: created)
                problems.append("\(m.lastPathComponent): " + (lastError ?? "mô hình không đọc được"))
            } else { added.append(name) }
        }
        return (added, problems)
    }
}

// ===== Phần của Game: đưa mô hình nhập vào thanh chọn, dựng mẫu (đoán đơn vị, đặt chân xuống đất) =====
extension Game {
    /// Làm mới nhóm "Mô hình nhập" theo nội dung thư mục Documents/Models.
    func reloadImported() {
        for old in items[ModelLib.category] ?? [] { catOf[old] = nil }
        let ids = ModelLib.list().map { ModelLib.id($0) }
        items[ModelLib.category] = ids
        ids.forEach { catOf[$0] = ModelLib.category }
        impRev += 1
    }

    /// Tên hiện trên thanh chọn.
    func label(_ i: String) -> String { i == "grass" ? "Cỏ" : ModelLib.isImp(i) ? ModelLib.display(i) : i }

    /// Mẫu của một mô hình nhập: đoán đơn vị (mét / cm), căn giữa, chân đặt đúng mặt đất (y = 0), như mô hình có sẵn.
    func impProto(_ id: String) -> SCNNode? {
        guard let url = ModelLib.mainModelURL(ModelLib.entry(id)), let scene = ModelLib.loadScene(at: url) else { return nil }
        let content = SCNNode()
        for c in scene.rootNode.childNodes { content.addChildNode(c) }
        content.enumerateHierarchy { node, _ in
            guard let g = node.geometry else { return }
            for m in g.materials {
                m.ambient.contents = UIColor.black   // Ka = 1 trong .mtl làm vật bị cháy trắng (HUONG_DAN mục 9)
                m.isDoubleSided = true
                if m.diffuse.contents == nil { m.diffuse.contents = UIColor(red: 0.78, green: 0.76, blue: 0.72, alpha: 1) }
            }
        }
        let (lo, hi) = content.boundingBox
        let big = max(hi.x - lo.x, max(hi.y - lo.y, hi.z - lo.z))
        guard big.isFinite, big > 0.0001 else { return nil }
        // đoán đơn vị: 0,3–30 → mét; 30–3000 → cm (Sweet Home 3D, SketchUp…); còn lại co về 6 m; quá nhỏ (< 0,5 m) thì phóng lên
        var s: Float = (big >= 0.3 && big <= 30) ? 1 : ((big > 30 && big <= 3000) ? 0.01 : 6 / big)
        if big * s < 0.5 { s = 0.5 / big }
        content.scale = SCNVector3(s, s, s)
        content.position = SCNVector3(-(lo.x + hi.x) / 2 * s, -lo.y * s, -(lo.z + hi.z) / 2 * s)
        let w = SCNNode(); w.addChildNode(content)
        return w
    }

    /// Nút ＋ trên thanh chọn: mở app Tệp, nhập xong thì chọn luôn mô hình đầu tiên để chạm đặt.
    func importModels() {
        DocPicker.shared.present(types: [.item]) { [weak self] urls in
            guard let self = self else { return }
            let r = ModelLib.add(urls)
            self.reloadImported()
            var msg = ""
            if !r.added.isEmpty {
                msg += "Đã nhập: " + r.added.map { ModelLib.display(ModelLib.id($0)) }.joined(separator: ", ") + ". Chạm mặt đất để đặt; ➕ ➖ chỉnh cỡ nếu to / nhỏ quá."
            }
            if !r.problems.isEmpty { msg += (msg.isEmpty ? "" : "\n") + r.problems.joined(separator: "\n") }
            if let first = r.added.first { self.cat = ModelLib.category; self.sel = ModelLib.id(first); self.mode = 0; self.sketchOpen = false }
            let text = msg
            if !text.isEmpty { DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { self.impAlert = text } }
        }
    }

    /// Xóa mô hình khỏi thư viện, kèm các bản đã đặt (thao tác thư viện, không đi qua hoàn tác).
    func deleteImported(_ id: String) {
        guard ModelLib.isImp(id) else { return }
        for r in recs where r.item == id { delRec(r.id) }
        recs.removeAll { $0.item == id }
        protos[id] = nil; thumbs[id] = nil; thumbQ.removeAll { $0 == id }
        ModelLib.remove(ModelLib.entry(id))
        reloadImported()
        if sel == id { sel = items[ModelLib.category]?.first ?? items[order[0]]?.first ?? sel; if items[ModelLib.category]?.isEmpty ?? true { cat = order[0] } }
        save(); showToast("Đã xóa “\(ModelLib.display(id))” khỏi thư viện")
    }
}
