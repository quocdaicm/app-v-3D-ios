import SceneKit
import UIKit
import simd

// ===== Ao cá: máy bơm + tia nước đổ, guồng quạt nước, xuồng, bọt nước =====
extension Game {
  func foamImg() -> UIImage {
    let f = UIGraphicsImageRendererFormat(); f.opaque = false; f.scale = 1
    return UIGraphicsImageRenderer(size: CGSize(width: 128, height: 128), format: f).image { c in
      let g = c.cgContext; g.clear(CGRect(x: 0, y: 0, width: 128, height: 128)); var r = RNG(); r.s = 5
      for _ in 0..<260 { let a = CGFloat(r.f(0, 6.28)), d = CGFloat(pow(r.f(0, 1), 0.7)) * 58, w = CGFloat(r.f(3, 12))
        UIColor(white: 1, alpha: CGFloat(r.f(0.2, 0.75)) * (1 - d / 64)).setFill()
        UIBezierPath(ovalIn: CGRect(x: 64 + cos(a) * d - w / 2, y: 64 + sin(a) * d - w / 2, width: w, height: w)).fill() } }
  }
  func jetImg() -> UIImage {
    let f = UIGraphicsImageRendererFormat(); f.opaque = false; f.scale = 1
    return UIGraphicsImageRenderer(size: CGSize(width: 64, height: 128), format: f).image { c in
      let g = c.cgContext; UIColor(red: 0.85, green: 0.93, blue: 0.97, alpha: 0.35).setFill(); g.fill(CGRect(x: 0, y: 0, width: 64, height: 128))
      var r = RNG(); r.s = 8
      for _ in 0..<26 { let x = CGFloat(r.f(0, 64)), y = CGFloat(r.f(0, 128)), h = CGFloat(r.f(14, 60)); UIColor(white: 1, alpha: CGFloat(r.f(0.5, 0.95))).setFill(); g.fill(CGRect(x: x, y: y, width: CGFloat(r.f(1, 4)), height: h))
        g.fill(CGRect(x: x, y: y - 128, width: 2, height: h)) } }
  }
  func whiteMat(_ img: UIImage, _ alpha: CGFloat) -> SCNMaterial {
    let m = SCNMaterial(); m.lightingModel = .constant; m.diffuse.contents = img; m.transparent.contents = img; m.transparencyMode = .aOne; m.transparency = alpha
    m.isDoubleSided = true; m.writesToDepthBuffer = false; m.diffuse.wrapS = .repeat; m.diffuse.wrapT = .repeat; m.transparent.wrapS = .repeat; m.transparent.wrapT = .repeat; return m
  }
  // bọt + vòng sóng lan ra từ điểm (x, z) trên mặt nước
  func splash(_ root: SCNNode, _ x: Float, _ z: Float, _ r: Float, _ first: Int, _ rings: Int) {
    let c = SCNCylinder(radius: CGFloat(r), height: 0.006); c.radialSegmentCount = 24; c.firstMaterial = whiteMat(foamImg(), 0.85)
    let fn = SCNNode(geometry: c); fn.position = SCNVector3(x, Game.pondWater + 0.006, z); fn.renderingOrder = 16; root.addChildNode(fn)
    let ringM = SCNMaterial(); ringM.lightingModel = .constant; ringM.diffuse.contents = UIColor(white: 1, alpha: 1); ringM.transparency = 0.55; ringM.writesToDepthBuffer = false
    for i in 0..<rings { let t = SCNTube(innerRadius: 0.95, outerRadius: 1.0, height: 0.004); t.radialSegmentCount = 36; t.firstMaterial = ringM
      let n = SCNNode(geometry: t); n.name = "ripple:\(first + i)"; n.position = SCNVector3(x, Game.pondWater + 0.007, z); n.scale = SCNVector3(0.6, 1, 0.6); n.renderingOrder = 16; root.addChildNode(n) }
  }

  // máy bơm đặt trên sàn gỗ nhô ra ao, ống hút xuống nước, ống đẩy phun tia nước cong vào ao
  func pondPump(_ th: Float, _ solid: SCNNode, _ root: SCNNode) {
    let M = bankFrame(th, 0.35, 0.2); let (outer, inner) = frameNode(M); let base = M.columns.3.y; let wl = Game.pondWater - base
    let dark = mat(woodImg(pc(0.3, 0.24, 0.17)), 1, 1), wood = mat(woodImg(pc(0.46, 0.38, 0.28)), 1, 1)
    let blue = pcol(0.1, 0.32, 0.58); blue.specular.contents = UIColor(white: 0.5, alpha: 1); blue.shininess = 0.5; blue.isDoubleSided = true
    let steel = pcol(0.45, 0.46, 0.47), rust = pcol(0.5, 0.17, 0.1), pvc = pcol(0.84, 0.84, 0.78)
    for i in 0..<8 { inner.addChildNode(pbox(0.22, 0.05, 1.5, -0.84 + 0.24 * Float(i), -0.025, 0.25, i % 3 == 0 ? dark : wood, 0.008)) }
    for z in [Float(-0.4), 0.25, 0.9] { inner.addChildNode(pbox(1.9, 0.07, 0.08, 0, -0.085, z, dark, 0.01)) }
    for sx in [Float(-0.85), 0.85] { for sz in [Float(-0.4), 0.9] {
      let q = bake(M, SIMD3<Float>(sx, 0, sz)); let bedLocal = pondBedY(min(max(pondS(q.x, q.z), 0.02), 1)) - base; let h = -0.06 - bedLocal
      inner.addChildNode(pcyl(0.06, CGFloat(h), sx, bedLocal + h / 2, sz, dark)) } }
    // động cơ điện nằm ngang có gân tản nhiệt
    let motor = SCNNode(); motor.position = SCNVector3(-0.25, 0.22, 0.1); motor.eulerAngles.z = .pi / 2
    let body = lathe([(0, -0.25), (0.13, -0.25), (0.16, -0.2), (0.16, 0.2), (0.13, 0.25), (0, 0.25)], 20); body.firstMaterial = blue; motor.addChildNode(SCNNode(geometry: body))
    for k in -3...3 { motor.addChildNode(pcyl(0.166, 0.014, 0, Float(k) * 0.065, 0, blue)) }
    motor.addChildNode(pcyl(0.14, 0.06, 0, -0.28, 0, steel)); inner.addChildNode(motor)
    inner.addChildNode(pbox(0.14, 0.09, 0.12, -0.25, 0.43, 0.1, steel, 0.01)); inner.addChildNode(pbox(0.6, 0.05, 0.24, -0.2, 0.025, 0.1, steel, 0.01))
    for sx in [Float(-0.4), 0.0] { inner.addChildNode(pbox(0.05, 0.12, 0.06, sx - 0.25 + 0.2, 0.06, 0.1, steel, 0.008)) }
    inner.addChildNode(psph(0.17, 0.17, 0.2, 0.1, 0.9, rust)); inner.addChildNode(pcyl(0.1, 0.05, 0.17, 0.4, 0.1, rust))
    // ống hút (PVC) xuống nước, ống đẩy cong lên rồi hướng ra ao
    let cn = SIMD3<Float>(0.17, 0.2, 0.5)
    inner.addChildNode(rod(SIMD3<Float>(0.17, 0.2, 0.2), cn, 0.045, pvc)); inner.addChildNode(psph(0.055, cn.x, cn.y, cn.z, 1, pvc))
    inner.addChildNode(rod(cn, SIMD3<Float>(0.17, wl - 0.3, 0.5), 0.045, pvc))
    let dp: [SIMD3<Float>] = [SIMD3<Float>(0.17, 0.4, 0.1), SIMD3<Float>(0.17, 0.62, 0.1), SIMD3<Float>(0.17, 0.72, 0.18), SIMD3<Float>(0.17, 0.74, 0.4), SIMD3<Float>(0.17, 0.78, 0.62)]
    let pg = tube(dp, 0.04, 0.04, 12, 1); pg.firstMaterial = pvc; inner.addChildNode(SCNNode(geometry: pg))
    inner.addChildNode(pcyl(0.052, 0.04, 0.17, 0.62, 0.1, steel)); inner.addChildNode(pcyl(0.05, 0.03, 0.17, 0.77, 0.6, steel))
    solid.addChildNode(outer.flattenedClone())
    // tia nước: parabol từ miệng ống tới mặt nước, họa tiết vệt chảy cuộn theo thời gian
    let y0: Float = 0.78, vy: Float = 0.5, vh: Float = 1.7; let T = (vy + sqrt(vy * vy + 19.6 * (y0 - wl))) / 9.8
    var jp = [SIMD3<Float>](); for k in 0...14 { let t = T * Float(k) / 14; jp.append(SIMD3<Float>(0.17, y0 + vy * t - 4.9 * t * t, 0.62 + vh * t)) }
    let jg = tube(jp, 0.03, 0.045, 10, 1.4); jg.firstMaterial = whiteMat(jetImg(), 0.9); let jn = SCNNode(geometry: jg); jn.name = "jet"; jn.simdTransform = M; jn.renderingOrder = 15; root.addChildNode(jn)
    let land = bake(M, jp[jp.count - 1]); splash(root, land.x, land.z, 0.3, 0, 3)
  }

  // guồng quạt nước (aerator): hai phao thùng xanh, khung gỗ, mô-tơ, trục cánh quạt quay, bọt trắng
  func pondAerator(_ cx: Float, _ cz: Float, _ solid: SCNNode, _ root: SCNNode) {
    let blue = pcol(0.1, 0.32, 0.58); blue.isDoubleSided = true; let dark = mat(woodImg(pc(0.3, 0.24, 0.17)), 1, 1), steel = pcol(0.5, 0.5, 0.5), paddle = pcol(0.9, 0.9, 0.86)
    for sx in [Float(-0.7), 0.7] { let f = pcyl(0.17, 1.0, cx + sx, 0.66, cz, blue); f.eulerAngles.x = .pi / 2; solid.addChildNode(f) }
    for sz in [Float(-0.32), 0.32] { solid.addChildNode(pbox(1.9, 0.05, 0.07, cx, 0.88, cz + sz, dark, 0.01)) }
    for sx in [Float(-0.7), 0.7] { solid.addChildNode(pbox(0.07, 0.05, 0.8, cx + sx, 0.84, cz, dark, 0.01)) }
    solid.addChildNode(pbox(0.34, 0.24, 0.22, cx, 1.02, cz, blue, 0.02)); solid.addChildNode(pbox(0.1, 0.1, 0.1, cx + 0.2, 1.1, cz, steel, 0.01))
    for sx in [Float(-0.5), 0.5] { solid.addChildNode(rod(SIMD3<Float>(cx + sx, 0.88, cz), SIMD3<Float>(cx + sx * 0.8, 0.74, cz + 0.0), 0.02, steel)) }
    let holder = SCNNode(); let shaft = pcyl(0.03, 1.5, 0, 0, 0, steel); shaft.eulerAngles.z = .pi / 2; holder.addChildNode(shaft)
    for k in 0..<8 { let p = pbox(1.0, 0.03, 0.22, 0, 0, 0, paddle, 0.004); p.simdTransform = mRx(Float(k) * Float.pi / 4) * mT(0, 0, 0.3); holder.addChildNode(p) }
    let wheel = SCNNode(); wheel.name = "wheel"; wheel.position = SCNVector3(cx, 0.72, cz); wheel.addChildNode(holder.flattenedClone()); root.addChildNode(wheel)
    splash(root, cx, cz, 0.85, 3, 2)
  }

  // xuồng ba lá neo ven ao: thân ghép ván, ghế, mái chèo, sào tre, đống lưới, dây buộc vào cọc
  func pondBoat(_ th: Float, _ solid: SCNNode) {
    let n = pondN(th), p = pondP(th); let pos = p - n * 1.15, t = SIMD2<Float>(-n.y, n.x)
    let M0 = mT(pos.x, 0.5, pos.y) * mRy(atan2(t.x, t.y)); let (outer, inner) = frameNode(M0)
    inner.addChildNode(sampanNode())
    let bamboo = pcol(0.72, 0.62, 0.36), net = pcol(0.15, 0.4, 0.3)
    inner.addChildNode(rod(SIMD3<Float>(-0.32, 0.5, -1.5), SIMD3<Float>(-0.32, 0.62, 1.5), 0.028, bamboo))
    for k in 0..<4 { let b = psph(0.12, 0.05 + 0.08 * Float(k % 2), 0.1 + 0.07 * Float(k / 3), -1.25 + 0.17 * Float(k), 0.6, net); b.scale = SCNVector3(1, 0.6, 1); inner.addChildNode(b) }
    solid.addChildNode(outer.flattenedClone())
    let bow = bake(M0, SIMD3<Float>(0, 0.55, 1.7)); let sp = SIMD2<Float>(bow.x, bow.z) + n * 1.9; let sy = pondBankY(0.8)
    solid.addChildNode(pcyl(0.035, 0.7, sp.x, sy + 0.3, sp.y, bamboo))
    solid.addChildNode(rod(bow, SIMD3<Float>(sp.x, sy + 0.55, sp.y), 0.008, pcol(0.78, 0.72, 0.55)))
  }
}
