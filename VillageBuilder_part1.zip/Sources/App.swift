import SwiftUI
@main struct VillageApp: App { var body: some Scene { WindowGroup { ContentView().ignoresSafeArea() } } }
