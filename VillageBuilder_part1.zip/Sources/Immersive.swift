import SwiftUI

// ===== Chế độ toàn màn hình (đắm chìm): ẩn mọi nút, chỉ còn người đi dạo, cảnh và cần điều khiển như game =====
// Điều khiển giống lúc không có người: cần `Joystick` cố định góc trái dưới để đi, vuốt chỗ khác để nhìn quanh (`Coordinator.pan` → `Game.look`), chụm / mở 2 ngón để thu / phóng (`Coordinator.pinch` → `walkZoom`). `WalkPad.swift` (cần nổi nửa trái + vuốt nửa phải) không còn được dùng.
// Mọi nút gom vào một nút ⋯ mờ ở góc trên phải.

/// Mục "Cảnh" dùng chung cho menu ⚙ và menu ⋯: thời tiết, mức cây lay.
@ViewBuilder func sceneMenuSections(_ g: Game) -> some View {
    Section("Thời tiết") {
        Picker("Thời tiết", selection: Binding(get: { g.weather }, set: { g.weather = $0 })) {
            ForEach(Weather.allCases) { w in Label(w.title, systemImage: w.symbol).tag(w) }
        }.pickerStyle(.inline)
    }
    Section("Cây lay theo gió") {
        Picker("Cây lay", selection: Binding(get: { g.swayLevel }, set: { g.setSway($0) })) {
            Text("Tắt").tag(0); Text("Nhẹ").tag(1); Text("Mạnh").tag(2)
        }.pickerStyle(.inline)
    }
}

/// Các hoạt ảnh của nhân vật (dùng cho nút ✨ và menu ⋯).
@ViewBuilder func emoteMenuItems(_ g: Game) -> some View {
    ForEach(WalkEmote.allCases) { e in
        Button { g.walkPerform(e) } label: { Label(e.title, systemImage: e.symbol) }
    }
    if !g.walkActions.isEmpty {
        Divider()
        ForEach(Array(g.walkActions.enumerated()), id: \.offset) { i, n in
            Button(n) { g.walkCustom(i) }
        }
    }
    Divider()
    Button { g.walkDoAction() } label: { Label("Hành động tiếp theo", systemImage: "forward.fill") }
    Button { g.walkStop() } label: { Label("Đứng dậy", systemImage: "figure.stand") }
}

/// Nút ⋯ duy nhất còn lại khi toàn màn hình: mọi chức năng nằm trong menu này.
struct ImmersiveMenu: View {
    @ObservedObject var g: Game
    var body: some View {
        Menu {
            Button { g.fullscreen = false } label: { Label("Thoát toàn màn hình", systemImage: "arrow.down.right.and.arrow.up.left") }
            Section("Nhân vật") {
                Button { g.ensureCharHooks(); g.charSheet = true } label: { Label("Đổi nhân vật…", systemImage: "person.crop.circle") }
                Menu { emoteMenuItems(g) } label: { Label("Hoạt ảnh", systemImage: "sparkles") }
                Button { g.walkTurnFace() } label: { Label("Xoay mặt", systemImage: "arrow.triangle.2.circlepath") }
                Button { g.toggleFly() } label: { Label(g.flyMode ? "Hạ xuống" : "Bay cao", systemImage: "airplane") }
                Button { g.run.toggle() } label: { Label(g.run ? "Đi bộ" : "Chạy", systemImage: g.run ? "figure.walk" : "hare.fill") }
                Button { g.home() } label: { Label("Về vị trí ban đầu", systemImage: "house") }
            }
            sceneMenuSections(g)
        } label: {
            Image(systemName: "ellipsis").font(.system(size: 18, weight: .bold)).frame(width: 44, height: 44)
                .background(.ultraThinMaterial, in: Circle()).foregroundColor(.primary).opacity(0.55)
        }
    }
}
