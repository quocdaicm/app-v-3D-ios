import SceneKit
import UIKit
import simd

/// Đọc file GLB / GLTF (không cần thư viện ngoài): hình học, vật liệu PBR, texture, cây node.
/// Hỗ trợ cả xương (skin) và hoạt ảnh. Nhận đuôi .glb, .gltf, .vrm.
/// Chưa hỗ trợ: nén Draco / Meshopt, morph target.
struct GLTFFailure: LocalizedError {
    let text: String
    var errorDescription: String? { text }
}

/// Một đoạn hoạt ảnh đọc từ glTF. Tự lấy mẫu từng khung rồi gán lên node theo TÊN xương,
/// nên cũng dùng lại được cho nhân vật khác có xương trùng tên (ví dụ bộ Mixamo).
final class GLTFClip {
    enum Path { case translation, rotation, scale }

    struct Channel {
        let node: String
        let path: Path
        let times: [Float]
        let values: [Float]     // 3 số (dời, co giãn) hoặc 4 số (quaternion) cho mỗi mốc
        let step: Bool
    }

    let name: String
    let duration: Float
    let channels: [Channel]

    /// Khóa so khớp tên xương giữa các bộ xương: bỏ tiền tố Mixamo, ký tự lạ và chữ hoa
    /// ("mixamorig:LeftHand", "mixamorig_LeftHand", "LeftHand" cùng ra "lefthand").
    static func key(_ raw: String) -> String {
        var s = raw.lowercased()
        if s.hasPrefix("mixamorig") { s = String(s.dropFirst("mixamorig".count)) }
        return String(s.unicodeScalars.filter { CharacterSet.alphanumerics.contains($0) })
    }

    init(name: String, duration: Float, channels: [Channel]) {
        self.name = name
        self.duration = duration
        self.channels = channels
    }

    private static func segment(_ times: [Float], _ t: Float) -> (Int, Int, Float) {
        let n = times.count
        if n == 1 || t <= times[0] { return (0, 0, 0) }
        if t >= times[n - 1] { return (n - 1, n - 1, 0) }
        var lo = 0
        var hi = n - 1
        while hi - lo > 1 {
            let mid = (lo + hi) / 2
            if times[mid] <= t { lo = mid } else { hi = mid }
        }
        let span = times[hi] - times[lo]
        return (lo, hi, span > 0 ? (t - times[lo]) / span : 0)
    }

    /// Đặt tư thế ở thời điểm t. weight < 1: trộn dần với tư thế đang có (để chuyển cảnh mượt).
    func apply(at t: Float, to nodes: [String: SCNNode], weight: Float = 1) {
        let w = min(max(weight, 0), 1)
        for ch in channels {
            guard let node = nodes[ch.node], !ch.times.isEmpty else { continue }
            let seg = GLTFClip.segment(ch.times, t)
            let a = seg.0
            let b = seg.1
            let f: Float = ch.step ? 0 : seg.2
            switch ch.path {
            case .translation, .scale:
                let va = SIMD3<Float>(ch.values[a * 3], ch.values[a * 3 + 1], ch.values[a * 3 + 2])
                let vb = SIMD3<Float>(ch.values[b * 3], ch.values[b * 3 + 1], ch.values[b * 3 + 2])
                let v = va + (vb - va) * f
                if ch.path == .translation {
                    node.simdPosition = w >= 1 ? v : node.simdPosition + (v - node.simdPosition) * w
                } else {
                    node.simdScale = w >= 1 ? v : node.simdScale + (v - node.simdScale) * w
                }
            case .rotation:
                let qa = simd_quatf(ix: ch.values[a * 4], iy: ch.values[a * 4 + 1],
                                    iz: ch.values[a * 4 + 2], r: ch.values[a * 4 + 3])
                let qb = simd_quatf(ix: ch.values[b * 4], iy: ch.values[b * 4 + 1],
                                    iz: ch.values[b * 4 + 2], r: ch.values[b * 4 + 3])
                var q = simd_slerp(qa, qb, f)
                if w < 1 { q = simd_slerp(node.simdOrientation, q, w) }
                node.simdOrientation = q
            }
        }
    }
}

/// Kết quả đọc một file glTF: cảnh, các hoạt ảnh, và cờ VRM đời cũ (VRM 0.x quay mặt về -Z).
struct GLTFImport {
    let scene: SCNScene
    let clips: [GLTFClip]
    let legacyVRM: Bool
}

enum GLTFLoader {
    static let extensions = ["glb", "gltf", "vrm"]

    static func handles(_ ext: String) -> Bool {
        extensions.contains(ext.lowercased())
    }

    static func load(at url: URL) throws -> GLTFImport {
        let reader = try GLTFReader(url: url)
        let scene = try reader.buildScene()
        return GLTFImport(scene: scene, clips: reader.builtClips, legacyVRM: reader.legacyVRM)
    }

    static func loadScene(at url: URL) throws -> SCNScene {
        try load(at: url).scene
    }
}

private final class GLTFReader {
    let baseURL: URL
    let glbBin: Data?
    let accessors: [[String: Any]]
    let bufferViews: [[String: Any]]
    let bufferList: [[String: Any]]
    let nodeList: [[String: Any]]
    let meshList: [[String: Any]]
    let materialList: [[String: Any]]
    let textureList: [[String: Any]]
    let imageList: [[String: Any]]
    let sceneList: [[String: Any]]
    let skinList: [[String: Any]]
    let animList: [[String: Any]]
    let sceneIndex: Int
    let legacyVRM: Bool

    var names: [String] = []                       // tên duy nhất của từng node
    var nodeMap: [Int: SCNNode] = [:]              // chỉ số node glTF -> node SceneKit
    var pendingSkins: [(Int, SCNNode)] = []        // node có mesh + skin, gắn sau khi đủ xương
    var builtClips: [GLTFClip] = []

    var bufferCache: [Int: Data] = [:]
    var imageCache: [Int: UIImage] = [:]
    var materialCache: [Int: SCNMaterial] = [:]

    // MARK: Đọc số nhị phân

    static func u32(_ d: Data, _ o: Int) -> UInt32 {
        UInt32(d[o]) | (UInt32(d[o + 1]) << 8) | (UInt32(d[o + 2]) << 16) | (UInt32(d[o + 3]) << 24)
    }

    static func u16(_ d: Data, _ o: Int) -> UInt16 {
        UInt16(d[o]) | (UInt16(d[o + 1]) << 8)
    }

    // MARK: Khởi tạo

    init(url: URL) throws {
        baseURL = url.deletingLastPathComponent()
        let data = try Data(contentsOf: url)
        var jsonData = data
        var bin: Data? = nil

        let ext = url.pathExtension.lowercased()
        let magicGLB = data.count >= 4 && GLTFReader.u32(data, data.startIndex) == 0x46546C67
        if ext == "glb" || ext == "vrm" || magicGLB {
            let s = data.startIndex
            guard data.count >= 20, GLTFReader.u32(data, s) == 0x46546C67 else {
                throw GLTFFailure(text: "không phải file GLB hợp lệ")
            }
            var off = 12
            var j: Data? = nil
            while off + 8 <= data.count {
                let len = Int(GLTFReader.u32(data, s + off))
                let type = GLTFReader.u32(data, s + off + 4)
                let start = off + 8
                if start + len > data.count { break }
                let chunk = data.subdata(in: (s + start)..<(s + start + len))
                if type == 0x4E4F534A { j = chunk }
                else if type == 0x004E4942, bin == nil { bin = chunk }
                off = start + ((len + 3) & ~3)
            }
            guard let jj = j else { throw GLTFFailure(text: "GLB thiếu phần JSON") }
            jsonData = jj
        }

        guard let obj = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any] else {
            throw GLTFFailure(text: "JSON của file không đọc được")
        }

        let required = (obj["extensionsRequired"] as? [String]) ?? []
        for e in required where e.lowercased().contains("draco") || e.lowercased().contains("meshopt") {
            throw GLTFFailure(text: "mô hình bị nén (\(e)), hãy xuất lại không nén")
        }

        glbBin = bin
        accessors = obj["accessors"] as? [[String: Any]] ?? []
        bufferViews = obj["bufferViews"] as? [[String: Any]] ?? []
        bufferList = obj["buffers"] as? [[String: Any]] ?? []
        nodeList = obj["nodes"] as? [[String: Any]] ?? []
        meshList = obj["meshes"] as? [[String: Any]] ?? []
        materialList = obj["materials"] as? [[String: Any]] ?? []
        textureList = obj["textures"] as? [[String: Any]] ?? []
        imageList = obj["images"] as? [[String: Any]] ?? []
        sceneList = obj["scenes"] as? [[String: Any]] ?? []
        skinList = obj["skins"] as? [[String: Any]] ?? []
        animList = obj["animations"] as? [[String: Any]] ?? []
        sceneIndex = obj["scene"] as? Int ?? 0
        legacyVRM = ((obj["extensionsUsed"] as? [String]) ?? []).contains("VRM")
        names = GLTFReader.makeNames(nodeList)
    }

    /// Mỗi node một tên duy nhất (node không tên hoặc trùng tên được thêm số), để gán hoạt ảnh theo tên.
    static func makeNames(_ list: [[String: Any]]) -> [String] {
        var used = Set<String>()
        var out: [String] = []
        for (i, d) in list.enumerated() {
            var n = (d["name"] as? String) ?? ""
            if n.isEmpty { n = "node\(i)" }
            if used.contains(n) { n = "\(n)_\(i)" }
            used.insert(n)
            out.append(n)
        }
        return out
    }

    // MARK: Buffer / accessor

    func loadURI(_ uri: String) -> Data? {
        if uri.hasPrefix("data:") {
            guard let comma = uri.firstIndex(of: ",") else { return nil }
            let payload = String(uri[uri.index(after: comma)...])
            return Data(base64Encoded: payload, options: .ignoreUnknownCharacters)
        }
        let name = uri.removingPercentEncoding ?? uri
        return try? Data(contentsOf: baseURL.appendingPathComponent(name))
    }

    func buffer(_ i: Int) -> Data? {
        if let b = bufferCache[i] { return b }
        guard i >= 0, i < bufferList.count else { return nil }
        var result: Data? = nil
        if let uri = bufferList[i]["uri"] as? String {
            result = loadURI(uri)
        } else if i == 0 {
            result = glbBin
        }
        if let r = result { bufferCache[i] = r }
        return result
    }

    func viewInfo(_ i: Int) -> (data: Data, base: Int, stride: Int)? {
        guard i >= 0, i < bufferViews.count,
              let b = bufferViews[i]["buffer"] as? Int,
              let data = buffer(b) else { return nil }
        let base = bufferViews[i]["byteOffset"] as? Int ?? 0
        let stride = bufferViews[i]["byteStride"] as? Int ?? 0
        return (data, base, stride)
    }

    func value(_ d: Data, _ o: Int, _ ct: Int, _ norm: Bool) -> Float {
        switch ct {
        case 5126:
            return Float(bitPattern: GLTFReader.u32(d, o))
        case 5125:
            return Float(GLTFReader.u32(d, o))
        case 5123:
            let v = Float(GLTFReader.u16(d, o))
            return norm ? v / 65535 : v
        case 5122:
            let v = Float(Int16(bitPattern: GLTFReader.u16(d, o)))
            return norm ? max(v / 32767, -1) : v
        case 5121:
            let v = Float(d[o])
            return norm ? v / 255 : v
        case 5120:
            let v = Float(Int8(bitPattern: d[o]))
            return norm ? max(v / 127, -1) : v
        default:
            return 0
        }
    }

    /// Đọc accessor thành mảng Float phẳng.
    func readFloats(_ idx: Int) -> (values: [Float], comps: Int, count: Int)? {
        guard idx >= 0, idx < accessors.count else { return nil }
        let a = accessors[idx]
        guard let ct = a["componentType"] as? Int,
              let count = a["count"] as? Int,
              let type = a["type"] as? String else { return nil }
        let table: [String: Int] = ["SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4,
                                    "MAT2": 4, "MAT3": 9, "MAT4": 16]
        guard let comps = table[type], count >= 0 else { return nil }
        let normalized = a["normalized"] as? Bool ?? false
        let compSize = (ct == 5120 || ct == 5121) ? 1 : ((ct == 5122 || ct == 5123) ? 2 : 4)

        var out = [Float](repeating: 0, count: count * comps)
        if let bvIdx = a["bufferView"] as? Int {
            guard let v = viewInfo(bvIdx) else { return nil }
            let accOff = a["byteOffset"] as? Int ?? 0
            let elemSize = compSize * comps
            let step = v.stride > 0 ? v.stride : elemSize
            for i in 0..<count {
                let rowStart = v.base + accOff + i * step
                if rowStart + elemSize > v.data.count { return nil }
                for c in 0..<comps {
                    let o = v.data.startIndex + rowStart + c * compSize
                    out[i * comps + c] = value(v.data, o, ct, normalized)
                }
            }
        }
        return (out, comps, count)
    }

    // MARK: Hình ảnh / vật liệu

    func image(forTexture t: Int) -> UIImage? {
        guard t >= 0, t < textureList.count, let s = textureList[t]["source"] as? Int else { return nil }
        if let c = imageCache[s] { return c }
        guard s >= 0, s < imageList.count else { return nil }
        var data: Data? = nil
        if let uri = imageList[s]["uri"] as? String {
            data = loadURI(uri)
        } else if let bv = imageList[s]["bufferView"] as? Int, let v = viewInfo(bv) {
            let len = bufferViews[bv]["byteLength"] as? Int ?? 0
            let st = v.data.startIndex + v.base
            if len > 0, st + len <= v.data.endIndex {
                data = v.data.subdata(in: st..<(st + len))
            }
        }
        guard let d = data, let img = UIImage(data: d) else { return nil }
        imageCache[s] = img
        return img
    }

    func material(_ index: Int?) -> SCNMaterial {
        let key = index ?? -1
        if let m = materialCache[key] { return m }
        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.diffuse.contents = UIColor(white: 0.8, alpha: 1)
        m.metalness.contents = 0.0
        m.roughness.contents = 0.8
        m.isDoubleSided = false

        if let i = index, i >= 0, i < materialList.count {
            let md = materialList[i]
            m.isDoubleSided = md["doubleSided"] as? Bool ?? false
            if (md["alphaMode"] as? String) == "BLEND" {
                m.blendMode = .alpha
                m.writesToDepthBuffer = false
            }

            if let pbr = md["pbrMetallicRoughness"] as? [String: Any] {
                if let f = pbr["baseColorFactor"] as? [Double], f.count == 4 {
                    m.diffuse.contents = UIColor(red: CGFloat(f[0]), green: CGFloat(f[1]),
                                                 blue: CGFloat(f[2]), alpha: CGFloat(f[3]))
                }
                if let t = pbr["baseColorTexture"] as? [String: Any],
                   let ti = t["index"] as? Int, let img = image(forTexture: ti) {
                    m.diffuse.contents = img
                    m.diffuse.wrapS = .repeat
                    m.diffuse.wrapT = .repeat
                }
                // Cảnh chưa có phản xạ môi trường: kim loại cao sẽ đen sì, nên giới hạn lại.
                let metal = pbr["metallicFactor"] as? Double ?? 0.0
                let rough = pbr["roughnessFactor"] as? Double ?? 0.8
                m.metalness.contents = min(metal, 0.3)
                m.roughness.contents = max(rough, 0.35)
            }
            if let nt = md["normalTexture"] as? [String: Any],
               let ti = nt["index"] as? Int, let img = image(forTexture: ti) {
                m.normal.contents = img
                m.normal.wrapS = .repeat
                m.normal.wrapT = .repeat
            }
            if let e = md["emissiveFactor"] as? [Double], e.count == 3, e.contains(where: { $0 > 0 }) {
                m.emission.contents = UIColor(red: CGFloat(e[0]), green: CGFloat(e[1]),
                                              blue: CGFloat(e[2]), alpha: 1)
            }
            if let et = md["emissiveTexture"] as? [String: Any],
               let ti = et["index"] as? Int, let img = image(forTexture: ti) {
                m.emission.contents = img
            }
        }
        materialCache[key] = m
        return m
    }

    // MARK: Hình học

    func computeNormals(_ v: [SCNVector3], _ idx: [UInt32]) -> [SCNVector3] {
        var acc = [SIMD3<Float>](repeating: SIMD3<Float>(0, 0, 0), count: v.count)
        var t = 0
        while t + 2 < idx.count {
            let a = Int(idx[t]), b = Int(idx[t + 1]), c = Int(idx[t + 2])
            let pa = SIMD3<Float>(v[a].x, v[a].y, v[a].z)
            let pb = SIMD3<Float>(v[b].x, v[b].y, v[b].z)
            let pc = SIMD3<Float>(v[c].x, v[c].y, v[c].z)
            let n = simd_cross(pb - pa, pc - pa)
            acc[a] += n
            acc[b] += n
            acc[c] += n
            t += 3
        }
        return acc.map { n in
            let l = simd_length(n)
            let u = l > 0 ? n / l : SIMD3<Float>(0, 1, 0)
            return SCNVector3(u.x, u.y, u.z)
        }
    }

    func geometry(for prim: [String: Any]) -> SCNGeometry? {
        let mode = prim["mode"] as? Int ?? 4
        guard mode == 4 else { return nil }   // chỉ nhận tam giác
        guard let attrs = prim["attributes"] as? [String: Int],
              let posIdx = attrs["POSITION"],
              let pos = readFloats(posIdx), pos.comps == 3, pos.count > 0 else { return nil }
        let n = pos.count

        var verts: [SCNVector3] = []
        verts.reserveCapacity(n)
        for i in 0..<n {
            verts.append(SCNVector3(pos.values[i * 3], pos.values[i * 3 + 1], pos.values[i * 3 + 2]))
        }

        var idx: [UInt32]
        if let ii = prim["indices"] as? Int, let ir = readFloats(ii) {
            idx = ir.values.map { UInt32(max($0, 0)) }
        } else {
            idx = (0..<n).map { UInt32($0) }
        }
        idx = Array(idx.prefix(idx.count - idx.count % 3))
        guard idx.count >= 3 else { return nil }
        if let mx = idx.max(), Int(mx) >= n { return nil }

        var sources: [SCNGeometrySource] = [SCNGeometrySource(vertices: verts)]

        if let ni = attrs["NORMAL"], let nr = readFloats(ni), nr.comps == 3, nr.count == n {
            var ns: [SCNVector3] = []
            ns.reserveCapacity(n)
            for i in 0..<n {
                ns.append(SCNVector3(nr.values[i * 3], nr.values[i * 3 + 1], nr.values[i * 3 + 2]))
            }
            sources.append(SCNGeometrySource(normals: ns))
        } else {
            sources.append(SCNGeometrySource(normals: computeNormals(verts, idx)))
        }

        if let ti = attrs["TEXCOORD_0"], let tc = readFloats(ti), tc.comps == 2, tc.count == n {
            var ts: [CGPoint] = []
            ts.reserveCapacity(n)
            for i in 0..<n {
                // glTF gốc ảnh ở góc trên-trái, SceneKit ở góc dưới-trái → lật trục v
                ts.append(CGPoint(x: CGFloat(tc.values[i * 2]), y: CGFloat(1 - tc.values[i * 2 + 1])))
            }
            sources.append(SCNGeometrySource(textureCoordinates: ts))
        }

        let data = idx.withUnsafeBufferPointer { Data(buffer: $0) }
        let element = SCNGeometryElement(data: data, primitiveType: .triangles,
                                         primitiveCount: idx.count / 3, bytesPerIndex: 4)
        let g = SCNGeometry(sources: sources, elements: [element])
        g.materials = [material(prim["material"] as? Int)]
        return g
    }

    // MARK: Cây node

    func node(_ i: Int, depth: Int) -> SCNNode? {
        guard i >= 0, i < nodeList.count, depth < 64 else { return nil }
        let d = nodeList[i]
        let n = SCNNode()
        n.name = i < names.count ? names[i] : (d["name"] as? String)
        nodeMap[i] = n

        if let m = d["matrix"] as? [Double], m.count == 16 {
            let f = m.map { Float($0) }
            n.simdTransform = simd_float4x4(columns: (
                SIMD4<Float>(f[0], f[1], f[2], f[3]),
                SIMD4<Float>(f[4], f[5], f[6], f[7]),
                SIMD4<Float>(f[8], f[9], f[10], f[11]),
                SIMD4<Float>(f[12], f[13], f[14], f[15])))
        } else {
            if let t = d["translation"] as? [Double], t.count == 3 {
                n.simdPosition = SIMD3<Float>(Float(t[0]), Float(t[1]), Float(t[2]))
            }
            if let r = d["rotation"] as? [Double], r.count == 4 {
                n.simdOrientation = simd_quatf(ix: Float(r[0]), iy: Float(r[1]),
                                               iz: Float(r[2]), r: Float(r[3]))
            }
            if let s = d["scale"] as? [Double], s.count == 3 {
                n.simdScale = SIMD3<Float>(Float(s[0]), Float(s[1]), Float(s[2]))
            }
        }

        if d["mesh"] as? Int != nil, d["skin"] as? Int != nil {
            pendingSkins.append((i, n))      // mesh có xương: gắn sau khi mọi node đã dựng xong
        } else if let mi = d["mesh"] as? Int, mi >= 0, mi < meshList.count,
           let prims = meshList[mi]["primitives"] as? [[String: Any]] {
            for p in prims {
                if let g = geometry(for: p) {
                    n.addChildNode(SCNNode(geometry: g))
                }
            }
        }
        if let kids = d["children"] as? [Int] {
            for k in kids {
                if let c = node(k, depth: depth + 1) { n.addChildNode(c) }
            }
        }
        return n
    }

    // MARK: Xương (skin)

    /// Trọng số và chỉ số xương của từng đỉnh (JOINTS_0 / WEIGHTS_0).
    func skinSources(_ prim: [String: Any], count n: Int) -> (SCNGeometrySource, SCNGeometrySource)? {
        guard let attrs = prim["attributes"] as? [String: Int],
              let ji = attrs["JOINTS_0"], let wi = attrs["WEIGHTS_0"],
              let jr = readFloats(ji), let wr = readFloats(wi),
              jr.comps == 4, wr.comps == 4, jr.count == n, wr.count == n else { return nil }
        var idx = [UInt16](repeating: 0, count: n * 4)
        var wts = [Float](repeating: 0, count: n * 4)
        for v in 0..<n {
            var sum: Float = 0
            for c in 0..<4 { sum += max(wr.values[v * 4 + c], 0) }
            for c in 0..<4 {
                let jf = jr.values[v * 4 + c]
                idx[v * 4 + c] = UInt16(clamping: Int(jf.isFinite ? min(max(jf, 0), 65535) : 0))
                let wv = max(wr.values[v * 4 + c], 0)
                wts[v * 4 + c] = sum > 1e-6 ? wv / sum : (c == 0 ? 1 : 0)
            }
        }
        let wd = wts.withUnsafeBufferPointer { Data(buffer: $0) }
        let idd = idx.withUnsafeBufferPointer { Data(buffer: $0) }
        let ws = SCNGeometrySource(data: wd, semantic: .boneWeights, vectorCount: n,
                                   usesFloatComponents: true, componentsPerVector: 4,
                                   bytesPerComponent: 4, dataOffset: 0, dataStride: 16)
        let isrc = SCNGeometrySource(data: idd, semantic: .boneIndices, vectorCount: n,
                                     usesFloatComponents: false, componentsPerVector: 4,
                                     bytesPerComponent: 2, dataOffset: 0, dataStride: 8)
        return (ws, isrc)
    }

    /// Gắn mesh có xương. glTF bỏ qua phép biến đổi của node mesh khi có skin, nên mesh được đặt
    /// thẳng dưới gốc cảnh với ma trận đơn vị; vị trí do xương quyết định.
    func attachSkinned(_ i: Int, into top: SCNNode) {
        let d = nodeList[i]
        guard let mi = d["mesh"] as? Int, mi >= 0, mi < meshList.count,
              let prims = meshList[mi]["primitives"] as? [[String: Any]],
              let si = d["skin"] as? Int, si >= 0, si < skinList.count,
              let joints = skinList[si]["joints"] as? [Int], !joints.isEmpty else { return }

        var bones: [SCNNode] = []
        for j in joints {
            guard let b = nodeMap[j] else { return }
            bones.append(b)
        }

        var ibms: [NSValue] = []
        if let ia = skinList[si]["inverseBindMatrices"] as? Int,
           let m = readFloats(ia), m.comps == 16, m.count >= joints.count {
            for k in 0..<joints.count {
                let o = k * 16
                let f = m.values
                let mat = simd_float4x4(columns: (
                    SIMD4<Float>(f[o], f[o + 1], f[o + 2], f[o + 3]),
                    SIMD4<Float>(f[o + 4], f[o + 5], f[o + 6], f[o + 7]),
                    SIMD4<Float>(f[o + 8], f[o + 9], f[o + 10], f[o + 11]),
                    SIMD4<Float>(f[o + 12], f[o + 13], f[o + 14], f[o + 15])))
                ibms.append(NSValue(scnMatrix4: SCNMatrix4(mat)))
            }
        } else {
            ibms = Array(repeating: NSValue(scnMatrix4: SCNMatrix4Identity), count: joints.count)
        }

        // gốc bộ xương: node "skeleton" nếu có, không thì khớp không có tổ tiên nào cũng là khớp
        var skeletonRoot: SCNNode? = nil
        if let sk = skinList[si]["skeleton"] as? Int { skeletonRoot = nodeMap[sk] }
        if skeletonRoot == nil {
            for b in bones {
                var p = b.parent
                var hasJointAncestor = false
                while let q = p {
                    if bones.contains(where: { $0 === q }) { hasJointAncestor = true; break }
                    p = q.parent
                }
                if !hasJointAncestor { skeletonRoot = b; break }
            }
        }

        for p in prims {
            guard let g = geometry(for: p) else { continue }
            let gn = SCNNode(geometry: g)
            if let src = g.sources(for: .vertex).first,
               let ws = skinSources(p, count: src.vectorCount) {
                let sk = SCNSkinner(baseGeometry: g, bones: bones, boneInverseBindTransforms: ibms,
                                    boneWeights: ws.0, boneIndices: ws.1)
                if let r = skeletonRoot { sk.skeleton = r }
                gn.skinner = sk
            }
            top.addChildNode(gn)
        }
    }

    // MARK: Hoạt ảnh

    func buildClips() -> [GLTFClip] {
        var out: [GLTFClip] = []
        for (ai, a) in animList.enumerated() {
            guard let chans = a["channels"] as? [[String: Any]],
                  let samplers = a["samplers"] as? [[String: Any]] else { continue }
            var list: [GLTFClip.Channel] = []
            var dur: Float = 0
            for ch in chans {
                guard let si = ch["sampler"] as? Int, si >= 0, si < samplers.count,
                      let tg = ch["target"] as? [String: Any],
                      let ni = tg["node"] as? Int, ni >= 0, ni < names.count,
                      let ps = tg["path"] as? String else { continue }
                let path: GLTFClip.Path
                switch ps {
                case "translation": path = .translation
                case "rotation":    path = .rotation
                case "scale":       path = .scale
                default: continue          // weights (morph target): chưa hỗ trợ
                }
                let s = samplers[si]
                guard let ii = s["input"] as? Int, let oi = s["output"] as? Int,
                      let tin = readFloats(ii), let vout = readFloats(oi), tin.count > 0 else { continue }
                let interp = s["interpolation"] as? String ?? "LINEAR"
                let comps = path == .rotation ? 4 : 3
                var vals = vout.values
                if interp == "CUBICSPLINE" {
                    // mỗi mốc có 3 giá trị (tiếp tuyến vào, giá trị, tiếp tuyến ra): lấy giá trị giữa
                    guard vals.count >= tin.count * 3 * comps else { continue }
                    var mid: [Float] = []
                    mid.reserveCapacity(tin.count * comps)
                    for k in 0..<tin.count {
                        let base = (k * 3 + 1) * comps
                        mid.append(contentsOf: vals[base..<(base + comps)])
                    }
                    vals = mid
                }
                guard vals.count >= tin.count * comps else { continue }
                list.append(GLTFClip.Channel(node: GLTFClip.key(names[ni]), path: path, times: tin.values,
                                             values: vals, step: interp == "STEP"))
                dur = max(dur, tin.values.last ?? 0)
            }
            if !list.isEmpty && dur > 0 {
                let nm = (a["name"] as? String) ?? "anim\(ai + 1)"
                out.append(GLTFClip(name: nm, duration: dur, channels: list))
            }
        }
        return out
    }

    func buildScene() throws -> SCNScene {
        let scene = SCNScene()
        var roots: [Int] = []
        if sceneIndex >= 0, sceneIndex < sceneList.count,
           let r = sceneList[sceneIndex]["nodes"] as? [Int] {
            roots = r
        } else if let first = sceneList.first, let r = first["nodes"] as? [Int] {
            roots = r
        } else {
            var isChild = Set<Int>()
            for nd in nodeList { for k in (nd["children"] as? [Int] ?? []) { isChild.insert(k) } }
            roots = (0..<nodeList.count).filter { !isChild.contains($0) }
        }
        for r in roots {
            if let n = node(r, depth: 0) { scene.rootNode.addChildNode(n) }
        }
        for (i, _) in pendingSkins { attachSkinned(i, into: scene.rootNode) }
        builtClips = buildClips()
        if scene.rootNode.childNodes.isEmpty {
            throw GLTFFailure(text: "không có hình học để hiển thị")
        }
        return scene
    }
}
