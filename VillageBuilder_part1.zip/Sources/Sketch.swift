import SwiftUI
import SceneKit
import simd

// ===== Bảng vẽ nét 2D (khung dưới) → tự dựng đường / mương / hàng rào trong khung 3D (khung trên) =====
// Khung dưới là bản đồ nhìn từ trên xuống (x sang phải, z xuống dưới, giống khung 3D khi nhìn từ trên).
// Kéo 1 ngón để vẽ nét. "Thẳng": nét đi thẳng từ chỗ chạm tới chỗ thả. "Cong": nét tay được làm mượt thành đường cong.
// Nét bắt đầu / kết thúc gần đầu nét cũ (trong 20 px) tự dính vào và nối liền. Chụm 2 ngón: phóng to / thu nhỏ, kéo 2 ngón: di chuyển.
final class SketchModel: ObservableObject {
  weak var g: Game?
  @Published var tool = 0                       // 0 thẳng, 1 cong
  @Published var angleSnap = false              // khóa góc mỗi 15° (nét thẳng)
  @Published var link = true                    // khung trên và dưới cùng phóng to / di chuyển
  @Published var center = SIMD2<Float>(0, 0)    // tâm khung nhìn (mét: x, z)
  @Published var scale: CGFloat = 10            // pixel mỗi mét
  @Published var live: [SIMD2<Float>] = []      // nét đang kéo
  @Published var snapMark: SIMD2<Float>? = nil  // chấm vàng báo đang dính vào điểm cũ
  @Published var strokes: [[SIMD2<Float>]] = [] // các nét đã vẽ trong lần mở này
  @Published var spacing: Float = 1             // khoảng cách vật khi vẽ hàng (hàng rào, bụi, cây...)
  @Published var rev = 0
  var size = CGSize(width: 360, height: 220)
  var rowEnds: [SIMD2<Float>] = []              // hai đầu các hàng vừa vẽ, để nét sau dính vào
  var drawing = false; var raw: [SIMD2<Float>] = []; var lastPrev: TimeInterval = 0

  // ---- đổi tọa độ ----
  func scr(_ p: SIMD2<Float>, _ s: CGSize) -> CGPoint {
    CGPoint(x: s.width / 2 + CGFloat(p.x - center.x) * scale, y: s.height / 2 + CGFloat(p.y - center.y) * scale)
  }
  func world(_ c: CGPoint, _ s: CGSize) -> SIMD2<Float> {
    SIMD2<Float>(center.x + Float((c.x - s.width / 2) / scale), center.y + Float((c.y - s.height / 2) / scale))
  }
  var gridStep: Float {
    let steps: [Float] = [1, 2, 5, 10, 20, 50, 100]
    return steps.first { CGFloat($0) * scale >= 30 } ?? 100
  }
  var scaleLabel: String { "1 ô = \(Int(gridStep)) m" }

  // ---- hình học nhỏ ----
  func polyLen(_ p: [SIMD2<Float>]) -> Float { zip(p, p.dropFirst()).reduce(0) { $0 + simd_length($1.0 - $1.1) } }
  func projSeg(_ p: SIMD2<Float>, _ a: SIMD2<Float>, _ b: SIMD2<Float>) -> SIMD2<Float> {
    let ab = b - a; let l2 = simd_dot(ab, ab); if l2 < 1e-9 { return a }
    let t = min(max(simd_dot(p - a, ab) / l2, 0), 1); return a + ab * t
  }
  func rdp(_ p: [SIMD2<Float>], _ eps: Float) -> [SIMD2<Float>] {
    guard p.count > 2 else { return p }
    let a = p[0], b = p[p.count - 1]; var dmax: Float = 0; var idx = 0
    for i in 1..<(p.count - 1) { let d = simd_length(p[i] - projSeg(p[i], a, b)); if d > dmax { dmax = d; idx = i } }
    if dmax > eps { let l = rdp(Array(p[0...idx]), eps), r = rdp(Array(p[idx...]), eps); return Array(l.dropLast()) + r }
    return [a, b]
  }
  func catmull(_ k: [SIMD2<Float>], _ step: Float) -> [SIMD2<Float>] {
    var out: [SIMD2<Float>] = [k[0]]
    for i in 0..<(k.count - 1) {
      let p0 = k[max(i - 1, 0)], p1 = k[i], p2 = k[i + 1], p3 = k[min(i + 2, k.count - 1)]
      let n = max(2, Int((simd_length(p2 - p1) / step).rounded(.up)))
      for j in 1...n {
        let t = Float(j) / Float(n), t2 = t * t, t3 = t2 * t
        let a: SIMD2<Float> = p1 * 2.0
        let b: SIMD2<Float> = (p2 - p0) * t
        let c1: SIMD2<Float> = p0 * 2.0 - p1 * 5.0
        let c2: SIMD2<Float> = p2 * 4.0 - p3
        let c: SIMD2<Float> = (c1 + c2) * t2
        let d1: SIMD2<Float> = p1 * 3.0 - p0
        let d2: SIMD2<Float> = p2 * 3.0 - p3
        let d: SIMD2<Float> = (d1 - d2) * t3
        out.append((a + b + c + d) * 0.5) } }
    return out
  }
  func fit(_ pts: [SIMD2<Float>]) -> [SIMD2<Float>] {   // nét tay → đường cong mượt đi qua các điểm chính
    guard pts.count > 2 else { return pts }
    let keys = rdp(pts, max(0.1, 3.5 / Float(scale)))
    if keys.count < 3 { return keys }
    return catmull(keys, max(0.6, 5 / Float(scale)))
  }
  func angleLock(_ a: SIMD2<Float>, _ p: SIMD2<Float>) -> SIMD2<Float> {
    let d = p - a; let l = simd_length(d); if l < 1e-4 { return p }
    let st = Float.pi / 12; let ang = (atan2(d.y, d.x) / st).rounded() * st
    return a + SIMD2<Float>(cos(ang), sin(ang)) * l
  }

  // ---- dính vào điểm cũ ----
  func endpoints() -> [SIMD2<Float>] {
    var e: [SIMD2<Float>] = rowEnds
    for r in g?.roads ?? [] where r.pts.count > 1 {
      for q in [r.pts[0], r.pts[r.pts.count - 1]] { e.append(SIMD2<Float>(q[0], q[1])) } }
    return e
  }
  func nearestEnd(_ p: SIMD2<Float>, _ r: Float) -> SIMD2<Float>? {
    var best: SIMD2<Float>? = nil; var bd = r
    for q in endpoints() { let d = simd_length(q - p); if d < bd { bd = d; best = q } }
    return best
  }
  func nearestOnRoad(_ p: SIMD2<Float>, _ r: Float) -> SIMD2<Float>? {
    var best: SIMD2<Float>? = nil; var bd = r
    for rd in g?.roads ?? [] {
      guard rd.pts.count > 1 else { continue }
      for i in 1..<rd.pts.count {
        let a = SIMD2<Float>(rd.pts[i - 1][0], rd.pts[i - 1][1]), b = SIMD2<Float>(rd.pts[i][0], rd.pts[i][1])
        let q = projSeg(p, a, b); let d = simd_length(q - p); if d < bd { bd = d; best = q } } }
    return best
  }
  var snapR: Float { 20 / Float(scale) }

  // ---- vẽ nét ----
  func drawBegin(_ s: CGPoint, _ sz: CGSize) {
    size = sz; drawing = true
    var p = world(s, sz)
    if let q = nearestEnd(p, snapR) { p = q; snapMark = q }
    else if let q = nearestOnRoad(p, snapR * 0.5) { p = q; snapMark = q }
    else { snapMark = nil }
    raw = [p]; live = [p]
  }
  func drawMove(_ s: CGPoint, _ sz: CGSize) {
    guard drawing, let a = raw.first else { return }
    var p = world(s, sz); snapMark = nil
    if let q = nearestEnd(p, snapR) { p = q; snapMark = q }
    else if tool == 0 && angleSnap { p = angleLock(a, p) }
    if tool == 0 { raw = [a, p]; live = raw }
    else {
      let minStep = 4 / Float(scale)
      if let l = raw.last, simd_length(p - l) >= minStep { raw.append(p) }
      else if raw.count > 1 { raw[raw.count - 1] = p }
      live = fit(raw) }
    let now = Date.timeIntervalSinceReferenceDate
    if now - lastPrev > 0.07 { lastPrev = now; g?.sketchPreview(live) }
  }
  func drawEnd() {
    guard drawing else { return }
    drawing = false
    let pts = live; live = []; snapMark = nil; raw = []
    g?.sketchClearPreview()
    guard pts.count > 1, polyLen(pts) >= max(0.3, 8 / Float(scale)) else { return }
    strokes.append(pts); g?.sketchCommit(pts)
  }
  func cancelStroke() {
    guard drawing else { return }
    drawing = false; live = []; snapMark = nil; raw = []; g?.sketchClearPreview()
  }

  // ---- phóng to / di chuyển khung dưới ----
  func clampScale() { scale = min(max(scale, 1.5), 160) }
  func zoomBy(_ k: CGFloat, around a: CGPoint, _ sz: CGSize) {
    size = sz; let w = world(a, sz)
    scale *= k; clampScale()
    center = SIMD2<Float>(w.x - Float((a.x - sz.width / 2) / scale), w.y - Float((a.y - sz.height / 2) / scale))
    g?.syncFromSketch()
  }
  func zoomStep(_ k: CGFloat) { zoomBy(k, around: CGPoint(x: size.width / 2, y: size.height / 2), size) }
  func panBy(_ d: CGPoint) {
    center = SIMD2<Float>(center.x - Float(d.x / scale), center.y - Float(d.y / scale))
    g?.syncFromSketch()
  }
  func recenter() {
    if let l = strokes.last?.last { center = l } else if let gg = g { center = gg.sketchHome }
    g?.syncFromSketch()
  }
  func resetSpacing() {
    rowEnds = []
    guard let gg = g, !gg.kinds.contains(gg.sel) else { return }
    let s = gg.rowSpec(gg.sel).spacing
    spacing = min(max((s * 10).rounded() / 10, 0.3), 20)
  }
}

// ===== Phần của Game: camera nhìn từ trên, dựng đường / hàng theo nét vẽ =====
extension Game {
  func isPathItem(_ i: String) -> Bool {
    let c = catOf[i] ?? ""
    if ["Vẽ đường", "Bụi & hàng rào", "Đường & giao thông", "Điện & hạ tầng"].contains(c) { return true }
    return ["Hàng rào gỗ", "Giàn leo", "Hàng chậu"].contains(i)
  }
  var sketchVisible: Bool { sketchOpen && mode == 0 && !fullscreen }
  var sketchHome: SIMD2<Float> { SIMD2<Float>(0, 0) }

  // ---- camera nhìn xuống (khung trên) ----
  func refreshSketchCam() {
    let on = sketchVisible; if on == sketchCam { return }
    sketchCam = on
    if on {
      if walkMode { walkMode = false }
      savedCam = (cam.position, yaw, pitch)
      aerialC = SIMD2<Float>(cam.position.x - sin(yaw) * 12, cam.position.z - cos(yaw) * 12); clampAerial()
      aerialH = 30; yaw = 0; pitch = -1.0
      sk.strokes = []; sk.live = []; sk.rowEnds = []; sk.snapMark = nil; sk.resetSpacing()
      sk.center = aerialC; applyAerial(); syncFromAerial()
    } else {
      sk.cancelStroke(); sketchClearPreview()
      if let s = savedCam { cam.position = s.0; yaw = s.1; pitch = s.2; camY = s.0.y; cam.eulerAngles = SCNVector3(pitch, yaw, 0) }
      savedCam = nil
    }
  }
  func clampAerial() { aerialC.x = min(max(aerialC.x, -30), 130); aerialC.y = min(max(aerialC.y, -230), 70) }
  func applyAerial() {
    let back = aerialH * 0.642   // nhìn xuống 57°, điểm giữa khung luôn là aerialC
    cam.position = SCNVector3(aerialC.x, aerialH, aerialC.y + back)
    cam.eulerAngles = SCNVector3(-1.0, 0, 0)
  }
  func aerialZoom(_ k: Float) { aerialH = min(max(aerialH / k, 4), 150); applyAerial(); syncFromAerial() }
  func aerialPan(_ dx: Float, _ dy: Float) {
    let k = aerialH * 0.0032
    aerialC.x -= dx * k; aerialC.y -= dy * k * 1.2; clampAerial(); applyAerial(); syncFromAerial()
  }
  func syncFromAerial() {   // khung dưới theo khung trên
    guard sketchCam, sk.link else { return }
    sk.center = aerialC
    let s = Float(sk.size.width) / (aerialH * 1.17)
    sk.scale = CGFloat(min(max(s, 1.5), 160))
  }
  func syncFromSketch() {   // khung trên theo khung dưới
    guard sketchCam, sk.link else { return }
    aerialC = sk.center; clampAerial()
    aerialH = min(max(Float(sk.size.width / sk.scale) / 1.17, 4), 150)
    applyAerial()
  }

  // ---- hàng vật (hàng rào, bụi, cột điện, mẫu đường OBJ...) dọc theo nét ----
  struct RowSpec { var spacing: Float; var aligned: Bool; var zAxis: Bool }
  func rowSpec(_ item: String) -> RowSpec {
    guard let p = proto(item) else { return RowSpec(spacing: 1, aligned: false, zAxis: false) }
    let (mn, mx) = p.boundingBox
    let ex = max(mx.x - mn.x, 0.05), ez = max(mx.z - mn.z, 0.05)
    let longer = max(ex, ez), shorter = min(ex, ez)
    let line = isLenModel(item) || longer > shorter * 1.6   // vật dài (đoạn hàng rào, đoạn đường) → xoay theo nét
    return RowSpec(spacing: max(0.3, longer), aligned: line, zAxis: ez > ex)
  }
  func rowRecs(_ pts: [SIMD2<Float>], item: String, spacing: Float, skipFirst: Bool) -> [Rec] {
    guard pts.count > 1 else { return [] }
    let spec = rowSpec(item); let sp = max(spacing, 0.2)
    var cum: [Float] = [0]
    for i in 1..<pts.count { cum.append(cum[i - 1] + simd_length(pts[i] - pts[i - 1])) }
    let total = cum[cum.count - 1]
    func at(_ d: Float) -> (SIMD2<Float>, SIMD2<Float>) {
      var i = 1; while i < pts.count - 1 && cum[i] < d { i += 1 }
      let seg = pts[i] - pts[i - 1]; let l = simd_length(seg)
      let t: Float = l > 0 ? min(max((d - cum[i - 1]) / l, 0), 1) : 0
      let dir: SIMD2<Float> = l > 0 ? seg / l : SIMD2<Float>(1, 0)
      return (pts[i - 1] + seg * t, dir)
    }
    var out: [Rec] = []
    var d: Float = spec.aligned ? sp / 2 : (skipFirst ? sp : 0)
    while out.count < 600 {
      let over = spec.aligned ? (d - sp / 2 > total - sp * 0.3) : (d > total + 0.001)
      if over { break }
      let (pos, tg) = at(min(d, total))
      let yw: Float = spec.aligned ? (spec.zAxis ? atan2(tg.x, tg.y) : atan2(-tg.y, tg.x)) : rng.f(0, 6.28)
      let sc: Float = spec.aligned ? 1 : rng.f(0.92, 1.08)
      out.append(Rec(id: UUID().uuidString, item: item, x: pos.x, z: pos.y, yaw: yw, s: sc))
      d += sp }
    return out
  }

  // ---- hiện ngay trong khung 3D khi đang kéo ----
  func sketchClearPreview() { scene.rootNode.childNode(withName: "sketch3d", recursively: false)?.removeFromParentNode() }
  func sketchPreview(_ pts: [SIMD2<Float>]) {
    sketchClearPreview()
    guard pts.count > 1 else { return }
    let n = SCNNode(); n.name = "sketch3d"
    if kinds.contains(sel) {
      let rn = roadNode(RoadRec(id: "sk", kind: kindIdx, pts: pts.map { [$0.x, $0.y] })); rn.name = "sk"; n.addChildNode(rn)
    } else if let p = proto(sel) {
      let a = pts[0], skip = sk.rowEnds.contains { simd_length($0 - a) < 0.06 }
      for r in rowRecs(pts, item: sel, spacing: sk.spacing, skipFirst: skip) {
        let c = p.clone(); c.position = SCNVector3(r.x, 0, r.z); c.eulerAngles.y = r.yaw; c.scale = SCNVector3(r.s, r.s, r.s); n.addChildNode(c) } }
    scene.rootNode.addChildNode(n)
  }

  // ---- thả tay: tạo thật, nối vào đường cũ nếu dính đầu ----
  func sketchCommit(_ pts: [SIMD2<Float>]) {
    sketchClearPreview()
    guard pts.count > 1 else { return }
    if kinds.contains(sel) { commitRoadStroke(pts, kind: kindIdx) } else { commitRowStroke(pts) }
    sk.rev += 1
  }
  func commitRoadStroke(_ pts: [SIMD2<Float>], kind: Int) {
    let P: [[Float]] = pts.map { [$0.x, $0.y] }
    let a = pts[0], b = pts[pts.count - 1]
    func near(_ q: [Float], _ p: SIMD2<Float>) -> Bool { hypot(q[0] - p.x, q[1] - p.y) < 0.06 }
    for r in roads where r.kind == kind && r.pts.count > 1 {
      let f = r.pts[0], l = r.pts[r.pts.count - 1]
      var merged: [[Float]]? = nil
      if near(l, a) { merged = r.pts + Array(P.dropFirst()) }                     // nét mới nối vào cuối đường
      else if near(f, a) { merged = Array(P.reversed()) + Array(r.pts.dropFirst()) }  // nối vào đầu đường (đảo chiều nét mới)
      else if near(l, b) { merged = r.pts + Array(P.reversed().dropFirst()) }
      else if near(f, b) { merged = P + Array(r.pts.dropFirst()) }
      if let m = merged {
        let id = r.id, old = r.pts; let newPts = m
        commit("Nối đường", toast: false, undo: { [weak self] in self?.setRoadPts(id, old) }, redo: { [weak self] in self?.setRoadPts(id, newPts) })
        setRoadPts(id, newPts); return } }
    let r = RoadRec(id: UUID().uuidString, kind: kind, pts: P); let idx = roads.count
    roads.append(r); scene.rootNode.addChildNode(roadNode(r)); roadRev += 1
    commit("Vẽ " + kinds[kind], toast: false, undo: { [weak self] in self?.delRoad(r.id) }, redo: { [weak self] in self?.addRoad(r, at: idx) })
    save()
  }
  func commitRowStroke(_ pts: [SIMD2<Float>]) {
    let a = pts[0], skip = sk.rowEnds.contains { simd_length($0 - a) < 0.06 }
    let made = rowRecs(pts, item: sel, spacing: sk.spacing, skipFirst: skip)
    guard !made.isEmpty else { return }
    for r in made { recs.append(r); spawn(r) }
    save(); sk.rowEnds.append(pts[0]); sk.rowEnds.append(pts[pts.count - 1])
    let all = made, name = itemName(sel)
    commit("Vẽ hàng \(all.count) \(name)", undo: { [weak self] in all.forEach { self?.delRec($0.id) } }, redo: { [weak self] in all.forEach { self?.addRec($0) } })
  }
}

// ===== Giao diện khung dưới =====
struct SketchPanel: View {
  @ObservedObject var g: Game
  @ObservedObject var sk: SketchModel
  let cats = ["Vẽ đường", "Bụi & hàng rào", "Đường & giao thông", "Điện & hạ tầng", "Nhà & vườn", "Cây cối", "Hoa & cây cảnh"]
  var isRow: Bool { !g.kinds.contains(g.sel) }
  func chip(_ t: String, on: Bool, _ act: @escaping () -> Void) -> some View {
    Button(action: act) {
      Text(t).font(.body).frame(width: 36, height: 32)
        .background(on ? Color.green.opacity(0.6) : Color.gray.opacity(0.25), in: RoundedRectangle(cornerRadius: 8))
    }.foregroundColor(.primary)
  }
  var body: some View {
    VStack(spacing: 6) {
      HStack(spacing: 6) {
        Menu {
          ForEach(cats, id: \.self) { c in Button(c) { g.cat = c; if let f = g.items[c]?.first { g.sel = f } } }
        } label: {
          Text("📂 " + g.cat).font(.caption.bold()).lineLimit(1).padding(.horizontal, 8).frame(height: 32)
            .background(Color.gray.opacity(0.25), in: RoundedRectangle(cornerRadius: 8))
        }.foregroundColor(.primary)
        ScrollView(.horizontal, showsIndicators: false) {
          HStack(spacing: 6) {
            ForEach(g.items[g.cat] ?? [], id: \.self) { i in
              Button { g.sel = i } label: {
                Text(i == "grass" ? "Cỏ" : i).font(.caption).lineLimit(1).padding(.horizontal, 10).frame(height: 32)
                  .background(g.sel == i ? Color.green.opacity(0.6) : Color.gray.opacity(0.25), in: Capsule())
              }.foregroundColor(.primary) } }
        }.frame(height: 34)
        Button { g.sketchOpen = false } label: { Text("✕").font(.title3).frame(width: 32, height: 32) }.foregroundColor(.primary)
      }
      HStack(spacing: 6) {
        Picker("", selection: $sk.tool) { Text("📏 Thẳng").tag(0); Text("〰️ Cong").tag(1) }.pickerStyle(.segmented).frame(width: 150)
        chip("📐", on: sk.angleSnap) { sk.angleSnap.toggle() }
        chip("🔗", on: sk.link) { sk.link.toggle(); g.syncFromAerial() }
        chip("＋", on: false) { sk.zoomStep(1.4) }
        chip("－", on: false) { sk.zoomStep(1 / 1.4) }
        chip("⌖", on: false) { sk.recenter() }
        Spacer(minLength: 0)
        Text(sk.scaleLabel).font(.caption2.monospacedDigit()).foregroundColor(.secondary)
      }
      ZStack { SketchCanvas(g: g, sk: sk); SketchTouch(sk: sk) }
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray.opacity(0.5), lineWidth: 1))
      if isRow { NumSlider(title: "Cách (m)", v: $sk.spacing, r: 0.3...20, step: 0.1, fmt: "%.1f") }
      else { Text("Kéo 1 ngón để vẽ • 2 ngón: chụm = phóng to, kéo = di chuyển • đầu nét gần đầu cũ tự dính").font(.caption2).foregroundColor(.secondary).lineLimit(2).frame(height: 30) }
    }
    .padding(8).background(Color(UIColor.systemBackground))
    .onAppear { sk.resetSpacing() }
    .onChange(of: g.sel) { _ in sk.resetSpacing() }
  }
}

struct SketchCanvas: View {
  @ObservedObject var g: Game
  @ObservedObject var sk: SketchModel
  var body: some View {
    Canvas { ctx, size in
      _ = sk.rev; _ = g.roadRev
      let sc = sk.scale
      func P(_ p: SIMD2<Float>) -> CGPoint { sk.scr(p, size) }
      ctx.fill(Path(CGRect(origin: .zero, size: size)), with: .color(Color(red: 0.86, green: 0.91, blue: 0.8)))
      let rx = P(SIMD2<Float>(-8, 0)).x   // sông bên trái (x < -8)
      if rx > 0 { ctx.fill(Path(CGRect(x: 0, y: 0, width: min(rx, size.width), height: size.height)), with: .color(Color(red: 0.66, green: 0.78, blue: 0.82))) }
      // lưới
      let st = sk.gridStep; let hw = Float(size.width / 2 / sc), hh = Float(size.height / 2 / sc)
      var grid = Path()
      var gx = ((sk.center.x - hw) / st).rounded(.down) * st
      while gx <= sk.center.x + hw { let x = P(SIMD2<Float>(gx, 0)).x; grid.move(to: CGPoint(x: x, y: 0)); grid.addLine(to: CGPoint(x: x, y: size.height)); gx += st }
      var gz = ((sk.center.y - hh) / st).rounded(.down) * st
      while gz <= sk.center.y + hh { let y = P(SIMD2<Float>(0, gz)).y; grid.move(to: CGPoint(x: 0, y: y)); grid.addLine(to: CGPoint(x: size.width, y: y)); gz += st }
      ctx.stroke(grid, with: .color(Color.black.opacity(0.13)), lineWidth: 0.6)
      // đường đã có
      let colors: [Color] = [Color(white: 0.3), Color(red: 0.55, green: 0.42, blue: 0.27), Color(red: 0.3, green: 0.55, blue: 0.6), Color(white: 0.68)]
      for r in g.roads where r.pts.count > 1 {
        var path = Path(); path.move(to: P(SIMD2<Float>(r.pts[0][0], r.pts[0][1])))
        for q in r.pts.dropFirst() { path.addLine(to: P(SIMD2<Float>(q[0], q[1]))) }
        ctx.stroke(path, with: .color(colors[min(r.kind, 3)]), style: StrokeStyle(lineWidth: max(3, CGFloat(g.widths[r.kind]) * sc), lineCap: .round, lineJoin: .round)) }
      // vật đã đặt (chấm)
      for r in g.recs + g.seedRecs {
        let p = P(SIMD2<Float>(r.x, r.z))
        if p.x < -6 || p.y < -6 || p.x > size.width + 6 || p.y > size.height + 6 { continue }
        var col = Color(red: 0.6, green: 0.4, blue: 0.2); var rad: CGFloat = 2.5
        if r.item == "grass" { col = Color(red: 0.5, green: 0.75, blue: 0.35); rad = 2 }
        else if g.catOf[r.item] == "Cây cối" { col = Color(red: 0.15, green: 0.45, blue: 0.2); rad = 4 }
        else if g.catOf[r.item] == "Bụi & hàng rào" { col = Color(red: 0.35, green: 0.55, blue: 0.2); rad = 3 }
        ctx.fill(Path(ellipseIn: CGRect(x: p.x - rad, y: p.y - rad, width: rad * 2, height: rad * 2)), with: .color(col)) }
      // nét đã vẽ trong lần mở này
      for s in sk.strokes where s.count > 1 {
        var path = Path(); path.move(to: P(s[0])); for q in s.dropFirst() { path.addLine(to: P(q)) }
        ctx.stroke(path, with: .color(Color.orange), style: StrokeStyle(lineWidth: 1.5, lineCap: .round, lineJoin: .round))
        for e in [s[0], s[s.count - 1]] { let c = P(e)
          ctx.fill(Path(ellipseIn: CGRect(x: c.x - 4, y: c.y - 4, width: 8, height: 8)), with: .color(Color.white))
          ctx.stroke(Path(ellipseIn: CGRect(x: c.x - 4, y: c.y - 4, width: 8, height: 8)), with: .color(Color.orange), lineWidth: 1.5) } }
      // nét đang kéo + chiều dài
      if sk.live.count > 1 {
        var path = Path(); path.move(to: P(sk.live[0])); for q in sk.live.dropFirst() { path.addLine(to: P(q)) }
        ctx.stroke(path, with: .color(Color.blue), style: StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round, dash: [6, 4]))
        let e = P(sk.live[sk.live.count - 1])
        ctx.draw(Text(String(format: "%.1f m", sk.polyLen(sk.live))).font(.caption.bold()), at: CGPoint(x: e.x + 8, y: e.y - 10), anchor: .bottomLeading) }
      if let m = sk.snapMark { let c = P(m)
        ctx.stroke(Path(ellipseIn: CGRect(x: c.x - 10, y: c.y - 10, width: 20, height: 20)), with: .color(Color.yellow), lineWidth: 3) }
      // thước tỉ lệ
      var bar = Path(); bar.move(to: CGPoint(x: 10, y: size.height - 10)); bar.addLine(to: CGPoint(x: 10 + CGFloat(st) * sc, y: size.height - 10))
      ctx.stroke(bar, with: .color(Color.black.opacity(0.7)), lineWidth: 2)
      ctx.draw(Text("\(Int(st)) m").font(.caption2), at: CGPoint(x: 10, y: size.height - 14), anchor: .bottomLeading)
    }
  }
}

final class SketchHostView: UIView {
  var onLayout: ((CGSize) -> Void)?
  override func layoutSubviews() { super.layoutSubviews(); onLayout?(bounds.size) }
}

struct SketchTouch: UIViewRepresentable {
  let sk: SketchModel
  func makeUIView(context: Context) -> SketchHostView {
    let v = SketchHostView(); v.backgroundColor = .clear; v.isMultipleTouchEnabled = true
    v.onLayout = { [weak sk] s in sk?.size = s }
    let draw = UILongPressGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.draw(_:)))
    draw.minimumPressDuration = 0; draw.allowableMovement = .greatestFiniteMagnitude; draw.numberOfTouchesRequired = 1
    let pan2 = UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pan2(_:)))
    pan2.minimumNumberOfTouches = 2; pan2.maximumNumberOfTouches = 2
    let pinch = UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pinch(_:)))
    let all: [UIGestureRecognizer] = [draw, pan2, pinch]
    for r in all { r.delegate = context.coordinator; v.addGestureRecognizer(r) }
    return v
  }
  func updateUIView(_ v: SketchHostView, context: Context) {}
  func makeCoordinator() -> Coordinator { Coordinator(sk) }
  final class Coordinator: NSObject, UIGestureRecognizerDelegate {
    let sk: SketchModel; init(_ sk: SketchModel) { self.sk = sk }
    func gestureRecognizer(_ a: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith b: UIGestureRecognizer) -> Bool { true }
    @objc func draw(_ r: UILongPressGestureRecognizer) {
      guard let v = r.view else { return }
      let p = r.location(in: v), sz = v.bounds.size
      switch r.state {
      case .began: sk.drawBegin(p, sz)
      case .changed: if r.numberOfTouches > 1 { sk.cancelStroke() } else { sk.drawMove(p, sz) }
      case .ended: if r.numberOfTouches <= 1 { sk.drawMove(p, sz) }; sk.drawEnd()
      case .cancelled, .failed: sk.cancelStroke()
      default: break }
    }
    @objc func pan2(_ r: UIPanGestureRecognizer) {
      guard let v = r.view else { return }
      sk.cancelStroke()
      let d = r.translation(in: v); r.setTranslation(.zero, in: v); sk.panBy(d)
    }
    @objc func pinch(_ r: UIPinchGestureRecognizer) {
      guard let v = r.view else { return }
      sk.cancelStroke()
      if r.state == .changed { sk.zoomBy(r.scale, around: r.location(in: v), v.bounds.size); r.scale = 1 }
    }
  }
}
