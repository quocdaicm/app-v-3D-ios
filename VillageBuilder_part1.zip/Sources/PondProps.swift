import SceneKit
import UIKit
import simd

// ===== Ao cá: công cụ phụ + chòi tôn + cầu ao =====
extension Game {
  func pc(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }

  // khung đặt vật trên bờ: gốc tại điểm bờ (th, d), trục +z hướng vào giữa ao
  func bankFrame(_ th: Float, _ d: Float, _ lift: Float = 0) -> simd_float4x4 {
    let p = pondBankPt(th, d), n = pondN(th)
    return mT(p.x, p.y + lift, p.z) * mRy(atan2(-n.x, -n.y))
  }
  // container giữ nguyên tọa độ cục bộ; trả (ngoài, trong): thêm con vào "trong", gộp "ngoài" bằng flattenedClone
  func frameNode(_ M: simd_float4x4) -> (SCNNode, SCNNode) { let o = SCNNode(), i = SCNNode(); i.simdTransform = M; o.addChildNode(i); return (o, i) }

  func rod(_ a: SIMD3<Float>, _ b: SIMD3<Float>, _ r: CGFloat, _ m: SCNMaterial) -> SCNNode {
    let d = b - a; let L = simd_length(d)
    let c = SCNCylinder(radius: r, height: CGFloat(L)); c.radialSegmentCount = 10; c.firstMaterial = m
    let n = SCNNode(geometry: c); n.simdPosition = (a + b) / 2
    n.simdOrientation = simd_quatf(from: SIMD3<Float>(0, 1, 0), to: d / max(L, 0.0001)); return n
  }
  // ống tròn dọc một đường gấp khúc (ống nước, tia nước, dây)
  func tube(_ path: [SIMD3<Float>], _ r0: Float, _ r1: Float, _ seg: Int, _ uvScale: Float) -> SCNGeometry {
    var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32](); var len: Float = 0
    for i in 0..<path.count {
      let T = simd_normalize(path[min(i + 1, path.count - 1)] - path[max(i - 1, 0)])
      let ref = abs(T.y) > 0.95 ? SIMD3<Float>(1, 0, 0) : SIMD3<Float>(0, 1, 0)
      let N = simd_normalize(simd_cross(T, ref)), B = simd_cross(T, N)
      if i > 0 { len += simd_length(path[i] - path[i - 1]) }
      let r = r0 + (r1 - r0) * Float(i) / Float(max(path.count - 1, 1))
      for j in 0...seg { let a = Float(j) / Float(seg) * 2 * Float.pi; P.append(path[i] + (N * cos(a) + B * sin(a)) * r); UV.append(SIMD2<Float>(Float(j) / Float(seg), len * uvScale)) } }
    for i in 0..<(path.count - 1) { for j in 0..<seg { let a = Int32(i * (seg + 1) + j), b = a + 1, c = a + Int32(seg + 1), d = c + 1; I += [a, b, c, b, d, c] } }
    return meshGeo(P, UV, I)
  }

  func tonImg() -> UIImage {   // tôn múi: gân sóng, vệt gỉ chảy dọc, mảng gỉ
    UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256), format: Game.fmtTex).image { c in
      let g = c.cgContext; pc(0.6, 0.58, 0.55).setFill(); g.fill(CGRect(x: 0, y: 0, width: 256, height: 256))
      for x in 0..<256 { let sh = CGFloat(sin(Double(x % 32) / 32 * 2 * Double.pi)); (sh > 0 ? UIColor.white : UIColor.black).withAlphaComponent(abs(sh) * 0.2).setFill(); g.fill(CGRect(x: CGFloat(x), y: 0, width: 1, height: 256)) }
      var r = RNG(); r.s = 909
      for _ in 0..<110 { let x = CGFloat(r.f(0, 256)), y = CGFloat(r.f(0, 256)), len = CGFloat(r.f(20, 120))
        pc(CGFloat(r.f(0.45, 0.62)), CGFloat(r.f(0.22, 0.3)), 0.1).withAlphaComponent(CGFloat(r.f(0.12, 0.35))).setStroke(); g.setLineWidth(CGFloat(r.f(1, 3)))
        g.move(to: CGPoint(x: x, y: y)); g.addQuadCurve(to: CGPoint(x: x + CGFloat(r.f(-3, 3)), y: y + len), control: CGPoint(x: x + 4, y: y + len / 2)); g.strokePath() }
      for _ in 0..<24 { pc(0.5, 0.24, 0.1).withAlphaComponent(CGFloat(r.f(0.15, 0.35))).setFill(); let w = CGFloat(r.f(8, 30)); UIBezierPath(ovalIn: CGRect(x: CGFloat(r.f(0, 256)), y: CGFloat(r.f(0, 256)), width: w, height: w * 0.7)).fill() } }
  }
  func netMat(_ sx: Float, _ sy: Float) -> SCNMaterial {
    let m = SCNMaterial(); m.lightingModel = .constant; m.diffuse.contents = netImg(); m.transparent.contents = netImg(); m.transparencyMode = .aOne
    m.isDoubleSided = true; m.writesToDepthBuffer = false
    for p in [m.diffuse, m.transparent] { p.wrapS = .repeat; p.wrapT = .repeat; p.contentsTransform = SCNMatrix4MakeScale(sx, sy, 1) }
    return m
  }
  func drum(_ x: Float, _ y: Float, _ z: Float, _ m: SCNMaterial, _ parent: SCNNode) {   // thùng phuy / thùng nhựa có gân
    let g = lathe([(0, 0), (0.25, 0), (0.27, 0.03), (0.27, 0.55), (0.25, 0.58), (0.2, 0.6), (0, 0.6)], 20); g.firstMaterial = m
    let n = SCNNode(geometry: g); n.position = SCNVector3(x, y, z); parent.addChildNode(n)
    for h in [Float(0.2), 0.4] { parent.addChildNode(pcyl(0.276, 0.02, x, y + h, z, m)) }
  }

  // chòi tôn trên sàn cao: ván gỗ cũ, cửa hé mở, cửa sổ chớp, mái tôn gỉ, thùng phuy + bao cám + lưới phơi
  func tonHut(_ w: Float, _ l: Float, _ wallH: Float) -> SCNNode {
    let r = SCNNode()
    let wood = mat(woodImg(pc(0.52, 0.46, 0.37)), 1.5, 1), dark = mat(woodImg(pc(0.3, 0.24, 0.18)), 1, 1)
    let ton = mat(tonImg(), w / 0.6, 1); ton.isDoubleSided = true; ton.specular.contents = UIColor(white: 0.35, alpha: 1); ton.shininess = 0.35
    let y0: Float = 0.25, hw = w / 2, hl = l / 2
    r.addChildNode(pbox(CGFloat(w + 0.2), 0.1, CGFloat(l + 0.2), 0, 0.2, 0, dark, 0.01))
    for sx in [Float(-1), 1] { for sz in [Float(-1), 1] { r.addChildNode(pcyl(0.07, 0.9, sx * (hw + 0.05), -0.25, sz * (hl + 0.05), dark)) } }
    r.addChildNode(pbox(CGFloat(w), CGFloat(wallH), 0.06, 0, y0 + wallH / 2, -hl, wood, 0.01))
    r.addChildNode(pbox(0.06, CGFloat(wallH), CGFloat(l), -hw, y0 + wallH / 2, 0, wood, 0.01))
    r.addChildNode(pbox(0.06, CGFloat(wallH), CGFloat(l), hw, y0 + wallH / 2, 0, wood, 0.01))
    let dx: Float = -0.35, dw: Float = 0.7   // cửa
    r.addChildNode(pbox(CGFloat(dx - dw / 2 + hw), CGFloat(wallH), 0.06, (-hw + dx - dw / 2) / 2, y0 + wallH / 2, hl, wood, 0.01))
    r.addChildNode(pbox(CGFloat(hw - dx - dw / 2), CGFloat(wallH), 0.06, (hw + dx + dw / 2) / 2, y0 + wallH / 2, hl, wood, 0.01))
    r.addChildNode(pbox(CGFloat(dw), CGFloat(wallH - 1.75), 0.06, dx, y0 + 1.75 + (wallH - 1.75) / 2, hl, wood, 0.01))
    let doorN = SCNNode(); doorN.simdTransform = mT(dx - dw / 2 + 0.03, y0 + 0.88, hl) * mRy(-1.15)
    doorN.addChildNode(pbox(CGFloat(dw - 0.04), 1.72, 0.04, (dw - 0.04) / 2, 0, 0, dark, 0.008))
    for i in 0..<3 { doorN.addChildNode(pbox(CGFloat(dw - 0.04), 0.06, 0.02, (dw - 0.04) / 2, -0.6 + 0.6 * Float(i), 0.03, wood, 0.004)) }
    r.addChildNode(doorN)
    r.addChildNode(pbox(CGFloat(dw), 1.75, 0.02, dx, y0 + 0.88, -hl + 0.04, pcol(0.05, 0.04, 0.03), 0.002))
    let win = pbox(0.02, 0.5, 0.55, hw + 0.035, y0 + 1.15, 0.15, pcol(0.04, 0.04, 0.03), 0.002); r.addChildNode(win)   // cửa sổ + khung + chớp
    for z in [Float(-0.14), 0.44] { r.addChildNode(pbox(0.04, 0.58, 0.04, hw + 0.04, y0 + 1.15, z, dark, 0.004)) }
    for y in [Float(0.88), 1.42] { r.addChildNode(pbox(0.04, 0.04, 0.62, hw + 0.04, y0 + y, 0.15, dark, 0.004)) }
    let sh = pbox(0.03, 0.5, 0.28, 0, 0, 0, dark, 0.004); sh.simdTransform = mT(hw + 0.04, y0 + 1.15, 0.47) * mRy(0.9) * mT(0, 0, 0.14); r.addChildNode(sh)
    for i in 1..<5 { r.addChildNode(pbox(0.012, 0.012, CGFloat(l), -hw - 0.035, y0 + Float(i) * wallH / 5, 0, dark, 0.002)) }   // gờ ván
    // mái tôn hai mái, nóc úp, đầu hồi gỗ
    let tilt: Float = 0.5, run = hl + 0.35, sl = run / cos(tilt)
    for s in [Float(0), 1] { let n = pbox(CGFloat(w + 0.7), 0.05, CGFloat(sl), 0, 0, 0, ton, 0.01); n.simdTransform = mT(0, y0 + wallH + run * tan(tilt) - 0.12, 0) * mRy(s * Float.pi) * mRx(tilt) * mT(0, 0, sl / 2); r.addChildNode(n) }
    let ridge = pcyl(0.09, CGFloat(w + 0.72), 0, y0 + wallH + run * tan(tilt) - 0.1, 0, ton); ridge.eulerAngles.z = .pi / 2; r.addChildNode(ridge)
    let tri = UIBezierPath(); tri.move(to: CGPoint(x: CGFloat(-hl), y: 0)); tri.addLine(to: CGPoint(x: CGFloat(hl), y: 0)); tri.addLine(to: CGPoint(x: 0, y: CGFloat(hl * tan(tilt)))); tri.close()
    for sx in [Float(-1), 1] { let sg = SCNShape(path: tri, extrusionDepth: 0.06); sg.firstMaterial = wood; let n = SCNNode(geometry: sg); n.position = SCNVector3(sx * hw, y0 + wallH, 0); n.eulerAngles.y = .pi / 2; r.addChildNode(n) }
    // hiên + bậc thềm + phuy + bao cám + lưới phơi
    r.addChildNode(pbox(1.0, 0.1, CGFloat(l + 0.2), hw + 0.6, 0.2, 0, dark, 0.01))
    for sz in [Float(-1), 1] { r.addChildNode(pcyl(0.06, 0.9, hw + 1.05, -0.25, sz * (hl + 0.05), dark)) }
    r.addChildNode(pbox(0.9, 0.12, 0.35, dx, 0.12, hl + 0.35, wood, 0.01)); r.addChildNode(pbox(0.9, 0.12, 0.3, dx, -0.04, hl + 0.62, wood, 0.01))
    let blue = pcol(0.1, 0.3, 0.6); blue.isDoubleSided = true; blue.specular.contents = UIColor(white: 0.5, alpha: 1); blue.shininess = 0.5
    drum(hw + 0.5, 0.25, hl - 0.4, blue, r); drum(hw + 0.55, 0.25, hl - 1.0, pcol(0.15, 0.4, 0.2), r); drum(hw + 0.85, 0.25, hl - 0.65, blue, r)
    let sack = pcol(0.82, 0.74, 0.55)
    for i in 0..<3 { let b = psph(0.2, hw + 0.7 + 0.05 * Float(i), 0.34 + 0.22 * Float(i % 2), -hl + 0.5 + 0.38 * Float(i), 0.55, sack); b.scale = SCNVector3(1.0, 0.55, 1.5); r.addChildNode(b) }
    let nt = SCNPlane(width: 1.0, height: 0.7); nt.firstMaterial = netMat(2, 1.4); let nn = SCNNode(geometry: nt); nn.position = SCNVector3(-hw - 0.05, y0 + 1.3, 0.1); nn.eulerAngles.y = -.pi / 2; nn.renderingOrder = 20; r.addChildNode(nn)
    r.addChildNode(rod(SIMD3<Float>(-hw - 0.06, y0 + 1.68, -0.4), SIMD3<Float>(-hw - 0.06, y0 + 1.68, 0.6), 0.015, pcol(0.72, 0.62, 0.36)))
    return r
  }

  // cầu ao: ván gỗ có khe, dầm, cọc cắm xuống đáy ao (thấy rõ chiều sâu), lan can tre, cần câu + phao
  func pondPier(_ th: Float, _ len: Float) -> SCNNode {
    let M = bankFrame(th, 1.0); let (outer, inner) = frameNode(M); let base = M.columns.3.y
    let wood = mat(woodImg(pc(0.46, 0.38, 0.28)), 1, 1), dark = mat(woodImg(pc(0.28, 0.22, 0.16)), 1, 1), bamboo = pcol(0.72, 0.62, 0.36)
    let n = Int(len / 0.27); let top: Float = 0.12
    for i in 0..<n { inner.addChildNode(pbox(1.1, 0.05, 0.24, 0, top, Float(i) * 0.27 + 0.1, i % 4 == 0 ? dark : wood, 0.008)) }
    for sx in [Float(-0.4), 0.4] { inner.addChildNode(pbox(0.09, 0.08, CGFloat(len), sx, top - 0.065, len / 2, dark, 0.01)) }
    for k in 0..<4 { let z = 0.5 + Float(k) * (len - 0.7) / 3
      for sx in [Float(-0.45), 0.45] {
        let q = bake(M, SIMD3<Float>(sx, 0, z)); let bedLocal = pondBedY(min(max(pondS(q.x, q.z), 0.02), 1)) - base   // cọc cắm xuống đáy ao
        let h = (top - 0.04) - bedLocal
        inner.addChildNode(pcyl(0.055, CGFloat(h), sx, bedLocal + h / 2, z, dark)) } }
    for k in 0..<4 { let z = 0.5 + Float(k) * (len - 0.7) / 3; inner.addChildNode(pcyl(0.03, 0.8, -0.5, top + 0.4, z, bamboo)) }
    inner.addChildNode(rod(SIMD3<Float>(-0.5, top + 0.75, 0.5), SIMD3<Float>(-0.5, top + 0.75, len - 0.2), 0.025, bamboo))
    inner.addChildNode(rod(SIMD3<Float>(-0.5, top + 0.42, 0.5), SIMD3<Float>(-0.5, top + 0.42, len - 0.2), 0.02, bamboo))
    let red = pcol(0.75, 0.15, 0.1); let bk = lathe([(0, 0), (0.1, 0), (0.12, 0.25), (0.11, 0.26), (0, 0.24)], 14); bk.firstMaterial = red; bk.firstMaterial?.isDoubleSided = true
    let bn = SCNNode(geometry: bk); bn.position = SCNVector3(0.3, top + 0.025, len - 0.35); inner.addChildNode(bn)   // xô
    let seat = pbox(0.3, 0.05, 0.25, 0.1, top + 0.25, len - 0.8, wood, 0.01); inner.addChildNode(seat)
    for sx in [Float(0), 0.22] { inner.addChildNode(pcyl(0.025, 0.25, sx - 0.02, top + 0.125, len - 0.8, dark)) }
    let tip = SIMD3<Float>(-0.1, top + 1.5, len + 1.0)   // cần câu tre nghiêng ra mặt nước, dây thả xuống phao
    inner.addChildNode(rod(SIMD3<Float>(0.35, top + 0.1, len - 1.2), tip, 0.014, bamboo))
    let waterLocal = Game.pondWater - base
    inner.addChildNode(rod(tip, SIMD3<Float>(tip.x, waterLocal + 0.02, tip.z), 0.003, pcol(0.9, 0.9, 0.85)))
    inner.addChildNode(psph(0.03, tip.x, waterLocal + 0.01, tip.z, 1.3, pcol(0.9, 0.2, 0.1)))
    return outer.flattenedClone()
  }
}
