import SceneKit
import UIKit
import simd

// ===== Ao cá: thảm thực vật, vật dưới đáy, bố cục tổng =====
extension Game {
  func padImg() -> UIImage {   // lá sen/súng: xanh sẫm, gân tỏa
    UIGraphicsImageRenderer(size: CGSize(width: 128, height: 128)).image { c in
      let g = c.cgContext
      if let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [pc(0.35, 0.58, 0.2).cgColor, pc(0.14, 0.38, 0.1).cgColor] as CFArray, locations: [0, 1]) {
        g.drawRadialGradient(gr, startCenter: CGPoint(x: 64, y: 64), startRadius: 0, endCenter: CGPoint(x: 64, y: 64), endRadius: 64, options: []) }
      pc(0.7, 0.85, 0.45).withAlphaComponent(0.4).setStroke(); g.setLineWidth(1.5)
      for k in 0..<14 { let a = CGFloat(k) / 14 * 2 * .pi; g.move(to: CGPoint(x: 64, y: 64)); g.addLine(to: CGPoint(x: 64 + cos(a) * 64, y: 64 + sin(a) * 64)); g.strokePath() }
      for i in 0..<250 { UIColor(white: CGFloat((i * 37) % 100) / 100, alpha: 0.07).setFill(); g.fill(CGRect(x: CGFloat((i * 53) % 128), y: CGFloat((i * 97) % 128), width: 3, height: 3)) } }
  }

  func pondDiorama() -> SCNNode {
    let root = SCNNode(), solid = SCNNode(); var rr = RNG(); rr.s = 4141
    pondTerrain(solid, root, &rr)

    // ----- bố cục các vật lớn -----
    let thHut: Float = -2.3, thShed: Float = -0.3, thPier: Float = 2.2, thBoat: Float = 1.25
    let (ho, hi) = frameNode(bankFrame(thHut, 1.75)); hi.addChildNode(tonHut(2.2, 1.8, 1.9)); solid.addChildNode(ho.flattenedClone())
    let (so, si) = frameNode(bankFrame(thShed, 2.0)); si.addChildNode(tonHut(1.6, 1.4, 1.7)); solid.addChildNode(so.flattenedClone())
    solid.addChildNode(pondPier(thPier, 3.8))
    pondPump(thShed, solid, root)
    pondAerator(2.8, 0.7, solid, root)
    pondBoat(thBoat, solid)
    pondNet(solid, root, -3.0, -1.9, 2.0, 1.4)
    pondFish(root, &rr)

    // vùng cần chừa trống mặt nước để cây nổi không chồng lên vật khác
    var avoid: [(Float, Float, Float)] = [(-3.0, -1.9, 1.9), (2.8, 0.7, 1.2)]
    let pn = pondN(thPier), ps = pondBankPt(thPier, 1.0); for k in 0..<5 { let d = Float(k) * 0.95 + 1.0; avoid.append((ps.x - pn.x * d, ps.z - pn.y * d, 0.9)) }
    let bn = pondN(thBoat), bp = pondP(thBoat) - bn * 1.15, bt = SIMD2<Float>(-bn.y, bn.x); for k in -1...1 { avoid.append((bp.x + bt.x * Float(k) * 1.2, bp.y + bt.y * Float(k) * 1.2, 1.1)) }
    let jn = pondN(thShed), jp = pondP(thShed) - jn * 1.9; avoid.append((jp.x, jp.y, 1.2))
    func clear(_ x: Float, _ z: Float, _ m: Float) -> Bool { pondInside(x, z, m) && !avoid.contains { simd_length(SIMD2<Float>(x - $0.0, z - $0.1)) < $0.2 } }

    // ----- dưới đáy ao: đá cuội, khúc gỗ chìm, rong mọc từ đáy lên gần mặt nước -----
    let stones = [pcol(0.36, 0.35, 0.31), pcol(0.28, 0.28, 0.26), pcol(0.42, 0.38, 0.3)]
    for _ in 0..<40 { let th = rr.f(0, 6.283), s = rr.f(0.25, 0.94), r = rr.f(0.05, 0.15); let q = pondP(th) * s
      let st = psph(CGFloat(r), q.x, pondBedY(s) + r * 0.2, q.y, 0.55, stones[Int(rr.f(0, 2.99))]); st.eulerAngles.y = rr.f(0, 6.28); solid.addChildNode(st) }
    func bedPt(_ th: Float, _ s: Float) -> SIMD3<Float> { let q = pondP(th) * s; return SIMD3<Float>(q.x, pondBedY(s) + 0.05, q.y) }
    solid.addChildNode(rod(bedPt(0.3, 0.55), bedPt(0.7, 0.8), 0.07, mat(woodImg(pc(0.2, 0.16, 0.1)), 1, 1)))
    let weed = leafMat("grass")
    for _ in 0..<110 { let th = rr.f(0, 6.283), s = rr.f(0.5, 0.94); let q = pondP(th) * s
      rosy(solid, mT(q.x, pondBedY(s), q.y) * mRy(rr.f(0, 6.28)) * mS(rr.f(0.8, 1.3)), 6, 0.6, 0.06, weed, outer: 1.2, inner: 1.5, arch: 0.3, fold: 0.1) }

    // ----- mặt nước: lục bình, lá + hoa sen/súng -----
    let hy = leafMat("lettuce")
    for _ in 0..<9 { var cx: Float = 0, cz: Float = 0, tries = 0
      repeat { cx = rr.f(-5, 5); cz = rr.f(-3.4, 3.4); tries += 1 } while !clear(cx, cz, 0.7) && tries < 40
      guard clear(cx, cz, 0.7) else { continue }
      for _ in 0..<4 { rosy(solid, mT(cx + rr.f(-0.4, 0.4), 0.64, cz + rr.f(-0.4, 0.4)) * mRy(rr.f(0, 6.28)) * mS(rr.f(0.8, 1.3)), 7, 0.22, 0.24, hy, outer: 0.25, inner: 0.8, arch: -0.1, fold: 0.3, radius: 0.03) } }
    let padM = mat(padImg(), 1, 1); padM.isDoubleSided = true; let lotus = leafMat("lotus")
    var flowers = 0
    for i in 0..<18 { var cx: Float = 0, cz: Float = 0, tries = 0
      repeat { cx = rr.f(-5, 5); cz = rr.f(-3.4, 3.4); tries += 1 } while !clear(cx, cz, 0.6) && tries < 40
      guard clear(cx, cz, 0.6) else { continue }
      let rad = rr.f(0.15, 0.3); let cyl = SCNCylinder(radius: CGFloat(rad), height: 0.006); cyl.radialSegmentCount = 20; cyl.firstMaterial = padM
      let pn = SCNNode(geometry: cyl); pn.position = SCNVector3(cx, Game.pondWater + 0.012, cz); pn.eulerAngles = SCNVector3(rr.f(-0.05, 0.05), rr.f(0, 6.28), rr.f(-0.05, 0.05)); solid.addChildNode(pn)
      if i % 4 == 1 && flowers < 5 { flowers += 1; let M = mT(cx + 0.35, 0.63, cz + 0.1)
        rosy(solid, M, 8, 0.15, 0.07, lotus, outer: 0.7, inner: 0.9, arch: 0.35, fold: 0.2, radius: 0.02)
        rosy(solid, M * mT(0, 0.02, 0), 6, 0.11, 0.06, lotus, outer: 1.1, inner: 1.35, arch: 0.3, fold: 0.2, radius: 0.015)
        solid.addChildNode(psph(0.025, cx + 0.35, 0.67, cz + 0.1, 0.8, pcol(0.95, 0.8, 0.15))) } }

    // ----- bờ: cỏ phủ, cỏ lau sát mép nước, lau sậy mọc dưới nước nông, hoa dại -----
    let grassLeaf = leafMat("grass")
    for _ in 0..<320 { let th = rr.f(-3.14, 3.14), d = rr.f(0.05, 3.4); let th2 = th < 0 ? th + 6.283 : th
      if th2 > 0.3 && th2 < 3.7 && d > 0.7 && d < 1.6 { continue }
      let q = pondBankPt(th, d); rosy(solid, mT(q.x, q.y, q.z) * mRy(rr.f(0, 6.28)) * mS(rr.f(0.8, 1.5)), 6, 0.5, 0.07, grassLeaf, outer: 0.9, inner: 1.35, arch: 0.4, fold: 0.1) }
    for _ in 0..<70 { let th = rr.f(-3.14, 3.14), d = rr.f(0.0, 0.7); let q = pondBankPt(th, d)
      rosy(solid, mT(q.x, q.y, q.z) * mRy(rr.f(0, 6.28)) * mS(rr.f(1.6, 2.4)), 6, 0.5, 0.07, grassLeaf, outer: 1.1, inner: 1.45, arch: 0.45, fold: 0.1) }
    for _ in 0..<34 { let th = rr.f(0, 6.283), s = rr.f(0.93, 0.99); let q = pondP(th) * s
      rosy(solid, mT(q.x, pondBedY(s), q.y) * mRy(rr.f(0, 6.28)) * mS(rr.f(1.6, 2.2)), 6, 0.5, 0.07, grassLeaf, outer: 1.2, inner: 1.5, arch: 0.35, fold: 0.1) }
    for _ in 0..<18 { let th = rr.f(0, 6.283), d = rr.f(0.9, 3.0); let q = pondBankPt(th, d); let f = flower(q.x, q.z, rr.f(0.25, 0.5)); f.position.y = q.y; solid.addChildNode(f) }

    // hàng rào tre phía sau + chuối + lu nước
    let bamboo = pcol(0.72, 0.62, 0.36)
    var fp = [SIMD3<Float>](); for k in 0...10 { fp.append(pondBankPt(-2.0 + Float(k) * 0.13, 2.2)) }
    for i in 0..<fp.count { solid.addChildNode(pcyl(0.03, 0.95, fp[i].x, fp[i].y + 0.45, fp[i].z, bamboo))
      if i > 0 { for h in [Float(0.3), 0.7] { solid.addChildNode(rod(fp[i - 1] + SIMD3<Float>(0, h, 0), fp[i] + SIMD3<Float>(0, h, 0), 0.018, bamboo)) } } }
    let bananaLeaf = leafMat("default"), trunkM = pcol(0.52, 0.56, 0.32)
    for (th, d, h) in [(Float(-2.9), Float(2.6), Float(3.0)), (-2.75, 3.0, 2.5), (-1.0, 2.9, 3.2), (3.0, 2.7, 2.8), (2.85, 3.1, 3.3), (0.05, 2.6, 2.6)] {
      let q = pondBankPt(th, d); let tg = lathe([(0.15, 0), (0.17, 0.3), (0.13, h * 0.8), (0.09, h)], 10); tg.firstMaterial = trunkM; geoNode(tg, mT(q.x, q.y, q.z), solid)
      for i in 0..<10 { let yw = Float(i) * 2.4 + rr.f(0, 0.4), el = 0.5 + rr.f(0, 0.55), sz = rr.f(0.85, 1.15)
        geoNode(leafGeo(2.4, 0.8, -0.5, 0.22, bananaLeaf), mT(q.x, q.y + h, q.z) * mRy(yw) * mS(sz) * mRx(-el), solid) } }
    let clay = pcol(0.45, 0.22, 0.1); clay.specular.contents = UIColor(white: 0.6, alpha: 1); clay.shininess = 0.7; clay.isDoubleSided = true
    let lg = lathe([(0, 0), (0.2, 0), (0.3, 0.05), (0.42, 0.25), (0.46, 0.45), (0.4, 0.65), (0.28, 0.8), (0.22, 0.88), (0.24, 0.93), (0.27, 0.96), (0.25, 0.985), (0.2, 0.96), (0, 0.94)], 24); lg.firstMaterial = clay
    let lq = pondBankPt(-2.55, 1.1); geoNode(lg, mT(lq.x, lq.y, lq.z) * mS(0.6), solid)
    root.addChildNode(solid.flattenedClone())

    // cây lớn (đung đưa theo gió như cây ngoài cảnh)
    for (id, th, d, yw) in [("coconutTreeBended", Float(-0.9), Float(2.9), Float(0.5)), ("palm 2", Float(2.75), Float(2.8), Float(1.7)), ("coconutTreeBended", Float(-1.7), Float(3.1), Float(3.4)), ("acacia", Float(2.0), Float(3.0), Float(0))] {
      if let p = proto(id) { let q = pondBankPt(th, d); let n = p.clone(); n.position = SCNVector3(q.x, q.y, q.z); n.eulerAngles.y = yw; root.addChildNode(n) } }
    return root
  }
}
