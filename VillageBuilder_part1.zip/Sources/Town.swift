import SceneKit
import UIKit
import simd

// ===== Thị trấn cổ: nhà ngói đỏ / xám, tường đỏ, cổng bài phường, tháp canh, hồ xây gạch, đường lát đá =====
// Dựng theo ảnh tham chiếu thị trấn (volamweb town.jpg) nhưng là mô hình 3D thật: mái ngói cong vút có hàng ngói ống,
// cột sơn son + đấu củng, cửa chấn song, tường vôi bong tróc, đá xếp, rêu. Quy ước như mục 4 của HUONG_DAN_AI.md:
// mét, y = 0 là mặt đất, gốc ở giữa chân, "phía trước" = +z, mô hình dài (tường, đường lát) dài theo trục x.

private func tcol(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat, _ a: CGFloat = 1) -> UIColor {
  UIColor(red: min(max(r, 0), 1), green: min(max(g, 0), 1), blue: min(max(b, 0), 1), alpha: a)
}
/// số giả ngẫu nhiên cố định theo chỉ số (0...1) để texture luôn giống nhau mỗi lần chạy
private func thash(_ i: Int) -> CGFloat {
  var x = UInt64(truncatingIfNeeded: i) &* 0x9E3779B97F4A7C15
  x ^= x >> 29; x = x &* 0xBF58476D1CE4E5B9; x ^= x >> 32
  return CGFloat(x % 10000) / 10000
}

/// vẽ texture 256x256 bằng mã (ngói, gạch, đá, vôi, tường đỏ, lát đá, chấn song)
private func townDraw(_ kind: String, _ g: CGContext) {
  let S: CGFloat = 256
  func rect(_ x: CGFloat, _ y: CGFloat, _ w: CGFloat, _ h: CGFloat, _ c: UIColor) { c.setFill(); g.fill(CGRect(x: x, y: y, width: w, height: h)) }
  func dot(_ x: CGFloat, _ y: CGFloat, _ d: CGFloat, _ c: UIColor) { c.setFill(); g.fillEllipse(in: CGRect(x: x, y: y, width: d, height: d * 0.7)) }
  switch kind {
  case "tileRed", "tileGray":
    let red = kind == "tileRed"
    let b: (CGFloat, CGFloat, CGFloat) = red ? (0.56, 0.22, 0.13) : (0.38, 0.39, 0.38)
    rect(0, 0, S, S, tcol(b.0 * 0.4, b.1 * 0.4, b.2 * 0.4))
    for r in 0..<8 {
      for k in 0..<16 {
        let h = thash(r * 16 + k + (red ? 0 : 777)), x = CGFloat(k) * 16, y = CGFloat(r) * 32, kk = 0.78 + 0.42 * h
        rect(x, y, 16, 32, tcol(b.0 * kk, b.1 * kk, b.2 * kk))
        rect(x + 3, y, 4, 32, UIColor(white: 1, alpha: 0.08 + 0.07 * h))
        rect(x, y, 2, 32, UIColor(white: 0, alpha: 0.45)); rect(x + 14, y, 2, 32, UIColor(white: 0, alpha: 0.45))
        rect(x, y + 25, 16, 7, UIColor(white: 0, alpha: 0.38)); rect(x + 1, y + 23, 14, 2, UIColor(white: 1, alpha: 0.07))
      }
    }
    for i in 0..<(red ? 90 : 230) {
      let d = 2 + thash(i * 3 + 2) * 7
      dot(thash(i * 3) * S, thash(i * 3 + 1) * S, d, i % 3 == 0 ? tcol(0.25, 0.36, 0.14, 0.4) : tcol(0.1, 0.08, 0.05, 0.25))
    }
  case "brickGray", "brickBrown":
    let gray = kind == "brickGray"
    let b: (CGFloat, CGFloat, CGFloat) = gray ? (0.45, 0.44, 0.41) : (0.5, 0.38, 0.29)
    rect(0, 0, S, S, tcol(0.2, 0.19, 0.17))
    for r in 0..<16 {
      let off: CGFloat = r % 2 == 0 ? 0 : 16
      for k in -1..<9 {
        let h = thash(r * 20 + k + 5000 + (gray ? 0 : 99)), kk = 0.7 + 0.5 * h
        rect(CGFloat(k) * 32 + off + 1, CGFloat(r) * 16 + 1, 30, 14, tcol(b.0 * kk, b.1 * kk, b.2 * kk))
        rect(CGFloat(k) * 32 + off + 1, CGFloat(r) * 16 + 1, 30, 2, UIColor(white: 1, alpha: 0.07))
      }
    }
    for i in 0..<260 { rect(thash(i * 5) * S, thash(i * 5 + 2) * S, 3, 2, UIColor(white: thash(i * 5 + 1) > 0.5 ? 1 : 0, alpha: 0.08)) }
    for i in 0..<40 { dot(thash(i * 7 + 3) * S, thash(i * 7 + 4) * S, 3 + thash(i * 7 + 5) * 8, tcol(0.2, 0.32, 0.12, 0.28)) }
  case "stoneBlock":
    rect(0, 0, S, S, tcol(0.22, 0.21, 0.19))
    for r in 0..<8 {
      var x: CGFloat = -thash(r + 90) * 60; var k = 0
      while x < S {
        let w = 50 + thash(r * 13 + k + 400) * 40, kk = 0.72 + 0.4 * thash(r * 29 + k + 1200)
        rect(x + 2, CGFloat(r) * 32 + 2, w - 3, 28, tcol(0.52 * kk, 0.5 * kk, 0.46 * kk))
        rect(x + 2, CGFloat(r) * 32 + 2, w - 3, 3, UIColor(white: 1, alpha: 0.12))
        x += w; k += 1
      }
    }
    for i in 0..<420 { rect(thash(i * 5) * S, thash(i * 5 + 2) * S, 2, 2, UIColor(white: thash(i * 5 + 1) > 0.5 ? 1 : 0, alpha: 0.1)) }
    for i in 0..<30 { dot(thash(i * 7 + 3) * S, thash(i * 7 + 4) * S, 3 + thash(i * 7 + 5) * 9, tcol(0.22, 0.34, 0.13, 0.3)) }
  case "plaster":
    rect(0, 0, S, S, tcol(0.8, 0.78, 0.72))
    for i in 0..<700 { dot(thash(i * 3) * S, thash(i * 3 + 1) * S, 1 + thash(i * 3 + 2) * 9, i % 2 == 0 ? tcol(0.5, 0.47, 0.4, 0.12) : tcol(1, 1, 0.95, 0.12)) }
    for i in 0..<26 { rect(thash(i * 7) * S, thash(i * 7 + 1) * 120, 3 + thash(i * 7 + 3) * 4, 30 + thash(i * 7 + 2) * 90, tcol(0.35, 0.32, 0.26, 0.13)) }
    tcol(0.25, 0.22, 0.18, 0.5).setStroke(); g.setLineWidth(1.2)
    for i in 0..<5 {
      var x = thash(i * 11 + 500) * S, y = thash(i * 11 + 501) * S; g.move(to: CGPoint(x: x, y: y))
      for k in 0..<7 { x += (thash(i * 11 + k + 600) - 0.5) * 30; y += 8 + thash(i * 11 + k + 700) * 14; g.addLine(to: CGPoint(x: x, y: y)) }
      g.strokePath()
    }
  case "redWall":
    rect(0, 0, S, S, tcol(0.55, 0.13, 0.09))
    for i in 0..<900 { dot(thash(i * 3) * S, thash(i * 3 + 1) * S, 1 + thash(i * 3 + 2) * 6, i % 2 == 0 ? tcol(0.3, 0.05, 0.03, 0.25) : tcol(0.75, 0.28, 0.2, 0.2)) }
    for i in 0..<9 {   // vết vôi bong tróc lộ gạch
      let cx = thash(i * 5 + 30) * S, cy = thash(i * 5 + 31) * S, rr = 10 + thash(i * 5 + 32) * 26
      let p = UIBezierPath()
      for k in 0..<8 {
        let a = CGFloat(k) / 8 * 2 * CGFloat.pi, r2 = rr * (0.6 + 0.6 * thash(i * 40 + k))
        let pt = CGPoint(x: cx + cos(a) * r2, y: cy + sin(a) * r2 * 0.7)
        if k == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
      }
      p.close(); tcol(0.52, 0.47, 0.4, 0.92).setFill(); p.fill()
      tcol(0.3, 0.26, 0.22, 0.6).setStroke(); p.lineWidth = 1.5; p.stroke()
      for k in 1..<3 { rect(cx - rr * 0.6, cy - rr * 0.4 + CGFloat(k) * rr * 0.35, rr * 1.2, 1.5, tcol(0.28, 0.24, 0.2, 0.55)) }
    }
    for i in 0..<20 { rect(thash(i * 9) * S, 0, 3, 40 + thash(i * 9 + 1) * 160, tcol(0.2, 0.04, 0.02, 0.18)) }
  case "pave":
    rect(0, 0, S, S, tcol(0.25, 0.24, 0.21))
    for r in 0..<4 {
      for k in 0..<4 {
        let kk = 0.78 + 0.35 * thash(r * 4 + k + 2000), x = CGFloat(k) * 64, y = CGFloat(r) * 64
        rect(x + 2, y + 2, 60, 60, tcol(0.62 * kk, 0.6 * kk, 0.55 * kk))
        rect(x + 2, y + 2, 60, 3, UIColor(white: 1, alpha: 0.14)); rect(x + 2, y + 59, 60, 3, UIColor(white: 0, alpha: 0.18))
        UIColor(white: 0, alpha: 0.12).setStroke(); g.setLineWidth(1); g.stroke(CGRect(x: x + 8, y: y + 8, width: 48, height: 48))
      }
    }
    for i in 0..<500 { rect(thash(i * 5) * S, thash(i * 5 + 2) * S, 2, 2, UIColor(white: thash(i * 5 + 1) > 0.5 ? 1 : 0, alpha: 0.1)) }
    for i in 0..<36 { dot(thash(i * 7 + 3) * S, thash(i * 7 + 4) * S, 3 + thash(i * 7 + 5) * 7, tcol(0.22, 0.36, 0.13, 0.35)) }
  case "lattice":   // chấn song cửa
    rect(0, 0, S, S, tcol(0.13, 0.05, 0.03))
    tcol(0.6, 0.28, 0.12).setStroke(); g.setLineWidth(6)
    for k in 0..<9 {
      let p = CGFloat(k) * 32
      g.move(to: CGPoint(x: p, y: 0)); g.addLine(to: CGPoint(x: p, y: S)); g.move(to: CGPoint(x: 0, y: p)); g.addLine(to: CGPoint(x: S, y: p))
    }
    g.strokePath()
    tcol(0.8, 0.45, 0.2, 0.7).setStroke(); g.setLineWidth(2)
    for k in 0..<8 { let p = CGFloat(k) * 32 + 16; g.move(to: CGPoint(x: p, y: 0)); g.addLine(to: CGPoint(x: p, y: S)); g.move(to: CGPoint(x: 0, y: p)); g.addLine(to: CGPoint(x: S, y: p)) }
    g.strokePath()
  default:
    rect(0, 0, S, S, tcol(0.5, 0.5, 0.5))
  }
}

extension Game {
  static var townImgs: [String: UIImage] = [:]
  static let townIds = ["Nhà ngói đỏ", "Nhà ngói xám", "Tường đỏ", "Cổng bài phường", "Tháp canh gạch", "Đường lát đá"]

  // ---------- vật liệu ----------
  func tmat(_ kind: String, _ sx: Float = 1, _ sy: Float = 1) -> SCNMaterial {
    let key = "T:\(kind):\(sx):\(sy)"
    if let m = leafMats[key] { return m }
    var img = Game.townImgs[kind]
    if img == nil {
      img = UIGraphicsImageRenderer(size: CGSize(width: 256, height: 256), format: Game.fmtTex).image { c in townDraw(kind, c.cgContext) }
      Game.townImgs[kind] = img
    }
    let m = mat(img!, sx, sy); m.isDoubleSided = true; m.name = key; leafMats[key] = m; return m
  }
  /// sơn son, gỗ tối, vàng, đèn lồng, lá sen
  func tLac(_ k: String) -> SCNMaterial {
    let key = "T:L:" + k
    if let c = leafMats[key] { return c }
    let m: SCNMaterial
    switch k {
    case "red": m = pcol(0.58, 0.09, 0.06); m.specular.contents = UIColor(white: 0.45, alpha: 1); m.shininess = 0.5
    case "dark": m = pcol(0.2, 0.11, 0.07); m.specular.contents = UIColor(white: 0.3, alpha: 1); m.shininess = 0.4
    case "gold": m = pcol(0.85, 0.64, 0.2); m.specular.contents = UIColor(white: 0.9, alpha: 1); m.shininess = 0.7
    case "lantern": m = pcol(0.75, 0.1, 0.05); m.emission.contents = UIColor(red: 0.4, green: 0.05, blue: 0, alpha: 1)
    case "pad": m = pcol(0.2, 0.42, 0.14)
    case "wood": m = mat(woodImg(UIColor(red: 0.4, green: 0.25, blue: 0.14, alpha: 1)), 1, 1)
    default: m = pcol(0.5, 0.5, 0.5)
    }
    m.isDoubleSided = true; leafMats[key] = m; return m
  }

  // ---------- khối cơ bản ----------
  func mBox(_ w: Float, _ h: Float, _ l: Float, _ x: Float, _ y: Float, _ z: Float, _ m: SCNMaterial, _ ch: CGFloat = 0.012) -> SCNNode {
    pbox(CGFloat(w), CGFloat(h), CGFloat(l), x, y, z, m, ch)
  }
  func mCyl(_ r: Float, _ h: Float, _ x: Float, _ y: Float, _ z: Float, _ m: SCNMaterial) -> SCNNode {
    pcyl(CGFloat(r), CGFloat(h), x, y, z, m)
  }
  func tQ(_ v: Float) -> Float { max(0.25, (v * 2).rounded() / 2) }
  /// khối có texture lặp theo kích thước thật (tw, tht = số mét cho một lần lặp)
  func tBox(_ w: Float, _ h: Float, _ l: Float, _ x: Float, _ y: Float, _ z: Float, _ kind: String, _ tw: Float = 2.5, _ tht: Float = 2.5, _ ch: CGFloat = 0.01) -> SCNNode {
    let g = SCNBox(width: CGFloat(w), height: CGFloat(h), length: CGFloat(l), chamferRadius: ch)
    let fb = tmat(kind, tQ(w / tw), tQ(h / tht)), sd = tmat(kind, tQ(l / tw), tQ(h / tht)), tp = tmat(kind, tQ(w / tw), tQ(l / tht))
    g.materials = [fb, sd, fb, sd, tp, tp]
    let n = SCNNode(geometry: g); n.position = SCNVector3(x, y, z); return n
  }

  // ---------- mái ngói cong ----------
  /// Mái hai dốc lõm (dốc đứng ở nóc, thoải ở mép), mép mái và hai đầu hồi vểnh lên, hàng ngói ống, diềm mái, đầu ngói tròn,
  /// nóc có bờ nóc + sừng + nụ vàng. Tọa độ tuyệt đối: (ox, oy, oz) = giữa nóc; nóc chạy dọc trục x.
  func townRoof(_ root: SCNNode, _ ox: Float, _ oy: Float, _ oz: Float, W: Float, D: Float, drop: Float, out: Float, up: Float,
                tile: SCNMaterial, gable: SCNMaterial?, trim: SCNMaterial, wallTop: Float) {
    let hd = D / 2 + out, hw = W / 2 + out * 0.7, nx = 18, nt = 12
    func prof(_ t: Float) -> Float { let e = max(0, (t - 0.82) / 0.18); return -drop * (1 - pow(1 - t, 1.7)) + up * e * e }
    func lift(_ u: Float, _ t: Float) -> Float { up * 1.4 * pow(abs(u), 5) * t * t }
    var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
    for s in [Float(1), Float(-1)] {
      let base = Int32(P.count)
      for i in 0...nt {
        let t = Float(i) / Float(nt)
        for j in 0...nx {
          let u = Float(j) / Float(nx) * 2 - 1
          P.append(SIMD3<Float>(ox + u * hw, oy + prof(t) + lift(u, t), oz + s * hd * t))
          UV.append(SIMD2<Float>(u * hw / 2.7, t * hd / 1.6))
        }
      }
      for i in 0..<nt {
        for j in 0..<nx {
          let a = base + Int32(i * (nx + 1) + j), b = a + 1, c = a + Int32(nx + 1), d = c + 1
          if s > 0 { I += [a, c, b, b, c, d] } else { I += [a, b, c, b, d, c] }
        }
      }
    }
    let rg = meshGeo(P, UV, I); rg.firstMaterial = tile; root.addChildNode(SCNNode(geometry: rg))
    // diềm mái dày dọc hai mép
    for s in [Float(1), Float(-1)] {
      var Q = [SIMD3<Float>](), QU = [SIMD2<Float>](), QI = [Int32]()
      for j in 0...nx {
        let u = Float(j) / Float(nx) * 2 - 1, y = oy + prof(1) + lift(u, 1), x = ox + u * hw, z = oz + s * hd
        Q.append(SIMD3<Float>(x, y, z)); QU.append(SIMD2<Float>(Float(j) / 4, 0))
        Q.append(SIMD3<Float>(x, y - 0.17, z)); QU.append(SIMD2<Float>(Float(j) / 4, 0.2))
      }
      for j in 0..<nx { let a = Int32(2 * j); QI += [a, a + 1, a + 2, a + 1, a + 3, a + 2] }
      let fg = meshGeo(Q, QU, QI); fg.firstMaterial = trim; root.addChildNode(SCNNode(geometry: fg))
      // đầu ngói tròn dọc mép mái
      let nd = Int(2 * hw / 0.2)
      for j in 0..<nd {
        let u = (Float(j) + 0.5) / Float(nd) * 2 - 1
        let d = mCyl(0.075, 0.06, ox + u * hw, oy + prof(1) + lift(u, 1) - 0.05, oz + s * hd + s * 0.02, trim)
        d.eulerAngles.x = .pi / 2; root.addChildNode(d)
      }
    }
    // bờ nóc, sừng nóc, nụ vàng
    root.addChildNode(mBox(2 * hw * 0.97, 0.16, 0.36, ox, oy + 0.08, oz, trim, 0.03))
    let roll = mCyl(0.13, 2 * hw * 0.97, ox, oy + 0.2, oz, trim); roll.eulerAngles.z = .pi / 2; root.addChildNode(roll)
    for sx in [Float(1), Float(-1)] {
      let h = mBox(0.13, 0.55, 0.16, ox + sx * hw * 0.96, oy + 0.4, oz, trim, 0.03); h.eulerAngles.z = -sx * 0.4; root.addChildNode(h)
    }
    root.addChildNode(psph(0.13, ox, oy + 0.38, oz, 1.4, tLac("gold")))
    // tường hồi lấp khoảng hở dưới mái ở hai đầu nhà
    if let gm = gable {
      for sx in [Float(1), Float(-1)] {
        var A = [SIMD3<Float>](), AU = [SIMD2<Float>](), AI = [Int32](); let K = 14
        for k in 0...K {
          let z = -D / 2 + D * Float(k) / Float(K), t = abs(z) / hd
          let top = max(oy + prof(t) - 0.1, wallTop + 0.02), x = ox + sx * W / 2
          A.append(SIMD3<Float>(x, wallTop, oz + z)); AU.append(SIMD2<Float>(z / 2.7, wallTop / 2.7))
          A.append(SIMD3<Float>(x, top, oz + z)); AU.append(SIMD2<Float>(z / 2.7, top / 2.7))
        }
        for k in 0..<K { let a = Int32(2 * k); AI += [a, a + 1, a + 2, a + 1, a + 3, a + 2] }
        let ag = meshGeo(A, AU, AI); ag.firstMaterial = gm; root.addChildNode(SCNNode(geometry: ag))
      }
    }
  }

  // ---------- Nhà ngói đỏ (chính điện) ----------
  func townHall() -> SCNNode {
    let r = SCNNode(); let red = tLac("red"), dark = tLac("dark"), gold = tLac("gold"), stoneM = tmat("stoneBlock", 1, 1)
    let W: Float = 7.2, D: Float = 4.4, fl: Float = 0.4, zf: Float = 2.0, wt: Float = 3.26
    r.addChildNode(tBox(W + 1.4, fl, D + 1.4, 0, fl / 2, 0, "stoneBlock", 2.5, 2.5, 0.03))
    for k in 0..<3 {   // ba bậc đá phía trước
      let h = 0.13 * Float(k + 1), z = 3.11 + 0.42 * Float(2 - k)
      r.addChildNode(tBox(3.6, h, 0.42, 0, h / 2, z, "stoneBlock", 2.5, 2.5, 0.01))
    }
    // cột sơn son trên chân tảng đá
    let colG = lathe([(0.16, 0), (0.16, 0.05), (0.145, 0.08), (0.145, 2.56), (0.165, 2.6), (0.165, 2.7)], 14); colG.firstMaterial = red
    let xs: [Float] = [-3.3, -1.1, 1.1, 3.3]
    for x in xs {
      r.addChildNode(mCyl(0.26, 0.16, x, fl + 0.08, zf, stoneM))
      let c = SCNNode(geometry: colG); c.position = SCNVector3(x, fl + 0.16, zf); r.addChildNode(c)
      for (i, w) in [Float(0.5), 0.85, 1.2].enumerated() {   // đấu củng chồng ba tầng
        r.addChildNode(mBox(w, 0.12, 0.34, x, wt + 0.06 + 0.12 * Float(i), zf, i % 2 == 0 ? dark : red, 0.02))
      }
    }
    for sx in [Float(-1), Float(1)] {   // cột góc sau
      r.addChildNode(mCyl(0.26, 0.16, sx * 3.44, fl + 0.08, -2.2, stoneM))
      let c = SCNNode(geometry: colG); c.position = SCNVector3(sx * 3.44, fl + 0.16, -2.2); r.addChildNode(c)
    }
    r.addChildNode(mBox(W + 0.2, 0.28, 0.3, 0, wt - 0.14, zf, red, 0.02))
    r.addChildNode(mBox(W + 0.2, 0.07, 0.32, 0, wt - 0.36, zf, gold, 0.01))
    r.addChildNode(mBox(W + 0.6, 0.18, 0.5, 0, wt + 0.42, zf, dark, 0.02))
    r.addChildNode(mBox(1.4, 0.26, 0.05, 0, wt - 0.14, zf + 0.18, gold, 0.01)); r.addChildNode(mBox(1.2, 0.18, 0.06, 0, wt - 0.14, zf + 0.19, red, 0.01))
    // tường sau + hai bên: chân gạch, thân vôi
    r.addChildNode(tBox(W, 0.8, 0.36, 0, fl + 0.4, -2.2, "brickGray", 2.5, 2.5, 0.01)); r.addChildNode(tBox(W, 2.06, 0.32, 0, fl + 0.8 + 1.03, -2.2, "plaster", 2.5, 2.5, 0.01))
    for sx in [Float(-1), Float(1)] {
      let x = sx * 3.44
      r.addChildNode(tBox(0.36, 0.8, D, x, fl + 0.4, 0, "brickGray", 2.5, 2.5, 0.01)); r.addChildNode(tBox(0.32, 2.06, D, x, fl + 0.8 + 1.03, 0, "plaster", 2.5, 2.5, 0.01))
      let wx = sx * 3.62, wy = fl + 1.75   // cửa sổ chấn song
      r.addChildNode(tBox(0.06, 1.1, 1.8, wx, wy, 0, "lattice", 0.9, 0.9, 0.005))
      r.addChildNode(mBox(0.1, 0.12, 2.0, wx, wy + 0.6, 0, red)); r.addChildNode(mBox(0.1, 0.12, 2.0, wx, wy - 0.6, 0, red))
      r.addChildNode(mBox(0.1, 1.3, 0.12, wx, wy, 0.95, red)); r.addChildNode(mBox(0.1, 1.3, 0.12, wx, wy, -0.95, red))
    }
    // ba gian cửa chấn song phía trước
    for xc in [Float(-2.2), 0, 2.2] {
      r.addChildNode(mBox(1.9, 0.55, 0.08, xc, 0.675, 1.9, red, 0.01))
      r.addChildNode(tBox(1.9, 2.0, 0.07, xc, 1.95, 1.9, "lattice", 0.9, 0.9, 0.005))
      r.addChildNode(mBox(0.06, 2.55, 0.1, xc, 1.7, 1.94, red, 0.01)); r.addChildNode(mBox(2.0, 0.07, 0.1, xc, 0.96, 1.94, gold, 0.01))
    }
    // đèn lồng treo + trống đá
    let lg = lathe([(0, 0), (0.12, 0.03), (0.2, 0.2), (0.2, 0.3), (0.12, 0.47), (0, 0.5)], 12); lg.firstMaterial = tLac("lantern")
    for x in [Float(-2.2), 2.2] {
      let ln = SCNNode(geometry: lg); ln.position = SCNVector3(x, 2.2, zf + 0.4); r.addChildNode(ln)
      r.addChildNode(mCyl(0.012, 0.3, x, 2.85, zf + 0.4, dark)); r.addChildNode(mCyl(0.1, 0.04, x, 2.72, zf + 0.4, gold)); r.addChildNode(mCyl(0.08, 0.04, x, 2.18, zf + 0.4, gold))
    }
    let drum = lathe([(0, 0), (0.28, 0), (0.3, 0.1), (0.3, 0.5), (0.24, 0.55), (0, 0.55)], 14); drum.firstMaterial = stoneM
    for x in [Float(-2.3), 2.3] { let d = SCNNode(geometry: drum); d.position = SCNVector3(x, fl, 2.6); r.addChildNode(d) }
    townRoof(r, 0, 5.8, 0, W: W, D: D, drop: 2.3, out: 1.0, up: 0.45, tile: tmat("tileRed", 1, 1), gable: tmat("plaster", 1, 1), trim: dark, wallTop: wt)
    return r.flattenedClone()
  }

  // ---------- Nhà ngói xám ----------
  func townHouse() -> SCNNode {
    let r = SCNNode(); let dark = tLac("dark"), gold = tLac("gold"), wood = tLac("wood")
    let W: Float = 5.0, D: Float = 3.6, fl: Float = 0.25, wt: Float = 2.75
    r.addChildNode(tBox(W + 0.5, fl, D + 0.5, 0, fl / 2, 0, "stoneBlock", 2.5, 2.5, 0.02))
    r.addChildNode(tBox(W, 2.5, D, 0, fl + 1.25, 0, "plaster", 2.5, 2.5, 0.01))
    r.addChildNode(tBox(W + 0.06, 0.9, D + 0.06, 0, fl + 0.45, 0, "brickGray", 2.5, 2.5, 0.01))
    for sx in [Float(-1), Float(1)] { for sz in [Float(-1), Float(1)] { r.addChildNode(mBox(0.22, 2.5, 0.22, sx * W / 2, fl + 1.25, sz * D / 2, dark, 0.02)) } }
    r.addChildNode(mBox(W + 0.12, 0.2, D + 0.12, 0, wt - 0.1, 0, dark, 0.02))
    // cửa chính + đinh cửa + bậc đá
    r.addChildNode(mBox(1.3, 2.05, 0.1, 0, fl + 1.03, D / 2 + 0.02, dark, 0.02)); r.addChildNode(mBox(1.1, 1.9, 0.06, 0, fl + 0.95, D / 2 + 0.06, wood, 0.01))
    r.addChildNode(mBox(0.05, 1.9, 0.08, 0, fl + 0.95, D / 2 + 0.09, dark, 0.005))
    for row in 0..<4 { for sx in [Float(-0.36), -0.12, 0.12, 0.36] { r.addChildNode(psph(0.03, sx, fl + 0.5 + 0.35 * Float(row), D / 2 + 0.1, 1, gold)) } }
    r.addChildNode(tBox(1.8, 0.12, 0.5, 0, 0.06, D / 2 + 0.55, "stoneBlock", 2.5, 2.5, 0.01))
    // cửa sổ chấn song trước + hai bên
    for x in [Float(-1.7), 1.7] {
      r.addChildNode(tBox(1.0, 0.9, 0.06, x, fl + 1.5, D / 2 + 0.03, "lattice", 0.9, 0.9, 0.005))
      r.addChildNode(mBox(1.15, 0.1, 0.1, x, fl + 1.98, D / 2 + 0.05, dark)); r.addChildNode(mBox(1.15, 0.1, 0.1, x, fl + 1.02, D / 2 + 0.05, dark))
    }
    for sx in [Float(-1), Float(1)] { r.addChildNode(tBox(0.06, 0.9, 1.0, sx * (W / 2 + 0.03), fl + 1.5, 0, "lattice", 0.9, 0.9, 0.005)) }
    // ống khói gạch
    r.addChildNode(tBox(0.5, 1.4, 0.5, 1.6, 3.9, -0.6, "brickGray", 2.5, 2.5, 0.01)); r.addChildNode(mBox(0.64, 0.1, 0.64, 1.6, 4.65, -0.6, dark, 0.02))
    townRoof(r, 0, 4.45, 0, W: W, D: D, drop: 1.5, out: 0.65, up: 0.3, tile: tmat("tileGray", 1, 1), gable: tmat("plaster", 1, 1), trim: dark, wallTop: wt)
    return r.flattenedClone()
  }

  // ---------- Tường đỏ (dài 6 m theo trục x) ----------
  func townWall(_ L: Float) -> SCNNode {
    let r = SCNNode(); let dark = tLac("dark")
    r.addChildNode(tBox(L, 0.5, 0.56, 0, 0.25, 0, "stoneBlock", 2.5, 2.5, 0.02))
    r.addChildNode(tBox(L, 1.75, 0.42, 0, 1.375, 0, "redWall", 2.5, 2.5, 0.01))
    r.addChildNode(mBox(L + 0.04, 0.1, 0.5, 0, 2.3, 0, dark, 0.01))
    for s in [Float(1), Float(-1)] {   // mái ngói che đầu tường
      let p = tBox(L + 0.2, 0.07, 0.4, 0, 2.5, s * 0.17, "tileGray", 2.5, 1, 0.01); p.eulerAngles.x = s * 0.5; r.addChildNode(p)
    }
    r.addChildNode(mBox(L + 0.2, 0.1, 0.14, 0, 2.66, 0, dark, 0.02))
    for sx in [Float(-1), Float(1)] {   // trụ đầu tường
      r.addChildNode(tBox(0.5, 1.8, 0.6, sx * (L / 2 - 0.25), 1.4, 0, "redWall", 2.5, 2.5, 0.01)); r.addChildNode(mBox(0.6, 0.12, 0.7, sx * (L / 2 - 0.25), 2.36, 0, dark, 0.02))
    }
    if L >= 5 {   // cửa sổ chấn song trang trí
      r.addChildNode(tBox(1.2, 0.9, 0.06, 0, 1.65, 0.23, "lattice", 0.9, 0.9, 0.005))
      r.addChildNode(mBox(1.4, 0.1, 0.1, 0, 2.15, 0.24, dark)); r.addChildNode(mBox(1.4, 0.1, 0.1, 0, 1.15, 0.24, dark))
      r.addChildNode(mBox(0.1, 1.1, 0.1, 0.65, 1.65, 0.24, dark)); r.addChildNode(mBox(0.1, 1.1, 0.1, -0.65, 1.65, 0.24, dark))
    }
    return r.flattenedClone()
  }

  // ---------- Cổng bài phường (ba cửa) ----------
  func townPailou() -> SCNNode {
    let r = SCNNode(); let red = tLac("red"), dark = tLac("dark"), gold = tLac("gold"), tile = tmat("tileGray", 1, 1)
    r.addChildNode(tBox(8.6, 0.15, 1.8, 0, 0.075, 0, "stoneBlock", 2.5, 2.5, 0.02))
    let xs: [Float] = [-3.5, -1.5, 1.5, 3.5]
    for (i, x) in xs.enumerated() {
      let inner = i == 1 || i == 2, h: Float = inner ? 4.05 : 3.55
      r.addChildNode(tBox(0.8, 0.5, 0.8, x, 0.4, 0, "stoneBlock", 2.5, 2.5, 0.03))
      let cg = lathe([(0.2, 0), (0.2, 0.05), (0.18, 0.08), (0.18, h - 0.06), (0.2, h - 0.03), (0.2, h)], 12); cg.firstMaterial = red
      let c = SCNNode(geometry: cg); c.position = SCNVector3(x, 0.65, 0); r.addChildNode(c)
      let top = 0.65 + h
      for (k, w) in [Float(0.6), 1.0, 1.4].enumerated() { r.addChildNode(mBox(w, 0.14, 0.5, x, top + 0.07 + 0.14 * Float(k), 0, k % 2 == 0 ? dark : red, 0.02)) }
      r.addChildNode(mBox(0.5, 0.9, 0.5, x, 0.65 + 0.45, 0.62, dark, 0.03))   // đá kẹp chân cột
    }
    r.addChildNode(mBox(7.4, 0.3, 0.42, 0, 3.3, 0, red, 0.02)); r.addChildNode(mBox(3.4, 0.3, 0.42, 0, 4.45, 0, red, 0.02))
    r.addChildNode(mBox(7.4, 0.07, 0.44, 0, 3.12, 0, gold, 0.01))
    r.addChildNode(mBox(2.4, 0.9, 0.14, 0, 3.88, 0, gold, 0.02)); r.addChildNode(mBox(2.1, 0.7, 0.16, 0, 3.88, 0, red, 0.02))
    r.addChildNode(mBox(1.4, 0.3, 0.18, 0, 3.88, 0, gold, 0.02))
    townRoof(r, 0, 5.75, 0, W: 3.4, D: 1.2, drop: 0.9, out: 0.7, up: 0.3, tile: tile, gable: nil, trim: dark, wallTop: 4.9)
    for sx in [Float(-1), Float(1)] { townRoof(r, sx * 2.5, 5.05, 0, W: 2.2, D: 1.2, drop: 0.8, out: 0.6, up: 0.28, tile: tile, gable: nil, trim: dark, wallTop: 4.4) }
    return r.flattenedClone()
  }

  // ---------- Tháp canh gạch ----------
  func townFrustum(_ a: Float, _ b: Float, _ h: Float, _ y0: Float, _ m: SCNMaterial) -> SCNNode {
    var P = [SIMD3<Float>](), UV = [SIMD2<Float>](), I = [Int32]()
    let c: [(Float, Float)] = [(-1, -1), (1, -1), (1, 1), (-1, 1)]
    for k in 0..<4 {
      let p = c[k], q = c[(k + 1) % 4], base = Int32(P.count)
      P.append(SIMD3<Float>(p.0 * a, y0, p.1 * a)); UV.append(SIMD2<Float>(0, 0))
      P.append(SIMD3<Float>(q.0 * a, y0, q.1 * a)); UV.append(SIMD2<Float>(2 * a / 2.5, 0))
      P.append(SIMD3<Float>(p.0 * b, y0 + h, p.1 * b)); UV.append(SIMD2<Float>(0, h / 2.5))
      P.append(SIMD3<Float>(q.0 * b, y0 + h, q.1 * b)); UV.append(SIMD2<Float>(2 * a / 2.5, h / 2.5))
      I += [base, base + 2, base + 1, base + 1, base + 2, base + 3]
    }
    let g = meshGeo(P, UV, I); g.firstMaterial = m; return SCNNode(geometry: g)
  }
  func townTower() -> SCNNode {
    let r = SCNNode(); let dark = tLac("dark"), red = tLac("red"), wood = tLac("wood")
    func halfAt(_ y: Float) -> Float { 1.25 - 0.3 * (y - 0.4) / 5.2 }
    r.addChildNode(tBox(3.2, 0.4, 3.2, 0, 0.2, 0, "stoneBlock", 2.5, 2.5, 0.03))
    r.addChildNode(townFrustum(1.25, 0.95, 5.2, 0.4, tmat("brickBrown", 1, 1)))
    for y in [Float(2.2), 4.0] { let w = 2 * (halfAt(y) + 0.06); r.addChildNode(tBox(w, 0.14, w, 0, y, 0, "stoneBlock", 2.5, 2.5, 0.01)) }
    // cửa vòm + khe bắn tên
    r.addChildNode(mBox(1.1, 1.7, 0.06, 0, 1.25, halfAt(1.1) + 0.02, tmat("stoneBlock", 1, 1), 0.01))
    r.addChildNode(mBox(0.8, 1.45, 0.1, 0, 1.13, halfAt(1.1) + 0.04, dark, 0.01))
    let arch = mCyl(0.4, 0.1, 0, 1.86, halfAt(1.1) + 0.04, dark); arch.eulerAngles.x = .pi / 2; r.addChildNode(arch)
    for y in [Float(3.1), 4.6] {
      let hh = halfAt(y) + 0.02
      r.addChildNode(mBox(0.12, 0.5, 0.06, 0, y, hh, dark, 0.005)); r.addChildNode(mBox(0.12, 0.5, 0.06, 0, y, -hh, dark, 0.005))
      r.addChildNode(mBox(0.06, 0.5, 0.12, hh, y, 0, dark, 0.005)); r.addChildNode(mBox(0.06, 0.5, 0.12, -hh, y, 0, dark, 0.005))
    }
    // sàn gác, lan can, bốn cột đỡ mái
    r.addChildNode(mBox(3.2, 0.18, 3.2, 0, 5.69, 0, wood, 0.01))
    let ps: [Float] = [-1.5, -0.9, -0.3, 0.3, 0.9, 1.5]
    for p in ps {
      for e in [Float(-1.5), Float(1.5)] { r.addChildNode(mCyl(0.04, 0.8, p, 6.2, e, dark)); r.addChildNode(mCyl(0.04, 0.8, e, 6.2, p, dark)) }
    }
    for y in [Float(6.55), 6.25] {
      for e in [Float(-1.5), Float(1.5)] { r.addChildNode(mBox(3.08, 0.06, 0.06, 0, y, e, dark, 0.01)); r.addChildNode(mBox(0.06, 0.06, 3.08, e, y, 0, dark, 0.01)) }
    }
    for sx in [Float(-1), Float(1)] { for sz in [Float(-1), Float(1)] { r.addChildNode(mCyl(0.1, 2.4, sx * 1.35, 7.0, sz * 1.35, red)) } }
    r.addChildNode(mBox(3.2, 0.14, 3.2, 0, 8.22, 0, dark, 0.01))
    townRoof(r, 0, 9.5, 0, W: 3.4, D: 3.2, drop: 1.5, out: 0.8, up: 0.35, tile: tmat("tileGray", 1, 1), gable: nil, trim: dark, wallTop: 8.3)
    for (i, p) in [(Float(1.75), Float(1.0)), (Float(1.6), Float(1.75)), (Float(2.35), Float(1.2))].enumerated() {   // thùng gỗ dưới chân tháp
      let s: Float = i == 2 ? 0.55 : 0.7
      r.addChildNode(mBox(s, s * 0.85, s, p.0, 0.4 + s * 0.425, p.1 + 0.9, wood, 0.02))
      r.addChildNode(mBox(s + 0.02, 0.06, s + 0.02, p.0, 0.4 + s * 0.6, p.1 + 0.9, dark, 0.005))
    }
    return r.flattenedClone()
  }

  // ---------- Đường lát đá (khối dài theo x, hoặc sân bất kỳ) ----------
  func townPaveBox(_ w: Float, _ l: Float) -> SCNNode {
    let g = SCNBox(width: CGFloat(w), height: 0.1, length: CGFloat(l), chamferRadius: 0.01)
    let tp = tmat("pave", tQ(w / 2.4), tQ(l / 2.4)), sd = tmat("stoneBlock", tQ(l / 2.5), 0.25)
    g.materials = [sd, sd, sd, sd, tp, sd]
    let n = SCNNode(geometry: g); n.position = SCNVector3(0, 0.05, 0)
    let r = SCNNode(); r.addChildNode(n); return r
  }

  // ---------- Hồ xây gạch (mẫu) ----------
  func townPond() -> SCNNode {
    let r = SCNNode(); let W: Float = 12, L: Float = 8
    r.addChildNode(tBox(W + 0.5, 1.0, 0.5, 0, 0.5, L / 2 + 0.25, "brickGray", 2.5, 2.5, 0.01)); r.addChildNode(tBox(W + 0.5, 1.0, 0.5, 0, 0.5, -L / 2 - 0.25, "brickGray", 2.5, 2.5, 0.01))
    r.addChildNode(tBox(0.5, 1.0, L, W / 2 + 0.25, 0.5, 0, "brickGray", 2.5, 2.5, 0.01)); r.addChildNode(tBox(0.5, 1.0, L, -W / 2 - 0.25, 0.5, 0, "brickGray", 2.5, 2.5, 0.01))
    for s in [Float(-1), Float(1)] {
      r.addChildNode(tBox(W + 1.0, 0.1, 0.8, 0, 1.05, s * (L / 2 + 0.25), "stoneBlock", 2.5, 2.5, 0.01))
      r.addChildNode(tBox(0.8, 0.1, L + 0.3, s * (W / 2 + 0.25), 1.05, 0, "stoneBlock", 2.5, 2.5, 0.01))
      for t in [Float(-1), Float(1)] { r.addChildNode(tBox(0.7, 1.5, 0.7, s * (W / 2 + 0.25), 0.75, t * (L / 2 + 0.25), "stoneBlock", 2.5, 2.5, 0.03)) }
    }
    let wg = SCNBox(width: CGFloat(W), height: 0.02, length: CGFloat(L), chamferRadius: 0); wg.firstMaterial = canalWater
    let wn = SCNNode(geometry: wg); wn.position = SCNVector3(0, 0.82, 0); r.addChildNode(wn)
    for i in 0..<14 {   // lá sen nổi
      let x = Float(thash(i * 3 + 11)) * (W - 2) - (W - 2) / 2, z = Float(thash(i * 3 + 12)) * (L - 2) - (L - 2) / 2, rad = 0.16 + Float(thash(i * 3 + 13)) * 0.18
      r.addChildNode(mCyl(rad, 0.01, x, 0.835, z, tLac("pad")))
    }
    return r
  }

  // ---------- Thị trấn cổ (mẫu ghép sẵn) ----------
  func townDiorama() -> SCNNode {
    let root = SCNNode()
    func put(_ n: SCNNode, _ x: Float, _ z: Float, _ yaw: Float = 0) { n.position = SCNVector3(x, 0, z); n.eulerAngles.y = yaw; root.addChildNode(n) }
    let hall = townHall(), house = townHouse(), tower = townTower()
    put(townPaveBox(18, 13), 0, 3.5); put(townPaveBox(3.6, 9), 0, 15.5)
    put(hall, 0, -6.5)
    put(house, -9, -2.5, .pi / 2); put(house.clone(), 9, -2.5, -.pi / 2); put(house.clone(), -9, 4.5, .pi / 2); put(house.clone(), 9, 4.5, -.pi / 2)
    put(tower, -11.5, 8.5); put(tower.clone(), 11.5, 8.5)
    for x in [Float(-10.5), -3.5, 3.5, 10.5] { put(townWall(7), x, -11) }
    for z in [Float(-7.3333), 0, 7.3333] { put(townWall(7.3333), -14, z, .pi / 2); put(townWall(7.3333), 14, z, .pi / 2) }
    put(townWall(10.5), -8.75, 11); put(townWall(10.5), 8.75, 11)
    put(townPailou(), 0, 11)
    put(townPond(), 0, 24)
    let spots: [(Float, Float)] = [(-5, -1), (5, -1), (-4, 5), (4, 5), (-11, -8), (11, -8), (-8, 14), (8, 14), (-18, 2), (18, 2), (-17, -8), (17, -8), (-10, 20), (10, 20), (-17, 14), (17, 14)]
    for (i, p) in spots.enumerated() {
      if let pr = proto(i % 3 == 2 ? "pine 2" : "tree") {
        let n = pr.clone(); let sc = Float(0.8 + 0.4 * thash(i + 77))
        n.position = SCNVector3(p.0, 0, p.1); n.scale = SCNVector3(sc, sc, sc); n.eulerAngles.y = Float(thash(i + 5)) * 6.28; root.addChildNode(n)
      }
    }
    return root
  }

  /// mô hình thị trấn đặt riêng từng món (nhóm "Thị trấn")
  func townModel(_ id: String) -> SCNNode? {
    switch id {
    case "Nhà ngói đỏ": return townHall()
    case "Nhà ngói xám": return townHouse()
    case "Tường đỏ": return townWall(6)
    case "Cổng bài phường": return townPailou()
    case "Tháp canh gạch": return townTower()
    case "Đường lát đá": return townPaveBox(6, 2.4)
    default: return nil
    }
  }
}
