import SwiftUI
import UniformTypeIdentifiers

/// Nút hoạt ảnh ✨, xoay mặt ⟲, bay cao 🛩 và ➖ ➕ (camera lên cao / xuống thấp), hiện bên phải khi đang đi dạo.
struct WalkTools: View {
    @ObservedObject var g: Game
    private func circle(_ s: String, _ on: Bool = false) -> some View {
        Text(s).font(.title2).frame(width: 52, height: 52).background(on ? Color.green.opacity(0.6) : Color.white.opacity(0.4), in: Circle())
    }
    var body: some View {
        HStack(spacing: 8) {
            Menu {
                ForEach(WalkEmote.allCases) { e in
                    Button { g.walkPerform(e) } label: { Label(e.title, systemImage: e.symbol) }
                }
                if !g.walkActions.isEmpty {
                    Divider()
                    ForEach(Array(g.walkActions.enumerated()), id: \.offset) { i, n in
                        Button(n) { g.walkCustom(i) }
                    }
                }
                Divider()
                Button { g.walkDoAction() } label: { Label("Hành động tiếp theo", systemImage: "forward.fill") }
                Button { g.walkStop() } label: { Label("Đứng dậy", systemImage: "figure.stand") }
            } label: { circle("✨") }
            Button { g.walkTurnFace() } label: { circle("⟲") }.foregroundColor(.primary)
        }
        HStack(spacing: 8) {
            Button { g.walkZoom(1 / 1.3) } label: { circle("➖") }.foregroundColor(.primary)
            Button { g.walkZoom(1.3) } label: { circle("➕") }.foregroundColor(.primary)
            Button { g.toggleFly() } label: { circle("🛩", g.flyMode) }.foregroundColor(.primary)
        }
    }
}

/// Chọn nhân vật đi dạo, nhập mô hình / hoạt ảnh, gắn xương cho mô hình tĩnh.
struct CharacterSheet: View {
    @ObservedObject var g: Game
    @Environment(\.presentationMode) private var presentation
    @State private var chars: [String] = CharFiles.list()
    @State private var clips: [String] = ClipLibrary.entries().map { $0.name }
    @State private var report = ""
    @State private var rigTarget: RigTarget? = nil

    private func refresh() { chars = CharFiles.list(); clips = ClipLibrary.entries().map { $0.name } }

    private func row(_ name: String?, title: String, subtitle: String, canRig: Bool, canDelete: Bool) -> some View {
        let rigName = name
        return HStack {
            Button { g.useCharacter(name) } label: {
                HStack {
                    Image(systemName: g.walkCharacter == name ? "checkmark.circle.fill" : "circle").foregroundColor(.green)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title).font(.body)
                        Text(subtitle).font(.caption).foregroundColor(.secondary)
                    }
                    Spacer()
                }
            }.buttonStyle(.plain)
            if canRig || canDelete {
                Menu {
                    if canRig, let n = rigName {
                        Button { rigTarget = RigTarget(id: n) } label: {
                            Label(RigStore.has(n) ? "Chỉnh lại xương đã gắn" : "Gắn xương cho nhân vật…", systemImage: "figure.walk") }
                        if RigStore.has(n) {
                            Button(role: .destructive) { RigStore.remove(n); if g.walkCharacter == n { g.reloadWalker() }; refresh() } label: {
                                Label("Bỏ xương đã gắn", systemImage: "xmark") }
                        }
                    }
                    if let n = rigName {
                        Menu {
                            ForEach(1...5, id: \.self) { b in Button(Game.npcNames[b]) { g.addNPC(char: n, behavior: b) } }
                        } label: { Label("Thả NPC ra cảnh…", systemImage: "person.badge.plus") }
                    }
                    if canDelete, let n = rigName {
                        Button(role: .destructive) {
                            if g.walkCharacter == n { g.useCharacter(nil) }
                            CharFiles.remove(n); refresh() } label: { Label("Xóa nhân vật", systemImage: "trash") }
                    }
                } label: { Image(systemName: "ellipsis.circle").font(.title3) }
            }
        }
    }

    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Nhân vật đi dạo (🚶)")) {
                    row(nil, title: "Người đi dạo có sẵn", subtitle: "tay chân đung đưa, không cần xương", canRig: false, canDelete: false)
                    row(CharFiles.builtinName, title: CharFiles.builtinName, subtitle: RigStore.has(CharFiles.builtinName) ? "đã gắn xương tự dựng" : "mô hình tĩnh, có thể gắn xương", canRig: true, canDelete: false)
                    ForEach(chars, id: \.self) { n in
                        row(n, title: CharFiles.display(n), subtitle: RigStore.has(n) ? "đã gắn xương tự dựng" : "nhân vật nhập vào", canRig: true, canDelete: true)
                    }
                    Button { importCharacters() } label: { Label("Nhập nhân vật…", systemImage: "square.and.arrow.down") }
                }
                Section(header: Text("Hoạt ảnh nhập riêng"), footer: Text("Đặt tên file theo việc: Idle, Walk, Run, Jump. Tên khác (Wave, Dance…) thành hành động trong ✨. Dùng chung cho mọi nhân vật cùng bộ xương (ví dụ Mixamo, tải dạng zip / DAE / GLB).")) {
                    ForEach(clips, id: \.self) { c in
                        HStack { Text(c); Spacer()
                            Button(role: .destructive) { ClipLibrary.remove(c); g.reloadWalker(); refresh() } label: { Image(systemName: "trash") } }
                    }
                    Button { importClips() } label: { Label("Nhập hoạt ảnh…", systemImage: "figure.run") }
                }
                if !g.npcs.isEmpty {
                    Section(header: Text("NPC trong cảnh")) {
                        ForEach(g.npcs, id: \.id) { n in
                            HStack { Text("\(CharFiles.display(n.char)) · \(Game.npcNames[n.behavior])"); Spacer()
                                Button(role: .destructive) { g.removeNPC(n.id) } label: { Image(systemName: "trash") } }
                        }
                    }
                }
                if !report.isEmpty { Section { Text(report).font(.footnote) } }
                Section(footer: Text("Nhân vật tĩnh (OBJ, USDZ…) chưa có xương: chọn ⋯ → Gắn xương, chạm đặt các khớp rồi bấm Lưu. Mô hình có xương sẵn (GLB, VRM, DAE, USDZ) tự đi, chạy, đứng theo cần điều khiển.")) { EmptyView() }
            }
            .navigationTitle("Nhân vật")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("Xong") { presentation.wrappedValue.dismiss() } } }
        }
        .onAppear { g.ensureCharHooks(); refresh() }
        .fullScreenCover(item: $rigTarget) { t in
            RigEditorView(modelName: t.id, onSaved: { name in g.useCharacter(name); refresh() }) { rigTarget = nil }
        }
    }

    private func importCharacters() {
        DocPicker.shared.present(types: [.item]) { urls in
            let r = CharFiles.add(urls)
            report = (r.added.isEmpty ? "" : "Đã nhập: " + r.added.map { CharFiles.display($0) }.joined(separator: ", ") + "\n") + r.problems.joined(separator: "\n")
            refresh()
            if let first = r.added.first { g.useCharacter(first) }
        }
    }

    private func importClips() {
        DocPicker.shared.present(types: [.item]) { urls in
            let r = ClipLibrary.add(urls)
            report = (r.added.isEmpty ? "" : "Đã nhập hoạt ảnh: " + r.added.joined(separator: ", ") + "\n") + r.problems.joined(separator: "\n")
            g.reloadWalker(); refresh()
        }
    }
}
