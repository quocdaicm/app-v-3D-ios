import SwiftUI

/// Bảng âm thanh: bật / tắt và kéo âm lượng từng nhóm (mở từ menu ⚙ hoặc ⋯ → Âm thanh → Âm lượng…).
struct SoundSheet: View {
    @ObservedObject var g: Game
    @Environment(\.dismiss) private var dismiss

    private func row(_ title: String, _ icon: String, _ value: Binding<Float>) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Label(title, systemImage: icon)
            Slider(value: value, in: 0...1)
        }
        .padding(.vertical, 2)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Toggle(isOn: Binding(get: { g.sfxOn }, set: { g.setSfx($0) })) { Label("Hiệu ứng âm thanh", systemImage: "speaker.wave.2.fill") }
                    Toggle(isOn: Binding(get: { g.musicOn }, set: { g.setMusic($0) })) { Label("Nhạc nền", systemImage: "music.note") }
                }
                Section("Âm lượng") {
                    row("Nhạc nền", "music.note", Binding(get: { g.musicVol }, set: { g.setMusicVol($0) }))
                    row("Bước chân và thao tác", "figure.walk", Binding(get: { g.sfxVol }, set: { g.setSfxVol($0) }))
                    row("Mưa, gió, suối, chim", "cloud.rain.fill", Binding(get: { g.ambVol }, set: { g.setAmbVol($0) }))
                }
            }
            .navigationTitle("Âm thanh")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Xong") { dismiss() } } }
        }
        .presentationDetents([.medium])
    }
}
