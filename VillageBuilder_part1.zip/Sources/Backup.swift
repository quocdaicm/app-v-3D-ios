import SwiftUI
import SceneKit
import UniformTypeIdentifiers

// ===== Chụp ảnh làng, sao lưu / nhập làng (Backup.swift) =====
// Dữ liệu làng nằm trong UserDefaults (recs, roads, seedEdits, seedGone, vb.npcs) cùng vài cài đặt (thời tiết, cây lay, giờ).
// Sao lưu = gói các khóa đó vào một file .json rồi mở bảng chia sẻ (Lưu vào Tệp, AirDrop, iCloud...).
// Mô hình 3D bạn tự nhập thêm (thư mục Documents) KHÔNG nằm trong file sao lưu.

struct ShareItem: Identifiable {
    let id = UUID()
    let items: [Any]
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

struct VillageBackup: Codable {
    var app = "langque"
    var version = 1
    var created = ""
    var recs: Data?
    var roads: Data?
    var seedEdits: Data?
    var seedGone: [String]?
    var npcs: Data?
    var weather: String?
    var sway: Int?
    var timeMode: Int?
    var timeHour: Float?
}

extension Game {
    private func stamp() -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyyMMdd-HHmm"
        return f.string(from: Date())
    }

    private func makeBackup() -> VillageBackup {
        let ud = UserDefaults.standard
        var b = VillageBackup()
        b.created = stamp()
        b.recs = ud.data(forKey: "recs")
        b.roads = ud.data(forKey: "roads")
        b.seedEdits = ud.data(forKey: "seedEdits")
        b.seedGone = ud.stringArray(forKey: "seedGone")
        b.npcs = ud.data(forKey: "vb.npcs")
        b.weather = weather.rawValue
        b.sway = swayLevel
        b.timeMode = timeMode
        b.timeHour = weatherSys?.hour
        return b
    }

    private func writeBackup(to dir: URL, name: String) -> URL? {
        guard let data = try? JSONEncoder().encode(makeBackup()) else { return nil }
        let url = dir.appendingPathComponent(name)
        do { try data.write(to: url, options: .atomic); return url } catch { return nil }
    }

    /// Chụp khung cảnh 3D đang xem (không có nút bấm) rồi mở bảng chia sẻ để lưu vào Ảnh / gửi đi.
    func takePhoto() {
        guard let v = scnView else { return }
        let img = v.snapshot()
        SoundFX.shared.cue(.shutter)
        showToast("Đã chụp ảnh")
        shareItem = ShareItem(items: [img])
    }

    /// Xuất toàn bộ làng ra một file .json và mở bảng chia sẻ (Lưu vào Tệp, AirDrop, iCloud Drive...).
    func exportVillage() {
        save(); saveNPCs()
        guard let url = writeBackup(to: FileManager.default.temporaryDirectory, name: "LangQue_\(stamp()).json") else {
            villageAlert = "Không tạo được file sao lưu."
            return
        }
        shareItem = ShareItem(items: [url])
    }

    /// Chọn file .json đã sao lưu. Sau khi nhập cần mở lại app để làng mới hiện ra.
    func importVillage() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
            DocPicker.shared.present(types: [.json, .plainText], multiple: false) { [weak self] urls in
                guard let self = self, let url = urls.first else { return }
                self.applyBackup(from: url)
            }
        }
    }

    private func applyBackup(from url: URL) {
        guard let d = try? Data(contentsOf: url), let b = try? JSONDecoder().decode(VillageBackup.self, from: d), b.app == "langque" else {
            villageAlert = "File này không phải bản sao lưu Làng Quê hoặc đã bị hỏng."
            return
        }
        // giữ lại làng hiện tại phòng khi nhập nhầm: file nằm trong Documents (xem được trong app Tệp)
        save(); saveNPCs()
        if let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            _ = writeBackup(to: docs, name: "LangQue_TruocKhiNhap.json")
        }
        let ud = UserDefaults.standard
        func put(_ v: Data?, _ k: String) { if let v = v { ud.set(v, forKey: k) } else { ud.removeObject(forKey: k) } }
        put(b.recs, "recs"); put(b.roads, "roads"); put(b.seedEdits, "seedEdits"); put(b.npcs, "vb.npcs")
        if let g = b.seedGone { ud.set(g, forKey: "seedGone") } else { ud.removeObject(forKey: "seedGone") }
        if let w = b.weather { ud.set(w, forKey: "weather") }
        if let s = b.sway { ud.set(s, forKey: "sway") }
        if let m = b.timeMode { ud.set(m, forKey: "timeMode") }
        if let h = b.timeHour { ud.set(h, forKey: "timeHour") }
        ud.set(true, forKey: "mainInit")
        importLock = true
        ud.synchronize()
        villageAlert = "Đã nhập làng (sao lưu lúc \(b.created)). Làng cũ được giữ trong file LangQue_TruocKhiNhap.json. Bấm Thoát app rồi mở lại để thấy làng mới."
    }

    /// Tự lưu một bản vào Documents mỗi khi app ra nền (file LangQue_TuDongLuu.json, xem được trong app Tệp).
    func autoBackup() {
        if importLock { return }
        save(); saveNPCs()
        if let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            _ = writeBackup(to: docs, name: "LangQue_TuDongLuu.json")
        }
    }
}
