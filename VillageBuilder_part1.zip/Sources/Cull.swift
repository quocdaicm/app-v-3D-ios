import SceneKit

// ===== Ẩn vật ở xa camera (Cull.swift) =====
// Làng càng nhiều vật thì GPU càng tốn lượt vẽ. Vật nằm quá xa camera (ngang mặt đất) bị ẩn, vào gần thì hiện lại.
// Chỉ áp dụng cho vật đặt / dựng sẵn ("placed:..."); đường, địa hình, chân trời, mẫu lớn (ao, mương) không bị ẩn.
// Tắt khi nhìn từ trên xuống (bảng vẽ nét) để thấy trọn cảnh.
extension Game {
  func cullStep(_ dt: Float) {
    cullT += dt
    guard cullT >= 0.5 else { return }
    cullT = 0
    let off = sketchCam || cam.position.y > 30
    if off && !cullAny { return }
    let p = cam.position
    let show2 = Game.cullShow * Game.cullShow, hide2 = Game.cullHide * Game.cullHide
    var any = false
    for n in scene.rootNode.childNodes {
      guard let nm = n.name, nm.hasPrefix("placed:"), !cullExempt.contains(nm) else { continue }
      if off { if n.isHidden { n.isHidden = false }; continue }
      let dx = n.position.x - p.x, dz = n.position.z - p.z, d2 = dx * dx + dz * dz
      if n.isHidden { if d2 < show2 { n.isHidden = false } else { any = true } }
      else if d2 > hide2 { n.isHidden = true; any = true }
    }
    cullAny = any
  }
}
