#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
/// Chạy block và bắt NSException (AVAudioEngine hay ném ngoại lệ ObjC mà Swift không bắt được → app thoát). Trả về true nếu chạy êm.
BOOL VBTry(void (NS_NOESCAPE ^block)(void));
NS_ASSUME_NONNULL_END
