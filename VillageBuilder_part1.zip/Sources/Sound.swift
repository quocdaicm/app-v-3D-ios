import AVFoundation
import UIKit

// ===== Âm thanh cho Làng Quê (Sound.swift) =====
// Toàn bộ tiếng được TẠO BẰNG CODE lúc chạy (không cần file mp3 / wav nên app không nặng thêm):
//   • tiếng nền liên tục: mưa, gió, suối (bên sông), nhạc nền dịu (đàn gảy kiểu Karplus-Strong + nốt trầm kéo dài + vang)
//   • tiếng một lần: bước chân (cỏ / nền cứng / ướt), đặt vật, xóa vật, chọn, hoàn tác / làm lại, sấm, chim hót
// Bật / tắt "Hiệu ứng âm thanh" và "Nhạc nền" trong menu ⚙ (lưu ở UserDefaults: snd.sfx, snd.music).
// Dùng category .ambient: gạt công tắc im lặng của iPhone thì game cũng im.

/// Bộ số ngẫu nhiên nhỏ (xorshift) an toàn dùng trong luồng âm thanh.
struct SoundRNG {
    var s: UInt32
    init(_ seed: UInt32) { s = seed == 0 ? 2463534242 : seed }
    mutating func n() -> Float {            // -1 ... 1
        s ^= s << 13; s ^= s >> 17; s ^= s << 5
        return Float(Int32(bitPattern: s)) / 2147483648
    }
    mutating func f() -> Float { (n() + 1) * 0.5 }   // 0 ... 1
}

/// Một lớp tiếng nền chạy liên tục trên luồng âm thanh. Chỉ đọc / ghi số Float đơn giản nên không cần khóa.
final class AmbientLoop {
    enum Kind { case rain, wind, stream, pad, leaves, night }
    let kind: Kind
    var gain: Float = 0                      // mục tiêu 0...1, đặt từ luồng khác; tiếng tự lên / xuống mượt
    private var cur: Float = 0
    private var rng: SoundRNG
    private var a: Float = 0, b: Float = 0, c: Float = 0
    private var drop: Float = 0
    private var t: Float = 0
    private var hold: Float = 0, tgt: Float = 0.7
    private var p1: Float = 0, p2: Float = 0, p3: Float = 0

    init(_ kind: Kind, seed: UInt32) { self.kind = kind; rng = SoundRNG(seed) }

    func render(_ n: Int, _ out: UnsafeMutablePointer<Float>) {
        let target = gain
        if target < 0.0005 && cur < 0.0005 { for i in 0..<n { out[i] = 0 }; cur = 0; return }
        let dt: Float = 1.0 / 44100.0
        let tau: Float = 6.2831853
        for i in 0..<n {
            cur += (target - cur) * 0.00006
            t += dt; if t > 1000 { t -= 1000 }     // 1000 là bội của chu kỳ mọi LFO bên dưới nên không bị giật
            var s: Float = 0
            switch kind {
            case .rain:
                let w = rng.n()
                a += 0.38 * (w - a)                 // cắt trên ~3 kHz
                b += 0.025 * (a - b)                // cắt dưới ~170 Hz
                var x = (a - b) * 0.8
                if rng.f() < 0.0007 { drop = rng.n() * 0.9 }    // giọt lách tách ~30 lần / giây
                drop *= 0.92
                x += drop * 0.5
                s = x
            case .wind:
                let w = rng.n()
                let g1 = 0.5 + 0.5 * sin(t * 0.37 * tau)
                let g2 = 0.5 + 0.5 * sin(t * 0.11 * tau + 1.3)
                let gust = 0.2 + 0.8 * g1 * g2                  // cơn gió mạnh yếu
                let k = 0.004 + 0.035 * gust                    // cơn mạnh thì tiếng sáng hơn
                a += k * (w - a); b += k * (a - b)
                s = b * (5 + 9 * gust) * (0.35 + 0.65 * gust) * 0.4
            case .stream:
                let w = rng.n()
                a += 0.16 * (w - a)
                b += 0.012 * (a - b)
                hold -= dt
                if hold <= 0 { hold = 0.03 + 0.05 * rng.f(); tgt = 0.35 + 0.65 * rng.f() }   // nước ùng ục
                c += 0.002 * (tgt - c)
                s = (a - b) * 0.9 * c
            case .leaves:
                let w = rng.n()
                a += 0.45 * (w - a)                 // cắt trên ~4,4 kHz
                b += 0.08 * (a - b)                 // cắt dưới ~600 Hz
                let g1 = 0.5 + 0.5 * sin(t * 0.29 * tau)
                let g2 = 0.5 + 0.5 * sin(t * 0.13 * tau + 0.7)
                let gust = 0.15 + 0.85 * g1 * g2    // lá xào xạc theo từng đợt gió
                hold -= dt
                if hold <= 0 { hold = 0.02 + 0.06 * rng.f(); tgt = 0.3 + 0.7 * rng.f() }    // lách tách từng lá
                c += 0.004 * (tgt - c)
                s = (a - b) * gust * c * 1.1
            case .night:
                p1 += 4300 * dt; if p1 >= 1 { p1 -= 1 }       // dế 1
                p2 += 4750 * dt; if p2 >= 1 { p2 -= 1 }       // dế 2 (lệch nhịp)
                p3 += 190 * dt; if p3 >= 1 { p3 -= 1 }        // ếch ộp trầm
                let u1 = t.truncatingRemainder(dividingBy: 0.62)
                let u2 = (t + 0.21).truncatingRemainder(dividingBy: 0.83)
                let u3 = (t + 1.1).truncatingRemainder(dividingBy: 2.9)
                let e1: Float = u1 < 0.16 ? sin(Float.pi * (u1 * 25).truncatingRemainder(dividingBy: 1)) : 0      // 4 xung / cụm
                let e2: Float = u2 < 0.2 ? sin(Float.pi * (u2 * 22).truncatingRemainder(dividingBy: 1)) : 0
                let e3: Float = u3 < 0.3 ? (1 - u3 / 0.3) * (0.55 + 0.45 * sin(u3 * 18 * tau)) : 0
                s = sin(p1 * tau) * e1 * 0.5 + sin(p2 * tau) * e2 * 0.4 + (sin(p3 * tau) + 0.4 * sin(p3 * 2 * tau)) * e3 * 0.35
            case .pad:
                p1 += 73.42 * dt; if p1 >= 1 { p1 -= 1 }       // Rê2
                p2 += 110.0 * dt; if p2 >= 1 { p2 -= 1 }       // La2
                p3 += 146.83 * dt; if p3 >= 1 { p3 -= 1 }      // Rê3
                let trem = 0.75 + 0.25 * sin(t * 0.09 * tau)
                s = (sin(p1 * tau) * 0.5 + sin(p2 * tau) * 0.32 + sin(p3 * tau) * 0.18) * trem * 0.3
            }
            out[i] = s * cur
        }
    }
}

final class SoundFX {
    static let shared = SoundFX()

    enum Cue: Hashable { case place, remove, select, undo, redo, tick, jump, land, climb, sit, shutter }

    // ----- cài đặt -----
    private(set) var sfxOn: Bool = UserDefaults.standard.object(forKey: "snd.sfx") as? Bool ?? true
    private(set) var musicOn: Bool = UserDefaults.standard.object(forKey: "snd.music") as? Bool ?? true
    // âm lượng 0...1 (mặc định 0,7 = mức đã cân sẵn; kéo lên tới 1 là to hơn ~40%)
    private(set) var musicVol: Float = UserDefaults.standard.object(forKey: "snd.vmusic") as? Float ?? 0.7
    private(set) var sfxVol: Float = UserDefaults.standard.object(forKey: "snd.vsfx") as? Float ?? 0.7
    private(set) var ambVol: Float = UserDefaults.standard.object(forKey: "snd.vamb") as? Float ?? 0.7
    private var mMul: Float { musicVol * 1.4 }
    private var sMul: Float { sfxVol * 1.4 }
    private var aMul: Float { ambVol * 1.4 }

    // ----- động cơ âm thanh -----
    private let engine = AVAudioEngine()
    private let mono = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 1)!
    private let stereo = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 2)!
    private let q = DispatchQueue(label: "langque.sfx")
    private var started = false

    private let rain = AmbientLoop(.rain, seed: 0x1F2E3D4C)
    private let wind = AmbientLoop(.wind, seed: 0x2468ACE1)
    private let stream = AmbientLoop(.stream, seed: 0x13579BDF)
    private let pad = AmbientLoop(.pad, seed: 1)
    private let leaves = AmbientLoop(.leaves, seed: 0x5A5A1234)
    private let nightLoop = AmbientLoop(.night, seed: 0x0BADBEEF)
    private var nightAmt: Float = 0

    private var sfxPlayers: [AVAudioPlayerNode] = []
    private var sfxNext = 0
    private var musicPlayers: [AVAudioPlayerNode] = []
    private var musicNext = 0
    private let reverb = AVAudioUnitReverb()

    // ----- kho tiếng đã dựng sẵn -----
    private var steps: [[AVAudioPCMBuffer]] = []        // [0 cỏ, 1 nền cứng, 2 ướt][biến thể]
    private var cues: [Cue: AVAudioPCMBuffer] = [:]
    private var thunders: [AVAudioPCMBuffer] = []
    private var birds: [AVAudioPCMBuffer] = []
    private var notes: [AVAudioPCMBuffer] = []
    private var lastCue: [Cue: CFTimeInterval] = [:]

    // ----- trạng thái -----
    private var weather: Weather = .clear
    private var level: Float = 1
    private var rainTarget: Float = 0, windTarget: Float = 0.08
    private var streamTarget: Float = 0, leavesTarget: Float = 0.1
    private var swayLevel = 1
    private var melodyIdx = 4, noteCount = 0
    private var musicRunning = false, musicToken = 0
    private var birdsRunning = false, birdToken = 0

    // MARK: Khởi động

    /// Dấu vết để khoanh vùng lỗi: ghi bước âm thanh đang chạy; nếu app thoát thì lần sau Game báo bước này.
    private var lastCrumb = ""
    private func crumb(_ s: String, sync: Bool = false) {
        guard s != lastCrumb else { return }
        lastCrumb = s
        UserDefaults.standard.set(s, forKey: "vb.detail")
        if sync { UserDefaults.standard.synchronize() }
    }

    func start() {
        guard !started else { return }
        started = true
        crumb("phiên âm thanh", sync: true)
        let session = AVAudioSession.sharedInstance()
        VBTry {
            try? session.setCategory(.ambient, mode: .default, options: [.mixWithOthers])
            try? session.setActive(true)
        }

        crumb("nối tiếng nền", sync: true)
        for loop in [rain, wind, stream, pad, leaves, nightLoop] { attach(loop) }
        crumb("nối loa hiệu ứng", sync: true)
        for _ in 0..<6 {
            let p = AVAudioPlayerNode(); engine.attach(p)
            engine.connect(p, to: engine.mainMixerNode, format: mono); sfxPlayers.append(p)
        }
        crumb("nối bộ vang", sync: true)
        reverb.loadFactoryPreset(.largeHall); reverb.wetDryMix = 50
        engine.attach(reverb); engine.connect(reverb, to: engine.mainMixerNode, format: stereo)
        for _ in 0..<4 {
            let p = AVAudioPlayerNode(); engine.attach(p)
            engine.connect(p, to: reverb, format: stereo); musicPlayers.append(p)
        }
        engine.mainMixerNode.outputVolume = 0.8

        crumb("đăng ký thông báo", sync: true)
        let nc = NotificationCenter.default
        nc.addObserver(forName: .AVAudioEngineConfigurationChange, object: engine, queue: .main) { [weak self] _ in self?.applyState() }
        nc.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] n in
            guard let self = self, let v = n.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                  AVAudioSession.InterruptionType(rawValue: v) == .ended else { return }
            try? AVAudioSession.sharedInstance().setActive(true); self.applyState()
        }
        nc.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main) { [weak self] _ in
            self?.musicRunning = false; self?.birdsRunning = false
            if let e = self?.engine { VBTry { e.pause() } }
        }
        nc.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: .main) { [weak self] _ in self?.applyState() }

        // dựng kho tiếng ở luồng nền để không giật lúc mở game
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self = self else { return }
            self.crumb("dựng tiếng bước chân", sync: true)
            var st: [[AVAudioPCMBuffer]] = []
            for kind in 0..<3 {
                var row: [AVAudioPCMBuffer] = []
                for v in 0..<4 { if let b = SoundFX.buffer(SoundFX.stepSamples(kind: kind, seed: UInt32(900 + kind * 17 + v * 31)), self.mono) { row.append(b) } }
                st.append(row)
            }
            self.crumb("dựng âm báo", sync: true)
            var cu: [Cue: AVAudioPCMBuffer] = [:]
            let defs: [(Cue, [Float])] = [(.place, SoundFX.placeSamples()), (.remove, SoundFX.removeSamples()), (.select, SoundFX.selectSamples()),
                                          (.undo, SoundFX.undoSamples(rising: false)), (.redo, SoundFX.undoSamples(rising: true)), (.tick, SoundFX.tickSamples()),
                                          (.jump, SoundFX.jumpSamples()), (.land, SoundFX.landSamples()), (.climb, SoundFX.climbSamples()), (.sit, SoundFX.sitSamples()), (.shutter, SoundFX.shutterSamples())]
            for (c, x) in defs { if let b = SoundFX.buffer(x, self.mono) { cu[c] = b } }
            self.crumb("dựng sấm", sync: true)
            var th: [AVAudioPCMBuffer] = []
            for v in 0..<2 { if let b = SoundFX.buffer(SoundFX.thunderSamples(seed: UInt32(77 + v * 13)), self.mono) { th.append(b) } }
            self.crumb("dựng tiếng chim", sync: true)
            var bi: [AVAudioPCMBuffer] = []
            for v in 0..<5 { if let b = SoundFX.buffer(SoundFX.birdSamples(seed: UInt32(500 + v * 29)), self.mono) { bi.append(b) } }
            // đàn gảy: ngũ cung Rê (A3 B3 D4 E4 F#4 A4 B4 D5 E5)
            let freqs: [Float] = [220.0, 246.94, 293.66, 329.63, 369.99, 440.0, 493.88, 587.33, 659.25]
            self.crumb("dựng đàn gảy", sync: true)
            var nt: [AVAudioPCMBuffer] = []
            for (i, f) in freqs.enumerated() { if let b = SoundFX.buffer(SoundFX.pluckSamples(f, 3.4, UInt32(31 + i * 7)), self.stereo) { nt.append(b) } }
            let stF = st, cuF = cu, thF = th, biF = bi, ntF = nt
            self.q.async { self.steps = stF; self.cues = cuF; self.thunders = thF; self.birds = biF }
            self.crumb("dựng kho tiếng xong", sync: true)
            DispatchQueue.main.async { self.notes = ntF; self.applyState() }
        }
        applyState()
    }

    private func attach(_ loop: AmbientLoop) {
        let node = AVAudioSourceNode(format: mono) { _, _, frames, abl -> OSStatus in
            let list = UnsafeMutableAudioBufferListPointer(abl)
            for buf in list {
                if let p = buf.mData?.assumingMemoryBound(to: Float.self) { loop.render(Int(frames), p) }
            }
            return noErr
        }
        engine.attach(node)
        engine.connect(node, to: engine.mainMixerNode, format: mono)
    }

    // MARK: Điều khiển từ game

    func setSfx(_ on: Bool) {
        sfxOn = on; UserDefaults.standard.set(on, forKey: "snd.sfx")
        DispatchQueue.main.async { self.applyState() }
    }
    func setMusicVol(_ v: Float) { musicVol = v; UserDefaults.standard.set(v, forKey: "snd.vmusic"); DispatchQueue.main.async { self.applyState() } }
    func setSfxVol(_ v: Float) { sfxVol = v; UserDefaults.standard.set(v, forKey: "snd.vsfx") }
    func setAmbVol(_ v: Float) { ambVol = v; UserDefaults.standard.set(v, forKey: "snd.vamb"); DispatchQueue.main.async { self.applyState() } }
    func setMusic(_ on: Bool) {
        musicOn = on; UserDefaults.standard.set(on, forKey: "snd.music")
        DispatchQueue.main.async { self.applyState() }
    }

    /// Thời tiết đổi (gọi từ Weather.swift): chỉnh mưa, gió, chim hót, nhạc nhỏ bớt khi mưa.
    func setWeather(_ w: Weather, level lv: Float) {
        weather = w; level = lv
        let L = min(max(lv, 0.5), 1.4)
        switch w {
        case .rain:  rainTarget = 0.55 * L; windTarget = 0.18
        case .storm: rainTarget = 0.9 * min(L, 1.2); windTarget = 0.55
        case .wind:  rainTarget = 0; windTarget = 0.8
        case .snow:  rainTarget = 0; windTarget = 0.3
        case .fog:   rainTarget = 0; windTarget = 0.1
        case .cloudy: rainTarget = 0; windTarget = 0.22
        case .clear: rainTarget = 0; windTarget = 0.08
        }
        updateLeaves()
        DispatchQueue.main.async { self.applyState() }
    }

    /// Mức "Cây lay" của game (0 tắt, 1 nhẹ, 2 mạnh): lá xào xạc theo mức này và theo thời tiết.
    func setSway(_ n: Int) { swayLevel = n; updateLeaves(); DispatchQueue.main.async { self.applyState() } }

    private func updateLeaves() {
        let base: Float
        switch weather {
        case .wind: base = 0.6
        case .storm: base = 0.5
        case .cloudy, .rain: base = 0.2
        case .clear: base = 0.12
        case .snow: base = 0.1
        case .fog: base = 0.05
        }
        let k: [Float] = [0, 0.6, 1]
        leavesTarget = base * k[min(max(swayLevel, 0), 2)]
    }

    /// Gần sông (x < -8) thì nghe tiếng nước chảy; gọi mỗi khung hình nên chỉ ghi một số.
    func setStream(_ g: Float) {
        streamTarget = g * 0.55
        stream.gain = sfxOn ? streamTarget * aMul : 0
    }

    /// 0 ban ngày ... 1 giữa đêm (gọi từ Weather.swift); đêm có dế / ếch, hết chim hót.
    func setNight(_ n: Float) {
        if abs(n - nightAmt) < 0.02 { return }
        nightAmt = n
        DispatchQueue.main.async { self.applyState() }
    }

    private var duck: Float { weather == .storm ? 0.6 : (weather == .rain ? 0.8 : 1) }

    private func applyState() {
        guard started else { return }
        rain.gain = sfxOn ? rainTarget * aMul : 0
        wind.gain = sfxOn ? windTarget * aMul : 0
        stream.gain = sfxOn ? streamTarget * aMul : 0
        leaves.gain = sfxOn ? leavesTarget * aMul : 0
        let rainy = weather == .rain || weather == .storm
        nightLoop.gain = sfxOn ? nightAmt * (rainy ? 0.15 : 0.5) * aMul : 0     // đêm: dế và ếch kêu, mưa thì át bớt
        pad.gain = musicOn ? 0.5 * duck * mMul : 0
        if sfxOn || musicOn {
            if !engine.isRunning {
                crumb("bật engine", sync: true)
                var err: Error?
                let ok = VBTry { do { try self.engine.start() } catch { err = error } }
                if !ok || err != nil { crumb("engine lỗi, bỏ qua", sync: true) }
            }
            // KHÔNG gọi play() cho cả 10 loa ở đây nữa: mỗi loa chỉ play() ngay trước khi có tiếng (playSfx / playMusic)
        } else if engine.isRunning { VBTry { self.engine.pause() } }
        // nhạc
        let wantMusic = musicOn && !notes.isEmpty && engine.isRunning
        if wantMusic && !musicRunning { musicRunning = true; musicToken += 1; scheduleMusic(token: musicToken) }
        else if !wantMusic && musicRunning { musicRunning = false; musicToken += 1 }
        // chim hót: ban ngày, trời quang hoặc nhiều mây
        let wantBirds = sfxOn && engine.isRunning && nightAmt < 0.3 && (weather == .clear || weather == .cloudy)
        if wantBirds && !birdsRunning { birdsRunning = true; birdToken += 1; scheduleBirds(token: birdToken) }
        else if !wantBirds && birdsRunning { birdsRunning = false; birdToken += 1 }
    }

    // MARK: Phát tiếng một lần

    /// Bật loa + xếp tiếng, bọc VBTry: lỗi AVFoundation chỉ làm mất tiếng đó chứ không thoát app.
    private func safePlay(_ p: AVAudioPlayerNode, _ buf: AVAudioPCMBuffer, interrupts: Bool) {
        guard engine.isRunning, p.engine === engine else { return }
        crumb("xếp tiếng vào loa")
        VBTry {
            p.scheduleBuffer(buf, at: nil, options: interrupts ? .interrupts : [], completionHandler: nil)
            if !p.isPlaying { p.play() }
        }
    }

    private func playSfx(_ buf: AVAudioPCMBuffer, _ volume: Float, amb: Bool = false) {     // chạy trên hàng đợi q
        guard engine.isRunning, !sfxPlayers.isEmpty else { return }
        crumb("phát hiệu ứng")
        let p = sfxPlayers[sfxNext % sfxPlayers.count]; sfxNext += 1
        p.volume = min(1, volume * (amb ? aMul : sMul))
        safePlay(p, buf, interrupts: true)
    }

    /// Bước chân: kind 0 cỏ, 1 nền cứng (đường bê tông, sàn gỗ), 2 đất ướt.
    func step(kind: Int, run: Bool) {
        guard sfxOn, started else { return }
        q.async { [weak self] in
            guard let self = self, kind >= 0, kind < self.steps.count, let b = self.steps[kind].randomElement() else { return }
            self.playSfx(b, (run ? 0.85 : 0.6) * Float.random(in: 0.8...1.0))
        }
    }

    func cue(_ c: Cue) {
        guard sfxOn, started else { return }
        q.async { [weak self] in
            guard let self = self, let b = self.cues[c] else { return }
            let now = CACurrentMediaTime()
            if now - (self.lastCue[c] ?? 0) < 0.06 { return }
            self.lastCue[c] = now
            let v: Float
            switch c {
            case .tick: v = 0.35
            case .jump, .sit: v = 0.45
            case .climb: v = 0.5
            case .shutter: v = 0.7
            default: v = c == .land ? 0.6 : 0.55
            }
            self.playSfx(b, v)
        }
    }

    /// Chọn tiếng theo tên thao tác trong `Game.commit` ("Đặt ...", "Xóa ...", "Xoay", "Di chuyển"...).
    func cue(forAction name: String) {
        if name.hasPrefix("Đặt") { cue(.place) }
        else if name.hasPrefix("Xóa") { cue(.remove) }
        else if name.hasPrefix("Vẽ") { cue(.select) }
        else { cue(.tick) }
    }

    /// Sấm: tới trễ theo khoảng cách tia sét (130...330 m), xa thì nhỏ hơn.
    func thunder(distance: Float) {
        guard sfxOn, started else { return }
        let d = min(max(distance, 130), 330)
        let delay = Double(d / 220)
        let vol: Float = 1 - (d - 130) / 200 * 0.5
        q.asyncAfter(deadline: .now() + delay) { [weak self] in
            guard let self = self, let b = self.thunders.randomElement() else { return }
            self.playSfx(b, vol, amb: true)
        }
    }

    // MARK: Nhạc nền và chim hót (chuỗi hẹn giờ trên luồng chính)

    private func scheduleMusic(token: Int) {
        let gap = Double.random(in: 0.8...2.0)
        DispatchQueue.main.asyncAfter(deadline: .now() + gap) { [weak self] in
            guard let self = self, self.musicRunning, token == self.musicToken else { return }
            self.playMelodyNote()
            self.scheduleMusic(token: token)
        }
    }

    private func playMelodyNote() {
        guard engine.isRunning, !notes.isEmpty, UIApplication.shared.applicationState == .active else { return }
        if Float.random(in: 0...1) < 0.18 { return }                        // nghỉ một nhịp
        let move = [-2, -1, -1, 0, 1, 1, 2].randomElement() ?? 0
        melodyIdx = min(max(melodyIdx + move, 0), notes.count - 1)
        noteCount += 1
        let d = duck
        playMusic(notes[melodyIdx], Float.random(in: 0.3...0.55) * d)
        if melodyIdx >= 2, Float.random(in: 0...1) < 0.22 { playMusic(notes[melodyIdx - 2], 0.3 * d) }     // thêm nốt hòa
        if noteCount % 7 == 0 { playMusic(notes[0], 0.45 * d) }                                              // nốt trầm điểm nhịp
    }

    private func playMusic(_ buf: AVAudioPCMBuffer, _ volume: Float) {
        guard !musicPlayers.isEmpty else { return }
        crumb("phát nhạc nền")
        let p = musicPlayers[musicNext % musicPlayers.count]; musicNext += 1
        p.volume = min(1, volume * mMul)
        safePlay(p, buf, interrupts: false)    // không ngắt nốt cũ: để nốt ngân hết
    }

    private func scheduleBirds(token: Int) {
        let gap = Double.random(in: 5...14)
        DispatchQueue.main.asyncAfter(deadline: .now() + gap) { [weak self] in
            guard let self = self, self.birdsRunning, token == self.birdToken else { return }
            if UIApplication.shared.applicationState == .active {
                self.q.async { if let b = self.birds.randomElement() { self.playSfx(b, Float.random(in: 0.12...0.3), amb: true) } }
            }
            self.scheduleBirds(token: token)
        }
    }

    // MARK: Dựng tiếng (chạy ở luồng nền lúc khởi động)

    private static func buffer(_ x: [Float], _ format: AVAudioFormat) -> AVAudioPCMBuffer? {
        guard !x.isEmpty, let buf = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(x.count)) else { return nil }
        buf.frameLength = AVAudioFrameCount(x.count)
        guard let ch = buf.floatChannelData else { return nil }
        for c in 0..<Int(format.channelCount) { for i in 0..<x.count { ch[c][i] = x[i] } }
        return buf
    }

    private static func norm(_ x: [Float], _ peak: Float) -> [Float] {
        var m: Float = 0.0001
        for v in x { m = max(m, abs(v)) }
        let k = peak / m
        return x.map { $0 * k }
    }

    /// Sin quét tần số từ f0 tới f1 trong T giây (nghiệm đóng của pha).
    private static func sweep(_ f0: Float, _ f1: Float, _ T: Float, _ t: Float) -> Float {
        let k = log(f1 / f0) / T
        let ph = abs(k) < 0.0001 ? f0 * t : f0 * (exp(k * t) - 1) / k
        return sin(2 * Float.pi * ph)
    }

    private static func stepSamples(kind: Int, seed: UInt32) -> [Float] {
        let sr: Float = 44100
        let dur: Float = kind == 1 ? 0.09 : (kind == 2 ? 0.17 : 0.15)
        let n = Int(dur * sr)
        var r = SoundRNG(seed)
        var a: Float = 0, b: Float = 0
        let k1: Float = kind == 1 ? 0.55 : (kind == 2 ? 0.42 : 0.3)
        let k2: Float = kind == 1 ? 0.06 : 0.02
        let decay: Float = kind == 1 ? 55 : (kind == 2 ? 26 : 32)
        let thump: Float = kind == 1 ? 0.6 : 0.3
        let tf: Float = 80 + 40 * r.f()
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            let t = Float(i) / sr
            let w = r.n()
            a += k1 * (w - a); b += k2 * (a - b)
            let env = min(1, t / 0.004) * exp(-t * decay)
            var x = (a - b) * env * 1.8
            x += sin(2 * Float.pi * tf * t) * exp(-t * 60) * thump
            out[i] = x
        }
        return norm(out, 0.8)
    }

    private static func placeSamples() -> [Float] {
        let sr: Float = 44100, T: Float = 0.18
        let n = Int(T * sr)
        var r = SoundRNG(4242)
        var lp: Float = 0
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            let t = Float(i) / sr
            lp += 0.3 * (r.n() - lp)
            out[i] = sweep(170, 60, T, t) * exp(-t * 22) * 0.9 + lp * exp(-t * 120) * 0.35
        }
        return norm(out, 0.85)
    }

    private static func removeSamples() -> [Float] {
        let sr: Float = 44100, T: Float = 0.3
        let n = Int(T * sr)
        var r = SoundRNG(777)
        var lp: Float = 0
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            let t = Float(i) / sr
            let u = 1 - t / T
            let k = 0.06 + 0.5 * u * u
            lp += k * (r.n() - lp)
            let env = t < 0.02 ? t / 0.02 : exp(-(t - 0.02) * 9)
            out[i] = lp * env * 1.6 + sweep(130, 50, T, t) * exp(-t * 14) * 0.4
        }
        return norm(out, 0.8)
    }

    private static func selectSamples() -> [Float] {
        let sr: Float = 44100
        let n = Int(0.08 * sr)
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            let t = Float(i) / sr
            let env = min(1, t / 0.002) * exp(-t * 45)
            out[i] = (sin(2 * Float.pi * 1046 * t) * 0.6 + sin(2 * Float.pi * 1568 * t) * 0.25) * env
        }
        return norm(out, 0.6)
    }

    private static func tickSamples() -> [Float] {
        let sr: Float = 44100
        let n = Int(0.05 * sr)
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            let t = Float(i) / sr
            out[i] = sin(2 * Float.pi * 760 * t) * min(1, t / 0.002) * exp(-t * 70)
        }
        return norm(out, 0.55)
    }

    private static func undoSamples(rising: Bool) -> [Float] {
        let sr: Float = 44100
        let n = Int(0.16 * sr)
        let f1: Float = rising ? 470 : 620, f2: Float = rising ? 620 : 470
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            let t = Float(i) / sr
            let f = t < 0.075 ? f1 : f2
            let tt = t < 0.075 ? t : t - 0.075
            out[i] = sin(2 * Float.pi * f * tt) * min(1, tt / 0.003) * exp(-tt * 40)
        }
        return norm(out, 0.55)
    }

    private static func jumpSamples() -> [Float] {          // vút lên
        let sr: Float = 44100, T: Float = 0.2
        let n = Int(T * sr)
        var r = SoundRNG(2025)
        var a: Float = 0, b: Float = 0
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            let t = Float(i) / sr
            let k = 0.1 + 0.4 * (t / T)
            a += k * (r.n() - a); b += 0.03 * (a - b)
            out[i] = (a - b) * sin(Float.pi * t / T) * 1.8
        }
        return norm(out, 0.7)
    }

    private static func landSamples() -> [Float] {          // tiếp đất
        let sr: Float = 44100, T: Float = 0.16
        let n = Int(T * sr)
        var r = SoundRNG(909)
        var lp: Float = 0
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            let t = Float(i) / sr
            lp += 0.25 * (r.n() - lp)
            out[i] = sweep(120, 55, T, t) * exp(-t * 26) + lp * exp(-t * 45) * 0.5
        }
        return norm(out, 0.9)
    }

    private static func climbSamples() -> [Float] {         // bám, trèo lên: hai nhịp sột soạt
        let sr: Float = 44100, T: Float = 0.3
        let n = Int(T * sr)
        var r = SoundRNG(311)
        var lp: Float = 0
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            let t = Float(i) / sr
            lp += 0.22 * (r.n() - lp)
            let b1 = exp(-t * 22)
            let t2 = max(0, t - 0.13)
            let b2 = t >= 0.13 ? min(1, t2 / 0.004) * exp(-t2 * 22) : 0
            out[i] = lp * (b1 + b2) * 1.5 + sin(2 * Float.pi * 90 * t2) * b2 * 0.35
        }
        return norm(out, 0.8)
    }

    private static func sitSamples() -> [Float] {           // ngồi xuống: tiếng vải và cú tựa nhẹ
        let sr: Float = 44100, T: Float = 0.24
        let n = Int(T * sr)
        var r = SoundRNG(606)
        var lp: Float = 0
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            let t = Float(i) / sr
            lp += 0.12 * (r.n() - lp)
            out[i] = lp * min(1, t / 0.015) * exp(-t * 17) * 2 + sweep(100, 60, T, t) * exp(-t * 25) * 0.5
        }
        return norm(out, 0.75)
    }

    private static func shutterSamples() -> [Float] {       // tách - tách của máy ảnh
        let sr: Float = 44100, T: Float = 0.2
        let n = Int(T * sr)
        var r = SoundRNG(1999)
        var a: Float = 0, b: Float = 0
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            let t = Float(i) / sr
            a += 0.6 * (r.n() - a); b += 0.08 * (a - b)
            let c1 = exp(-t * 260)
            let t2 = max(0, t - 0.075)
            let c2 = t >= 0.075 ? exp(-t2 * 200) : 0
            out[i] = (a - b) * (c1 + c2 * 0.8) * 1.6 + sin(2 * Float.pi * 150 * t) * exp(-t * 90) * 0.25
        }
        return norm(out, 0.8)
    }

    private static func thunderSamples(seed: UInt32) -> [Float] {
        let sr: Float = 44100, T: Float = 4.6
        let n = Int(T * sr)
        var r = SoundRNG(seed)
        var a: Float = 0, b: Float = 0, c: Float = 0
        let ph1 = r.f() * 6, ph2 = r.f() * 6
        var out = [Float](repeating: 0, count: n)
        for i in 0..<n {
            let t = Float(i) / sr
            let w = r.n()
            a += 0.014 * (w - a); b += 0.014 * (a - b)             // ầm trầm
            c += 0.45 * (w - c)
            let bumps = 0.65 + 0.35 * sin(t * 3.1 + ph1) * sin(t * 1.7 + ph2)
            let env = min(1, t / 0.12) * exp(-t * 0.65) * bumps
            let crack = (w - c) * exp(-t * 28) * 0.6                // tiếng nổ ngắn lúc đầu
            out[i] = b * 22 * env + crack
        }
        return norm(out, 0.9)
    }

    private static func birdSamples(seed: UInt32) -> [Float] {
        let sr: Float = 44100
        var r = SoundRNG(seed)
        var out: [Float] = []
        let chirps = 3 + Int(r.f() * 3)
        let base: Float = 2800 + 1400 * r.f()
        for _ in 0..<chirps {
            let dur: Float = 0.07 + 0.05 * r.f()
            let f0 = base * (0.9 + 0.3 * r.f()), f1 = f0 * (0.8 + 0.55 * r.f())
            let n = Int(dur * sr)
            for i in 0..<n {
                let t = Float(i) / sr
                let ph = sweep(f0, f1, dur, t)
                let env = sin(Float.pi * t / dur)
                out.append(ph * env * env)
            }
            let gap = Int((0.05 + 0.07 * r.f()) * sr)
            out.append(contentsOf: [Float](repeating: 0, count: gap))
        }
        return norm(out, 0.9)
    }

    /// Dây đàn gảy (Karplus-Strong): tiếng ấm, tắt dần tự nhiên; nhân đôi ra 2 kênh cho bộ vang.
    private static func pluckSamples(_ f: Float, _ sec: Float, _ seed: UInt32) -> [Float] {
        let sr: Float = 44100
        let n = Int(sec * sr)
        let len = max(2, Int(sr / f - 0.5))
        var r = SoundRNG(seed)
        var line = [Float](repeating: 0, count: len)
        for i in 0..<len { line[i] = r.n() }
        for i in 1..<len { line[i] = 0.5 * (line[i] + line[i - 1]) }       // làm mượt: ấm hơn
        var out = [Float](repeating: 0, count: n)
        var idx = 0
        for i in 0..<n {
            let nxt = line[(idx + 1) % len]
            out[i] = line[idx]
            line[idx] = 0.5 * (line[idx] + nxt) * 0.9992
            idx = (idx + 1) % len
        }
        let fade = Int(0.5 * sr)
        for i in 0..<min(fade, n) { out[n - 1 - i] *= Float(i) / Float(fade) }   // tắt mượt cuối nốt
        for i in 0..<min(120, n) { out[i] *= Float(i) / 120 }
        return norm(out, 0.8)
    }
}
