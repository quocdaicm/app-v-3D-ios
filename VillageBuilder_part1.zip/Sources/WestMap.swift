import SwiftUI
import WebKit

/// Bản đồ "Khu nhà sân vườn miền Tây": chạy bản 3D WebGL (Three.js) đóng gói trong app (Resources/WestMap), hoàn toàn offline.
/// Trang được phục vụ qua scheme riêng wmap://app/ để tải được file model OBJ/ảnh từ bundle.
final class WestMapHandler: NSObject, WKURLSchemeHandler {
  func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
    guard let url = urlSchemeTask.request.url, let base = Bundle.main.url(forResource: "WestMap", withExtension: nil) else {
      urlSchemeTask.didFailWithError(URLError(.fileDoesNotExist)); return }
    var rel = url.path; while rel.hasPrefix("/") { rel.removeFirst() }
    if rel.isEmpty { rel = "index.html" }
    let f = base.appendingPathComponent(rel)
    guard let data = try? Data(contentsOf: f) else { urlSchemeTask.didFailWithError(URLError(.fileDoesNotExist)); return }
    let mime: String
    switch f.pathExtension.lowercased() {
    case "html": mime = "text/html; charset=utf-8"
    case "js": mime = "application/javascript; charset=utf-8"
    case "css": mime = "text/css; charset=utf-8"
    case "json": mime = "application/json"
    case "jpg", "jpeg": mime = "image/jpeg"
    case "png": mime = "image/png"
    default: mime = "text/plain; charset=utf-8" }
    let resp = HTTPURLResponse(url: url, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: ["Content-Type": mime, "Content-Length": "\(data.count)", "Access-Control-Allow-Origin": "*"])!
    urlSchemeTask.didReceive(resp); urlSchemeTask.didReceive(data); urlSchemeTask.didFinish()
  }
  func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}
}

/// nhận trạng thái các vật đã đặt từ trang web và lưu vào UserDefaults
final class WestMapSaver: NSObject, WKScriptMessageHandler {
  static let key = "westmap.state.v1"
  func userContentController(_ uc: WKUserContentController, didReceive message: WKScriptMessage) {
    if let s = message.body as? String { UserDefaults.standard.set(s, forKey: WestMapSaver.key) }
  }
}

struct WestMapWeb: UIViewRepresentable {
  func makeUIView(context: Context) -> WKWebView {
    let c = WKWebViewConfiguration()
    let uc = WKUserContentController()
    uc.add(WestMapSaver(), name: "save")
    if let st = UserDefaults.standard.string(forKey: WestMapSaver.key), let d = try? JSONSerialization.data(withJSONObject: [st]), let arr = String(data: d, encoding: .utf8) {
      uc.addUserScript(WKUserScript(source: "window.__initState = \(arr)[0];", injectionTime: .atDocumentStart, forMainFrameOnly: true))
    }
    c.userContentController = uc
    c.setURLSchemeHandler(WestMapHandler(), forURLScheme: "wmap")
    let w = WKWebView(frame: .zero, configuration: c)
    w.scrollView.isScrollEnabled = false; w.scrollView.bounces = false
    w.scrollView.contentInsetAdjustmentBehavior = .never
    w.isOpaque = false; w.backgroundColor = .black
    if let u = URL(string: "wmap://app/index.html") { w.load(URLRequest(url: u)) }
    return w
  }
  func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct WestMapScreen: View {
  let close: () -> Void
  var body: some View {
    ZStack(alignment: .topTrailing) {
      Color.black.ignoresSafeArea()
      WestMapWeb().ignoresSafeArea()
      Button(action: close) {
        Image(systemName: "xmark").font(.system(size: 16, weight: .bold)).foregroundColor(.white)
          .frame(width: 40, height: 40).background(.black.opacity(0.55), in: Circle())
      }.padding(.top, 10).padding(.trailing, 12)
    }
    .statusBarHidden(true)
  }
}
