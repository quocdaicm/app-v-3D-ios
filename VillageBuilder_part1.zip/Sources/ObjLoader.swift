import SceneKit
import UIKit
import simd

/// Bộ đọc OBJ + MTL riêng (chuyển từ Builder.swift của CityBuilder-v12-clean).
/// Không qua ModelIO nên giữ đúng màu Kd, texture map_Kd, độ trong suốt; tự tính pháp tuyến khi thiếu.
enum ObjLoader {
    static func rgb(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor {
        UIColor(red: r, green: g, blue: b, alpha: 1)
    }

    private struct MTLInfo {
        var kd: UIColor? = nil
        var image: UIImage? = nil
        var alpha: CGFloat = 1
    }

    /// Tìm file .mtl của một OBJ: theo dòng mtllib, rồi cùng tên, rồi bất kỳ .mtl nào trong thư mục.
    private static func findMTL(for obj: URL) -> URL? {
        let dir = obj.deletingLastPathComponent()
        let fm = FileManager.default
        if let fh = try? FileHandle(forReadingFrom: obj) {
            let head = fh.readData(ofLength: 65536)
            try? fh.close()
            let text = String(decoding: head, as: UTF8.self)
            for line in text.split(whereSeparator: { $0 == "\n" || $0 == "\r" }) {
                let l = line.trimmingCharacters(in: .whitespaces)
                guard l.hasPrefix("mtllib") else { continue }
                let name = l.dropFirst(6).trimmingCharacters(in: .whitespaces)
                if name.isEmpty { continue }
                let u = dir.appendingPathComponent(name)
                if fm.fileExists(atPath: u.path) { return u }
                let u2 = dir.appendingPathComponent((name as NSString).lastPathComponent)
                if fm.fileExists(atPath: u2.path) { return u2 }
            }
        }
        let same = obj.deletingPathExtension().appendingPathExtension("mtl")
        if fm.fileExists(atPath: same.path) { return same }
        if let items = try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil) {
            return items.first { $0.pathExtension.lowercased() == "mtl" }
        }
        return nil
    }

    /// Tìm ảnh texture theo đường dẫn trong .mtl (chịu được thư mục con, đường dẫn tuyệt đối của máy khác, sai hoa/thường).
    private static func findImage(_ ref: String, near dir: URL) -> UIImage? {
        let fm = FileManager.default
        let cleaned = ref.replacingOccurrences(of: "\\", with: "/")
        let direct = dir.appendingPathComponent(cleaned)
        if fm.fileExists(atPath: direct.path), let im = Game.capImage(UIImage(contentsOfFile: direct.path)) { return im }
        let base = (cleaned as NSString).lastPathComponent.lowercased()
        if let en = fm.enumerator(at: dir, includingPropertiesForKeys: nil) {
            for case let u as URL in en where u.lastPathComponent.lowercased() == base {
                if let im = Game.capImage(UIImage(contentsOfFile: u.path)) { return im }
            }
        }
        return nil
    }

    private static func parseMTL(for obj: URL) -> [String: MTLInfo] {
        guard let mtl = findMTL(for: obj),
              let data = try? Data(contentsOf: mtl) else { return [:] }
        let text = String(decoding: data, as: UTF8.self)
        let dir = mtl.deletingLastPathComponent()
        var out: [String: MTLInfo] = [:]
        var cur: String? = nil
        var imageCache: [String: UIImage] = [:]
        for raw in text.split(whereSeparator: { $0 == "\n" || $0 == "\r" }) {
            let line = raw.trimmingCharacters(in: .whitespaces)
            if line.isEmpty || line.hasPrefix("#") { continue }
            let parts = line.split(separator: " ", omittingEmptySubsequences: true).map(String.init)
            guard let key = parts.first?.lowercased() else { continue }
            if key == "newmtl" {
                cur = line.dropFirst(6).trimmingCharacters(in: .whitespaces)
                if let c = cur { out[c] = MTLInfo() }
                continue
            }
            guard let c = cur else { continue }
            switch key {
            case "kd":
                if parts.count >= 4, let r = Double(parts[1]), let g = Double(parts[2]), let b = Double(parts[3]) {
                    out[c]?.kd = UIColor(red: CGFloat(r), green: CGFloat(g), blue: CGFloat(b), alpha: 1)
                }
            case "d":
                if parts.count >= 2, let v = Double(parts[1]) { out[c]?.alpha = CGFloat(v) }
            case "tr":
                if parts.count >= 2, let v = Double(parts[1]) { out[c]?.alpha = CGFloat(1 - v) }
            case "map_kd":
                // bỏ các tuỳ chọn (-s, -o, -bm…): lấy phần đường dẫn sau cùng
                var rest = Array(parts.dropFirst())
                while let f = rest.first, f.hasPrefix("-") {
                    rest.removeFirst()
                    while let n = rest.first, Double(n) != nil { rest.removeFirst() }
                }
                let ref = rest.joined(separator: " ")
                if ref.isEmpty { break }
                if let im = imageCache[ref] ?? findImage(ref, near: dir) {
                    imageCache[ref] = im
                    out[c]?.image = im
                }
            default: break
            }
        }
        return out
    }


    private struct OBJKey: Hashable {
        var v: Int32
        var t: Int32
        var n: Int32
        var f: Int32      // khác 0 khi mặt không có pháp tuyến: mỗi mặt một đỉnh riêng → bóng phẳng
    }

    private static func objMaterial(named name: String, info: MTLInfo?) -> SCNMaterial {
        let m = SCNMaterial()
        m.name = name
        m.lightingModel = .blinn
        if let im = info?.image {
            m.diffuse.contents = im
            m.diffuse.wrapS = .repeat
            m.diffuse.wrapT = .repeat
        } else {
            m.diffuse.contents = info?.kd ?? rgb(0.78, 0.76, 0.72)
        }
        m.specular.contents = UIColor(white: 0.12, alpha: 1)
        m.shininess = 0.1
        m.isDoubleSided = true
        if let a = info?.alpha, a < 0.99, a > 0.01 {
            m.transparency = a
            m.writesToDepthBuffer = false
        }
        return m
    }

    /// Đọc file .obj + .mtl thành SCNScene: mỗi vật liệu một phần lưới, tự tính pháp tuyến nếu thiếu.
    static func loadOBJScene(at url: URL) -> SCNScene? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        var bytes = [UInt8](data)
        bytes.append(0)
        let infos = parseMTL(for: url)

        var pos: [SIMD3<Float>] = []
        var uvs: [SIMD2<Float>] = []
        var nrm: [SIMD3<Float>] = []
        var outP: [SCNVector3] = []
        var outN: [SCNVector3] = []
        var outT: [CGPoint] = []
        var dedupe: [OBJKey: UInt32] = [:]
        var matNames: [String] = [""]
        var matIndex: [String: Int] = ["": 0]
        var tris: [[UInt32]] = [[]]
        var cur = 0
        var faceId: Int32 = 0
        var face: [(Int, Int, Int)] = []
        var ids: [UInt32] = []

        func resolve(_ x: Int, _ count: Int) -> Int {
            if x > 0 { return x - 1 }
            if x < 0 { return count + x }
            return -1
        }

        bytes.withUnsafeBufferPointer { (buf: UnsafeBufferPointer<UInt8>) -> Void in
            guard let raw = buf.baseAddress else { return }
            let cbase = UnsafeRawPointer(raw).assumingMemoryBound(to: CChar.self)
            let n = buf.count - 1
            var i = 0
            var endp: UnsafeMutablePointer<CChar>? = nil

            func readFloat() -> Float {
                let v = strtof(cbase + i, &endp)
                if let e = endp { i = UnsafePointer<CChar>(e) - cbase }
                return v
            }
            func readInt() -> Int {
                let v = strtol(cbase + i, &endp, 10)
                if let e = endp { i = UnsafePointer<CChar>(e) - cbase }
                return Int(v)
            }

            while i < n {
                while i < n && (raw[i] == 32 || raw[i] == 9 || raw[i] == 13 || raw[i] == 10) { i += 1 }
                if i >= n { break }
                let c0 = raw[i]
                let c1: UInt8 = (i + 1 < n) ? raw[i + 1] : 0

                if c0 == 118 && (c1 == 32 || c1 == 9) {                 // v
                    i += 1
                    let x = readFloat()
                    let y = readFloat()
                    let z = readFloat()
                    pos.append(SIMD3<Float>(x, y, z))
                } else if c0 == 118 && c1 == 116 {                      // vt
                    i += 2
                    let u = readFloat()
                    let v = readFloat()
                    uvs.append(SIMD2<Float>(u, v))
                } else if c0 == 118 && c1 == 110 {                      // vn
                    i += 2
                    let x = readFloat()
                    let y = readFloat()
                    let z = readFloat()
                    nrm.append(SIMD3<Float>(x, y, z))
                } else if c0 == 102 && (c1 == 32 || c1 == 9) {          // f
                    i += 1
                    face.removeAll(keepingCapacity: true)
                    while i < n {
                        while i < n && (raw[i] == 32 || raw[i] == 9 || raw[i] == 13) { i += 1 }
                        if i >= n || raw[i] == 10 { break }
                        let start = i
                        let vi = readInt()
                        if i == start { break }
                        var ti = 0
                        var ni = 0
                        if i < n && raw[i] == 47 {
                            i += 1
                            if i < n && raw[i] != 47 { ti = readInt() }
                            if i < n && raw[i] == 47 {
                                i += 1
                                ni = readInt()
                            }
                        }
                        face.append((vi, ti, ni))
                    }
                    if face.count >= 3 {
                        var p: [Int] = []
                        var t: [Int] = []
                        var nn: [Int] = []
                        var ok = true
                        for f in face {
                            let a = resolve(f.0, pos.count)
                            let b = resolve(f.1, uvs.count)
                            let d = resolve(f.2, nrm.count)
                            if a < 0 || a >= pos.count { ok = false; break }
                            p.append(a)
                            t.append((b >= 0 && b < uvs.count) ? b : -1)
                            nn.append((d >= 0 && d < nrm.count) ? d : -1)
                        }
                        if ok {
                            faceId &+= 1
                            var fn = SIMD3<Float>(0, 1, 0)
                            if nn.contains(-1) {
                                let e1 = pos[p[1]] - pos[p[0]]
                                let e2 = pos[p[2]] - pos[p[0]]
                                let cr = simd_cross(e1, e2)
                                let len = simd_length(cr)
                                if len > 1e-12 { fn = cr / len }
                            }
                            ids.removeAll(keepingCapacity: true)
                            for k in 0..<p.count {
                                let key = OBJKey(v: Int32(p[k]), t: Int32(t[k]), n: Int32(nn[k]),
                                                 f: nn[k] < 0 ? faceId : 0)
                                if let id = dedupe[key] {
                                    ids.append(id)
                                } else {
                                    let id = UInt32(outP.count)
                                    let q = pos[p[k]]
                                    outP.append(SCNVector3(q.x, q.y, q.z))
                                    let nv = nn[k] >= 0 ? nrm[nn[k]] : fn
                                    outN.append(SCNVector3(nv.x, nv.y, nv.z))
                                    if t[k] >= 0 {
                                        let u = uvs[t[k]]
                                        outT.append(CGPoint(x: CGFloat(u.x), y: CGFloat(1 - u.y)))
                                    } else {
                                        outT.append(CGPoint.zero)
                                    }
                                    dedupe[key] = id
                                    ids.append(id)
                                }
                            }
                            if ids.count >= 3 {
                                for k in 1..<(ids.count - 1) {
                                    tris[cur].append(ids[0])
                                    tris[cur].append(ids[k])
                                    tris[cur].append(ids[k + 1])
                                }
                            }
                        }
                    }
                } else if c0 == 117 && i + 6 < n && raw[i + 1] == 115 && raw[i + 2] == 101
                            && raw[i + 3] == 109 && raw[i + 4] == 116 && raw[i + 5] == 108 {   // usemtl
                    i += 6
                    while i < n && (raw[i] == 32 || raw[i] == 9) { i += 1 }
                    let start = i
                    while i < n && raw[i] != 10 { i += 1 }
                    let name = String(decoding: UnsafeBufferPointer(start: raw + start, count: i - start),
                                      as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
                    if let idx = matIndex[name] {
                        cur = idx
                    } else {
                        matNames.append(name)
                        tris.append([])
                        cur = matNames.count - 1
                        matIndex[name] = cur
                    }
                }
                while i < n && raw[i] != 10 { i += 1 }      // bỏ phần còn lại của dòng
            }
        }

        guard !outP.isEmpty else { return nil }
        var elements: [SCNGeometryElement] = []
        var mats: [SCNMaterial] = []
        for (mi, idx) in tris.enumerated() where !idx.isEmpty {
            elements.append(SCNGeometryElement(indices: idx, primitiveType: .triangles))
            mats.append(objMaterial(named: matNames[mi], info: infos[matNames[mi]]))
        }
        guard !elements.isEmpty else { return nil }
        let geo = SCNGeometry(sources: [SCNGeometrySource(vertices: outP),
                                        SCNGeometrySource(normals: outN),
                                        SCNGeometrySource(textureCoordinates: outT)],
                              elements: elements)
        geo.materials = mats
        let scene = SCNScene()
        scene.rootNode.addChildNode(SCNNode(geometry: geo))
        return scene
    }
}
