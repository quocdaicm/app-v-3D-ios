import SceneKit
import UIKit
import simd

// =====================================================================
//  Cây đào hoa hồng (theo ảnh Võ Lâm: thân sẫm xoắn, tán hoa hồng thành từng cụm, cánh hoa rơi dưới gốc)
//  Thân + cành: ống nội suy bLoft (Beasts.swift). Tán: các cụm elip hồng phủ hàng trăm bông 5 cánh
//  (cánh có khía đầu, nhị vàng) gộp thành MỘT lưới nên rất nhẹ. Tất cả tĩnh (không đung đưa).
//  CHƯA BIÊN DỊCH khi viết: nếu GitHub Actions báo lỗi thì sửa theo log.
// =====================================================================

extension Game {
  static var blossomImgs: [String: UIImage] = [:]
  static let blossomIds = ["Đào hoa", "Đào hoa nhỏ", "Bụi hoa đào"]

  func blossomModel(_ id: String) -> SCNNode? {
    switch id {
    case "Đào hoa": return blossomTree(size: 1.0, blobs: 14, seed: 11, pal: 0)
    case "Đào hoa nhỏ": return blossomTree(size: 0.62, blobs: 9, seed: 23, pal: 1)
    case "Bụi hoa đào": return blossomBush(seed: 5)
    default: return nil
    }
  }

  // ---------------------------------------------------------------- texture
  func blossomImg(_ kind: String, _ pal: Int) -> UIImage {
    let k = "\(kind):\(pal)"
    if let i = Game.blossomImgs[k] { return i }
    var r = RNG(s: UInt64(31 + pal * 7 + kind.count))
    func R(_ a: CGFloat, _ b: CGFloat) -> CGFloat { return CGFloat(r.f(Float(a), Float(b))) }
    func C(_ a: CGFloat, _ b: CGFloat, _ c: CGFloat, _ al: CGFloat = 1) -> UIColor { return UIColor(red: a, green: b, blue: c, alpha: al) }
    let img: UIImage
    switch kind {
    case "bark":
      img = UIGraphicsImageRenderer(size: CGSize(width: 128, height: 128), format: Game.fmtTex).image { c in
        let g = c.cgContext
        C(0.2, 0.14, 0.1).setFill(); g.fill(CGRect(x: 0, y: 0, width: 128, height: 128))
        for i in 0..<220 {
          let x = R(0, 128), y = R(0, 128), ln = R(14, 46)
          g.setStrokeColor((i % 3 == 0 ? C(0.36, 0.27, 0.2, 0.35) : C(0.07, 0.05, 0.04, 0.4)).cgColor); g.setLineWidth(R(1, 2.4))
          g.move(to: CGPoint(x: x, y: y)); g.addQuadCurve(to: CGPoint(x: x + R(-3, 3), y: y + ln), control: CGPoint(x: x + R(-4, 4), y: y + ln * 0.5)); g.strokePath()
        }
        for _ in 0..<26 {   // mảng rêu / địa y xám xanh
          let x = R(0, 128), y = R(0, 128), rd = R(2, 6)
          g.setFillColor(C(0.5, 0.56, 0.46, 0.35).cgColor); g.fillEllipse(in: CGRect(x: x - rd, y: y - rd, width: rd * 2, height: rd * 1.4))
        }
      }
    case "blob":
      img = UIGraphicsImageRenderer(size: CGSize(width: 128, height: 128), format: Game.fmtTex).image { c in
        let g = c.cgContext
        (pal == 0 ? C(0.8, 0.4, 0.55) : C(0.93, 0.78, 0.83)).setFill(); g.fill(CGRect(x: 0, y: 0, width: 128, height: 128))
        for i in 0..<600 {
          let x = R(0, 128), y = R(0, 128), rd = R(1.5, 5)
          let col: UIColor = i % 3 == 0 ? (pal == 0 ? C(0.55, 0.2, 0.34, 0.5) : C(0.75, 0.5, 0.58, 0.5)) : (pal == 0 ? C(0.98, 0.78, 0.86, 0.5) : C(1, 0.96, 0.97, 0.5))
          g.setFillColor(col.cgColor); g.fillEllipse(in: CGRect(x: x - rd, y: y - rd, width: rd * 2, height: rd * 2))
        }
      }
    default:   // cánh hoa: ba dải màu (nhạt, hồng, hồng đậm); dọc cánh đối xứng (mép đậm, giữa nhạt) nên không phụ thuộc chiều v
      img = UIGraphicsImageRenderer(size: CGSize(width: 96, height: 64), format: Game.fmtTex).image { c in
        let g = c.cgContext
        let bands: [UIColor] = pal == 0 ? [C(0.99, 0.88, 0.92), C(0.96, 0.62, 0.76), C(0.86, 0.34, 0.5)] : [C(1, 0.96, 0.97), C(0.98, 0.84, 0.9), C(0.94, 0.66, 0.78)]
        for i in 0..<3 {
          var red: CGFloat = 0, grn: CGFloat = 0, blu: CGFloat = 0, al: CGFloat = 0
          bands[i].getRed(&red, green: &grn, blue: &blu, alpha: &al)
          let deep = C(red * 0.82, grn * 0.7, blu * 0.78)
          let cols = [deep.cgColor, bands[i].cgColor, deep.cgColor] as CFArray
          if let gr = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: cols, locations: [0, 0.5, 1]) {
            g.saveGState(); g.clip(to: CGRect(x: CGFloat(i) * 32, y: 0, width: 32, height: 64))
            g.drawLinearGradient(gr, start: CGPoint(x: 0, y: 0), end: CGPoint(x: 0, y: 64), options: [])
            g.restoreGState()
          }
        }
      }
    }
    Game.blossomImgs[k] = img; return img
  }
  func blossomMat(_ kind: String, _ pal: Int, sx: Float = 1, sy: Float = 1) -> SCNMaterial {
    let key = "BL:\(kind):\(pal):\(sx):\(sy)"
    if let m = leafMats[key] { return m }
    let m = mat(blossomImg(kind, pal), sx, sy); m.isDoubleSided = true; m.name = key
    if kind == "petal" { m.specular.contents = UIColor(white: 0.2, alpha: 1); m.shininess = 0.2 }
    leafMats[key] = m; return m
  }

  // ---------------------------------------------------------------- bông hoa
  func addPetal(_ b: inout BMesh, _ c: V3, _ d: V3, _ n: V3, _ L: Float, _ W: Float, _ cup: Float, _ band: Float) {
    let s = simd_cross(n, d)
    let v0 = b.vert(c, n, SIMD2<Float>(band, 0))
    let v1 = b.vert(c + d * (L * 0.5) - s * (W * 0.5) + n * (cup * 0.4), n, SIMD2<Float>(band, 0.5))
    let v2 = b.vert(c + d * (L * 0.5) + s * (W * 0.5) + n * (cup * 0.4), n, SIMD2<Float>(band, 0.5))
    let v3 = b.vert(c + d * (L * 0.96) - s * (W * 0.26) + n * cup, n, SIMD2<Float>(band, 1))
    let v4 = b.vert(c + d * (L * 0.96) + s * (W * 0.26) + n * cup, n, SIMD2<Float>(band, 1))
    let v5 = b.vert(c + d * (L * 0.88) + n * (cup * 0.8), n, SIMD2<Float>(band, 0.9))   // khía đầu cánh
    b.tri(v0, v1, v2); b.tri(v1, v5, v2); b.tri(v1, v3, v5); b.tri(v2, v5, v4)
  }
  func addFlower(_ pm: inout BMesh, _ sm: inout BMesh, _ c: V3, _ n: V3, _ size: Float, _ rot: Float, _ band: Float) {
    let up: V3 = abs(n.y) > 0.9 ? V3(1, 0, 0) : V3(0, 1, 0)
    let t1 = simd_normalize(simd_cross(n, up)), t2 = simd_cross(n, t1)
    for k in 0..<5 {
      let a = rot + Float(k) * 2 * Float.pi / 5
      let d = t1 * cos(a) + t2 * sin(a)
      addPetal(&pm, c, d, n, size, size * 0.8, size * 0.28, band)
    }
    // nhị vàng: quạt sáu tam giác
    let cc = c + n * (size * 0.07)
    let sv = sm.vert(cc + n * (size * 0.04), n, SIMD2<Float>(0.5, 0.5))
    var ring = [Int32]()
    for k in 0..<6 {
      let a = Float(k) * Float.pi / 3
      ring.append(sm.vert(cc + (t1 * cos(a) + t2 * sin(a)) * (size * 0.17), n, SIMD2<Float>(0.5, 0.5)))
    }
    for k in 0..<6 { sm.tri(sv, ring[k], ring[(k + 1) % 6]) }
  }

  /// một cụm tán: elip hồng + hoa phủ mặt trên và hai bên
  func addBlob(_ pm: inout BMesh, _ sm: inout BMesh, _ root: SCNNode, _ c: V3, _ rx: Float, _ ry: Float, _ rz: Float, _ count: Int, _ size: Float, _ pal: Int, _ r: inout RNG) {
    let yaw = r.f(0, 6.28)
    let sph = SCNSphere(radius: 1); sph.segmentCount = 14; sph.firstMaterial = blossomMat("blob", pal, sx: 2, sy: 2)
    let bn = SCNNode(geometry: sph); bn.position = SCNVector3(c.x, c.y, c.z); bn.scale = SCNVector3(rx, ry, rz); bn.eulerAngles.y = yaw
    root.addChildNode(bn)
    let cs = cos(yaw), sn = sin(yaw)
    func rot(_ v: V3) -> V3 { return V3(v.x * cs + v.z * sn, v.y, -v.x * sn + v.z * cs) }
    let bands: [Float] = [0.17, 0.5, 0.83]
    for _ in 0..<count {
      let th = r.f(0.1, 2.5), ph = r.f(0, 6.2832)
      let lx = sin(th) * cos(ph), ly = cos(th), lz = sin(th) * sin(ph)
      let k = r.f(0.98, 1.07)
      let p = V3(lx * rx * k, ly * ry * k, lz * rz * k)
      let nl = V3(lx / rx, ly / ry, lz / rz)
      let wp = c + rot(p), wn = simd_normalize(rot(nl))
      let sz = size * r.f(0.8, 1.25)
      let band = bands[Int(r.f(0, 2.999))]
      addFlower(&pm, &sm, wp, wn, sz, r.f(0, 6.28), band)
    }
  }
  func addFallen(_ pm: inout BMesh, _ n: Int, _ spread: Float, _ r: inout RNG) {
    let bands: [Float] = [0.17, 0.5, 0.83]
    for _ in 0..<n {
      let a = r.f(0, 6.28), rho = spread * sqrt(r.f(0.02, 1))
      let c = V3(cos(a) * rho, 0.012, sin(a) * rho)
      let da = r.f(0, 6.28)
      addPetal(&pm, c, V3(cos(da), 0, sin(da)), V3(0, 1, 0), 0.06, 0.05, 0.008, bands[Int(r.f(0, 2.999))])
    }
  }

  // ---------------------------------------------------------------- cây đào
  func blossomTree(size big: Float, blobs nb: Int, seed: UInt64, pal: Int) -> SCNNode {
    var r = RNG(s: seed)
    let root = SCNNode()
    let H = 4.8 * big
    let lean = r.f(-0.3, 0.3) * big
    let barkM = blossomMat("bark", 0, sx: 1.5, sy: 3)
    let R0 = 0.24 * big
    // thân xoắn nhẹ, chân loe
    let tp: [V3] = [V3(0, -0.05, 0), V3(lean * 0.2, 0.12 * H, 0.03), V3(lean * 0.7, 0.26 * H, -0.04), V3(lean, 0.4 * H, 0.02)]
    let tr: [Float] = [R0 * 1.6, R0 * 1.15, R0 * 0.9, R0 * 0.72]
    let tg = bLoft(tp, tr, tr, samples: 6, seg: 14, u0: 0, u1: 1); tg.firstMaterial = barkM
    root.addChildNode(SCNNode(geometry: tg))
    for k in 0..<5 {   // rễ nổi
      let a = Float(k) * 1.2566 + r.f(-0.2, 0.2)
      let rp: [V3] = [V3(cos(a) * R0 * 0.7, 0.2 * big, sin(a) * R0 * 0.7), V3(cos(a) * (R0 + 0.35 * big), 0.05, sin(a) * (R0 + 0.35 * big)), V3(cos(a) * (R0 + 0.8 * big), -0.02, sin(a) * (R0 + 0.8 * big))]
      root.addChildNode(bTubeNode(rp, [0.11 * big, 0.075 * big, 0.03 * big], barkM, seg: 8))
    }
    let top = tp[3]
    let canopyR = 1.9 * big
    var petals = BMesh(), stamens = BMesh()
    for i in 0..<nb {
      let f = Float(i) / Float(max(nb - 1, 1))
      let ang = Float(i) * 2.39996
      let rho = (0.15 + 0.85 * sqrt(f)) * canopyR
      let cx = top.x + cos(ang) * rho, cz = top.z + sin(ang) * rho
      let cyh = (0.6 + 0.28 * (1 - f)) * H + r.f(-0.2, 0.2) * big
      let rx = r.f(0.75, 1.1) * big, ry = r.f(0.55, 0.8) * big, rz = r.f(0.75, 1.1) * big
      let sy0 = r.f(0.28, 0.42) * H
      let st = V3(lean * (sy0 / (0.4 * H)) * 0.9, sy0, 0.02)
      let en = V3(cx, cyh - ry * 0.55, cz)
      var mid = (st + en) * 0.5
      mid.y += 0.15 * big; mid.x += r.f(-0.15, 0.15) * big; mid.z += r.f(-0.15, 0.15) * big
      let bg = bLoft([st, mid, en], [0.1 * big, 0.062 * big, 0.03 * big], [0.1 * big, 0.062 * big, 0.03 * big], samples: 5, seg: 8, u0: 0, u1: 1)
      bg.firstMaterial = barkM
      root.addChildNode(SCNNode(geometry: bg))
      let cnt = Int(70 * big * big) + 14
      addBlob(&petals, &stamens, root, V3(cx, cyh, cz), rx, ry, rz, cnt, 0.085, pal, &r)
    }
    addFallen(&petals, Int(90 * big), 2.6 * big, &r)
    let pg = bMeshGeo(petals); pg.firstMaterial = blossomMat("petal", pal)
    root.addChildNode(SCNNode(geometry: pg))
    let sg = bMeshGeo(stamens); sg.firstMaterial = bcol("stamen", 0.95, 0.75, 0.2)
    root.addChildNode(SCNNode(geometry: sg))
    return root
  }

  // ---------------------------------------------------------------- bụi hoa đào (như cụm hồng ở góc ảnh)
  func blossomBush(seed: UInt64) -> SCNNode {
    var r = RNG(s: seed)
    let root = SCNNode()
    let barkM = blossomMat("bark", 0, sx: 1.5, sy: 3)
    var petals = BMesh(), stamens = BMesh()
    for i in 0..<5 {
      let a = Float(i) * 1.2566 + r.f(-0.3, 0.3)
      let rho = r.f(0.15, 0.55)
      let cx = cos(a) * rho, cz = sin(a) * rho
      let hh = r.f(0.8, 1.25)
      let sp: [V3] = [V3(cx * 0.3, -0.02, cz * 0.3), V3(cx * 0.7, hh * 0.5, cz * 0.7), V3(cx, hh * 0.85, cz)]
      let sg = bLoft(sp, [0.05, 0.035, 0.022], [0.05, 0.035, 0.022], samples: 4, seg: 8, u0: 0, u1: 1); sg.firstMaterial = barkM
      root.addChildNode(SCNNode(geometry: sg))
      let rx = r.f(0.4, 0.6), ry = r.f(0.3, 0.45), rz = r.f(0.4, 0.6)
      addBlob(&petals, &stamens, root, V3(cx, hh, cz), rx, ry, rz, 34, 0.08, 0, &r)
    }
    addFallen(&petals, 40, 1.2, &r)
    let pg = bMeshGeo(petals); pg.firstMaterial = blossomMat("petal", 0)
    root.addChildNode(SCNNode(geometry: pg))
    let sg = bMeshGeo(stamens); sg.firstMaterial = bcol("stamen", 0.95, 0.75, 0.2)
    root.addChildNode(SCNNode(geometry: sg))
    return root
  }
}
