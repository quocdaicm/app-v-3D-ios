import SwiftUI

/// Điều khiển kiểu game di động trong chế độ đi dạo (chuyển từ CityBuilder):
/// chạm bất kỳ đâu ở NỬA TRÁI màn hình thì cần đi hiện ra đúng chỗ ngón tay (kéo để đi, thả để dừng);
/// kéo ở NỬA PHẢI để nhìn quanh (kéo xuống = nhìn từ cao); chụm / mở 2 ngón để thu / phóng camera (khi chụm, cần đi và nhìn tạm dừng).
struct WalkPad: View {
    @ObservedObject var g: Game

    @State private var joyOrigin: CGPoint? = nil
    @State private var knob: CGSize = .zero
    @State private var lookPrev: CGSize = .zero
    @State private var lookActive = false
    @State private var pinching = false
    @State private var lastScale: CGFloat = 1
    private let radius: CGFloat = 62

    var body: some View {
        GeometryReader { geo in
            HStack(spacing: 0) {
                ZStack(alignment: .topLeading) {
                    Color.clear
                    if joyOrigin == nil {
                        ring.opacity(0.45).position(x: 92, y: geo.size.height - 190).allowsHitTesting(false)
                    }
                    if let o = joyOrigin {
                        ZStack {
                            ring
                            Circle()
                                .fill(LinearGradient(colors: [Color.green, Color(red: 0.2, green: 0.55, blue: 0.35)], startPoint: .top, endPoint: .bottom))
                                .frame(width: 56, height: 56)
                                .shadow(color: .black.opacity(0.35), radius: 6, y: 3)
                                .offset(knob)
                        }
                        .position(x: o.x, y: o.y)
                        .allowsHitTesting(false)
                    }
                }
                .frame(width: geo.size.width / 2, height: geo.size.height)
                .contentShape(Rectangle())
                .gesture(joyGesture)

                Color.clear
                    .frame(width: geo.size.width / 2, height: geo.size.height)
                    .contentShape(Rectangle())
                    .gesture(lookGesture)
            }
            .simultaneousGesture(
                MagnificationGesture()
                    .onChanged { s in
                        if !pinching { pinching = true; joyOrigin = nil; knob = .zero; g.move = .zero }
                        let k = s / lastScale; lastScale = s
                        if k > 0 { g.walkZoom(Float(1 / k)) }      // mở 2 ngón = lại gần, chụm = ra xa
                    }
                    .onEnded { _ in pinching = false; lastScale = 1 }
            )
        }
    }

    private var ring: some View {
        Circle()
            .fill(Color.white.opacity(0.10))
            .overlay(Circle().stroke(Color.white.opacity(0.40), lineWidth: 1.5))
            .frame(width: radius * 2, height: radius * 2)
    }

    private var joyGesture: some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { v in
                if pinching { g.move = .zero; return }
                if joyOrigin == nil { joyOrigin = v.startLocation }
                let o = joyOrigin ?? v.startLocation
                let dx = v.location.x - o.x
                let dy = v.location.y - o.y
                let len = sqrt(dx * dx + dy * dy)
                let k: CGFloat = len > radius ? radius / len : 1
                knob = CGSize(width: dx * k, height: dy * k)
                g.move = CGVector(dx: dx * k / radius, dy: -dy * k / radius)
            }
            .onEnded { _ in
                joyOrigin = nil
                knob = .zero
                g.move = .zero
            }
    }

    private var lookGesture: some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { v in
                if pinching { lookPrev = v.translation; return }
                if !lookActive { lookActive = true; lookPrev = .zero }
                let t = v.translation
                let dx = t.width - lookPrev.width
                let dy = t.height - lookPrev.height
                lookPrev = t
                g.look(Float(dx), Float(dy))
            }
            .onEnded { _ in lookActive = false; lookPrev = .zero }
    }
}
